package com.example.data.repository

import android.content.Context
import com.example.data.local.SessionManager
import com.example.data.model.GameRoom
import com.example.data.model.Player
import com.example.data.remote.FirebaseGameService
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.Flow

class GameRepository(context: Context) {
    private val sessionManager = SessionManager(context)
    private val firebaseGameService = FirebaseGameService()

    /**
     * Local player session functions
     */
    fun savePlayer(name: String): Player {
        val player = sessionManager.savePlayer(name)
        firebaseGameService.savePlayerProfile(player)
        return player
    }

    fun getPlayer(): Player? {
        return sessionManager.getPlayer()
    }

    fun isLoggedIn(): Boolean {
        return sessionManager.isLoggedIn()
    }

    fun logout() {
        sessionManager.clearSession()
    }

    /**
     * Matchmaking functions
     */
    fun startMatchmaking(
        player: Player,
        onMatched: (roomId: String) -> Unit,
        onSearching: () -> Unit,
        onError: (String) -> Unit
    ): ValueEventListener {
        return firebaseGameService.startMatchmaking(player, onMatched, onSearching, onError)
    }

    fun cancelMatchmaking(playerId: String, listener: ValueEventListener?) {
        firebaseGameService.cancelMatchmaking(playerId, listener)
    }

    /**
     * Private room functions
     */
    fun createPrivateRoom(
        player: Player,
        onRoomCreated: (roomId: String) -> Unit,
        onError: (String) -> Unit
    ) {
        firebaseGameService.createPrivateRoom(player, onRoomCreated, onError)
    }

    fun joinPrivateRoom(
        roomId: String,
        player: Player,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        firebaseGameService.joinPrivateRoom(roomId, player, onSuccess, onError)
    }

    /**
     * Game play functions
     */
    fun observeRoom(roomId: String): Flow<GameRoom?> {
        return firebaseGameService.observeRoom(roomId)
    }

    fun registerDisconnectHandler(roomId: String) {
        firebaseGameService.registerDisconnectHandler(roomId)
    }

    fun makeMove(roomId: String, index: Int, symbol: String, nextTurnId: String, currentRoom: GameRoom) {
        firebaseGameService.makeMove(roomId, index, symbol, nextTurnId, currentRoom)
    }

    fun requestRematch(roomId: String, isPlayerX: Boolean, currentRoom: GameRoom) {
        firebaseGameService.requestRematch(roomId, isPlayerX, currentRoom)
    }

    fun leaveRoom(roomId: String, playerId: String, isPlayerX: Boolean, currentRoom: GameRoom) {
        firebaseGameService.leaveRoom(roomId, playerId, isPlayerX, currentRoom)
    }
}
