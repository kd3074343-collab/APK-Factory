package com.example.data.model

/**
 * Represents a Tic-Tac-Toe game room.
 * Must have default parameter values to generate a no-argument constructor for Firebase deserialization.
 */
data class GameRoom(
    val roomId: String = "",
    val playerX: Player? = null,
    val playerO: Player? = null,
    val board: List<String> = List(9) { "" },
    val turn: String = "", // Player ID of current turn
    val status: String = "WAITING", // "WAITING", "PLAYING", "FINISHED", "DISCONNECTED"
    val winnerId: String = "", // Player ID or "DRAW"
    val rematchX: Boolean = false,
    val rematchO: Boolean = false,
    val lastActionTime: Long = 0L,
    val lastActionBy: String = ""
) {
    // Check if the room is full
    fun isFull(): Boolean = playerX != null && playerO != null

    // Get the symbol ('X' or 'O') of a player by their ID
    fun getSymbolOfPlayer(playerId: String): String {
        return when (playerId) {
            playerX?.id -> "X"
            playerO?.id -> "O"
            else -> ""
        }
    }
}
