package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.Player
import java.util.UUID

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "tic_tac_toe_prefs"
        private const val KEY_PLAYER_ID = "player_id"
        private const val KEY_PLAYER_NAME = "player_name"
    }

    /**
     * Saves the player's name and generates a unique UUID if not already present.
     */
    fun savePlayer(name: String): Player {
        var id = prefs.getString(KEY_PLAYER_ID, null)
        if (id.isNullOrEmpty()) {
            id = UUID.randomUUID().toString()
            prefs.edit().putString(KEY_PLAYER_ID, id).apply()
        }
        prefs.edit().putString(KEY_PLAYER_NAME, name).apply()
        return Player(id, name)
    }

    /**
     * Retrieves the stored Player, or null if no player is logged in.
     */
    fun getPlayer(): Player? {
        val id = prefs.getString(KEY_PLAYER_ID, null)
        val name = prefs.getString(KEY_PLAYER_NAME, null)
        return if (!id.isNullOrEmpty() && !name.isNullOrEmpty()) {
            Player(id, name)
        } else {
            null
        }
    }

    /**
     * Checks if a player is currently logged in.
     */
    fun isLoggedIn(): Boolean {
        return getPlayer() != null
    }

    /**
     * Clears the player session on logout.
     */
    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
