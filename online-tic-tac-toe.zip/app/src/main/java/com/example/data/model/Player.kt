package com.example.data.model

/**
 * Represents a player in the game.
 * Must have default parameter values to generate a no-argument constructor for Firebase deserialization.
 */
data class Player(
    val id: String = "",
    val name: String = ""
)
