package com.example.data.remote

import android.util.Log
import com.example.data.model.GameRoom
import com.example.data.model.Player
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.UUID

class FirebaseGameService {
    private val db: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val roomsRef: DatabaseReference = db.getReference("rooms")
    private val queueRef: DatabaseReference = db.getReference("queue")
    private val playersRef: DatabaseReference = db.getReference("players")

    companion object {
        private const val TAG = "FirebaseGameService"
    }

    /**
     * Stores player profile in Firebase.
     */
    fun savePlayerProfile(player: Player) {
        playersRef.child(player.id).setValue(player)
            .addOnFailureListener { Log.e(TAG, "Failed to save player profile", it) }
    }

    /**
     * Starts matchmaking for a player.
     * Uses a queue structure with an elegant matching mechanism.
     */
    fun startMatchmaking(
        player: Player,
        onMatched: (roomId: String) -> Unit,
        onSearching: () -> Unit,
        onError: (String) -> Unit
    ): ValueEventListener {
        onSearching()

        // Write player to the queue with empty matchedRoomId
        val myQueueItem = mapOf(
            "id" to player.id,
            "name" to player.name,
            "matchedRoomId" to ""
        )
        queueRef.child(player.id).setValue(myQueueItem)

        // Set up presence: remove from queue if disconnected
        queueRef.child(player.id).onDisconnect().removeValue()

        // Listen for matches or find an available opponent
        val matchmakingListener = object : ValueEventListener {
            private var hasMatched = false

            override fun onDataChange(snapshot: DataSnapshot) {
                if (hasMatched) return

                // Check if someone matched us and wrote a room ID to our queue node
                val myNode = snapshot.child(player.id)
                val matchedRoomId = myNode.child("matchedRoomId").getValue(String::class.java)
                if (!matchedRoomId.isNullOrEmpty()) {
                    hasMatched = true
                    // Remove from queue and notify
                    queueRef.child(player.id).removeValue()
                    onMatched(matchedRoomId)
                    return
                }

                // If not matched yet, scan the queue for an available opponent who is waiting
                for (child in snapshot.children) {
                    val opponentId = child.key ?: continue
                    if (opponentId == player.id) continue

                    val opponentName = child.child("name").getValue(String::class.java) ?: "Opponent"
                    val opponentMatchedRoomId = child.child("matchedRoomId").getValue(String::class.java) ?: ""

                    // Opponent must not be matched yet
                    if (opponentMatchedRoomId.isEmpty()) {
                        hasMatched = true

                        // Found a match! Create a unique room ID
                        val roomId = "match_${UUID.randomUUID()}"
                        val opponent = Player(opponentId, opponentName)

                        val newRoom = GameRoom(
                            roomId = roomId,
                            playerX = opponent, // Opponent gets X (first turn)
                            playerO = player,   // We get O (second turn)
                            board = List(9) { "" },
                            turn = opponentId,
                            status = "PLAYING",
                            lastActionTime = System.currentTimeMillis(),
                            lastActionBy = player.id
                        )

                        // Write room first
                        roomsRef.child(roomId).setValue(newRoom)
                            .addOnSuccessListener {
                                // Match the opponent by writing the room ID to their queue node
                                queueRef.child(opponentId).child("matchedRoomId").setValue(roomId)
                                // Remove ourselves from the queue
                                queueRef.child(player.id).removeValue()
                                onMatched(roomId)
                            }
                            .addOnFailureListener { e ->
                                hasMatched = false
                                onError("Failed to create match room: ${e.message}")
                            }
                        break
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        }

        queueRef.addValueEventListener(matchmakingListener)
        return matchmakingListener
    }

    /**
     * Cancels matchmaking by removing player from the queue.
     */
    fun cancelMatchmaking(playerId: String, listener: ValueEventListener?) {
        if (listener != null) {
            queueRef.removeEventListener(listener)
        }
        queueRef.child(playerId).removeValue()
    }

    /**
     * Creates a private room.
     */
    fun createPrivateRoom(
        player: Player,
        onRoomCreated: (roomId: String) -> Unit,
        onError: (String) -> Unit
    ) {
        val roomId = (100000..999999).random().toString()
        val room = GameRoom(
            roomId = roomId,
            playerX = player,
            playerO = null,
            board = List(9) { "" },
            turn = player.id,
            status = "WAITING",
            lastActionTime = System.currentTimeMillis(),
            lastActionBy = player.id
        )

        roomsRef.child(roomId).setValue(room)
            .addOnSuccessListener {
                onRoomCreated(roomId)
            }
            .addOnFailureListener { e ->
                onError("Failed to create room: ${e.message}")
            }
    }

    /**
     * Joins a private room.
     */
    fun joinPrivateRoom(
        roomId: String,
        player: Player,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        roomsRef.child(roomId).get().addOnSuccessListener { snapshot ->
            if (!snapshot.exists()) {
                onError("Room ID is invalid or does not exist.")
                return@addOnSuccessListener
            }

            val room = snapshot.getValue(GameRoom::class.java)
            if (room == null) {
                onError("Failed to read room data.")
                return@addOnSuccessListener
            }

            if (room.isFull()) {
                onError("This room is already full.")
                return@addOnSuccessListener
            }

            if (room.playerX?.id == player.id) {
                // Already joined as X, just succeed
                onSuccess()
                return@addOnSuccessListener
            }

            // Join as player O and start the game
            val updatedRoom = room.copy(
                playerO = player,
                status = "PLAYING",
                turn = room.playerX?.id ?: player.id, // Player X goes first
                lastActionTime = System.currentTimeMillis(),
                lastActionBy = player.id
            )

            roomsRef.child(roomId).setValue(updatedRoom)
                .addOnSuccessListener { onSuccess() }
                .addOnFailureListener { e -> onError("Failed to join room: ${e.message}") }
        }.addOnFailureListener { e ->
            onError(e.message ?: "Database error.")
        }
    }

    /**
     * Real-time subscription to room changes using Flow.
     */
    fun observeRoom(roomId: String): Flow<GameRoom?> = callbackFlow {
        val roomRef = roomsRef.child(roomId)
        
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java)
                trySend(room)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        roomRef.addValueEventListener(listener)
        awaitClose { roomRef.removeEventListener(listener) }
    }

    /**
     * Registers disconnect handler for a room.
     * When connection drops, sets status to DISCONNECTED.
     */
    fun registerDisconnectHandler(roomId: String) {
        roomsRef.child(roomId).child("status").onDisconnect().setValue("DISCONNECTED")
    }

    /**
     * Cancels disconnect handler when match ends normally.
     */
    fun cancelDisconnectHandler(roomId: String) {
        roomsRef.child(roomId).child("status").onDisconnect().cancel()
    }

    /**
     * Submits a move onto the board with anti-cheat/turn validation.
     */
    fun makeMove(roomId: String, index: Int, symbol: String, nextTurnId: String, currentRoom: GameRoom) {
        // Double-check board boundary
        if (index < 0 || index >= 9) return
        if (currentRoom.board[index].isNotEmpty()) return
        if (currentRoom.status != "PLAYING") return

        val newBoard = currentRoom.board.toMutableList()
        newBoard[index] = symbol

        // Check for game completion
        val winnerSymbol = checkWinner(newBoard)
        val isBoardFull = newBoard.none { it.isEmpty() }

        val (status, winnerId) = when {
            winnerSymbol.isNotEmpty() -> {
                cancelDisconnectHandler(roomId)
                val winId = if (winnerSymbol == "X") currentRoom.playerX?.id else currentRoom.playerO?.id
                Pair("FINISHED", winId ?: "")
            }
            isBoardFull -> {
                cancelDisconnectHandler(roomId)
                Pair("FINISHED", "DRAW")
            }
            else -> {
                Pair("PLAYING", "")
            }
        }

        val updates = hashMapOf<String, Any>(
            "board" to newBoard,
            "status" to status,
            "winnerId" to winnerId,
            "lastActionTime" to System.currentTimeMillis(),
            "lastActionBy" to currentRoom.lastActionBy
        )

        if (status == "PLAYING") {
            updates["turn"] = nextTurnId
        }

        roomsRef.child(roomId).updateChildren(updates)
            .addOnFailureListener { Log.e(TAG, "Failed to submit move", it) }
    }

    /**
     * Submits a rematch agreement request.
     */
    fun requestRematch(roomId: String, isPlayerX: Boolean, currentRoom: GameRoom) {
        val updates = hashMapOf<String, Any>()
        
        if (isPlayerX) {
            updates["rematchX"] = true
        } else {
            updates["rematchO"] = true
        }

        // If both agreed, restart the game
        val willRestart = (isPlayerX && currentRoom.rematchO) || (!isPlayerX && currentRoom.rematchX)
        if (willRestart) {
            updates["board"] = List(9) { "" }
            updates["status"] = "PLAYING"
            updates["winnerId"] = ""
            updates["rematchX"] = false
            updates["rematchO"] = false
            // Alternate starting turn to the other player for fairness, or use playerX
            updates["turn"] = currentRoom.playerX?.id ?: ""
            registerDisconnectHandler(roomId)
        }

        roomsRef.child(roomId).updateChildren(updates)
            .addOnFailureListener { Log.e(TAG, "Failed to request rematch", it) }
    }

    /**
     * Leaves the room gracefully.
     */
    fun leaveRoom(roomId: String, playerId: String, isPlayerX: Boolean, currentRoom: GameRoom) {
        cancelDisconnectHandler(roomId)
        
        if (currentRoom.status == "PLAYING") {
            // If the game was active, leaving gives a forfeit win to the other player
            val otherPlayerId = if (isPlayerX) currentRoom.playerO?.id else currentRoom.playerX?.id
            val updates = mapOf(
                "status" to "DISCONNECTED",
                "winnerId" to (otherPlayerId ?: "")
            )
            roomsRef.child(roomId).updateChildren(updates)
        } else if (currentRoom.status == "WAITING") {
            // If waiting, delete the room
            roomsRef.child(roomId).removeValue()
        }
    }

    /**
     * Tic-Tac-Toe Win Checker
     */
    private fun checkWinner(board: List<String>): String {
        val winPositions = listOf(
            listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8), // Rows
            listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8), // Columns
            listOf(0, 4, 8), listOf(2, 4, 6)                  // Diagonals
        )

        for (pos in winPositions) {
            if (board[pos[0]].isNotEmpty() && board[pos[0]] == board[pos[1]] && board[pos[1]] == board[pos[2]]) {
                return board[pos[0]]
            }
        }
        return ""
    }
}
