package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.GameRoom
import com.example.data.model.Player
import com.example.data.repository.GameRepository
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = GameRepository(application.applicationContext)

    private val _currentPlayer = MutableStateFlow<Player?>(repository.getPlayer())
    val currentPlayer: StateFlow<Player?> = _currentPlayer.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _currentRoom = MutableStateFlow<GameRoom?>(null)
    val currentRoom: StateFlow<GameRoom?> = _currentRoom.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var matchmakingListener: ValueEventListener? = null
    private var roomObserveJob: Job? = null

    /**
     * Determines the assigned symbol ('X' or 'O') of the current player in the room.
     */
    fun getMySymbol(): String {
        val player = _currentPlayer.value ?: return ""
        val room = _currentRoom.value ?: return ""
        return room.getSymbolOfPlayer(player.id)
    }

    /**
     * Checks if it is currently the logged-in player's turn.
     */
    fun isMyTurn(): Boolean {
        val player = _currentPlayer.value ?: return false
        val room = _currentRoom.value ?: return false
        return room.status == "PLAYING" && room.turn == player.id
    }

    /**
     * Authenticates the player with a user-provided name.
     */
    fun loginPlayer(name: String) {
        if (name.trim().isEmpty()) {
            _errorMessage.value = "Player name cannot be empty."
            return
        }
        val player = repository.savePlayer(name.trim())
        _currentPlayer.value = player
    }

    /**
     * Performs a local sign-out and resets states.
     */
    fun logout() {
        repository.logout()
        _currentPlayer.value = null
        _currentRoom.value = null
        _isSearching.value = false
    }

    /**
     * Enters the automatic matchmaking queue.
     */
    fun startMatchmaking(onMatched: (roomId: String) -> Unit) {
        val player = _currentPlayer.value ?: return
        _errorMessage.value = null
        matchmakingListener = repository.startMatchmaking(
            player = player,
            onMatched = { roomId ->
                _isSearching.value = false
                onMatched(roomId)
            },
            onSearching = {
                _isSearching.value = true
            },
            onError = { err ->
                _isSearching.value = false
                _errorMessage.value = err
            }
        )
    }

    /**
     * Gracefully cancels searching for matchmaking.
     */
    fun cancelMatchmaking() {
        val player = _currentPlayer.value ?: return
        _isSearching.value = false
        repository.cancelMatchmaking(player.id, matchmakingListener)
        matchmakingListener = null
    }

    /**
     * Creates a private room and triggers completion callback with the Room ID.
     */
    fun createPrivateRoom(onRoomCreated: (roomId: String) -> Unit) {
        val player = _currentPlayer.value ?: return
        _errorMessage.value = null
        repository.createPrivateRoom(
            player = player,
            onRoomCreated = onRoomCreated,
            onError = { err -> _errorMessage.value = err }
        )
    }

    /**
     * Joins a private room with the provided ID.
     */
    fun joinPrivateRoom(roomId: String, onSuccess: () -> Unit) {
        val player = _currentPlayer.value ?: return
        if (roomId.trim().isEmpty()) {
            _errorMessage.value = "Please enter a Room ID."
            return
        }
        _errorMessage.value = null
        repository.joinPrivateRoom(
            roomId = roomId.trim(),
            player = player,
            onSuccess = onSuccess,
            onError = { err -> _errorMessage.value = err }
        )
    }

    /**
     * Subscribes to the live room updates.
     */
    fun observeRoom(roomId: String) {
        roomObserveJob?.cancel()
        roomObserveJob = viewModelScope.launch {
            repository.observeRoom(roomId).collectLatest { room ->
                _currentRoom.value = room
                if (room != null && room.status == "PLAYING") {
                    // Start disconnect monitoring
                    repository.registerDisconnectHandler(roomId)
                }
            }
        }
    }

    /**
     * Submits a grid move selection.
     */
    fun makeMove(index: Int) {
        val player = _currentPlayer.value ?: return
        val room = _currentRoom.value ?: return
        val mySymbol = getMySymbol()

        if (room.status != "PLAYING") return
        if (room.turn != player.id) return
        if (room.board[index].isNotEmpty()) return

        val nextTurnId = if (player.id == room.playerX?.id) {
            room.playerO?.id ?: ""
        } else {
            room.playerX?.id ?: ""
        }

        repository.makeMove(room.roomId, index, mySymbol, nextTurnId, room)
    }

    /**
     * Updates player rematch consent status.
     */
    fun requestRematch() {
        val player = _currentPlayer.value ?: return
        val room = _currentRoom.value ?: return
        val isPlayerX = room.playerX?.id == player.id
        repository.requestRematch(room.roomId, isPlayerX, room)
    }

    /**
     * Gracefully exits the current match room.
     */
    fun leaveCurrentRoom() {
        val player = _currentPlayer.value ?: return
        val room = _currentRoom.value ?: return
        val isPlayerX = room.playerX?.id == player.id
        
        repository.leaveRoom(room.roomId, player.id, isPlayerX, room)
        
        roomObserveJob?.cancel()
        _currentRoom.value = null
    }

    /**
     * Resets the active error message.
     */
    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        roomObserveJob?.cancel()
        matchmakingListener?.let {
            _currentPlayer.value?.id?.let { pid ->
                repository.cancelMatchmaking(pid, it)
            }
        }
    }
}
