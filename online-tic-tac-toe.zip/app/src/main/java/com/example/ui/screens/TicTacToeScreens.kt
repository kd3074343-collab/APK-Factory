package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.GameRoom
import com.example.data.model.Player
import com.example.ui.GameViewModel
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMagenta

/**
 * 1. LOGIN SCREEN
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    viewModel: GameViewModel,
    onLoginSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    var nameInput by remember { mutableStateOf("") }
    val errorMsg by viewModel.errorMessage.collectAsStateWithLifecycle()
    val currentPlayer by viewModel.currentPlayer.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(currentPlayer) {
        if (currentPlayer != null) {
            onLoginSuccess()
        }
    }

    LaunchedEffect(errorMsg) {
        errorMsg?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearErrorMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.background.copy(alpha = 0.9f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Large visual branding
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .background(
                            Brush.linearGradient(listOf(NeonCyan, NeonMagenta)),
                            shape = RoundedCornerShape(28.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "XO",
                        color = Color.White,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Tic-Tac-Toe",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Enter your alias to play online",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { if (it.length <= 15) nameInput = it },
                    label = { Text("Your Player Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            keyboardController?.hide()
                            viewModel.loginPlayer(nameInput)
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("username_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                Button(
                    onClick = {
                        keyboardController?.hide()
                        viewModel.loginPlayer(nameInput)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("continue_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan,
                        contentColor = Color.Black
                    )
                ) {
                    Text(
                        text = "Continue",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * 2. HOME SCREEN
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GameViewModel,
    onNavigateToSearching: () -> Unit,
    onNavigateToGame: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val player by viewModel.currentPlayer.collectAsStateWithLifecycle()
    val errorMsg by viewModel.errorMessage.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showJoinDialog by remember { mutableStateOf(false) }
    var joinRoomIdInput by remember { mutableStateOf("") }

    LaunchedEffect(errorMsg) {
        errorMsg?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearErrorMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(NeonCyan, shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (player?.name?.firstOrNull() ?: 'P').toString().uppercase(),
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = player?.name ?: "Guest Player",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Online ID: ${player?.id?.take(8) ?: ""}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Log Out"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Game Hero Title
            Text(
                text = "MULTIPLATER LOBBY",
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.Bold,
                color = NeonCyan,
                modifier = Modifier.align(Alignment.Start)
            )

            // Random Match card
            Card(
                onClick = {
                    viewModel.startMatchmaking { roomId ->
                        onNavigateToGame(roomId)
                    }
                    onNavigateToSearching()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .testTag("random_match_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, borderBrush())
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Random Matchmaking",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Instantly play with another online player.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(NeonCyan.copy(alpha = 0.15f), shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = "Quick Match",
                            tint = NeonCyan,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            // Private Room Options Title
            Text(
                text = "PRIVATE GAME ROOMS",
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.Bold,
                color = NeonMagenta,
                modifier = Modifier
                    .align(Alignment.Start)
                    .padding(top = 16.dp)
            )

            // Row for Create and Join Rooms
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    onClick = {
                        viewModel.createPrivateRoom { roomId ->
                            onNavigateToGame(roomId)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(140.dp)
                        .testTag("create_room_card"),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddBox,
                                contentDescription = "Create",
                                tint = NeonCyan
                            )
                        }
                        Column {
                            Text(
                                text = "Create Room",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Get unique code",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                    }
                }

                Card(
                    onClick = { showJoinDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(140.dp)
                        .testTag("join_room_card"),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(NeonMagenta.copy(alpha = 0.1f), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MeetingRoom,
                                contentDescription = "Join",
                                tint = NeonMagenta
                            )
                        }
                        Column {
                            Text(
                                text = "Join Room",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Enter shared code",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }

    // Join Private Room Dialog
    if (showJoinDialog) {
        AlertDialog(
            onDismissRequest = { showJoinDialog = false },
            title = { Text("Join Private Room", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter the 6-digit Room ID provided by the host:")
                    OutlinedTextField(
                        value = joinRoomIdInput,
                        onValueChange = { if (it.length <= 6) joinRoomIdInput = it.filter { c -> c.isDigit() } },
                        placeholder = { Text("e.g. 123456") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("room_id_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (joinRoomIdInput.length == 6) {
                            showJoinDialog = false
                            viewModel.joinPrivateRoom(joinRoomIdInput) {
                                onNavigateToGame(joinRoomIdInput)
                            }
                        } else {
                            Toast.makeText(context, "Room ID must be exactly 6 digits.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonMagenta),
                    modifier = Modifier.testTag("confirm_join_button")
                ) {
                    Text("Join Match")
                }
            },
            dismissButton = {
                TextButton(onClick = { showJoinDialog = false }) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(28.dp)
        )
    }
}

/**
 * 3. MATCHMAKING SCREEN (SEARCHING)
 */
@Composable
fun SearchingScreen(
    viewModel: GameViewModel,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "searching")
    
    // Circular orbital rotation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Pulsating circle size scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(32.dp),
                modifier = Modifier.padding(24.dp)
            ) {
                // Highly visual custom loader
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .scale(pulseScale),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer spinning dotted ring
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(rotation)
                    ) {
                        drawCircle(
                            color = NeonCyan,
                            radius = size.minDimension / 2,
                            style = Stroke(
                                width = 4.dp.toPx(),
                                cap = StrokeCap.Round,
                                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(
                                    floatArrayOf(15f, 35f), 0f
                                )
                            )
                        )
                    }

                    // Inner reverse spinning ring
                    Canvas(
                        modifier = Modifier
                            .size(110.dp)
                            .rotate(-rotation)
                    ) {
                        drawCircle(
                            color = NeonMagenta,
                            radius = size.minDimension / 2,
                            style = Stroke(
                                width = 3.dp.toPx(),
                                cap = StrokeCap.Round,
                                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(
                                    floatArrayOf(20f, 25f), 0f
                                )
                            )
                        )
                    }

                    // Center static core icon
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .background(
                                Brush.verticalGradient(listOf(NeonCyan, NeonMagenta)),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Searching",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Searching for Opponent...",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Matching you automatically with another online player",
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        viewModel.cancelMatchmaking()
                        onCancel()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .width(180.dp)
                        .height(50.dp)
                        .testTag("cancel_matchmaking_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Cancel,
                        contentDescription = "Cancel",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cancel", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * 4. GAME PLAY SCREEN
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    viewModel: GameViewModel,
    roomId: String,
    onLeaveGame: () -> Unit,
    modifier: Modifier = Modifier
) {
    val room by viewModel.currentRoom.collectAsStateWithLifecycle()
    val player by viewModel.currentPlayer.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var showLeaveConfirmation by remember { mutableStateOf(false) }

    // Start observing room
    LaunchedEffect(roomId) {
        viewModel.observeRoom(roomId)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            clipboardManager.setText(AnnotatedString(roomId))
                            Toast.makeText(context, "Room ID copied to clipboard!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text(
                            text = "Room: $roomId",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy ID",
                            modifier = Modifier.size(16.dp),
                            tint = NeonCyan
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { showLeaveConfirmation = true },
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Leave Game"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            val currentRoom = room
            if (currentRoom == null) {
                // Loading State or Room Deleted
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = NeonCyan)
                        Text(
                            text = "Synchronizing Game Room...",
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Game Status Header / Players
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Duel Players Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlayerScoreCard(
                                name = currentRoom.playerX?.name ?: "Waiting...",
                                symbol = "X",
                                symbolColor = NeonCyan,
                                isActive = currentRoom.turn == currentRoom.playerX?.id && currentRoom.status == "PLAYING"
                            )
                            Text(
                                text = "VS",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)
                            )
                            PlayerScoreCard(
                                name = currentRoom.playerO?.name ?: "Waiting...",
                                symbol = "O",
                                symbolColor = NeonMagenta,
                                isActive = currentRoom.turn == currentRoom.playerO?.id && currentRoom.status == "PLAYING"
                            )
                        }

                        // Active Turn / Status Banner
                        GameStatusBanner(room = currentRoom, viewModel = viewModel)
                    }

                    // 3x3 Board Grid
                    GameBoard(room = currentRoom, viewModel = viewModel)

                    // Bottom info or Leave Game button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        if (currentRoom.status == "WAITING") {
                            Text(
                                text = "Waiting for an opponent to join...",
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan,
                                fontSize = 14.sp
                            )
                        } else if (currentRoom.status == "FINISHED") {
                            RematchControls(room = currentRoom, viewModel = viewModel)
                        } else {
                            Text(
                                text = "Online Multiplayer — Fast RTDB Sync",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                            )
                        }
                    }
                }

                // Opponent Left Dialog / Overlay
                if (currentRoom.status == "DISCONNECTED") {
                    Dialog(
                        onDismissRequest = {
                            viewModel.leaveCurrentRoom()
                            onLeaveGame()
                        },
                        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(NeonMagenta.copy(alpha = 0.15f), shape = CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Alert",
                                        tint = NeonMagenta,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Text(
                                    text = "Opponent Left",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = "The opponent has left the room or lost connection. The match has ended.",
                                    textAlign = TextAlign.Center,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )
                                Button(
                                    onClick = {
                                        viewModel.leaveCurrentRoom()
                                        onLeaveGame()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black)
                                ) {
                                    Text("Back to Lobby", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Game Finished / Winner Overlays
                if (currentRoom.status == "FINISHED") {
                    val winnerName = when (currentRoom.winnerId) {
                        "DRAW" -> "It's a Draw!"
                        currentRoom.playerX?.id -> "${currentRoom.playerX?.name} Wins!"
                        currentRoom.playerO?.id -> "${currentRoom.playerO?.name} Wins!"
                        else -> "Game Finished"
                    }

                    val isWinner = currentRoom.winnerId == player?.id
                    val isDraw = currentRoom.winnerId == "DRAW"

                    Dialog(
                        onDismissRequest = {},
                        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, borderBrush())
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .background(
                                            if (isDraw) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                                            else if (isWinner) NeonCyan.copy(alpha = 0.15f)
                                            else NeonMagenta.copy(alpha = 0.15f),
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isDraw) Icons.Default.DragHandle
                                                      else if (isWinner) Icons.Default.EmojiEvents
                                                      else Icons.Default.SentimentVeryDissatisfied,
                                        contentDescription = "End Result",
                                        tint = if (isDraw) MaterialTheme.colorScheme.onSurface
                                               else if (isWinner) NeonCyan
                                               else NeonMagenta,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                Text(
                                    text = if (isDraw) "Draw Match" else if (isWinner) "Victory!" else "Defeat",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isDraw) MaterialTheme.colorScheme.onBackground
                                            else if (isWinner) NeonCyan
                                            else NeonMagenta
                                )

                                Text(
                                    text = winnerName,
                                    textAlign = TextAlign.Center,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                                )

                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                                // Rematch status indicators inside dialog
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    RematchStatusLabel(
                                        name = currentRoom.playerX?.name ?: "Player X",
                                        voted = currentRoom.rematchX
                                    )
                                    RematchStatusLabel(
                                        name = currentRoom.playerO?.name ?: "Player O",
                                        voted = currentRoom.rematchO
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            viewModel.leaveCurrentRoom()
                                            onLeaveGame()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Leave")
                                    }

                                    val isMyRematchSubmitted = if (currentRoom.playerX?.id == player?.id) currentRoom.rematchX else currentRoom.rematchO
                                    Button(
                                        onClick = { viewModel.requestRematch() },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("play_again_button"),
                                        enabled = !isMyRematchSubmitted,
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black)
                                    ) {
                                        Text(if (isMyRematchSubmitted) "Waiting..." else "Play Again")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Leave Confirmation Dialog
    if (showLeaveConfirmation) {
        AlertDialog(
            onDismissRequest = { showLeaveConfirmation = false },
            title = { Text("Quit Match?") },
            text = { Text("Are you sure you want to forfeit and leave this room? If the game is in progress, leaving results in automatic loss.") },
            confirmButton = {
                Button(
                    onClick = {
                        showLeaveConfirmation = false
                        viewModel.leaveCurrentRoom()
                        onLeaveGame()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonMagenta),
                    modifier = Modifier.testTag("confirm_leave_button")
                ) {
                    Text("Quit Room")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLeaveConfirmation = false }) {
                    Text("Resume Play")
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }
}

/**
 * CUSTOM COMPOSABLE: PLAYER SCORE CARD
 */
@Composable
fun PlayerScoreCard(
    name: String,
    symbol: String,
    symbolColor: Color,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .width(135.dp)
            .border(
                width = if (isActive) 2.dp else 0.dp,
                brush = Brush.linearGradient(listOf(symbolColor, symbolColor.copy(alpha = 0.3f))),
                shape = RoundedCornerShape(20.dp)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) MaterialTheme.colorScheme.surfaceVariant
                             else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = symbol,
                color = symbolColor,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = name,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}

/**
 * CUSTOM COMPOSABLE: ACTIVE GAME STATUS BANNER
 */
@Composable
fun GameStatusBanner(
    room: GameRoom,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val mySymbol = viewModel.getMySymbol()
    val isMyTurn = viewModel.isMyTurn()

    val (bannerText, color) = when {
        room.status == "WAITING" -> Pair("Sharing room ID...", NeonCyan)
        room.status == "PLAYING" && isMyTurn -> Pair("YOUR TURN ($mySymbol)", NeonCyan)
        room.status == "PLAYING" && !isMyTurn -> {
            val opponentName = if (mySymbol == "X") room.playerO?.name else room.playerX?.name
            Pair("${opponentName ?: "Opponent"}'s Turn", MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
        else -> Pair("Match Ended", NeonMagenta)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = bannerText.uppercase(),
            fontSize = 12.sp,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.ExtraBold,
            color = color
        )
    }
}

/**
 * CUSTOM COMPOSABLE: 3x3 TIC-TAC-TOE BOARD
 */
@Composable
fun GameBoard(
    room: GameRoom,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val isMyTurn = viewModel.isMyTurn()

    Box(
        modifier = modifier
            .size(310.dp)
            .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp))
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(16.dp)
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = false,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(9) { index ->
                val cellSymbol = room.board.getOrNull(index) ?: ""
                val isCellClickable = cellSymbol.isEmpty() && room.status == "PLAYING" && isMyTurn

                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .background(
                            color = if (isCellClickable) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                                    else MaterialTheme.colorScheme.background,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable(
                            enabled = isCellClickable,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = LocalIndication.current
                        ) {
                            viewModel.makeMove(index)
                        }
                        .testTag("cell_$index"),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedVisibility(
                        visible = cellSymbol.isNotEmpty(),
                        enter = fadeIn() + scaleIn(initialScale = 0.5f),
                        exit = fadeOut()
                    ) {
                        Text(
                            text = cellSymbol,
                            color = if (cellSymbol == "X") NeonCyan else NeonMagenta,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                }
            }
        }
    }
}

/**
 * CUSTOM COMPOSABLE: REMATCH VOTING STATUS LABEL
 */
@Composable
fun RematchStatusLabel(
    name: String,
    voted: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = modifier
    ) {
        Icon(
            imageVector = if (voted) Icons.Default.CheckCircle else Icons.Default.HourglassEmpty,
            contentDescription = null,
            tint = if (voted) NeonCyan else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f),
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = name,
            fontSize = 13.sp,
            color = if (voted) MaterialTheme.colorScheme.onBackground
                   else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            fontWeight = if (voted) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

/**
 * CUSTOM COMPOSABLE: REMATCH CONTROL ROW
 */
@Composable
fun RematchControls(
    room: GameRoom,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val player = viewModel.currentPlayer.collectAsStateWithLifecycle().value
    val isMyRematchSubmitted = if (room.playerX?.id == player?.id) room.rematchX else room.rematchO

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(
            onClick = { viewModel.requestRematch() },
            enabled = !isMyRematchSubmitted,
            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Text(if (isMyRematchSubmitted) "Voting Play Again..." else "Request Rematch")
        }
    }
}

/**
 * HELPER: LINEAR GRADIENT BRUSH FOR CARDS
 */
@Composable
private fun borderBrush(): Brush {
    return Brush.linearGradient(
        colors = listOf(
            NeonCyan.copy(alpha = 0.4f),
            NeonMagenta.copy(alpha = 0.4f)
        )
    )
}
