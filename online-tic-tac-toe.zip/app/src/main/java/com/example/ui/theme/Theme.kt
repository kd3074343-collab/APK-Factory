package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    secondary = NeonMagenta,
    tertiary = Purple80,
    background = SlateDarkBg,
    surface = SlateDarkSurface,
    onPrimary = Color(0xFF0B0E14),
    onSecondary = Color.White,
    onBackground = SlateTextPrimary,
    onSurface = SlateTextPrimary,
    outline = SlateDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF1E3A8A), // Deep blue primary
    secondary = Color(0xFFB91C1C), // Deep crimson secondary
    tertiary = PurpleGrey40,
    background = SlateLightBg,
    surface = SlateLightSurface,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = SlateTextPrimaryLight,
    onSurface = SlateTextPrimaryLight,
    outline = SlateLightBorder
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
