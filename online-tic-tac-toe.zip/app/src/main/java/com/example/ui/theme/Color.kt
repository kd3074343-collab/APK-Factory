package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicDark = Color(0xFF0F0E17)
val CosmicSurface = Color(0xFF1E1C2A)
val CosmicPrimary = Color(0xFFE53170)
val CosmicSecondary = Color(0xFF00ADB5)
val CosmicTertiary = Color(0xFFFF8906)

val CyberCyan = Color(0xFF00F5FF)
val CyberPink = Color(0xFFFF2E93)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

