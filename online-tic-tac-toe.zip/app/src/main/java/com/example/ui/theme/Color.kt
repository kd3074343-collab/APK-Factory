package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Default colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Custom Neon Theme Colors
val NeonCyan = Color(0xFF00E5FF)
val NeonMagenta = Color(0xFFFF2D55)

// Dark Theme Palette
val SlateDarkBg = Color(0xFF0B0E14)
val SlateDarkSurface = Color(0xFF151B26)
val SlateDarkBorder = Color(0xFF232D3F)
val SlateTextPrimary = Color(0xFFF3F4F6)
val SlateTextSecondary = Color(0xFF9CA3AF)

// Light Theme Palette
val SlateLightBg = Color(0xFFF3F4F6)
val SlateLightSurface = Color(0xFFFFFFFF)
val SlateLightBorder = Color(0xFFE5E7EB)
val SlateTextPrimaryLight = Color(0xFF111827)
val SlateTextSecondaryLight = Color(0xFF4B5563)

