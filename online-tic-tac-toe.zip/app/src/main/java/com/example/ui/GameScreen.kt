package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.ui.theme.CosmicDark
import com.example.ui.theme.CosmicPrimary
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberPink
import com.example.viewmodel.GameViewModel

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val user by viewModel.user.collectAsState()
    val room by viewModel.activeRoom.collectAsState()

    val myUid = user?.uid ?: ""

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CosmicDark,
        topBar = {
            // Elegant top action bar with Back navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CosmicSurface)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = { viewModel.leaveRoom() },
                    modifier = Modifier.testTag("leave_game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Leave Match Back Button",
                        tint = Color.White
                    )
                }

                Text(
                    text = if (room != null && room?.playerO == null) "WAITING ROOM" else "GAME MATCH",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )

                IconButton(
                    onClick = { viewModel.leaveRoom() },
                    modifier = Modifier.background(Color(0x11FFFFFF), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "Leave Room Icon",
                        tint = CyberPink
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(CosmicDark, Color(0xFF161524))
                    )
                )
        ) {
            val activeRoom = room
            if (activeRoom == null) {
                // Loading screen while room state loads
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = CyberCyan)
                }
            } else if (activeRoom.status == "WAITING") {
                // Waiting for Player O to join private room screen
                WaitingRoomUI(roomId = activeRoom.roomId, context = context, onLeave = { viewModel.leaveRoom() })
            } else {
                // Game Match Screen
                GamePlayUI(
                    room = activeRoom,
                    myUid = myUid,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun WaitingRoomUI(
    roomId: String,
    context: Context,
    onLeave: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .background(CosmicPrimary.copy(alpha = 0.1f), CircleShape)
                .border(2.dp, CosmicPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                color = CosmicPrimary,
                modifier = Modifier.size(64.dp)
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = "WAITING FOR OPPONENT",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            letterSpacing = 1.5.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Share this Room ID with a friend. Once they enter it, the game will start automatically!",
            fontSize = 14.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))

        // Display Room ID Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(16.dp))
                .border(1.dp, CosmicPrimary, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = CosmicSurface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ROOM ID",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = roomId,
                    fontSize = 36.sp,
                    color = CosmicPrimary,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp,
                    modifier = Modifier.testTag("waiting_room_id")
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Copy Button
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Room ID", roomId)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Room ID copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("copy_room_id_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicPrimary)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Icon", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Share Button
                    Button(
                        onClick = {
                            // Native Share Intent
                            val shareIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_TEXT, "Join my Tic-Tac-Toe match! Room ID: $roomId")
                            }
                            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Room ID"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicSurface),
                        border = BorderStroke(1.dp, Color.Gray)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Share, contentDescription = "Share Icon", modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        // Leave waiting room
        Button(
            onClick = onLeave,
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = CyberPink),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberPink, RoundedCornerShape(12.dp))
                .height(48.dp)
        ) {
            Text("CANCEL & LEAVE LOBBY", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
fun GamePlayUI(
    room: com.example.model.GameRoom,
    myUid: String,
    viewModel: GameViewModel
) {
    val isX = room.playerX?.uid == myUid
    val mySymbol = if (isX) "X" else "O"
    val isMyTurn = room.currentTurn == myUid
    val opponentName = if (isX) room.playerO?.name ?: "Opponent" else room.playerX?.name ?: "Opponent"

    // Pulsing Animation for Turn Indicator
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Player Profiles Header Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(6.dp, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CosmicSurface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Player X Profile (Left)
                val xPainter = rememberAsyncImagePainter(
                    model = room.playerX?.photoUrl ?: "https://www.gravatar.com/avatar/?d=mp"
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = xPainter,
                        contentDescription = "Player X Profile",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(2.dp, CyberCyan, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = room.playerX?.name ?: "Player X",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(text = "Playing X", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // VS center node
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(Color(0x11FFFFFF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "VS", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Player O Profile (Right)
                val oPainter = rememberAsyncImagePainter(
                    model = room.playerO?.photoUrl ?: "https://www.gravatar.com/avatar/?d=mp"
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = room.playerO?.name ?: "Player O",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(text = "Playing O", color = CyberPink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Image(
                        painter = oPainter,
                        contentDescription = "Player O Profile",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(2.dp, CyberPink, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        // Real-Time Turn Indicator Text
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            if (room.status == "PLAYING") {
                if (isMyTurn) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(CyberCyan.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                            .border(1.dp, CyberCyan.copy(alpha = pulseAlpha), RoundedCornerShape(12.dp))
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(CyberCyan, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "YOUR TURN (${mySymbol})",
                            color = CyberCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(Color(0x11FFFFFF), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp))
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color.Gray, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "OPPONENT'S TURN (${if (mySymbol == "X") "O" else "X"})",
                            color = Color.Gray,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            } else {
                Text(
                    text = "MATCH COMPLETED",
                    color = CosmicPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
            }
        }

        // Interactive Tic-Tac-Toe 3x3 Grid Board
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .shadow(12.dp, RoundedCornerShape(24.dp))
                .border(2.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp))
                .background(CosmicSurface, RoundedCornerShape(24.dp))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                userScrollEnabled = false,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(9) { index ->
                    val cellValue = room.board[index]
                    val isCellEmpty = cellValue.isEmpty()

                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                color = when (cellValue) {
                                    "X" -> CyberCyan.copy(alpha = 0.05f)
                                    "O" -> CyberPink.copy(alpha = 0.05f)
                                    else -> CosmicDark
                                }
                            )
                            .border(
                                width = when {
                                    cellValue == "X" -> 2.dp
                                    cellValue == "O" -> 2.dp
                                    isMyTurn && room.status == "PLAYING" -> 1.dp
                                    else -> 0.5.dp
                                },
                                color = when {
                                    cellValue == "X" -> CyberCyan
                                    cellValue == "O" -> CyberPink
                                    isMyTurn && room.status == "PLAYING" -> CyberCyan.copy(alpha = 0.4f)
                                    else -> Color(0x22FFFFFF)
                                },
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable(
                                enabled = isCellEmpty && isMyTurn && room.status == "PLAYING",
                                onClick = { viewModel.makeMove(index) }
                            )
                            .testTag("cell_$index"),
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.animation.AnimatedVisibility(
                            visible = cellValue.isNotEmpty(),
                            enter = fadeIn(animationSpec = tween(300)) + scaleIn(initialScale = 0.4f, animationSpec = tween(300)),
                            exit = fadeOut(animationSpec = tween(250)) + scaleOut(targetScale = 0.4f, animationSpec = tween(250))
                        ) {
                            Text(
                                text = cellValue,
                                fontSize = 48.sp,
                                fontWeight = FontWeight.Black,
                                color = if (cellValue == "X") CyberCyan else CyberPink,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Leaving Button
        Button(
            onClick = { viewModel.leaveRoom() },
            colors = ButtonDefaults.buttonColors(containerColor = CosmicSurface, contentColor = Color.LightGray),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("leave_match_button")
        ) {
            Text("LEAVE GAME", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }

    // Winner/Completion Overlays
    val opponentLeft = room.disconnectedUid.isNotEmpty() && room.status == "ENDED"
    if (room.status == "ENDED" || opponentLeft) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xCC0F0E17)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .shadow(24.dp, RoundedCornerShape(24.dp))
                    .border(2.dp, CosmicPrimary, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val isWinnerMe = room.winner == myUid
                    val isDraw = room.winner == "DRAW"

                    val resultTitle: String
                    val resultSubtitle: String
                    val resultColor: Color

                    when {
                        opponentLeft -> {
                            resultTitle = "OPPONENT LEFT"
                            resultSubtitle = "The match ended because $opponentName disconnected. You win!"
                            resultColor = CyberCyan
                        }
                        isDraw -> {
                            resultTitle = "DRAW MATCH"
                            resultSubtitle = "Great strategy! Both players matched perfectly."
                            resultColor = Color.LightGray
                        }
                        isWinnerMe -> {
                            resultTitle = "VICTORY!"
                            resultSubtitle = "Fantastic game! You defeated your opponent."
                            resultColor = CyberCyan
                        }
                        else -> {
                            resultTitle = "DEFEAT"
                            resultSubtitle = "$opponentName won this round. Best of luck next time!"
                            resultColor = CyberPink
                        }
                    }

                    Text(
                        text = resultTitle,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = resultColor,
                        letterSpacing = 1.sp,
                        modifier = Modifier.testTag("game_result_title")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = resultSubtitle,
                        fontSize = 14.sp,
                        color = Color.LightGray,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    if (!opponentLeft) {
                        // Rematch state detection
                        val amIRequested = if (isX) room.rematchRequests.playerX else room.rematchRequests.playerO
                        val isOpponentRequested = if (isX) room.rematchRequests.playerO else room.rematchRequests.playerX

                        if (amIRequested && isOpponentRequested) {
                            CircularProgressIndicator(color = CyberCyan)
                        } else {
                            Button(
                                onClick = { viewModel.requestRematch() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (amIRequested) Color.DarkGray else CosmicPrimary
                                ),
                                enabled = !amIRequested,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("play_again_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Play Again Icon")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (amIRequested) "WAITING FOR OPPONENT" else "PLAY AGAIN",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            if (isOpponentRequested && !amIRequested) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "$opponentName requested a rematch!",
                                    color = CyberCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Exit to lobby button
                    Button(
                        onClick = { viewModel.leaveRoom() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .border(1.dp, Color.Gray, RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("RETURN TO LOBBY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
