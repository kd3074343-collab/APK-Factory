package com.example.model

import androidx.annotation.Keep

@Keep
data class PlayerInfo(
    val uid: String = "",
    val name: String = "",
    val photoUrl: String = ""
)

@Keep
data class RematchRequests(
    val playerX: Boolean = false,
    val playerO: Boolean = false
)

@Keep
data class GameRoom(
    val roomId: String = "",
    val playerX: PlayerInfo? = null,
    val playerO: PlayerInfo? = null,
    val board: List<String> = List(9) { "" },
    val currentTurn: String = "",
    val winner: String = "", // "X", "O", "DRAW", or other status like "OPPONENT_LEFT"
    val status: String = "WAITING", // "WAITING", "PLAYING", "ENDED"
    val rematchRequests: RematchRequests = RematchRequests(),
    val disconnectedUid: String = ""
)

@Keep
data class MatchmakingQueueItem(
    val uid: String = "",
    val name: String = "",
    val photoUrl: String = "",
    val timestamp: Long = 0,
    val matchedRoomId: String = ""
)
