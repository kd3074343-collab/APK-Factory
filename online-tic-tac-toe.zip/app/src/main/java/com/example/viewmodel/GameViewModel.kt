package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.GameRoom
import com.example.model.MatchmakingQueueItem
import com.example.model.PlayerInfo
import com.example.model.RematchRequests
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface GameState {
    object Idle : GameState
    object LoggingIn : GameState
    object Home : GameState
    object Matchmaking : GameState
    data class Playing(val roomId: String) : GameState
    data class Error(val message: String) : GameState
}

class GameViewModel : ViewModel() {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()

    private val _user = MutableStateFlow<FirebaseUser?>(auth.currentUser)
    val user: StateFlow<FirebaseUser?> = _user.asStateFlow()

    private val _gameState = MutableStateFlow<GameState>(GameState.Idle)
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    private val _activeRoom = MutableStateFlow<GameRoom?>(null)
    val activeRoom: StateFlow<GameRoom?> = _activeRoom.asStateFlow()

    private val _isFirebaseConnected = MutableStateFlow(true)
    val isFirebaseConnected: StateFlow<Boolean> = _isFirebaseConnected.asStateFlow()

    private var activeRoomListener: ValueEventListener? = null
    private var matchmakingListener: ValueEventListener? = null
    private var activeRoomId: String? = null

    init {
        // Track auth state
        auth.addAuthStateListener { firebaseAuth ->
            val currentUser = firebaseAuth.currentUser
            _user.value = currentUser
            if (currentUser != null && _gameState.value is GameState.Idle) {
                _gameState.value = GameState.Home
            } else if (currentUser == null) {
                _gameState.value = GameState.Idle
            }
        }

        // Track connection state
        database.getReference(".info/connected").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                _isFirebaseConnected.value = connected
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun signInWithGoogleToken(idToken: String) {
        _gameState.value = GameState.LoggingIn
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    _gameState.value = GameState.Home
                } else {
                    val errMsg = task.exception?.localizedMessage ?: "Google Sign-In failed"
                    _gameState.value = GameState.Error(errMsg)
                }
            }
    }

    fun signOut() {
        cancelMatchmaking()
        leaveRoom()
        auth.signOut()
        _gameState.value = GameState.Idle
    }

    fun dismissError() {
        if (_gameState.value is GameState.Error) {
            _gameState.value = if (auth.currentUser != null) GameState.Home else GameState.Idle
        }
    }

    // Matchmaking Logic
    fun startRandomMatchmaking() {
        val currentUser = auth.currentUser ?: return
        _gameState.value = GameState.Matchmaking

        val myUid = currentUser.uid
        val myName = currentUser.displayName ?: "Player"
        val myPhotoUrl = currentUser.photoUrl?.toString() ?: ""

        val queueRef = database.getReference("matchmaking_queue")

        // First check if another player is in the queue
        queueRef.orderByChild("timestamp").limitToFirst(5)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (_gameState.value != GameState.Matchmaking) return // Matchmaking cancelled

                    var foundOpponent: MatchmakingQueueItem? = null
                    for (child in snapshot.children) {
                        val item = child.getValue(MatchmakingQueueItem::class.java)
                        if (item != null && item.uid != myUid && item.matchedRoomId.isEmpty()) {
                            foundOpponent = item
                            break
                        }
                    }

                    if (foundOpponent != null) {
                        // Found a waiting player! Create a match room.
                        val roomId = "rand_" + UUID.randomUUID().toString().substring(0, 6).uppercase()
                        val newRoom = GameRoom(
                            roomId = roomId,
                            playerX = PlayerInfo(
                                uid = foundOpponent.uid,
                                name = foundOpponent.name,
                                photoUrl = foundOpponent.photoUrl
                            ),
                            playerO = PlayerInfo(
                                uid = myUid,
                                name = myName,
                                photoUrl = myPhotoUrl
                            ),
                            board = List(9) { "" },
                            currentTurn = foundOpponent.uid, // X goes first
                            status = "PLAYING"
                        )

                        // Write Room to Database
                        database.getReference("rooms/$roomId").setValue(newRoom)
                            .addOnSuccessListener {
                                // Update opponent's record in queue with the match room ID
                                queueRef.child(foundOpponent.uid).child("matchedRoomId").setValue(roomId)
                                // Enter room immediately
                                joinGameRoom(roomId)
                            }
                            .addOnFailureListener {
                                _gameState.value = GameState.Error("Failed to create match room")
                            }
                    } else {
                        // No opponent available. Enter queue and wait.
                        val queueItemMap = mapOf(
                            "uid" to myUid,
                            "name" to myName,
                            "photoUrl" to myPhotoUrl,
                            "timestamp" to ServerValue.TIMESTAMP,
                            "matchedRoomId" to ""
                        )

                        queueRef.child(myUid).setValue(queueItemMap)
                            .addOnSuccessListener {
                                // Register disconnect cleanup
                                queueRef.child(myUid).onDisconnect().removeValue()

                                // Listen for match assignment
                                matchmakingListener = queueRef.child(myUid)
                                    .addValueEventListener(object : ValueEventListener {
                                        override fun onDataChange(queueSnapshot: DataSnapshot) {
                                            val matchedId = queueSnapshot.child("matchedRoomId").getValue(String::class.java)
                                            if (!matchedId.isNullOrEmpty()) {
                                                // Matched! Clean up queue item and join
                                                queueRef.child(myUid).removeValue()
                                                queueRef.child(myUid).onDisconnect().cancel()
                                                joinGameRoom(matchedId)
                                            }
                                        }

                                        override fun onCancelled(error: DatabaseError) {
                                            _gameState.value = GameState.Error("Matchmaking cancelled: ${error.message}")
                                        }
                                    })
                            }
                            .addOnFailureListener {
                                _gameState.value = GameState.Error("Failed to enter matchmaking queue")
                            }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    _gameState.value = GameState.Error(error.message)
                }
            })
    }

    fun cancelMatchmaking() {
        val currentUser = auth.currentUser ?: return
        matchmakingListener?.let {
            database.getReference("matchmaking_queue/${currentUser.uid}").removeEventListener(it)
            matchmakingListener = null
        }
        database.getReference("matchmaking_queue/${currentUser.uid}").removeValue()
        database.getReference("matchmaking_queue/${currentUser.uid}").onDisconnect().cancel()
        _gameState.value = GameState.Home
    }

    // Private Room Logic
    fun createPrivateRoom() {
        val currentUser = auth.currentUser ?: return
        _gameState.value = GameState.LoggingIn // Temporary loading state

        val roomId = UUID.randomUUID().toString().substring(0, 6).uppercase()
        val room = GameRoom(
            roomId = roomId,
            playerX = PlayerInfo(
                uid = currentUser.uid,
                name = currentUser.displayName ?: "Player X",
                photoUrl = currentUser.photoUrl?.toString() ?: ""
            ),
            playerO = null,
            board = List(9) { "" },
            currentTurn = currentUser.uid,
            status = "WAITING"
        )

        database.getReference("rooms/$roomId").setValue(room)
            .addOnSuccessListener {
                joinGameRoom(roomId)
            }
            .addOnFailureListener {
                _gameState.value = GameState.Error("Failed to create room: ${it.localizedMessage}")
            }
    }

    fun joinPrivateRoom(roomId: String) {
        val currentUser = auth.currentUser ?: return
        val cleanRoomId = roomId.trim().uppercase()
        if (cleanRoomId.isEmpty()) {
            _gameState.value = GameState.Error("Please enter a valid Room ID")
            return
        }

        _gameState.value = GameState.LoggingIn

        val roomRef = database.getReference("rooms/$cleanRoomId")
        roomRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java)
                if (room == null) {
                    _gameState.value = GameState.Error("Room not found!")
                    return
                }

                if (room.playerO != null) {
                    _gameState.value = GameState.Error("Room is already full!")
                    return
                }

                if (room.playerX?.uid == currentUser.uid) {
                    _gameState.value = GameState.Error("You cannot join your own room from another session!")
                    return
                }

                // Join the room as Player O
                val myInfo = PlayerInfo(
                    uid = currentUser.uid,
                    name = currentUser.displayName ?: "Player O",
                    photoUrl = currentUser.photoUrl?.toString() ?: ""
                )

                val updates = hashMapOf<String, Any>(
                    "playerO" to myInfo,
                    "status" to "PLAYING"
                )

                roomRef.updateChildren(updates)
                    .addOnSuccessListener {
                        joinGameRoom(cleanRoomId)
                    }
                    .addOnFailureListener {
                        _gameState.value = GameState.Error("Failed to join room: ${it.localizedMessage}")
                    }
            }

            override fun onCancelled(error: DatabaseError) {
                _gameState.value = GameState.Error(error.message)
            }
        })
    }

    private fun joinGameRoom(roomId: String) {
        val currentUser = auth.currentUser ?: return
        activeRoomId = roomId
        _gameState.value = GameState.Playing(roomId)

        val roomRef = database.getReference("rooms/$roomId")

        // Register disconnect handlers to notify opponent
        roomRef.child("disconnectedUid").onDisconnect().setValue(currentUser.uid)
        roomRef.child("status").onDisconnect().setValue("ENDED")

        // Listen for real-time room updates
        activeRoomListener = roomRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java)
                _activeRoom.value = room
                
                // Auto trigger rematch reset if both agreed
                if (room != null && room.status == "ENDED" && room.rematchRequests.playerX && room.rematchRequests.playerO) {
                    if (room.playerX?.uid == currentUser.uid) {
                        triggerRematchReset(roomId)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("GameViewModel", "Room listener cancelled: ${error.message}")
            }
        })
    }

    fun makeMove(cellIndex: Int) {
        val room = _activeRoom.value ?: return
        val currentUser = auth.currentUser ?: return

        // Validate turn
        if (room.currentTurn != currentUser.uid) return
        if (room.status != "PLAYING") return
        if (room.board[cellIndex].isNotEmpty()) return

        // Identify symbol
        val symbol = if (room.playerX?.uid == currentUser.uid) "X" else "O"

        // Create updated board
        val updatedBoard = room.board.toMutableList()
        updatedBoard[cellIndex] = symbol

        // Check win or draw
        val winnerSymbol = checkWinner(updatedBoard)
        var nextStatus = room.status
        var finalWinner = ""

        if (winnerSymbol.isNotEmpty()) {
            nextStatus = "ENDED"
            finalWinner = if (winnerSymbol == "DRAW") {
                "DRAW"
            } else {
                if (winnerSymbol == "X") room.playerX?.uid ?: "" else room.playerO?.uid ?: ""
            }
        }

        // Switch turn
        val nextTurn = if (room.playerX?.uid == currentUser.uid) {
            room.playerO?.uid ?: ""
        } else {
            room.playerX?.uid ?: ""
        }

        val roomRef = database.getReference("rooms/${room.roomId}")
        val updates = hashMapOf<String, Any>(
            "board" to updatedBoard,
            "currentTurn" to nextTurn,
            "winner" to finalWinner,
            "status" to nextStatus
        )

        roomRef.updateChildren(updates)
    }

    fun requestRematch() {
        val room = _activeRoom.value ?: return
        val currentUser = auth.currentUser ?: return
        val isPlayerX = room.playerX?.uid == currentUser.uid

        val roomRef = database.getReference("rooms/${room.roomId}")

        if (isPlayerX) {
            roomRef.child("rematchRequests").child("playerX").setValue(true)
        } else {
            roomRef.child("rematchRequests").child("playerO").setValue(true)
        }

        // Check if both agreed (or will agree)
        // Since we are listening, we handle the actual reset in the listener block when both are true!
        // Wait, to be perfectly synchronous and avoid dual write resets, let's do the check here too, or let the listener trigger the reset.
        // Actually, let's do the reset checks when receiving room updates.
        // Wait! Let's write the check in a database transaction or a single checked listener:
        // When a player sees in their listener that BOTH rematch requests are true, the first one to detect it can trigger the reset!
        // To prevent multiple triggers, we can do it via a quick conditional transaction, or just write it:
        // If we see both are true, we reset the board. Since reset resets rematchRequests to false, it's atomic.
        // Let's implement the trigger logic:
    }

    fun triggerRematchReset(roomId: String) {
        val roomRef = database.getReference("rooms/$roomId")
        val resetData = hashMapOf<String, Any>(
            "board" to List(9) { "" },
            "currentTurn" to (_activeRoom.value?.playerX?.uid ?: ""), // X starts first
            "winner" to "",
            "status" to "PLAYING",
            "rematchRequests" to RematchRequests(playerX = false, playerO = false),
            "disconnectedUid" to ""
        )
        roomRef.updateChildren(resetData)
    }

    fun leaveRoom() {
        val roomId = activeRoomId ?: return
        val currentUser = auth.currentUser

        activeRoomListener?.let {
            database.getReference("rooms/$roomId").removeEventListener(it)
            activeRoomListener = null
        }

        val roomRef = database.getReference("rooms/$roomId")

        // Cancel disconnect listeners
        roomRef.child("disconnectedUid").onDisconnect().cancel()
        roomRef.child("status").onDisconnect().cancel()

        if (currentUser != null) {
            val room = _activeRoom.value
            if (room != null && room.status != "ENDED") {
                // Inform opponent that we left
                val updates = hashMapOf<String, Any>(
                    "status" to "ENDED",
                    "disconnectedUid" to currentUser.uid
                )
                roomRef.updateChildren(updates)
            }
        }

        _activeRoom.value = null
        activeRoomId = null
        _gameState.value = GameState.Home
    }

    private fun checkWinner(board: List<String>): String {
        val winPositions = listOf(
            listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8), // rows
            listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8), // columns
            listOf(0, 4, 8), listOf(2, 4, 6)                  // diagonals
        )
        for (pos in winPositions) {
            if (board[pos[0]].isNotEmpty() && board[pos[0]] == board[pos[1]] && board[pos[1]] == board[pos[2]]) {
                return board[pos[0]] // "X" or "O"
            }
        }
        if (board.all { it.isNotEmpty() }) {
            return "DRAW"
        }
        return ""
    }

    override fun onCleared() {
        super.onCleared()
        signOut()
    }
}
