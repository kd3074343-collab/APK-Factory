package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.GameScreen
import com.example.ui.HomeScreen
import com.example.ui.LoginScreen
import com.example.ui.MatchmakingScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GameState
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val gameViewModel: GameViewModel = viewModel()
        val gameState by gameViewModel.gameState.collectAsState()
        val currentUser by gameViewModel.user.collectAsState()

        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          when (gameState) {
            is GameState.Idle, is GameState.LoggingIn -> {
              LoginScreen(
                viewModel = gameViewModel,
                modifier = Modifier.padding(innerPadding)
              )
            }
            is GameState.Home -> {
              HomeScreen(
                viewModel = gameViewModel,
                modifier = Modifier.padding(innerPadding)
              )
            }
            is GameState.Matchmaking -> {
              MatchmakingScreen(
                viewModel = gameViewModel,
                modifier = Modifier.padding(innerPadding)
              )
            }
            is GameState.Playing -> {
              GameScreen(
                viewModel = gameViewModel,
                modifier = Modifier.padding(innerPadding)
              )
            }
            is GameState.Error -> {
              // If logged in, show home screen (it displays the error)
              // If not logged in, show login screen (it displays the error)
              if (currentUser != null) {
                HomeScreen(
                  viewModel = gameViewModel,
                  modifier = Modifier.padding(innerPadding)
                )
              } else {
                LoginScreen(
                  viewModel = gameViewModel,
                  modifier = Modifier.padding(innerPadding)
                )
              }
            }
          }
        }
      }
    }
  }
}

