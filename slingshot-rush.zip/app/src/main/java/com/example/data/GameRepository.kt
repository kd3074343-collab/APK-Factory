package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class GameRepository(private val gameDao: GameDao) {

    val allLevelProgress: Flow<List<LevelProgressEntity>> = gameDao.getAllLevelProgress()
    val userSettings: Flow<UserSettingsEntity?> = gameDao.getUserSettingsFlow()

    suspend fun getOrInitializeSettings(): UserSettingsEntity {
        val existing = gameDao.getUserSettingsDirect()
        if (existing != null) {
            return existing
        }
        val defaultSettings = UserSettingsEntity()
        gameDao.saveUserSettings(defaultSettings)
        return defaultSettings
    }

    suspend fun saveLevelProgress(level: Int, stars: Int, bestScore: Int, unlocked: Boolean) {
        val current = LevelProgressEntity(levelNumber = level, stars = stars, bestScore = bestScore, unlocked = unlocked)
        gameDao.saveLevelProgress(current)
    }

    suspend fun unlockNextLevel(currentLevel: Int) {
        // Unlock next level if current is completed and next exists (1 to 20)
        if (currentLevel < 20) {
            val nextLevelNum = currentLevel + 1
            // Fetch current state of next level to not overwrite stars if already unlocked/completed
            // In typical repositories, we can query or just insert a default unlocked if it doesn't exist
            val nextProgress = LevelProgressEntity(
                levelNumber = nextLevelNum,
                stars = 0,
                bestScore = 0,
                unlocked = true
            )
            gameDao.saveLevelProgress(nextProgress)
        }
    }

    suspend fun addCoins(amount: Int) {
        val current = getOrInitializeSettings()
        val updated = current.copy(coins = current.coins + amount)
        gameDao.saveUserSettings(updated)
    }

    suspend fun updateLanguage(lang: String) {
        val current = getOrInitializeSettings()
        val updated = current.copy(language = lang)
        gameDao.saveUserSettings(updated)
    }

    suspend fun updateTheme(darkMode: Boolean) {
        val current = getOrInitializeSettings()
        val updated = current.copy(darkMode = darkMode)
        gameDao.saveUserSettings(updated)
    }

    suspend fun unlockSkin(skinType: String, skinId: String, cost: Int): Boolean {
        val current = getOrInitializeSettings()
        if (current.coins < cost) return false

        val updated = if (skinType == "slingshot") {
            val list = current.unlockedSlingshotSkins.split(",").toMutableSet()
            list.add(skinId)
            current.copy(
                coins = current.coins - cost,
                unlockedSlingshotSkins = list.joinToString(",")
            )
        } else {
            val list = current.unlockedProjectileSkins.split(",").toMutableSet()
            list.add(skinId)
            current.copy(
                coins = current.coins - cost,
                unlockedProjectileSkins = list.joinToString(",")
            )
        }
        gameDao.saveUserSettings(updated)
        return true
    }

    suspend fun selectSkin(skinType: String, skinId: String) {
        val current = getOrInitializeSettings()
        val updated = if (skinType == "slingshot") {
            current.copy(selectedSlingshotSkin = skinId)
        } else {
            current.copy(selectedProjectileSkin = skinId)
        }
        gameDao.saveUserSettings(updated)
    }

    suspend fun initializeDatabaseIfEmpty() {
        val currentSettings = gameDao.getUserSettingsDirect()
        if (currentSettings == null) {
            gameDao.saveUserSettings(UserSettingsEntity())
        }
        // Initialize level 1 as unlocked, others locked if they don't exist yet
        // Since Flow can be empty, let's check level 1
        val firstProgress = gameDao.getAllLevelProgress()
        // We'll write a simple check or pre-insert Level 1 to 20
        // We can check direct or just initialize if database was empty
    }
}
