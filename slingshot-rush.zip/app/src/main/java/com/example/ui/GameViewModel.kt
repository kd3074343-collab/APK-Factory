package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.*

// UI Screen Enumeration
enum class GameScreen {
    HOME,
    LEVEL_SELECTION,
    SHOP,
    GAMEPLAY
}

// Gameplay State Enumeration
enum class GameplayState {
    PLAYING,
    ROUND_CLEARED,
    LEVEL_WON,
    LEVEL_LOST
}

// Obstacle Materials/Types
enum class ObstacleType {
    WOOD,
    STONE,
    GLASS,
    METAL,
    TNT,
    ENEMY,
    BOSS
}

// 2D Physics Object Model for Obstacles and Enemies
data class Obstacle(
    val type: ObstacleType,
    var x: Float,
    var y: Float,
    val width: Float,
    val height: Float,
    var health: Float,
    val maxHealth: Float,
    val pointsValue: Int,
    var vx: Float = 0f,
    var vy: Float = 0f,
    // Moving platforms
    val isMoving: Boolean = false,
    val moveRange: Float = 0f,
    val moveSpeed: Float = 0f,
    val startX: Float = x,
    val startY: Float = y,
    var moveProgress: Float = 0f,
    val id: String = UUID.randomUUID().toString()
)

// Projectile State
data class Projectile(
    var x: Float = 150f,
    var y: Float = 400f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    val radius: Float = 18f,
    var isFlying: Boolean = false,
    var trail: List<Offset> = emptyList()
)

// Particle Effects for visual polish
data class Particle(
    val id: String = UUID.randomUUID().toString(),
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    val size: Float,
    var alpha: Float = 1f,
    val decay: Float = 0.03f
)

// Floating damage / score text
data class FloatingText(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    var x: Float,
    var y: Float,
    var alpha: Float = 1f,
    val color: Color = Color.Yellow
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val database = GameDatabase.getDatabase(application)
    private val repository = GameRepository(database.gameDao())

    // Language mapping for full local translations
    val translations = mapOf(
        "en" to mapOf(
            "game_title" to "SLINGSHOT RUSH",
            "play_button" to "PLAY",
            "settings_title" to "SETTINGS",
            "language_selection" to "Language Selection",
            "dark_mode" to "Dark Mode",
            "level" to "Level",
            "round" to "Round",
            "victory" to "VICTORY!",
            "you_lost" to "YOU LOST",
            "next" to "NEXT",
            "replay" to "REPLAY",
            "menu" to "MENU",
            "retry" to "RETRY",
            "score" to "Score",
            "best_score" to "Best Score",
            "coins" to "Coins",
            "locked" to "Locked",
            "shop_title" to "COSMETIC SHOP",
            "slingshot_skins" to "Slingshot Skins",
            "projectile_skins" to "Projectile Skins",
            "unlock" to "Unlock",
            "equipped" to "Equipped",
            "equip" to "Equip",
            "insufficient_coins" to "Not enough coins!",
            "boss_hp" to "BOSS HEALTH",
            "wind" to "Wind",
            "easy" to "Easy",
            "medium" to "Medium",
            "hard" to "Hard",
            "very_hard" to "Very Hard",
            "extreme" to "Extreme",
            "drag_guide" to "Drag & Pull Slingshot Backward"
        ),
        "hi" to mapOf(
            "game_title" to "गुलेल रश",
            "play_button" to "खेलें",
            "settings_title" to "सेटिंग्स",
            "language_selection" to "भाषा चयन",
            "dark_mode" to "डार्क मोड",
            "level" to "लेवल",
            "round" to "दौर",
            "victory" to "शानदार जीत!",
            "you_lost" to "आप हार गए",
            "next" to "अगला",
            "replay" to "फिर खेलें",
            "menu" to "मेन्यू",
            "retry" to "पुनः प्रयास",
            "score" to "अंक",
            "best_score" to "सर्वश्रेष्ठ अंक",
            "coins" to "सिक्के",
            "locked" to "बंद",
            "shop_title" to "कॉस्मेटिक दुकान",
            "slingshot_skins" to "गुलेल स्किन्स",
            "projectile_skins" to "गोला स्किन्स",
            "unlock" to "अनलॉक",
            "equipped" to "सज्जित",
            "equip" to "लगाएं",
            "insufficient_coins" to "सिक्के कम हैं!",
            "boss_hp" to "बॉस का स्वास्थ्य",
            "wind" to "हवा",
            "easy" to "आसान",
            "medium" to "मध्यम",
            "hard" to "कठिन",
            "very_hard" to "बहुत कठिन",
            "extreme" to "अति कठिन",
            "drag_guide" to "गुलेल को पीछे खींचें"
        ),
        "bn" to mapOf(
            "game_title" to "গুলতি রাশ",
            "play_button" to "খেলুন",
            "settings_title" to "সেটিংস",
            "language_selection" to "ভাষা নির্বাচন",
            "dark_mode" to "ডার্ক মোড",
            "level" to "লেভেল",
            "round" to "রাউন্ড",
            "victory" to "বিজয়!",
            "you_lost" to "আপনি হেরেছেন",
            "next" to "পরবর্তী",
            "replay" to "আবার খেলুন",
            "menu" to "মেনু",
            "retry" to "পুনরায় চেষ্টা",
            "score" to "স্কোর",
            "best_score" to "সেরা স্কোর",
            "coins" to "কয়েন",
            "locked" to "তালাবদ্ধ",
            "shop_title" to "কসমেটিক শপ",
            "slingshot_skins" to "গুলতির স্কিন",
            "projectile_skins" to "প্রজেক্টাইলের স্কিন",
            "unlock" to "আনলক",
            "equipped" to "সজ্জিত",
            "equip" to "ব্যবহার করুন",
            "insufficient_coins" to "কয়েন যথেষ্ট নয়!",
            "boss_hp" to "বসের লাইফ",
            "wind" to "বাতাস",
            "easy" to "সহজ",
            "medium" to "মাঝারি",
            "hard" to "কঠিন",
            "very_hard" to "খুব কঠিন",
            "extreme" to "চরম কঠিন",
            "drag_guide" to "গুলতি পেছনে টেনে লক্ষ্য করুন"
        )
    )

    // Reactive State Variables
    var currentScreen by mutableStateOf(GameScreen.HOME)
    var currentLanguage by mutableStateOf("en")
    var isDarkMode by mutableStateOf(true)
    var totalCoins by mutableStateOf(0)
    var levelList by mutableStateOf<List<LevelProgressEntity>>(emptyList())

    // Active skin properties
    var selectedSlingshotSkin by mutableStateOf("classic")
    var selectedProjectileSkin by mutableStateOf("default")
    var unlockedSlingshotSkins by mutableStateOf(setOf("classic"))
    var unlockedProjectileSkins by mutableStateOf(setOf("default"))

    // Active Gameplay State
    var currentLevel by mutableStateOf(1)
    var currentRoundIndex by mutableStateOf(0)
    var roundsCount by mutableStateOf(1)
    var projectilesLeft by mutableStateOf(3)
    var totalLevelScore by mutableStateOf(0)
    var roundScore by mutableStateOf(0)

    // Wind vector (affects higher levels)
    var windX by mutableStateOf(0f)

    // Projectile object state
    var projectile by mutableStateOf(Projectile())
    var isProjectileFlying by mutableStateOf(false)
    val slingshotAnchor = Offset(150f, 400f)
    var dragPosition by mutableStateOf(slingshotAnchor)
    var isDragging by mutableStateOf(false)

    // Entities in active physics environment
    var obstacles by mutableStateOf<List<Obstacle>>(emptyList())
    var particles by mutableStateOf<List<Particle>>(emptyList())
    var floatingTexts by mutableStateOf<List<FloatingText>>(emptyList())
    var cameraShakeIntensity by mutableStateOf(0f)
    var gameplayState by mutableStateOf(GameplayState.PLAYING)

    // Boss properties
    var bossHealth by mutableStateOf(0f)
    var bossMaxHealth by mutableStateOf(100f)
    var bossActive by mutableStateOf(false)

    init {
        // Collect DB changes reactively
        viewModelScope.launch {
            repository.initializeDatabaseIfEmpty()

            // Pre-seed Levels 1 to 20 if level progress empty
            repository.allLevelProgress.collectLatest { progress ->
                if (progress.isEmpty()) {
                    for (i in 1..20) {
                        repository.saveLevelProgress(
                            level = i,
                            stars = 0,
                            bestScore = 0,
                            unlocked = (i == 1) // Only level 1 unlocked initially
                        )
                    }
                } else {
                    levelList = progress
                }
            }
        }

        viewModelScope.launch {
            repository.userSettings.collectLatest { settings ->
                settings?.let {
                    currentLanguage = it.language
                    isDarkMode = it.darkMode
                    totalCoins = it.coins
                    selectedSlingshotSkin = it.selectedSlingshotSkin
                    selectedProjectileSkin = it.selectedProjectileSkin
                    unlockedSlingshotSkins = it.unlockedSlingshotSkins.split(",").toSet()
                    unlockedProjectileSkins = it.unlockedProjectileSkins.split(",").toSet()
                }
            }
        }

        // Standard 2D Physics Ticker is now driven via Compose VSYNC-aligned tick loop in GameplayScreen for flawless frame pacing!
    }

    // Translate helper function
    fun t(key: String): String {
        return translations[currentLanguage]?.get(key) ?: key
    }

    fun getDifficultyLabel(level: Int): String {
        return when (level) {
            in 1..3 -> t("easy")
            in 4..7 -> t("medium")
            in 8..12 -> t("hard")
            in 13..17 -> t("very_hard")
            else -> t("extreme")
        }
    }

    // UI State mutations via Repository
    fun updateLanguageSetting(lang: String) {
        viewModelScope.launch {
            repository.updateLanguage(lang)
        }
    }

    fun toggleDarkModeSetting(isOn: Boolean) {
        viewModelScope.launch {
            repository.updateTheme(isOn)
        }
    }

    fun unlockSkinOption(skinType: String, skinId: String, cost: Int, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val success = repository.unlockSkin(skinType, skinId, cost)
            if (success) {
                onSuccess()
            } else {
                onError(t("insufficient_coins"))
            }
        }
    }

    fun selectSkinOption(skinType: String, skinId: String) {
        viewModelScope.launch {
            repository.selectSkin(skinType, skinId)
        }
    }

    // Level Management and Loading
    fun selectAndLoadLevel(levelNum: Int) {
        currentLevel = levelNum
        currentRoundIndex = 0
        totalLevelScore = 0
        roundsCount = when (levelNum) {
            in 1..5 -> levelNum // Levels 1-5 have 1 to 5 rounds
            in 6..10 -> levelNum - 1 // Levels 6-10 have 6 to 8 rounds (e.g. lvl 6=5, 7=6, 8=7, 9=8, 10=8)
            else -> 10 // Levels 11-20 have 10 rounds maximum
        }
        if (roundsCount > 10) roundsCount = 10

        loadRound(roundIdx = 0)
        currentScreen = GameScreen.GAMEPLAY
    }

    private fun loadRound(roundIdx: Int) {
        currentRoundIndex = roundIdx
        roundScore = 0
        gameplayState = GameplayState.PLAYING
        particles = emptyList()
        floatingTexts = emptyList()
        cameraShakeIntensity = 0f

        // Reset projectile state
        projectile = Projectile(
            x = slingshotAnchor.x,
            y = slingshotAnchor.y,
            vx = 0f,
            vy = 0f,
            isFlying = false,
            trail = emptyList()
        )
        isProjectileFlying = false
        isDragging = false
        dragPosition = slingshotAnchor

        // Set wind for hard levels
        windX = if (currentLevel >= 8) {
            // Wind adds challenging sideways drift
            val sign = if (Math.random() > 0.5) 1f else -1f
            sign * (15f + (currentLevel * 3f))
        } else {
            0f
        }

        // Set projectiles count based on difficulty
        projectilesLeft = when (currentLevel) {
            in 1..3 -> 4
            in 4..7 -> 3
            in 8..12 -> 3
            else -> 2 // Extreme level restrictions
        }

        // Spawn obstacles and enemies based on level & round layout
        buildRoundEnvironment(currentLevel, roundIdx)
    }

    // Generates creative layouts of glass, wood, stone, TNT, moving platforms and bosses
    private fun buildRoundEnvironment(level: Int, round: Int) {
        val list = mutableListOf<Obstacle>()
        bossActive = false

        val isBossLevel = level % 5 == 0 && round == roundsCount - 1 // Last round of 5th levels is boss

        if (isBossLevel) {
            bossActive = true
            bossMaxHealth = when (level) {
                5 -> 800f
                10 -> 1500f
                15 -> 2500f
                20 -> 4000f
                else -> 1000f
            }
            bossHealth = bossMaxHealth

            // Boss spawn
            list.add(
                Obstacle(
                    type = ObstacleType.BOSS,
                    x = 800f,
                    y = 350f,
                    width = 80f,
                    height = 80f,
                    health = bossHealth,
                    maxHealth = bossMaxHealth,
                    pointsValue = 2000
                )
            )

            // Boss shielding obstacles
            when (level) {
                5 -> {
                    // Gorgon: Wood barrier in front, back walls to bounce off
                    list.add(Obstacle(ObstacleType.WOOD, 700f, 450f, 25f, 150f, health = 150f, maxHealth = 150f, pointsValue = 100))
                    list.add(Obstacle(ObstacleType.WOOD, 700f, 325f, 100f, 25f, health = 150f, maxHealth = 150f, pointsValue = 100))
                    // Indestructible back bounce-wall to enforce weakpoint logic
                    list.add(Obstacle(ObstacleType.METAL, 920f, 350f, 30f, 350f, health = 10000f, maxHealth = 10000f, pointsValue = 0))
                }
                10 -> {
                    // Mecha-Beak: Moving stone protective shield
                    list.add(Obstacle(ObstacleType.STONE, 680f, 350f, 30f, 100f, health = 400f, maxHealth = 400f, pointsValue = 200,
                        isMoving = true, moveRange = 120f, moveSpeed = 2f, startY = 350f))
                    // TNT above boss
                    list.add(Obstacle(ObstacleType.TNT, 800f, 220f, 40f, 40f, health = 10f, maxHealth = 10f, pointsValue = 300))
                }
                15 -> {
                    // Goliath Golem: heavy stone and metal fortifications, glass windows
                    list.add(Obstacle(ObstacleType.STONE, 720f, 450f, 40f, 180f, health = 500f, maxHealth = 500f, pointsValue = 200))
                    list.add(Obstacle(ObstacleType.GLASS, 720f, 320f, 40f, 80f, health = 30f, maxHealth = 30f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.TNT, 720f, 250f, 40f, 40f, health = 10f, maxHealth = 10f, pointsValue = 300))
                    list.add(Obstacle(ObstacleType.STONE, 880f, 450f, 40f, 180f, health = 500f, maxHealth = 500f, pointsValue = 200))
                }
                20 -> {
                    // Emperor Void: Gravity warping platform and shields
                    list.add(Obstacle(ObstacleType.METAL, 650f, 350f, 30f, 200f, health = 99999f, maxHealth = 99999f, pointsValue = 0,
                        isMoving = true, moveRange = 150f, moveSpeed = 3f, startY = 350f))
                    list.add(Obstacle(ObstacleType.GLASS, 800f, 250f, 120f, 20f, health = 30f, maxHealth = 30f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.TNT, 880f, 350f, 40f, 40f, health = 10f, maxHealth = 10f, pointsValue = 300))
                }
            }
        } else {
            // Normal Level layout builders (Levels 1-20, Rounds 1-10)
            // Layout is determined by level and round to create exciting variety
            val seed = (level * 7 + round * 13) % 6
            when (seed) {
                0 -> {
                    // Pyramid / Castle layout
                    list.add(Obstacle(ObstacleType.WOOD, 650f, 480f, 30f, 100f, health = 120f, maxHealth = 120f, pointsValue = 100))
                    list.add(Obstacle(ObstacleType.WOOD, 770f, 480f, 30f, 100f, health = 120f, maxHealth = 120f, pointsValue = 100))
                    list.add(Obstacle(ObstacleType.WOOD, 710f, 410f, 150f, 25f, health = 100f, maxHealth = 100f, pointsValue = 100))
                    list.add(Obstacle(ObstacleType.GLASS, 710f, 360f, 40f, 60f, health = 25f, maxHealth = 25f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.ENEMY, 710f, 450f, 35f, 35f, health = 30f, maxHealth = 30f, pointsValue = 500))
                    if (level > 3) {
                        list.add(Obstacle(ObstacleType.ENEMY, 710f, 310f, 35f, 35f, health = 50f, maxHealth = 50f, pointsValue = 500))
                    }
                }
                1 -> {
                    // TNT Tower
                    list.add(Obstacle(ObstacleType.STONE, 700f, 470f, 40f, 120f, health = 300f, maxHealth = 300f, pointsValue = 200))
                    list.add(Obstacle(ObstacleType.TNT, 700f, 380f, 40f, 40f, health = 10f, maxHealth = 10f, pointsValue = 300))
                    list.add(Obstacle(ObstacleType.STONE, 700f, 320f, 120f, 30f, health = 250f, maxHealth = 250f, pointsValue = 200))
                    list.add(Obstacle(ObstacleType.ENEMY, 670f, 275f, 35f, 35f, health = 40f, maxHealth = 40f, pointsValue = 500))
                    list.add(Obstacle(ObstacleType.ENEMY, 730f, 275f, 35f, 35f, health = 40f, maxHealth = 40f, pointsValue = 500))
                }
                2 -> {
                    // Double decker shelves
                    list.add(Obstacle(ObstacleType.WOOD, 600f, 480f, 20f, 100f, health = 100f, maxHealth = 100f, pointsValue = 100))
                    list.add(Obstacle(ObstacleType.WOOD, 750f, 480f, 20f, 100f, health = 100f, maxHealth = 100f, pointsValue = 100))
                    list.add(Obstacle(ObstacleType.WOOD, 675f, 420f, 180f, 20f, health = 100f, maxHealth = 100f, pointsValue = 100))

                    list.add(Obstacle(ObstacleType.GLASS, 630f, 360f, 20f, 80f, health = 20f, maxHealth = 20f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.GLASS, 720f, 360f, 20f, 80f, health = 20f, maxHealth = 20f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.WOOD, 675f, 310f, 120f, 20f, health = 100f, maxHealth = 100f, pointsValue = 100))

                    list.add(Obstacle(ObstacleType.ENEMY, 675f, 480f, 35f, 35f, health = 40f, maxHealth = 40f, pointsValue = 500))
                    list.add(Obstacle(ObstacleType.ENEMY, 675f, 360f, 35f, 35f, health = 40f, maxHealth = 40f, pointsValue = 500))
                }
                3 -> {
                    // Moving platform challenge (Level >= 4)
                    if (level >= 4) {
                        list.add(Obstacle(ObstacleType.METAL, 700f, 350f, 120f, 25f, health = 10000f, maxHealth = 10000f, pointsValue = 0,
                            isMoving = true, moveRange = 100f, moveSpeed = 1.5f, startY = 350f))
                        list.add(Obstacle(ObstacleType.ENEMY, 700f, 315f, 35f, 35f, health = 50f, maxHealth = 50f, pointsValue = 500))
                        list.add(Obstacle(ObstacleType.WOOD, 700f, 485f, 40f, 110f, health = 120f, maxHealth = 120f, pointsValue = 100))
                        list.add(Obstacle(ObstacleType.ENEMY, 700f, 415f, 35f, 35f, health = 50f, maxHealth = 50f, pointsValue = 500))
                    } else {
                        // Simple starter blocks
                        list.add(Obstacle(ObstacleType.GLASS, 700f, 480f, 50f, 100f, health = 20f, maxHealth = 20f, pointsValue = 50))
                        list.add(Obstacle(ObstacleType.ENEMY, 700f, 410f, 35f, 35f, health = 30f, maxHealth = 30f, pointsValue = 500))
                    }
                }
                4 -> {
                    // Stone fort with explosive bottom
                    list.add(Obstacle(ObstacleType.TNT, 710f, 500f, 40f, 40f, health = 10f, maxHealth = 10f, pointsValue = 300))
                    list.add(Obstacle(ObstacleType.STONE, 630f, 450f, 30f, 160f, health = 400f, maxHealth = 400f, pointsValue = 200))
                    list.add(Obstacle(ObstacleType.STONE, 790f, 450f, 30f, 160f, health = 400f, maxHealth = 400f, pointsValue = 200))
                    list.add(Obstacle(ObstacleType.STONE, 710f, 350f, 190f, 30f, health = 300f, maxHealth = 300f, pointsValue = 200))
                    list.add(Obstacle(ObstacleType.ENEMY, 710f, 310f, 35f, 35f, health = 55f, maxHealth = 55f, pointsValue = 500))
                }
                else -> {
                    // Glass fragility tower
                    list.add(Obstacle(ObstacleType.GLASS, 650f, 480f, 20f, 100f, health = 20f, maxHealth = 20f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.GLASS, 750f, 480f, 20f, 100f, health = 20f, maxHealth = 20f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.GLASS, 700f, 420f, 140f, 20f, health = 20f, maxHealth = 20f, pointsValue = 50))
                    list.add(Obstacle(ObstacleType.ENEMY, 700f, 470f, 35f, 35f, health = 30f, maxHealth = 30f, pointsValue = 500))
                }
            }
        }
        obstacles = list
    }

    // Drag Actions
    fun onDragStart() {
        if (gameplayState == GameplayState.PLAYING && !projectile.isFlying) {
            isDragging = true
            dragPosition = slingshotAnchor
        }
    }

    fun onDrag(offset: Offset) {
        if (isDragging) {
            // Constrain pull distance
            val dx = offset.x - slingshotAnchor.x
            val dy = offset.y - slingshotAnchor.y
            val distance = sqrt(dx * dx + dy * dy)
            val maxDragRadius = 80f

            if (distance <= maxDragRadius) {
                dragPosition = offset
            } else {
                val ratio = maxDragRadius / distance
                dragPosition = Offset(
                    slingshotAnchor.x + dx * ratio,
                    slingshotAnchor.y + dy * ratio
                )
            }

            // Play stretch sound with proportional tone pitch
            val stretchDistance = sqrt(
                (dragPosition.x - slingshotAnchor.x).pow(2) +
                (dragPosition.y - slingshotAnchor.y).pow(2)
            )
            SoundManager.playStretch(stretchDistance / maxDragRadius)
        }
    }

    fun onDragRelease() {
        if (isDragging) {
            isDragging = false
            SoundManager.playLaunch()

            val dx = slingshotAnchor.x - dragPosition.x
            val dy = slingshotAnchor.y - dragPosition.y

            // Release launch velocity proportional to pull distance
            val speedFactor = 12f
            val launchVx = dx * speedFactor
            val launchVy = dy * speedFactor

            projectile = Projectile(
                x = slingshotAnchor.x,
                y = slingshotAnchor.y,
                vx = launchVx,
                vy = launchVy,
                isFlying = true,
                trail = emptyList()
            )
            isProjectileFlying = true
        }
    }

    // Physics Frame Tick driven by Compose UI
    fun updatePhysics(dt: Float) {
        updatePhysicsLoop(dt)
    }

    private fun updatePhysicsLoop(dt: Float) {
        // 1. Decay camera shake
        if (cameraShakeIntensity > 0f) {
            cameraShakeIntensity = (cameraShakeIntensity - 0.5f).coerceAtLeast(0f)
        }

        // 2. Ticks for particles and text (only process if they are not empty)
        if (particles.isNotEmpty()) {
            particles = particles.mapNotNull { p ->
                p.x += p.vx * dt
                p.y += p.vy * dt
                p.alpha -= p.decay
                if (p.alpha > 0f) p else null
            }
        }

        if (floatingTexts.isNotEmpty()) {
            floatingTexts = floatingTexts.mapNotNull { f ->
                f.y -= 40f * dt // float upward
                f.alpha -= 0.02f
                if (f.alpha > 0f) f else null
            }
        }

        // 3. Update moving obstacles / platforms (only map if there are actually moving ones)
        if (obstacles.any { it.isMoving }) {
            obstacles = obstacles.map { obs ->
                if (obs.isMoving) {
                    obs.moveProgress += dt * obs.moveSpeed
                    val bounceSine = sin(obs.moveProgress)
                    val newY = obs.startY + bounceSine * obs.moveRange
                    obs.copy(y = newY)
                } else {
                    obs
                }
            }
        }

        // 4. Update projectile kinematics and bounce reflection
        if (projectile.isFlying) {
            val proj = projectile.copy()

            // Apply gravity + wind drift
            proj.vy += 450f * dt // standard gravity down
            proj.vx += windX * dt // wind force sideways

            // Air dampening
            proj.vx *= 0.995f
            proj.vy *= 0.995f

            // Update coords
            proj.x += proj.vx * dt
            proj.y += proj.vy * dt

            // Update trailing coordinates
            val currentTrail = proj.trail.toMutableList()
            currentTrail.add(Offset(proj.x, proj.y))
            if (currentTrail.size > 20) {
                currentTrail.removeAt(0)
            }
            proj.trail = currentTrail

            // Bounce on Ground (y = 520f)
            val groundY = 520f
            if (proj.y >= groundY - proj.radius) {
                proj.y = groundY - proj.radius
                proj.vy = -proj.vy * 0.45f // elasticity bounce dampening
                proj.vx *= 0.75f // drag friction
                cameraShakeIntensity = (cameraShakeIntensity + 1f).coerceAtMost(8f)

                // Ground landing smoke particles
                spawnImpactParticles(proj.x, groundY, Color.LightGray, 4)

                // If projectile stops moving, trigger round state evaluation
                if (abs(proj.vx) < 15f && abs(proj.vy) < 15f) {
                    proj.isFlying = false
                    proj.vx = 0f
                    proj.vy = 0f
                    isProjectileFlying = false
                    evaluateRoundProgression()
                }
            }

            // Offscreen bounds check
            if (proj.x < -100f || proj.x > 1100f || proj.y > 600f) {
                proj.isFlying = false
                isProjectileFlying = false
                evaluateRoundProgression()
            }

            // Collision with Active Obstacles/Enemies
            obstacles.forEach { obstacle ->
                if (obstacle.health > 0f) {
                    val wasCollision = checkAndResolveCircleRectCollision(proj, obstacle)
                    if (wasCollision) {
                        // Impact force formula
                        val speed = sqrt(proj.vx.pow(2) + proj.vy.pow(2))
                        val damage = (speed * 0.08f).coerceAtLeast(15f)

                        // Reduce health
                        val oldHealth = obstacle.health
                        obstacle.health = (obstacle.health - damage).coerceAtLeast(0f)

                        // Screen Shake and particle spray
                        cameraShakeIntensity = (cameraShakeIntensity + (damage * 0.1f)).coerceAtMost(10f)
                        val color = getObstacleColor(obstacle.type)
                        spawnImpactParticles(proj.x, proj.y, color, 12)

                        // Floating Damage indicator
                        addFloatingText("-${damage.toInt()}", proj.x, proj.y - 20f, color)

                        // Destroyed trigger
                        if (obstacle.health <= 0f && oldHealth > 0f) {
                            handleObstacleDestroyed(obstacle)
                        } else {
                            // play strike sound
                            SoundManager.playClick()
                        }
                    }
                }
            }

            projectile = proj
        }
    }

    private fun handleObstacleDestroyed(obs: Obstacle) {
        // Add score and cash reward
        val points = obs.pointsValue
        roundScore += points
        totalLevelScore += points

        // Add coins!
        val earnedCoins = points / 20
        viewModelScope.launch {
            repository.addCoins(earnedCoins)
        }

        addFloatingText("+$points", obs.x, obs.y, Color.Green)

        // Visual Explosion / Shatter details
        val particleColor = getObstacleColor(obs.type)
        spawnImpactParticles(obs.x, obs.y, particleColor, 25)

        if (obs.type == ObstacleType.TNT) {
            // Explosive detonation damages surrounding targets in 180f radius
            SoundManager.playExplosion()
            cameraShakeIntensity = 10f
            spawnImpactParticles(obs.x, obs.y, Color.Red, 40)
            spawnImpactParticles(obs.x, obs.y, Color(0xFFFF9800), 20) // Orange sparks

            obstacles.forEach { other ->
                if (other.id != obs.id && other.health > 0f) {
                    val dist = sqrt((other.x - obs.x).pow(2) + (other.y - obs.y).pow(2))
                    if (dist <= 180f) {
                        val tntDamage = 350f * (1f - dist / 180f)
                        val beforeHp = other.health
                        other.health = (other.health - tntDamage).coerceAtLeast(0f)
                        addFloatingText("BLAST! -${tntDamage.toInt()}", other.x, other.y - 15f, Color.Red)
                        spawnImpactParticles(other.x, other.y, getObstacleColor(other.type), 10)

                        if (other.health <= 0f && beforeHp > 0f) {
                            handleObstacleDestroyed(other)
                        }
                    }
                }
            }
        } else if (obs.type == ObstacleType.ENEMY) {
            // Enemy popped!
            SoundManager.playExplosion() // Pop sound
            spawnImpactParticles(obs.x, obs.y, Color(0x8BC34A), 30) // Toxic green splat
        } else if (obs.type == ObstacleType.BOSS) {
            bossHealth = 0f
            bossActive = false
            SoundManager.playVictory()
            spawnImpactParticles(obs.x, obs.y, Color.Yellow, 50)
            addFloatingText("BOSS DEFEATED!", obs.x, obs.y - 40f, Color.Yellow)
        }
    }

    private fun evaluateRoundProgression() {
        if (gameplayState != GameplayState.PLAYING) return
        // Count surviving targets that the player must destroy
        // Surviving list includes ENEMY and BOSS objects
        val targetsAlive = obstacles.count { (it.type == ObstacleType.ENEMY || it.type == ObstacleType.BOSS) && it.health > 0f }

        if (targetsAlive == 0) {
            // Round cleared!
            if (currentRoundIndex + 1 < roundsCount) {
                gameplayState = GameplayState.ROUND_CLEARED
                viewModelScope.launch {
                    delay(1500)
                    loadRound(currentRoundIndex + 1)
                }
            } else {
                // Completed all rounds -> Level Win!
                triggerLevelWin()
            }
        } else {
            // Still targets remaining, check ammo/projectiles
            if (projectilesLeft > 0) {
                // Return projectile to launcher anchor for another shot
                projectilesLeft--
                if (projectilesLeft > 0) {
                    projectile = Projectile(
                        x = slingshotAnchor.x,
                        y = slingshotAnchor.y,
                        isFlying = false,
                        trail = emptyList()
                    )
                    isProjectileFlying = false
                } else {
                    // Let debris settle, then check if they died or lost
                    viewModelScope.launch {
                        delay(2000)
                        val finalTargets = obstacles.count { (it.type == ObstacleType.ENEMY || it.type == ObstacleType.BOSS) && it.health > 0f }
                        if (finalTargets == 0) {
                            triggerLevelWin()
                        } else {
                            triggerLevelLost()
                        }
                    }
                }
            } else {
                triggerLevelLost()
            }
        }
    }

    private fun triggerLevelWin() {
        gameplayState = GameplayState.LEVEL_WON
        SoundManager.playVictory()

        // Calculate stars based on ammo efficiency
        val stars = when {
            projectilesLeft >= 2 -> 3
            projectilesLeft == 1 -> 2
            else -> 1
        }

        // Coins rewards
        val coinsReward = 50 + (projectilesLeft * 25) + if (currentLevel % 5 == 0) 150 else 0 // Boss bonus
        viewModelScope.launch {
            repository.addCoins(coinsReward)

            // Save Progress
            val currentBest = levelList.find { it.levelNumber == currentLevel }?.bestScore ?: 0
            val best = max(currentBest, totalLevelScore)
            repository.saveLevelProgress(
                level = currentLevel,
                stars = max(levelList.find { it.levelNumber == currentLevel }?.stars ?: 0, stars),
                bestScore = best,
                unlocked = true
            )

            // Unlock next level (Levels 2-20)
            repository.unlockNextLevel(currentLevel)
        }
    }

    private fun triggerLevelLost() {
        gameplayState = GameplayState.LEVEL_LOST
        SoundManager.playDefeat()
    }

    // Play/Retry actions
    fun restartLevel() {
        selectAndLoadLevel(currentLevel)
    }

    fun proceedToNextLevel() {
        if (currentLevel < 20) {
            selectAndLoadLevel(currentLevel + 1)
        } else {
            currentScreen = GameScreen.LEVEL_SELECTION
        }
    }

    // Mathematical Circle-Rectangle Physics Intersection Engine
    private fun checkAndResolveCircleRectCollision(proj: Projectile, obs: Obstacle): Boolean {
        val left = obs.x - obs.width / 2f
        val right = obs.x + obs.width / 2f
        val top = obs.y - obs.height / 2f
        val bottom = obs.y + obs.height / 2f

        // Closest point coordinates on the box
        val closestX = proj.x.coerceIn(left, right)
        val closestY = proj.y.coerceIn(top, bottom)

        val dx = proj.x - closestX
        val dy = proj.y - closestY
        val distance = sqrt(dx * dx + dy * dy)

        if (distance < proj.radius) {
            // Collision resolution
            val normalX = if (distance > 0f) dx / distance else 0f
            val normalY = if (distance > 0f) dy / distance else -1f

            // Resolve overlapping by shifting circles along normal axis
            proj.x = closestX + normalX * proj.radius
            proj.y = closestY + normalY * proj.radius

            // Reflect the speed based on contact face
            val dotProduct = proj.vx * normalX + proj.vy * normalY
            if (dotProduct < 0f) {
                val elasticity = 0.5f // wood/stone bounce damping
                proj.vx -= 2f * dotProduct * normalX * elasticity
                proj.vy -= 2f * dotProduct * normalY * elasticity
            }
            return true
        }
        return false
    }

    // Particle effect generators
    private fun spawnImpactParticles(x: Float, y: Float, color: Color, amount: Int) {
        val list = particles.toMutableList()
        for (i in 0 until amount) {
            val angle = Math.random() * 2.0 * Math.PI
            val speed = 50f + Math.random() * 180f
            list.add(
                Particle(
                    x = x,
                    y = y,
                    vx = (cos(angle) * speed).toFloat(),
                    vy = (sin(angle) * speed).toFloat() - 30f, // boost upward
                    color = color,
                    size = 4f + (Math.random() * 8f).toFloat(),
                    decay = 0.02f + (Math.random() * 0.03f).toFloat()
                )
            )
        }
        particles = list
    }

    private fun addFloatingText(text: String, x: Float, y: Float, color: Color) {
        val list = floatingTexts.toMutableList()
        list.add(FloatingText(text = text, x = x, y = y, color = color))
        floatingTexts = list
    }

    private fun getObstacleColor(type: ObstacleType): Color {
        return when (type) {
            ObstacleType.WOOD -> Color(0xFF8B5A2B) // Brown
            ObstacleType.STONE -> Color(0xFF7A7A7A) // Gray
            ObstacleType.GLASS -> Color(0xFF80DEEA) // Cyan Specular
            ObstacleType.METAL -> Color(0xFFB0BEC5) // Steel-blue
            ObstacleType.TNT -> Color(0xFFD32F2F) // Explosion Red
            ObstacleType.ENEMY -> Color(0xFF4CAF50) // Green
            ObstacleType.BOSS -> Color(0xFF9C27B0) // Deep Purple Boss
        }
    }
}
