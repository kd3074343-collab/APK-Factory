package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.GameScreen
import com.example.ui.GameViewModel
import com.example.ui.SoundManager
import kotlinx.coroutines.launch

data class CosmeticItem(
    val id: String,
    val name: String,
    val description: String,
    val cost: Int,
    val displayColor: Color,
    val type: String // "slingshot" or "projectile"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(viewModel: GameViewModel) {
    var activeTab by remember { mutableStateOf(0) } // 0 = Slingshots, 1 = Projectiles
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val slingshotSkins = listOf(
        CosmeticItem("classic", "Classic Oak", "Sturdy traditional wooden slingshot", 0, Color(0xFF8B5A2B), "slingshot"),
        CosmeticItem("golden", "Aurum Royale", "Pure gold frame with glowing golden rubber band", 150, Color(0xFFFFD700), "slingshot"),
        CosmeticItem("cyber", "Cybernetic Grid", "Polished dark carbon with neon cyan energy bands", 300, Color(0xFF00E5FF), "slingshot"),
        CosmeticItem("inferno", "Hellfire Obsidian", "Magma-crust obsidians dripping slow lava sparks", 500, Color(0xFFFF3D00), "slingshot")
    )

    val projectileSkins = listOf(
        CosmeticItem("default", "Standard Sphere", "Polished red cartoon projectile", 0, Color(0xFFD32F2F), "projectile"),
        CosmeticItem("fireball", "Pyros Ember", "Meteor rock trailing burning flame sparks", 100, Color(0xFFFF9100), "projectile"),
        CosmeticItem("plasma", "Starlight Orb", "High energy plasma ball with static electric halos", 250, Color(0xFFD500F9), "projectile"),
        CosmeticItem("bubble", "Aqua Specular", "Slick water bubble with reflecting specular highlights", 400, Color(0xFF2979FF), "projectile")
    )

    val displayedSkins = if (activeTab == 0) slingshotSkins else projectileSkins

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = viewModel.t("shop_title"),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            SoundManager.playClick()
                            viewModel.currentScreen = GameScreen.HOME
                        },
                        modifier = Modifier.testTag("shop_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Default.ArrowBack,
                            contentDescription = "Back to Menu"
                        )
                    }
                },
                actions = {
                    // Balance indicator
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.padding(end = 16.dp).testTag("shop_coins_balance")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "🪙", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${viewModel.totalCoins}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Header Row
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().testTag("shop_tab_row")
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = {
                        SoundManager.playClick()
                        activeTab = 0
                    },
                    text = { Text(viewModel.t("slingshot_skins"), fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("slingshot_skins_tab")
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = {
                        SoundManager.playClick()
                        activeTab = 1
                    },
                    text = { Text(viewModel.t("projectile_skins"), fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("projectile_skins_tab")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Lazy Column for skins list
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .testTag("shop_skins_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(displayedSkins) { skin ->
                    val isUnlocked = if (skin.type == "slingshot") {
                        viewModel.unlockedSlingshotSkins.contains(skin.id)
                    } else {
                        viewModel.unlockedProjectileSkins.contains(skin.id)
                    }

                    val isEquipped = if (skin.type == "slingshot") {
                        viewModel.selectedSlingshotSkin == skin.id
                    } else {
                        viewModel.selectedProjectileSkin == skin.id
                    }

                    ShopItemCard(
                        skin = skin,
                        isUnlocked = isUnlocked,
                        isEquipped = isEquipped,
                        viewModel = viewModel,
                        onUnlock = {
                            viewModel.unlockSkinOption(
                                skinType = skin.type,
                                skinId = skin.id,
                                cost = skin.cost,
                                onSuccess = {
                                    SoundManager.playVictory()
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Successfully unlocked ${skin.name}!")
                                    }
                                    // Auto-equip upon purchase
                                    viewModel.selectSkinOption(skin.type, skin.id)
                                },
                                onError = { msg ->
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(msg)
                                    }
                                }
                            )
                        },
                        onEquip = {
                            SoundManager.playClick()
                            viewModel.selectSkinOption(skin.type, skin.id)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ShopItemCard(
    skin: CosmeticItem,
    isUnlocked: Boolean,
    isEquipped: Boolean,
    viewModel: GameViewModel,
    onUnlock: () -> Unit,
    onEquip: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEquipped) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
            else MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shop_skin_card_${skin.id}"),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isEquipped) 4.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Skin display sphere indicator
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(skin.displayColor.copy(alpha = 0.15f))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = skin.displayColor,
                    modifier = Modifier.size(32.dp),
                    shadowElevation = 4.dp
                ) {}
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text descriptions
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = skin.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = skin.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    lineHeight = 16.sp
                )
            }

            // Action Buttons (Unlock / Equip / Equipped)
            Box {
                if (isUnlocked) {
                    if (isEquipped) {
                        Button(
                            onClick = {},
                            enabled = false,
                            colors = ButtonDefaults.buttonColors(
                                disabledContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                disabledContentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("equipped_button_${skin.id}")
                        ) {
                            Text(viewModel.t("equipped"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = onEquip,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("equip_button_${skin.id}")
                        ) {
                            Text(viewModel.t("equip"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Button(
                        onClick = onUnlock,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("unlock_button_${skin.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "🪙", fontSize = 12.sp, modifier = Modifier.padding(end = 4.dp))
                            Text(
                                text = "${skin.cost}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
