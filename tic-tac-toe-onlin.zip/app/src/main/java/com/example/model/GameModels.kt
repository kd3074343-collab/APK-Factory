package com.example.model

data class PlayerInfo(
    val uid: String = "",
    val displayName: String = "",
    val photoUrl: String = ""
)

data class GameRoom(
    val id: String = "",
    val playerX: PlayerInfo? = null,
    val playerO: PlayerInfo? = null,
    val board: List<String> = List(9) { "" },
    val turn: String = "",
    val status: String = "WAITING", // WAITING, PLAYING, FINISHED, OPPONENT_LEFT
    val winner: String = "", // UID of the winner, or "DRAW"
    val rematchX: Boolean = false,
    val rematchO: Boolean = false,
    val playerXOnline: Boolean = true,
    val playerOOnline: Boolean = true
)
