package com.example

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.model.GameRoom
import com.example.model.PlayerInfo
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.Screen
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class MainActivity : ComponentActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure Google Sign-In using the Web Client ID from the Firebase metadata configuration
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("872470546997-m87hpmkefa63chli0bl1pklijilj20hn.apps.googleusercontent.com")
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        setContent {
            MyApplicationTheme {
                val viewModel: MainViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()
                val activeRoom by viewModel.activeRoom.collectAsState()
                val currentUser by viewModel.currentUser.collectAsState()
                val errorMessage by viewModel.errorMessage.collectAsState()
                val isSearching by viewModel.isSearching.collectAsState()

                val context = LocalContext.current

                // Launcher for Google Account Picker
                val googleSignInLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                    try {
                        val account = task.getResult(ApiException::class.java)
                        account?.idToken?.let { idToken ->
                            val credential = GoogleAuthProvider.getCredential(idToken, null)
                            FirebaseAuth.getInstance().signInWithCredential(credential)
                                .addOnCompleteListener { authResult ->
                                    if (!authResult.isSuccessful) {
                                        Toast.makeText(
                                            context,
                                            "Authentication Failed: ${authResult.exception?.message}",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                        } ?: run {
                            Toast.makeText(context, "Failed to retrieve Google token", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: ApiException) {
                        Toast.makeText(context, "Sign-in error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }

                LaunchedEffect(errorMessage) {
                    errorMessage?.let {
                        Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                        viewModel.clearError()
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                            },
                            label = "ScreenTransition"
                        ) { screen ->
                            when (screen) {
                                Screen.LOGIN -> {
                                    LoginScreen(
                                        onSignInClick = {
                                            googleSignInLauncher.launch(googleSignInClient.signInIntent)
                                        },
                                        onGuestSignInClick = { nickname ->
                                            viewModel.signInAnonymously(nickname)
                                        }
                                    )
                                }
                                Screen.HOME -> {
                                    HomeScreen(
                                        currentUser = currentUser,
                                        onSignOut = {
                                            googleSignInClient.signOut()
                                            viewModel.signOut()
                                        },
                                        onRandomMatch = { viewModel.startRandomMatchmaking() },
                                        onCreateRoom = { viewModel.createPrivateRoom() },
                                        onJoinRoom = { code, errorCallback ->
                                            viewModel.joinPrivateRoom(code, errorCallback)
                                        }
                                    )
                                }
                                Screen.MATCHMAKING -> {
                                    MatchmakingScreen(
                                        onCancel = { viewModel.cancelMatchmaking() }
                                    )
                                }
                                Screen.GAME_ROOM -> {
                                    activeRoom?.let { room ->
                                        GameRoomScreen(
                                            room = room,
                                            myUid = currentUser?.uid ?: "",
                                            onCellClick = { idx -> viewModel.makeMove(idx) },
                                            onRematchClick = { viewModel.requestRematch() },
                                            onLeaveClick = { viewModel.leaveRoom() }
                                        )
                                    } ?: Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(
    onSignInClick: () -> Unit,
    onGuestSignInClick: (String) -> Unit
) {
    var showGuestDialog by remember { mutableStateOf(false) }
    var guestNameInput by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF121824),
                        Color(0xFF1E293B)
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Animated Glowing Grid header representation
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "HeaderGlow")
                val glowAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.4f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1500, easing = EaseInOutSine),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "Glow"
                )

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeW = 4.dp.toPx()
                    val padding = 15.dp.toPx()
                    val width = size.width
                    val step = width / 3

                    // Vertical lines
                    drawLine(
                        color = Color(0xFF2196F3).copy(alpha = glowAlpha),
                        start = androidx.compose.ui.geometry.Offset(step, padding),
                        end = androidx.compose.ui.geometry.Offset(step, width - padding),
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color(0xFFFF5722).copy(alpha = glowAlpha),
                        start = androidx.compose.ui.geometry.Offset(step * 2, padding),
                        end = androidx.compose.ui.geometry.Offset(step * 2, width - padding),
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )

                    // Horizontal lines
                    drawLine(
                        color = Color(0xFF2196F3).copy(alpha = glowAlpha),
                        start = androidx.compose.ui.geometry.Offset(padding, step),
                        end = androidx.compose.ui.geometry.Offset(width - padding, step),
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color(0xFFFF5722).copy(alpha = glowAlpha),
                        start = androidx.compose.ui.geometry.Offset(padding, step * 2),
                        end = androidx.compose.ui.geometry.Offset(width - padding, step * 2),
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Tic-Tac-Toe Online",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Play real-time multiplayer with anyone, anywhere. Match instantly or host private rooms.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Continue with Google button
            Button(
                onClick = onSignInClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(8.dp, RoundedCornerShape(12.dp))
                    .testTag("login_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Canvas(modifier = Modifier.size(24.dp)) {
                        val strokeWidth = 3.dp.toPx()
                        drawArc(
                            color = Color(0xFF4285F4),
                            startAngle = 0f,
                            sweepAngle = 90f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = Color(0xFF34A853),
                            startAngle = 90f,
                            sweepAngle = 90f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = Color(0xFFFBBC05),
                            startAngle = 180f,
                            sweepAngle = 90f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = Color(0xFFEA4335),
                            startAngle = 270f,
                            sweepAngle = 90f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Text(
                        text = "Continue with Google",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Beautiful Divider Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF334155))
                Text(
                    text = "OR",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF334155))
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Play as Guest button
            OutlinedButton(
                onClick = { showGuestDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("guest_login_button"),
                border = BorderStroke(1.dp, Color(0xFF3B82F6)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF3B82F6)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Play as Guest",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    // Guest Registration Dialog
    if (showGuestDialog) {
        AlertDialog(
            onDismissRequest = { showGuestDialog = false },
            title = {
                Text(
                    text = "Guest Profile",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            },
            text = {
                Column {
                    Text(
                        text = "Please enter your nickname to join the online lobby.",
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = guestNameInput,
                        onValueChange = {
                            if (it.length <= 15) {
                                guestNameInput = it
                            }
                        },
                        label = { Text("Nickname") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedLabelColor = Color(0xFF3B82F6),
                            unfocusedLabelColor = Color(0xFF64748B),
                            focusedBorderColor = Color(0xFF3B82F6),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (guestNameInput.isNotBlank()) {
                            showGuestDialog = false
                            onGuestSignInClick(guestNameInput.trim())
                        }
                    },
                    enabled = guestNameInput.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF3B82F6),
                        contentColor = Color.White
                    )
                ) {
                    Text("Start Playing", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGuestDialog = false }) {
                    Text("Cancel", color = Color(0xFF64748B))
                }
            },
            containerColor = Color(0xFF1E293B),
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun HomeScreen(
    currentUser: com.google.firebase.auth.FirebaseUser?,
    onSignOut: () -> Unit,
    onRandomMatch: () -> Unit,
    onCreateRoom: () -> Unit,
    onJoinRoom: (String, (String) -> Unit) -> Unit
) {
    var roomCodeInput by remember { mutableStateOf("") }
    var joinError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        // Top profile and sign out bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val photoUrl = currentUser?.photoUrl?.toString()
            if (!photoUrl.isNullOrEmpty()) {
                AsyncImage(
                    model = photoUrl,
                    contentDescription = "Profile Photo",
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = (currentUser?.displayName ?: "P").take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = currentUser?.displayName ?: "Player",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = currentUser?.email ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B)
                )
            }

            IconButton(onClick = onSignOut) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = "Sign Out",
                    tint = Color(0xFFEF4444)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Game Lobby",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Random Matchmaking Card
        Card(
            onClick = onRandomMatch,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("random_match_button"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(20.dp))
                Column {
                    Text(
                        text = "Random Match",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Match instantly with an online opponent",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Private Room options
        Text(
            text = "Private Matches",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Create Room Card
            Card(
                onClick = onCreateRoom,
                modifier = Modifier
                    .weight(1f)
                    .height(120.dp)
                    .testTag("create_room_button"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color(0xFF3B82F6),
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Create Room",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Join Room Input Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFF334155))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "Join Private Room",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Enter a 6-digit room code to join an active friend's lobby.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = roomCodeInput,
                        onValueChange = {
                            if (it.length <= 6) {
                                roomCodeInput = it.uppercase()
                                joinError = null
                            }
                        },
                        placeholder = { Text("Code") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = Color(0xFF475569)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Button(
                        onClick = {
                            onJoinRoom(roomCodeInput) { err ->
                                joinError = err
                            }
                        },
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("join_room_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Join")
                    }
                }

                if (joinError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = joinError ?: "",
                        color = Color(0xFFEF4444),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun MatchmakingScreen(onCancel: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            RadarAnimation()

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = "Searching for Opponent...",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Please hold on while we find a suitable player to match you with.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))

            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier
                    .width(180.dp)
                    .height(48.dp)
                    .testTag("cancel_matchmaking_button"),
                border = BorderStroke(1.dp, Color(0xFFEF4444)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Cancel Search", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun RadarAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "Radar")
    val pulseScale1 by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 2.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Pulse1"
    )
    val pulseAlpha1 by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Alpha1"
    )

    val pulseScale2 by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 2.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, delayMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Pulse2"
    )
    val pulseAlpha2 by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, delayMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Alpha2"
    )

    Box(
        modifier = Modifier.size(160.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .scale(pulseScale1)
                .background(Color(0x332196F3), shape = CircleShape)
                .border(2.dp, Color(0xFF2196F3).copy(alpha = pulseAlpha1), CircleShape)
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .scale(pulseScale2)
                .background(Color(0x1aFF5722), shape = CircleShape)
                .border(2.dp, Color(0xFFFF5722).copy(alpha = pulseAlpha2), CircleShape)
        )

        Card(
            shape = CircleShape,
            modifier = Modifier.size(72.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    modifier = Modifier.size(32.dp),
                    tint = Color(0xFF3B82F6)
                )
            }
        }
    }
}

@Composable
fun GameRoomScreen(
    room: GameRoom,
    myUid: String,
    onCellClick: (Int) -> Unit,
    onRematchClick: () -> Unit,
    onLeaveClick: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val isPlayerX = (room.playerX?.uid == myUid)
    val isPlayerO = (room.playerO?.uid == myUid)

    val activeTurnName = when (room.turn) {
        room.playerX?.uid -> room.playerX.displayName
        room.playerO?.uid -> room.playerO.displayName ?: "Player O"
        else -> ""
    }

    val isMyTurn = (room.turn == myUid && room.status == "PLAYING")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top GameHeader / Quit bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onLeaveClick) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Leave match",
                    tint = Color.White
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Match Room",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.weight(1f)
            )

            // Room identifier / code if WAITING or Private
            if (room.status == "WAITING" || room.id.length == 6) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.clickable {
                        clipboardManager.setText(AnnotatedString(room.id))
                        Toast.makeText(context, "Room Code Copied!", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CODE: ${room.id}",
                            color = Color(0xFF3B82F6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Copy",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Players vs card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFF334155))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Player X representation
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val pXImage = room.playerX?.photoUrl
                    if (!pXImage.isNullOrEmpty()) {
                        AsyncImage(
                            model = pXImage,
                            contentDescription = "Player X Photo",
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .border(2.dp, Color(0xFF2196F3), CircleShape)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2196F3).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "X",
                                color = Color(0xFF2196F3),
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = room.playerX?.displayName ?: "Waiting...",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(100.dp)
                    )
                    Text(text = "Player X", color = Color(0xFF2196F3), fontSize = 12.sp)
                }

                Text(
                    text = "VS",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )

                // Player O representation
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val pOImage = room.playerO?.photoUrl
                    if (!pOImage.isNullOrEmpty()) {
                        AsyncImage(
                            model = pOImage,
                            contentDescription = "Player O Photo",
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .border(2.dp, Color(0xFFFF5722), CircleShape)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFF5722).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "O",
                                color = Color(0xFFFF5722),
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = room.playerO?.displayName ?: "Waiting...",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(100.dp)
                    )
                    Text(text = "Player O", color = Color(0xFFFF5722), fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Center / gameplay status bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            contentAlignment = Alignment.Center
        ) {
            when (room.status) {
                "WAITING" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Waiting for Player 2 to join...",
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                "PLAYING" -> {
                    Surface(
                        color = if (isMyTurn) Color(0xFF1E293B) else Color.Transparent,
                        border = if (isMyTurn) BorderStroke(1.dp, Color(0xFF334155)) else null,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isMyTurn) "YOUR TURN!" else "${activeTurnName}'s Turn",
                            color = if (isMyTurn) Color(0xFF3B82F6) else Color(0xFF94A3B8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
                "FINISHED" -> {
                    val resultMessage = when (room.winner) {
                        myUid -> "YOU WON! 🎉"
                        "DRAW" -> "IT'S A DRAW! 🤝"
                        else -> "YOU LOST! 😔"
                    }
                    Text(
                        text = resultMessage,
                        color = when (room.winner) {
                            myUid -> Color(0xFF10B981)
                            "DRAW" -> Color(0xFFF59E0B)
                            else -> Color(0xFFEF4444)
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                }
                "OPPONENT_LEFT" -> {
                    Text(
                        text = "Opponent Left the Game",
                        color = Color(0xFFEF4444),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Standard 3x3 game board
        Box(
            modifier = Modifier
                .size(310.dp)
                .background(Color(0xFF1E293B), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            // Drawing the grid lines inside Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val size = size.width
                val step = size / 3
                val strokeW = 3.dp.toPx()

                // Draw lines inside
                // Vertical lines
                drawLine(
                    color = Color(0xFF334155),
                    start = androidx.compose.ui.geometry.Offset(step, 0f),
                    end = androidx.compose.ui.geometry.Offset(step, size),
                    strokeWidth = strokeW
                )
                drawLine(
                    color = Color(0xFF334155),
                    start = androidx.compose.ui.geometry.Offset(step * 2, 0f),
                    end = androidx.compose.ui.geometry.Offset(step * 2, size),
                    strokeWidth = strokeW
                )

                // Horizontal lines
                drawLine(
                    color = Color(0xFF334155),
                    start = androidx.compose.ui.geometry.Offset(0f, step),
                    end = androidx.compose.ui.geometry.Offset(size, step),
                    strokeWidth = strokeW
                )
                drawLine(
                    color = Color(0xFF334155),
                    start = androidx.compose.ui.geometry.Offset(0f, step * 2),
                    end = androidx.compose.ui.geometry.Offset(size, step * 2),
                    strokeWidth = strokeW
                )
            }

            // Cell overlay buttons
            Column(modifier = Modifier.fillMaxSize()) {
                for (row in 0..2) {
                    Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        for (col in 0..2) {
                            val idx = row * 3 + col
                            val mark = room.board.getOrNull(idx) ?: ""
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clickable(
                                        enabled = room.status == "PLAYING" && isMyTurn && mark.isEmpty()
                                    ) {
                                        onCellClick(idx)
                                    }
                                    .testTag("cell_$idx"),
                                contentAlignment = Alignment.Center
                            ) {
                                CellContent(mark = mark)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Post-game controls (Rematch / Leave)
        if (room.status == "FINISHED") {
            val iAgreedRematch = if (isPlayerX) room.rematchX else room.rematchO
            val opponentAgreedRematch = if (isPlayerX) room.rematchO else room.rematchX

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onRematchClick,
                    enabled = !iAgreedRematch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("rematch_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (iAgreedRematch) "Waiting for Opponent..." else "Request Rematch",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (iAgreedRematch && !opponentAgreedRematch) {
                    Text(
                        text = "Waiting for Opponent's rematch consent...",
                        color = Color(0xFFF59E0B),
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                OutlinedButton(
                    onClick = onLeaveClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("leave_room_button"),
                    border = BorderStroke(1.dp, Color(0xFFEF4444)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Leave Match", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (room.status == "OPPONENT_LEFT") {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onLeaveClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("leave_room_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Return to Lobby", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
fun CellContent(mark: String) {
    val scale by animateFloatAsState(
        targetValue = if (mark.isNotEmpty()) 1.0f else 0.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "SymbolScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        if (mark == "X") {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val size = this.size.width * scale
                val offset = (this.size.width - size) / 2
                val strokeWidth = 7.dp.toPx()

                drawLine(
                    color = Color(0xFF2196F3),
                    start = androidx.compose.ui.geometry.Offset(offset, offset),
                    end = androidx.compose.ui.geometry.Offset(offset + size, offset + size),
                    strokeWidth = strokeWidth,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = Color(0xFF2196F3),
                    start = androidx.compose.ui.geometry.Offset(offset + size, offset),
                    end = androidx.compose.ui.geometry.Offset(offset, offset + size),
                    strokeWidth = strokeWidth,
                    cap = StrokeCap.Round
                )
            }
        } else if (mark == "O") {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 7.dp.toPx()
                val radius = (this.size.width / 2 - strokeWidth) * scale

                drawCircle(
                    color = Color(0xFFFF5722),
                    radius = radius,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }
        }
    }
}
