package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ToolsViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ToolDetailScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val viewModel: ToolsViewModel = viewModel()
        var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }

        when (val screen = currentScreen) {
          is Screen.Dashboard -> {
            DashboardScreen(
              viewModel = viewModel,
              onToolClick = { toolId ->
                currentScreen = Screen.ToolDetail(toolId)
              },
              onSettingsClick = {
                currentScreen = Screen.Settings
              }
            )
          }
          is Screen.ToolDetail -> {
            ToolDetailScreen(
              toolId = screen.toolId,
              viewModel = viewModel,
              onBack = { currentScreen = Screen.Dashboard }
            )
          }
          is Screen.Settings -> {
            SettingsScreen(
              onBack = { currentScreen = Screen.Dashboard }
            )
          }
        }
      }
    }
  }
}

sealed interface Screen {
  object Dashboard : Screen
  data class ToolDetail(val toolId: String) : Screen
  object Settings : Screen
}

