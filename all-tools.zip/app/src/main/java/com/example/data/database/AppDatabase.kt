package com.example.data.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// -------------------------------------------------------------------------
// ROOM ENTITIES
// -------------------------------------------------------------------------

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val colorHex: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "checklist_items")
data class ChecklistItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val task: String,
    val isCompleted: Boolean = false,
    val category: String = "General"
)

@Entity(tableName = "favorite_tools")
data class FavoriteToolEntity(
    @PrimaryKey val toolId: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_tools")
data class RecentToolEntity(
    @PrimaryKey val toolId: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "file_vault_items")
data class FileVaultItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val filePath: String,
    val contentHex: String, // Simulated locally-encrypted content
    val passcodeHash: String,
    val timestamp: Long = System.currentTimeMillis()
)

// -------------------------------------------------------------------------
// ROOM DAOS
// -------------------------------------------------------------------------

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: Int)
}

@Dao
interface ChecklistDao {
    @Query("SELECT * FROM checklist_items ORDER BY id DESC")
    fun getAllItems(): Flow<List<ChecklistItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: ChecklistItem)

    @Query("DELETE FROM checklist_items WHERE id = :id")
    suspend fun deleteItemById(id: Int)

    @Query("DELETE FROM checklist_items WHERE isCompleted = 1")
    suspend fun clearCompleted()
}

@Dao
interface FavoriteToolsDao {
    @Query("SELECT toolId FROM favorite_tools")
    fun getFavoriteToolIds(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(fav: FavoriteToolEntity)

    @Query("DELETE FROM favorite_tools WHERE toolId = :toolId")
    suspend fun removeFavorite(toolId: String)
}

@Dao
interface RecentToolsDao {
    @Query("SELECT toolId FROM recent_tools ORDER BY timestamp DESC LIMIT 10")
    fun getRecentToolIds(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addRecent(rec: RecentToolEntity)

    @Query("DELETE FROM recent_tools WHERE toolId = :toolId")
    suspend fun removeRecent(toolId: String)
}

@Dao
interface FileVaultDao {
    @Query("SELECT * FROM file_vault_items ORDER BY timestamp DESC")
    fun getAllVaultItems(): Flow<List<FileVaultItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultItem(item: FileVaultItemEntity)

    @Query("DELETE FROM file_vault_items WHERE id = :id")
    suspend fun deleteVaultItem(id: Int)
}

// -------------------------------------------------------------------------
// ROOM DATABASE
// -------------------------------------------------------------------------

@Database(
    entities = [
        NoteEntity::class,
        ChecklistItem::class,
        FavoriteToolEntity::class,
        RecentToolEntity::class,
        FileVaultItemEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun checklistDao(): ChecklistDao
    abstract fun favoriteToolsDao(): FavoriteToolsDao
    abstract fun recentToolsDao(): RecentToolsDao
    abstract fun fileVaultDao(): FileVaultDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "all_tools_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
