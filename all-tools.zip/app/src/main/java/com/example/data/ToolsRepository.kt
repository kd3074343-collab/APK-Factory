package com.example.data

import com.example.data.database.AppDatabase
import com.example.data.database.ChecklistItem
import com.example.data.database.FavoriteToolEntity
import com.example.data.database.FileVaultItemEntity
import com.example.data.database.NoteEntity
import com.example.data.database.RecentToolEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ToolsRepository(private val db: AppDatabase) {

    // -------------------------------------------------------------------------
    // NOTES OPERATIONS
    // -------------------------------------------------------------------------
    val allNotes: Flow<List<NoteEntity>> = db.noteDao().getAllNotes()

    suspend fun insertNote(note: NoteEntity) = withContext(Dispatchers.IO) {
        db.noteDao().insertNote(note)
    }

    suspend fun deleteNote(id: Int) = withContext(Dispatchers.IO) {
        db.noteDao().deleteNoteById(id)
    }

    // -------------------------------------------------------------------------
    // CHECKLIST OPERATIONS
    // -------------------------------------------------------------------------
    val allChecklistItems: Flow<List<ChecklistItem>> = db.checklistDao().getAllItems()

    suspend fun insertChecklistItem(item: ChecklistItem) = withContext(Dispatchers.IO) {
        db.checklistDao().insertItem(item)
    }

    suspend fun deleteChecklistItem(id: Int) = withContext(Dispatchers.IO) {
        db.checklistDao().deleteItemById(id)
    }

    suspend fun clearCompletedChecklist() = withContext(Dispatchers.IO) {
        db.checklistDao().clearCompleted()
    }

    // -------------------------------------------------------------------------
    // FAVORITE TOOLS OPERATIONS
    // -------------------------------------------------------------------------
    val favoriteToolIds: Flow<List<String>> = db.favoriteToolsDao().getFavoriteToolIds()

    suspend fun addFavorite(toolId: String) = withContext(Dispatchers.IO) {
        db.favoriteToolsDao().addFavorite(FavoriteToolEntity(toolId))
    }

    suspend fun removeFavorite(toolId: String) = withContext(Dispatchers.IO) {
        db.favoriteToolsDao().removeFavorite(toolId)
    }

    // -------------------------------------------------------------------------
    // RECENT TOOLS OPERATIONS
    // -------------------------------------------------------------------------
    val recentToolIds: Flow<List<String>> = db.recentToolsDao().getRecentToolIds()

    suspend fun addRecent(toolId: String) = withContext(Dispatchers.IO) {
        db.recentToolsDao().addRecent(RecentToolEntity(toolId, System.currentTimeMillis()))
    }

    suspend fun removeRecent(toolId: String) = withContext(Dispatchers.IO) {
        db.recentToolsDao().removeRecent(toolId)
    }

    // -------------------------------------------------------------------------
    // FILE LOCKER (VAULT) OPERATIONS
    // -------------------------------------------------------------------------
    val allVaultItems: Flow<List<FileVaultItemEntity>> = db.fileVaultDao().getAllVaultItems()

    suspend fun insertVaultItem(item: FileVaultItemEntity) = withContext(Dispatchers.IO) {
        db.fileVaultDao().insertVaultItem(item)
    }

    suspend fun deleteVaultItem(id: Int) = withContext(Dispatchers.IO) {
        db.fileVaultDao().deleteVaultItem(id)
    }
}
