package com.example.data

data class Tool(
    val id: String,
    val title: String,
    val category: String,
    val description: String,
    val keywords: List<String> = emptyList()
)

object ToolCategories {
    const val FILE_NETWORK = "File & Network"
    const val CAMERA = "Camera Tools"
    const val MEASUREMENT = "Measurement Tools"
    const val AUDIO = "Audio Tools"
    const val PRODUCTIVITY = "Productivity"
    const val HEALTH_FITNESS = "Health & Fitness"
    const val UTILITY = "Utility Tools"
    const val ADVANCED = "Advanced Tools"

    val ALL = listOf(
        FILE_NETWORK,
        CAMERA,
        MEASUREMENT,
        AUDIO,
        PRODUCTIVITY,
        HEALTH_FITNESS,
        UTILITY,
        ADVANCED
    )
}

object ToolsRegistry {
    val ALL_TOOLS = listOf(
        // FILE & NETWORK (15 tools)
        Tool(
            id = "file_transfer",
            title = "File Transfer (Offline)",
            category = ToolCategories.FILE_NETWORK,
            description = "Share and receive files over local WiFi peer-to-peer at high speed.",
            keywords = listOf("share", "send", "receive", "p2p", "local", "wi-fi", "hotspot")
        ),
        Tool(
            id = "music_sync",
            title = "Music Group Sync",
            category = ToolCategories.FILE_NETWORK,
            description = "Sync audio playback across multiple devices on the same WiFi network.",
            keywords = listOf("sync", "party", "group", "wifi", "sound", "stream")
        ),
        Tool(
            id = "cctv_camera",
            title = "CCTV Camera",
            category = ToolCategories.FILE_NETWORK,
            description = "Stream live camera feed over local IP address for secure remote monitoring.",
            keywords = listOf("cctv", "security", "stream", "surveillance", "ip camera", "monitor")
        ),
        Tool(
            id = "remote_camera",
            title = "Remote Camera",
            category = ToolCategories.FILE_NETWORK,
            description = "Control another device's camera shutter and preview feed remotely.",
            keywords = listOf("remote", "shutter", "control", "wifi", "spy", "trigger")
        ),
        Tool(
            id = "remote_flashlight",
            title = "Remote Flashlight",
            category = ToolCategories.FILE_NETWORK,
            description = "Turn on or trigger flashlight strobe on nearby connected devices.",
            keywords = listOf("remote", "torch", "flash", "strobe", "wifi", "control")
        ),
        Tool(
            id = "walkie_talkie",
            title = "Walkie Talkie",
            category = ToolCategories.FILE_NETWORK,
            description = "Push-to-talk live voice broadcasting to other local WiFi devices.",
            keywords = listOf("voice", "ptt", "broadcast", "local", "audio", "radio", "intercom")
        ),
        Tool(
            id = "wifi_calls",
            title = "WiFi Calls",
            category = ToolCategories.FILE_NETWORK,
            description = "Make secure peer-to-peer audio calls over local WiFi without internet.",
            keywords = listOf("call", "voip", "offline", "p2p", "phone", "wifi")
        ),
        Tool(
            id = "bluetooth_controller",
            title = "Bluetooth Controller HC05",
            category = ToolCategories.FILE_NETWORK,
            description = "Full terminal & gamepad console to control Arduino & Bluetooth hardware.",
            keywords = listOf("arduino", "bluetooth", "hc05", "hc06", "joystick", "serial", "terminal")
        ),
        Tool(
            id = "signal_strength",
            title = "Signal Strength",
            category = ToolCategories.FILE_NETWORK,
            description = "Real-time detailed cellular and WiFi signal analysis and metrics.",
            keywords = listOf("network", "signal", "rssi", "cellular", "dbm", "analyzer")
        ),
        Tool(
            id = "speed_test",
            title = "Internet Speed Test",
            category = ToolCategories.FILE_NETWORK,
            description = "Measure actual download/upload speeds and connection ping.",
            keywords = listOf("speed", "bandwidth", "ping", "internet", "download", "upload")
        ),
        Tool(
            id = "qr_generator",
            title = "QR Generator",
            category = ToolCategories.FILE_NETWORK,
            description = "Generate custom high-resolution QR codes from text, links, or contacts.",
            keywords = listOf("qr", "barcode", "create", "builder", "code")
        ),
        Tool(
            id = "barcode_generator",
            title = "Barcode Generator",
            category = ToolCategories.FILE_NETWORK,
            description = "Create 1D linear barcodes (Code 128, EAN-13) dynamically.",
            keywords = listOf("barcode", "code", "ean", "create", "generator")
        ),
        Tool(
            id = "qr_scanner",
            title = "QR Scanner",
            category = ToolCategories.FILE_NETWORK,
            description = "High-speed camera scanner for all 1D barcodes and QR codes.",
            keywords = listOf("scan", "reader", "camera", "qr", "barcode")
        ),
        Tool(
            id = "file_locker",
            title = "File Locker",
            category = ToolCategories.FILE_NETWORK,
            description = "Secure encrypted offline vault to hide and lock private files with a PIN.",
            keywords = listOf("vault", "lock", "secure", "encrypt", "private", "pin", "file")
        ),
        Tool(
            id = "screen_recorder",
            title = "Screen Recorder",
            category = ToolCategories.FILE_NETWORK,
            description = "Capture device screen action with FPS settings and audio recording.",
            keywords = listOf("record", "video", "capture", "screen", "game", "cast")
        ),

        // CAMERA TOOLS (7 tools)
        Tool(
            id = "motion_camera",
            title = "Motion Camera",
            category = ToolCategories.CAMERA,
            description = "Auto-triggers camera captures immediately upon detecting visual motion.",
            keywords = listOf("motion", "detect", "security", "spy", "trigger", "alarm")
        ),
        Tool(
            id = "blank_camera",
            title = "Blank Camera",
            category = ToolCategories.CAMERA,
            description = "Keep the screen blank and capture photos discreetly using volume keys.",
            keywords = listOf("stealth", "black", "spy", "discreet", "silent", "volume")
        ),
        Tool(
            id = "night_camera",
            title = "Night Camera",
            category = ToolCategories.CAMERA,
            description = "Simulate low-light camera boosting and infrared thermal visual overlays.",
            keywords = listOf("night", "thermal", "infrared", "dark", "exposure", "vision")
        ),
        Tool(
            id = "cam_scanner",
            title = "Cam Scanner",
            category = ToolCategories.CAMERA,
            description = "Scan documents using filters to auto-crop, contrast, and export to PDF.",
            keywords = listOf("scan", "pdf", "document", "ocr", "receipt", "paper")
        ),
        Tool(
            id = "ocr_text",
            title = "OCR Text Recognition",
            category = ToolCategories.CAMERA,
            description = "Instantly extract editable text from images and copy it to the clipboard.",
            keywords = listOf("ocr", "read", "scanner", "text", "extract", "camera")
        ),
        Tool(
            id = "magnifier",
            title = "Magnifier",
            category = ToolCategories.CAMERA,
            description = "Pinch-to-zoom digital microscope utilizing camera and flash controls.",
            keywords = listOf("zoom", "lens", "macro", "microscope", "light", "reading")
        ),
        Tool(
            id = "color_detector",
            title = "Color Detector",
            category = ToolCategories.CAMERA,
            description = "Point the camera to identify hex codes, RGB values, and color names.",
            keywords = listOf("color", "hex", "rgb", "palette", "detect", "eye")
        ),

        // MEASUREMENT TOOLS (15 tools)
        Tool(
            id = "compass",
            title = "Compass",
            category = ToolCategories.MEASUREMENT,
            description = "High-precision digital magnetic compass displaying heading and degree details.",
            keywords = listOf("compass", "direction", "north", "south", "heading", "navigation")
        ),
        Tool(
            id = "spirit_level",
            title = "Spirit Level",
            category = ToolCategories.MEASUREMENT,
            description = "Interactive bubble level tool to measure surface inclinations on X/Y axes.",
            keywords = listOf("bubble", "level", "tilt", "flat", "align", "slope")
        ),
        Tool(
            id = "pendulum_bob",
            title = "Pendulum Bob",
            category = ToolCategories.MEASUREMENT,
            description = "Measures gravity angles, period, and string length with sensor telemetry.",
            keywords = listOf("pendulum", "g", "period", "gravity", "angle", "bob")
        ),
        Tool(
            id = "speedometer",
            title = "Speedometer",
            category = ToolCategories.MEASUREMENT,
            description = "GPS-based speedometer tracking speed, max speed, and average velocity.",
            keywords = listOf("speed", "kmh", "mph", "gps", "velocity", "drive", "run")
        ),
        Tool(
            id = "altitude_meter",
            title = "Altitude Meter",
            category = ToolCategories.MEASUREMENT,
            description = "Calculates exact elevation above sea level using GPS and barometric sensors.",
            keywords = listOf("elevation", "height", "gps", "altitude", "pressure")
        ),
        Tool(
            id = "ruler",
            title = "Ruler",
            category = ToolCategories.MEASUREMENT,
            description = "Accurate on-screen metric and imperial ruler with calipers.",
            keywords = listOf("ruler", "measure", "cm", "inch", "length", "scale")
        ),
        Tool(
            id = "protractor",
            title = "Protractor",
            category = ToolCategories.MEASUREMENT,
            description = "Measures angles directly on screen or camera overlays in degrees.",
            keywords = listOf("angle", "protractor", "geometry", "degree", "measure")
        ),
        Tool(
            id = "metal_detector",
            title = "Metal Detector",
            category = ToolCategories.MEASUREMENT,
            description = "Uses magnetic sensors to detect iron, steel, and electrical pipes behind walls.",
            keywords = listOf("metal", "magnet", "magnetic", "field", "stud finder", "sensor")
        ),
        Tool(
            id = "rpm_meter",
            title = "RPM Meter",
            category = ToolCategories.MEASUREMENT,
            description = "Measures rotations per minute using strobe flashes or microphone peak frequencies.",
            keywords = listOf("rpm", "rotations", "spin", "frequency", "strobe", "engine")
        ),
        Tool(
            id = "g_force_meter",
            title = "G Force Meter",
            category = ToolCategories.MEASUREMENT,
            description = "Measures 3-axis gravitational acceleration force peaks in real-time.",
            keywords = listOf("gforce", "acceleration", "gravity", "sensor", "physics")
        ),
        Tool(
            id = "air_pressure",
            title = "Air Pressure",
            category = ToolCategories.MEASUREMENT,
            description = "Real-time atmospheric pressure reading using the onboard barometer.",
            keywords = listOf("pressure", "barometer", "weather", "hpa", "altitude")
        ),
        Tool(
            id = "light_meter",
            title = "Light Meter",
            category = ToolCategories.MEASUREMENT,
            description = "Analyzes ambient light levels in Lux for photography or environment comfort.",
            keywords = listOf("light", "lux", "exposure", "photo", "brightness")
        ),
        Tool(
            id = "sound_meter",
            title = "Sound Meter",
            category = ToolCategories.MEASUREMENT,
            description = "Measures environmental noise volume in Decibels (dB) with dynamic graphs.",
            keywords = listOf("noise", "sound", "decibel", "db", "audio", "volume")
        ),
        Tool(
            id = "vibrometer",
            title = "Vibrometer",
            category = ToolCategories.MEASUREMENT,
            description = "Measures ground and structural seismic vibrations based on Richter/Mercalli peaks.",
            keywords = listOf("earthquake", "vibrate", "shake", "seismic", "sensor")
        ),
        Tool(
            id = "temperature_meter",
            title = "Temperature Meter",
            category = ToolCategories.MEASUREMENT,
            description = "Displays local ambient and internal battery temperatures in °C or °F.",
            keywords = listOf("temperature", "weather", "heat", "sensor", "celsius", "fahrenheit")
        ),

        // AUDIO TOOLS (5 tools)
        Tool(
            id = "microphone",
            title = "Microphone Echo",
            category = ToolCategories.AUDIO,
            description = "Live microphone loopback audio tool with echo, reverb, and equalizer feedback.",
            keywords = listOf("mic", "sound", "loopback", "voice", "reverb", "echo", "karaoke")
        ),
        Tool(
            id = "sound_generator",
            title = "Sound Generator",
            category = ToolCategories.AUDIO,
            description = "Synthesizes custom audio frequencies (Sine, Square, Triangle waves) up to 20kHz.",
            keywords = listOf("frequency", "tone", "sine", "hz", "synth", "tuner")
        ),
        Tool(
            id = "text_to_speech",
            title = "Text To Speech",
            category = ToolCategories.AUDIO,
            description = "Convert any written text to high-quality spoken audio completely offline.",
            keywords = listOf("tts", "speech", "read", "talk", "voice", "output")
        ),
        Tool(
            id = "speech_to_text",
            title = "Speech To Text",
            category = ToolCategories.AUDIO,
            description = "Offline live voice dictation transcribing speech to text onto your notepad.",
            keywords = listOf("stt", "speech", "listen", "transcribe", "voice", "dictate")
        ),
        Tool(
            id = "music_player",
            title = "Music Player",
            category = ToolCategories.AUDIO,
            description = "Elegant local player to scan and play audio tracks with custom visualizations.",
            keywords = listOf("music", "song", "audio", "mp3", "playlist", "equalizer")
        ),

        // PRODUCTIVITY (12 tools)
        Tool(
            id = "checklist",
            title = "Checklist",
            category = ToolCategories.PRODUCTIVITY,
            description = "Task checklist tracker with categories and progress status.",
            keywords = listOf("todo", "task", "checklist", "manager", "notes", "goal")
        ),
        Tool(
            id = "notes",
            title = "Notes",
            category = ToolCategories.PRODUCTIVITY,
            description = "Fully styled local notes database with search and color groupings.",
            keywords = listOf("note", "notepad", "write", "diary", "journal")
        ),
        Tool(
            id = "billing_system",
            title = "Billing System",
            category = ToolCategories.PRODUCTIVITY,
            description = "Mini Point of Sale system to manage product inventory and checkout bills.",
            keywords = listOf("pos", "cashier", "checkout", "billing", "store", "sales")
        ),
        Tool(
            id = "invoice_generator",
            title = "Invoice Generator",
            category = ToolCategories.PRODUCTIVITY,
            description = "Build professional PDF invoices with products, taxes, and client details.",
            keywords = listOf("pdf", "invoice", "receipt", "bill", "taxes", "client")
        ),
        Tool(
            id = "age_calculator",
            title = "Age Calculator",
            category = ToolCategories.PRODUCTIVITY,
            description = "Calculates exact age down to months, days, hours, and shows next birthdays.",
            keywords = listOf("age", "birthday", "date", "calendar", "calculator")
        ),
        Tool(
            id = "days_counter",
            title = "Days Counter",
            category = ToolCategories.PRODUCTIVITY,
            description = "Countdowns and monitors days elapsed since or remaining to special events.",
            keywords = listOf("days", "count", "timer", "anniversary", "wedding", "countdown")
        ),
        Tool(
            id = "calculator",
            title = "Calculator",
            category = ToolCategories.PRODUCTIVITY,
            description = "High-performance scientific calculator with equation history.",
            keywords = listOf("calculator", "math", "scientific", "trig", "sum")
        ),
        Tool(
            id = "unit_converter",
            title = "Unit Converter",
            category = ToolCategories.PRODUCTIVITY,
            description = "Instant conversions between area, mass, length, storage, speed, and time.",
            keywords = listOf("convert", "unit", "length", "weight", "density", "metrics")
        ),
        Tool(
            id = "currency_converter",
            title = "Currency Converter",
            category = ToolCategories.PRODUCTIVITY,
            description = "Perform rapid multi-currency offline conversions with saved exchange rates.",
            keywords = listOf("currency", "money", "rate", "exchange", "usd", "euro", "offline")
        ),
        Tool(
            id = "stopwatch",
            title = "Stopwatch",
            category = ToolCategories.PRODUCTIVITY,
            description = "Millisecond precision split stopwatch for workouts, sports, and tasks.",
            keywords = listOf("stopwatch", "timer", "lap", "sports", "workout")
        ),
        Tool(
            id = "timer",
            title = "Timer",
            category = ToolCategories.PRODUCTIVITY,
            description = "Multi-purpose custom countdown timers with ringtone alarms.",
            keywords = listOf("timer", "countdown", "alarm", "clock", "kitchen")
        ),
        Tool(
            id = "world_clock",
            title = "World Clock",
            category = ToolCategories.PRODUCTIVITY,
            description = "Track local times and offset schedules across multiple international cities.",
            keywords = listOf("clock", "time", "world", "gmt", "timezone", "cities")
        ),

        // HEALTH & FITNESS (4 tools)
        Tool(
            id = "heart_rate",
            title = "Heart Rate",
            category = ToolCategories.HEALTH_FITNESS,
            description = "Real camera-based pulse detector. Checks color changes in fingertip.",
            keywords = listOf("heart", "pulse", "bpm", "cardio", "health", "camera")
        ),
        Tool(
            id = "step_counter",
            title = "Step Counter",
            category = ToolCategories.HEALTH_FITNESS,
            description = "Uses accelerometer or step sensors to log and track your daily steps.",
            keywords = listOf("steps", "pedometer", "walk", "fitness", "track")
        ),
        Tool(
            id = "distance_tracker",
            title = "Distance Estimator",
            category = ToolCategories.HEALTH_FITNESS,
            description = "Estimates direct walking and running distances with average paces.",
            keywords = listOf("distance", "track", "gps", "km", "miles", "walk")
        ),
        Tool(
            id = "calories_burned",
            title = "Calories Burned",
            category = ToolCategories.HEALTH_FITNESS,
            description = "Activity calorie logs based on height, weight, activity type, and time.",
            keywords = listOf("calories", "burn", "diet", "fitness", "tracker")
        ),

        // UTILITY TOOLS (13 tools)
        Tool(
            id = "torch",
            title = "Torch Light",
            category = ToolCategories.UTILITY,
            description = "Ultra-bright regular torch, variable strobe light, and screen light.",
            keywords = listOf("torch", "flashlight", "sos", "strobe", "light", "flash")
        ),
        Tool(
            id = "morse_code",
            title = "Morse Code",
            category = ToolCategories.UTILITY,
            description = "Translates texts to Morse and flashes or vibrates the translated codes.",
            keywords = listOf("morse", "code", "translator", "flash", "signal")
        ),
        Tool(
            id = "paint",
            title = "Paint",
            category = ToolCategories.UTILITY,
            description = "Multi-touch sketch canvas to paint with dynamic colors and export images.",
            keywords = listOf("paint", "draw", "canvas", "art", "sketch", "doodle")
        ),
        Tool(
            id = "stop_motion",
            title = "Stop Motion Animation",
            category = ToolCategories.UTILITY,
            description = "Capture consecutive frames and review or export them as clean GIF sequences.",
            keywords = listOf("stopmotion", "gif", "animation", "frames", "camera")
        ),
        Tool(
            id = "my_location",
            title = "My Location",
            category = ToolCategories.UTILITY,
            description = "Displays precise GPS latitude, longitude coordinates, and altitudes.",
            keywords = listOf("gps", "coordinates", "altitude", "location", "position")
        ),
        Tool(
            id = "lat_lng_converter",
            title = "Latitude Longitude",
            category = ToolCategories.UTILITY,
            description = "Convert between coordinate formats (DMS, DD, UTM) and lookup positions.",
            keywords = listOf("coords", "lat", "lng", "degree", "convert", "utm")
        ),
        Tool(
            id = "address_finder",
            title = "Address Finder",
            category = ToolCategories.UTILITY,
            description = "Reverse geocodes coordinates to display physical street address.",
            keywords = listOf("address", "reverse", "geocode", "map", "location")
        ),
        Tool(
            id = "device_info",
            title = "Device Info",
            category = ToolCategories.UTILITY,
            description = "Complete software and hardware overview of model, build, and screen density.",
            keywords = listOf("hardware", "specs", "model", "build", "android", "system")
        ),
        Tool(
            id = "battery_info",
            title = "Battery Info",
            category = ToolCategories.UTILITY,
            description = "Logs battery level, health rating, voltage, and running temperature.",
            keywords = listOf("battery", "power", "health", "voltage", "charging", "temperature")
        ),
        Tool(
            id = "storage_analyzer",
            title = "Storage Analyzer",
            category = ToolCategories.UTILITY,
            description = "Visual breakdown chart of internal space and largest folder caches.",
            keywords = listOf("storage", "space", "analyzer", "gb", "cleanup", "cache")
        ),
        Tool(
            id = "ram_monitor",
            title = "RAM Monitor",
            category = ToolCategories.UTILITY,
            description = "Tracks live RAM utilization and provides a simulator to optimize space.",
            keywords = listOf("ram", "memory", "usage", "speedup", "optimize")
        ),
        Tool(
            id = "cpu_info",
            title = "CPU Information",
            category = ToolCategories.UTILITY,
            description = "Detailed hardware processor chips, cores, architectures, and loads.",
            keywords = listOf("cpu", "processor", "cores", "load", "frequency", "architecture")
        ),
        Tool(
            id = "network_info",
            title = "Network Info",
            category = ToolCategories.UTILITY,
            description = "Detailed local and public IP details, gateway routing, and MAC address.",
            keywords = listOf("ip", "wifi", "dns", "network", "mac", "subnet")
        ),

        // ADVANCED TOOLS (5 tools)
        Tool(
            id = "ir_remote",
            title = "IR Remote",
            category = ToolCategories.ADVANCED,
            description = "Simulates Infrared control commands for TV, AC, Projectors, and more.",
            keywords = listOf("ir", "remote", "infrared", "tv", "ac", "projector")
        ),
        Tool(
            id = "local_device_controller",
            title = "Local Device Controller",
            category = ToolCategories.ADVANCED,
            description = "Trigger home automation systems over the network using direct HTTP requests.",
            keywords = listOf("iot", "home", "smart", "http", "control", "api")
        ),
        Tool(
            id = "local_wifi_comm",
            title = "Local WiFi Communication",
            category = ToolCategories.ADVANCED,
            description = "Secure chat terminal room hosted locally to talk with local peers.",
            keywords = listOf("chat", "wifi", "socket", "local", "terminal", "message")
        ),
        Tool(
            id = "nearby_discovery",
            title = "Nearby Device Discovery",
            category = ToolCategories.ADVANCED,
            description = "Pings and scans local subnets to discover active smart devices and open ports.",
            keywords = listOf("scan", "subnet", "ping", "discovery", "ports", "ip")
        ),
        Tool(
            id = "local_controller",
            title = "Local Device Interface",
            category = ToolCategories.ADVANCED,
            description = "Local node management and client interfaces for smart electronics.",
            keywords = listOf("smart", "electronics", "terminal", "local", "control")
        )
    )

    fun getToolById(id: String): Tool? {
        return ALL_TOOLS.find { it.id == id }
    }
}
