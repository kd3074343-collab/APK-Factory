package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Tool
import com.example.data.ToolsRegistry
import com.example.data.ToolsRepository
import com.example.data.database.AppDatabase
import com.example.data.database.ChecklistItem
import com.example.data.database.FileVaultItemEntity
import com.example.data.database.NoteEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ToolsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = ToolsRepository(db)

    // Search and Category states
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow<String?>(null)

    // Flow of Favorites
    val favoriteToolIds: StateFlow<List<String>> = repository.favoriteToolIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Flow of Recents
    val recentToolIds: StateFlow<List<String>> = repository.recentToolIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Tools List
    val filteredTools: StateFlow<List<Tool>> = combine(
        searchQuery,
        selectedCategory
    ) { query, category ->
        var list = ToolsRegistry.ALL_TOOLS
        if (!category.isNullOrEmpty()) {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }
        if (query.isNotEmpty()) {
            list = list.filter { tool ->
                tool.title.contains(query, ignoreCase = true) ||
                        tool.description.contains(query, ignoreCase = true) ||
                        tool.keywords.any { it.contains(query, ignoreCase = true) }
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ToolsRegistry.ALL_TOOLS)

    // Favorite Tools List
    val favoriteTools: StateFlow<List<Tool>> = favoriteToolIds.map { ids ->
        ToolsRegistry.ALL_TOOLS.filter { it.id in ids }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Recent Tools List
    val recentTools: StateFlow<List<Tool>> = recentToolIds.map { ids ->
        // Keep order of ids
        ids.mapNotNull { id -> ToolsRegistry.getToolById(id) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // -------------------------------------------------------------------------
    // ROOM PERSISTED STATE
    // -------------------------------------------------------------------------
    val notes: StateFlow<List<NoteEntity>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val checklistItems: StateFlow<List<ChecklistItem>> = repository.allChecklistItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vaultItems: StateFlow<List<FileVaultItemEntity>> = repository.allVaultItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Medical disclaimer state (usually in shared preferences)
    val hasAcceptedDisclaimer = MutableStateFlow(false)

    init {
        // Load disclaimer acceptance from SharedPrefs
        val prefs = application.getSharedPreferences("all_tools_prefs", Application.MODE_PRIVATE)
        hasAcceptedDisclaimer.value = prefs.getBoolean("disclaimer_accepted", false)
    }

    fun acceptDisclaimer() {
        hasAcceptedDisclaimer.value = true
        val prefs = getApplication<Application>().getSharedPreferences("all_tools_prefs", Application.MODE_PRIVATE)
        prefs.edit().putBoolean("disclaimer_accepted", true).apply()
    }

    // -------------------------------------------------------------------------
    // DB ACTIONS
    // -------------------------------------------------------------------------
    fun addFavorite(toolId: String) {
        viewModelScope.launch {
            repository.addFavorite(toolId)
        }
    }

    fun removeFavorite(toolId: String) {
        viewModelScope.launch {
            repository.removeFavorite(toolId)
        }
    }

    fun toggleFavorite(toolId: String) {
        viewModelScope.launch {
            val favs = favoriteToolIds.value
            if (toolId in favs) {
                repository.removeFavorite(toolId)
            } else {
                repository.addFavorite(toolId)
            }
        }
    }

    fun addRecent(toolId: String) {
        viewModelScope.launch {
            repository.addRecent(toolId)
        }
    }

    fun removeRecent(toolId: String) {
        viewModelScope.launch {
            repository.removeRecent(toolId)
        }
    }

    fun addNote(title: String, content: String, colorHex: String) {
        viewModelScope.launch {
            repository.insertNote(NoteEntity(title = title, content = content, colorHex = colorHex))
        }
    }

    fun deleteNote(id: Int) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    fun addChecklistItem(task: String, category: String = "General") {
        viewModelScope.launch {
            repository.insertChecklistItem(ChecklistItem(task = task, category = category))
        }
    }

    fun toggleChecklistItem(item: ChecklistItem) {
        viewModelScope.launch {
            repository.insertChecklistItem(item.copy(isCompleted = !item.isCompleted))
        }
    }

    fun deleteChecklistItem(id: Int) {
        viewModelScope.launch {
            repository.deleteChecklistItem(id)
        }
    }

    fun clearCompletedChecklist() {
        viewModelScope.launch {
            repository.clearCompletedChecklist()
        }
    }

    fun addVaultItem(fileName: String, filePath: String, contentHex: String, passcodeHash: String) {
        viewModelScope.launch {
            repository.insertVaultItem(
                FileVaultItemEntity(
                    fileName = fileName,
                    filePath = filePath,
                    contentHex = contentHex,
                    passcodeHash = passcodeHash
                )
            )
        }
    }

    fun deleteVaultItem(id: Int) {
        viewModelScope.launch {
            repository.deleteVaultItem(id)
        }
    }
}
