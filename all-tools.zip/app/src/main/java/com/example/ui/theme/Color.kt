package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors
val LightPrimary = Color(0xFF006C51)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFF76FAFC)
val LightOnPrimaryContainer = Color(0xFF002016)
val LightSecondary = Color(0xFF4B635A)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightBackground = Color(0xFFFBFDF9)
val LightSurface = Color(0xFFFBFDF9)
val LightOnBackground = Color(0xFF191C1B)
val LightOnSurface = Color(0xFF191C1B)

// Dark Scheme Colors - High Contrast Cosmic Slate
val DarkPrimary = Color(0xFF00DCAC)
val DarkOnPrimary = Color(0xFF003828)
val DarkPrimaryContainer = Color(0xFF00513C)
val DarkOnPrimaryContainer = Color(0xFF48FFCD)
val DarkSecondary = Color(0xFFB1CCBF)
val DarkOnSecondary = Color(0xFF1D352D)
val DarkBackground = Color(0xFF0C100E)
val DarkSurface = Color(0xFF121815)
val DarkOnBackground = Color(0xFFE1E3DF)
val DarkOnSurface = Color(0xFFE1E3DF)

// Brand Category Colors (For visual richness)
val CatFileNetwork = Color(0xFF3F51B5)
val CatCamera = Color(0xFFE91E63)
val CatMeasurement = Color(0xFFFF9800)
val CatAudio = Color(0xFF9C27B0)
val CatProductivity = Color(0xFF4CAF50)
val CatHealth = Color(0xFFF44336)
val CatUtility = Color(0xFF00BCD4)
val CatAdvanced = Color(0xFF607D8B)

