package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Basic M3 Palette
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Sleek Interface Light Theme Palette
val SleekLightBg = Color(0xFFF7F9FC)
val SleekLightKeypadBg = Color(0xFFFFFFFF)
val SleekLightTextPrimary = Color(0xFF1A1C1E)
val SleekLightTextSecondary = Color(0xFF74777F)
val SleekLightAcBg = Color(0xFFFDE2E1)
val SleekLightAcText = Color(0xFFBA1A1A)
val SleekLightAuxBg = Color(0xFFE1E2E9)
val SleekLightAuxText = Color(0xFF1A1C1E)
val SleekLightOpBg = Color(0xFFD3E3FD)
val SleekLightOpText = Color(0xFF001D35)
val SleekLightDigitBg = Color(0xFFF7F9FC)
val SleekLightDigitText = Color(0xFF1A1C1E)
val SleekLightEqualsBg = Color(0xFF005FAF)
val SleekLightEqualsText = Color(0xFFFFFFFF)

// Sleek Interface Dark Theme Palette (Inverted Premium Counterparts)
val SleekDarkBg = Color(0xFF121318)
val SleekDarkKeypadBg = Color(0xFF1B1B22)
val SleekDarkTextPrimary = Color(0xFFE2E2E9)
val SleekDarkTextSecondary = Color(0xFF8E9099)
val SleekDarkAcBg = Color(0xFF3B0A0A)
val SleekDarkAcText = Color(0xFFFFB4AB)
val SleekDarkAuxBg = Color(0xFF2A2B31)
val SleekDarkAuxText = Color(0xFFE2E2E9)
val SleekDarkOpBg = Color(0xFF004A77)
val SleekDarkOpText = Color(0xFFD1E4FF)
val SleekDarkDigitBg = Color(0xFF1E2025)
val SleekDarkDigitText = Color(0xFFE2E2E9)
val SleekDarkEqualsBg = Color(0xFFA8C7FA)
val SleekDarkEqualsText = Color(0xFF00305F)
