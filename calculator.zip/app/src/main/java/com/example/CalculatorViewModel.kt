package com.example

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("calculator_prefs", Context.MODE_PRIVATE)

    private val _displayText = MutableStateFlow("0")
    val displayText: StateFlow<String> = _displayText.asStateFlow()

    private val _expressionText = MutableStateFlow("")
    val expressionText: StateFlow<String> = _expressionText.asStateFlow()

    private val _vibrationEnabled = MutableStateFlow(prefs.getBoolean("vibration_enabled", true))
    val vibrationEnabled: StateFlow<Boolean> = _vibrationEnabled.asStateFlow()

    private val _darkModeEnabled = MutableStateFlow(prefs.getBoolean("dark_mode_enabled", true))
    val darkModeEnabled: StateFlow<Boolean> = _darkModeEnabled.asStateFlow()

    // Calculator internal state
    private var firstOperand: Double? = null
    private var pendingOperator: String? = null
    private var resetDisplayOnNextInput = false
    private var lastResult: Double? = null
    private var lastOperator: String? = null
    private var lastRightOperand: Double? = null

    // Internal buffer for raw user input to ensure no loss of decimal positions or trailing zeros while typing
    private var rawInput: String = "0"

    private val numberFormatter = DecimalFormat("#,##0.###########", DecimalFormatSymbols(Locale.US)).apply {
        maximumFractionDigits = 10
    }

    fun toggleVibration() {
        val newValue = !_vibrationEnabled.value
        _vibrationEnabled.value = newValue
        prefs.edit().putBoolean("vibration_enabled", newValue).apply()
    }

    fun toggleDarkMode() {
        val newValue = !_darkModeEnabled.value
        _darkModeEnabled.value = newValue
        prefs.edit().putBoolean("dark_mode_enabled", newValue).apply()
    }

    fun onDigitPressed(digit: String) {
        if (_displayText.value == "Error") {
            clearAll()
        }

        if (resetDisplayOnNextInput || rawInput == "0") {
            rawInput = digit
            resetDisplayOnNextInput = false
        } else {
            // Limit raw digits count to 12 for layout and double-precision safety
            val rawDigitsCount = rawInput.replace(".", "").length
            if (rawDigitsCount < 12) {
                rawInput += digit
            }
        }
        _displayText.value = formatRawInput(rawInput)
    }

    fun onDecimalPressed() {
        if (_displayText.value == "Error") {
            clearAll()
        }

        if (resetDisplayOnNextInput) {
            rawInput = "0."
            resetDisplayOnNextInput = false
        } else if (!rawInput.contains(".")) {
            rawInput += "."
        }
        _displayText.value = formatRawInput(rawInput)
    }

    fun onOperatorPressed(operator: String) {
        if (_displayText.value == "Error") return

        val currentValue = parseDisplayValue()

        if (firstOperand == null) {
            firstOperand = currentValue
            pendingOperator = operator
            _expressionText.value = "${formatNumber(currentValue)} $operator"
            resetDisplayOnNextInput = true
        } else if (resetDisplayOnNextInput) {
            pendingOperator = operator
            _expressionText.value = "${formatNumber(firstOperand!!)} $operator"
        } else {
            val result = calculate(firstOperand!!, currentValue, pendingOperator!!)
            if (result.isNaN() || result.isInfinite()) {
                _displayText.value = "Error"
                rawInput = "Error"
                _expressionText.value = ""
                firstOperand = null
                pendingOperator = null
                resetDisplayOnNextInput = true
            } else {
                firstOperand = result
                pendingOperator = operator
                val formatted = formatNumber(result)
                _displayText.value = formatted
                rawInput = formatted.replace(",", "")
                _expressionText.value = "${formatNumber(result)} $operator"
                resetDisplayOnNextInput = true
            }
        }

        lastResult = null
        lastOperator = null
        lastRightOperand = null
    }

    fun onEqualsPressed() {
        if (_displayText.value == "Error") return

        val currentValue = parseDisplayValue()

        if (firstOperand != null && pendingOperator != null) {
            val op = pendingOperator!!
            val result = calculate(firstOperand!!, currentValue, op)
            if (result.isNaN() || result.isInfinite()) {
                _displayText.value = "Error"
                rawInput = "Error"
                _expressionText.value = ""
                firstOperand = null
                pendingOperator = null
            } else {
                _expressionText.value = "${formatNumber(firstOperand!!)} $op ${formatNumber(currentValue)} ="
                val formatted = formatNumber(result)
                _displayText.value = formatted
                rawInput = formatted.replace(",", "")

                lastResult = result
                lastOperator = op
                lastRightOperand = currentValue

                firstOperand = null
                pendingOperator = null
            }
            resetDisplayOnNextInput = true
        } else if (lastResult != null && lastOperator != null && lastRightOperand != null) {
            val result = calculate(lastResult!!, lastRightOperand!!, lastOperator!!)
            if (result.isNaN() || result.isInfinite()) {
                _displayText.value = "Error"
                rawInput = "Error"
                _expressionText.value = ""
                lastResult = null
                lastOperator = null
                lastRightOperand = null
            } else {
                _expressionText.value = "${formatNumber(lastResult!!)} $lastOperator ${formatNumber(lastRightOperand!!)} ="
                val formatted = formatNumber(result)
                _displayText.value = formatted
                rawInput = formatted.replace(",", "")
                lastResult = result
            }
            resetDisplayOnNextInput = true
        }
    }

    fun onPercentagePressed() {
        if (_displayText.value == "Error") return
        val currentValue = parseDisplayValue()

        val percentageValue = if (firstOperand != null && pendingOperator != null) {
            if (pendingOperator == "+" || pendingOperator == "−") {
                firstOperand!! * (currentValue / 100.0)
            } else {
                currentValue / 100.0
            }
        } else {
            currentValue / 100.0
        }

        val formatted = formatNumber(percentageValue)
        _displayText.value = formatted
        rawInput = formatted.replace(",", "")
        resetDisplayOnNextInput = true
    }

    fun onClearPressed() {
        if (_displayText.value != "0") {
            _displayText.value = "0"
            rawInput = "0"
        } else {
            clearAll()
        }
    }

    fun onBackspacePressed() {
        if (_displayText.value == "Error" || resetDisplayOnNextInput) {
            _displayText.value = "0"
            rawInput = "0"
            resetDisplayOnNextInput = false
            return
        }

        if (rawInput.length > 1) {
            rawInput = rawInput.dropLast(1)
            if (rawInput == "-") {
                rawInput = "0"
            }
        } else {
            rawInput = "0"
        }
        _displayText.value = formatRawInput(rawInput)
    }

    private fun clearAll() {
        _displayText.value = "0"
        rawInput = "0"
        _expressionText.value = ""
        firstOperand = null
        pendingOperator = null
        resetDisplayOnNextInput = false
        lastResult = null
        lastOperator = null
        lastRightOperand = null
    }

    private fun parseDisplayValue(): Double {
        val clean = rawInput.replace(",", "")
        return clean.toDoubleOrNull() ?: 0.0
    }

    private fun formatNumber(value: Double): String {
        if (value.isNaN()) return "Error"
        if (value.isInfinite()) return "Error"

        val absVal = kotlin.math.abs(value)
        return when {
            absVal == 0.0 -> "0"
            absVal >= 1e12 || (absVal < 1e-6 && absVal > 0.0) -> {
                String.format(Locale.US, "%.6e", value)
                    .replace("e+", "e")
                    .replace("e0", "e")
            }
            else -> {
                numberFormatter.format(value)
            }
        }
    }

    private fun formatRawInput(input: String): String {
        if (input == "Error" || input == "0" || input.isEmpty()) return input
        val isNegative = input.startsWith("-")
        val cleanInput = if (isNegative) input.substring(1) else input

        val parts = cleanInput.split(".")
        val integerPart = parts[0]

        val formattedInteger = if (integerPart.isNotEmpty()) {
            val doubleVal = integerPart.toDoubleOrNull() ?: 0.0
            val formatter = DecimalFormat("#,##0", DecimalFormatSymbols(Locale.US))
            formatter.format(doubleVal)
        } else {
            "0"
        }

        val result = if (parts.size > 1) {
            "$formattedInteger.${parts[1]}"
        } else if (cleanInput.contains(".")) {
            "$formattedInteger."
        } else {
            formattedInteger
        }

        return if (isNegative) "-$result" else result
    }

    private fun calculate(op1: Double, op2: Double, operator: String): Double {
        return when (operator) {
            "+" -> op1 + op2
            "−" -> op1 - op2
            "×" -> op1 * op2
            "÷" -> if (op2 == 0.0) Double.NaN else op1 / op2
            else -> 0.0
        }
    }
}
