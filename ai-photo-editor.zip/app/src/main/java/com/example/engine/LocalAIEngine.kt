package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.example.data.model.Point2D
import java.util.LinkedList
import java.util.Queue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

object LocalAIEngine {

    /**
     * AI Auto Enhance: Automatically optimizes levels, exposure, contrast, and saturation.
     */
    fun autoEnhance(src: Bitmap): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        var totalLum = 0.0
        var minLum = 255
        var maxLum = 0

        for (p in pixels) {
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val lum = (0.2126 * r + 0.7152 * g + 0.0722 * b).toInt()
            totalLum += lum
            if (lum < minLum) minLum = lum
            if (lum > maxLum) maxLum = lum
        }

        val avgLum = totalLum / size
        val targetAvg = 128.0
        val expCorrection = (targetAvg / (avgLum + 1.0)).coerceIn(0.8, 1.4)

        // Stretch contrast if image is flat
        val contrastRange = maxLum - minLum
        val stretchContrast = contrastRange < 180

        for (i in 0 until size) {
            val p = pixels[i]
            val a = Color.alpha(p)
            var r = Color.red(p)
            var g = Color.green(p)
            var b = Color.blue(p)

            // Apply auto-exposure scaling
            r = (r * expCorrection).roundToInt().coerceIn(0, 255)
            g = (g * expCorrection).roundToInt().coerceIn(0, 255)
            b = (b * expCorrection).roundToInt().coerceIn(0, 255)

            // Dynamic Contrast stretching
            if (stretchContrast && contrastRange > 10) {
                r = (((r - minLum) / contrastRange.toFloat()) * 255).roundToInt().coerceIn(0, 255)
                g = (((g - minLum) / contrastRange.toFloat()) * 255).roundToInt().coerceIn(0, 255)
                b = (((b - minLum) / contrastRange.toFloat()) * 255).roundToInt().coerceIn(0, 255)
            }

            // Slight Saturation boost
            val gray = (0.2126f * r + 0.7152f * g + 0.0722f * b)
            r = (gray + (r - gray) * 1.12f).roundToInt().coerceIn(0, 255)
            g = (gray + (g - gray) * 1.12f).roundToInt().coerceIn(0, 255)
            b = (gray + (b - gray) * 1.12f).roundToInt().coerceIn(0, 255)

            pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }

        dest.setPixels(pixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Skin Smoothing & Face Retouch: Detects skin tones and applies high frequency blurring.
     */
    fun skinSmoothing(src: Bitmap, smoothingAmount: Float): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        // Generate a blurred copy for skin smoothing
        val blurRadius = (2 + (smoothingAmount * 12)).toInt()
        val blurredBmp = boxBlur(src, blurRadius)
        val blurredPixels = IntArray(size)
        blurredBmp.getPixels(blurredPixels, 0, w, 0, 0, w, h)

        for (i in 0 until size) {
            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)

            // Highly robust skin color heuristic algorithm:
            // R > 95, G > 40, B > 20, R > G, R > B, Max - Min > 15, |R - G| > 15
            val maxC = max(r, max(g, b))
            val minC = min(r, min(g, b))
            val isSkin = (r > 95 && g > 40 && b > 20 &&
                    r > g && r > b &&
                    (maxC - minC) > 15 &&
                    abs(r - g) > 12)

            if (isSkin) {
                // Blend smoothed version based on intensity
                val bp = blurredPixels[i]
                val br = Color.red(bp)
                val bg = Color.green(bp)
                val bb = Color.blue(bp)

                val outR = (r * (1f - smoothingAmount) + br * smoothingAmount).roundToInt().coerceIn(0, 255)
                val outG = (g * (1f - smoothingAmount) + bg * smoothingAmount).roundToInt().coerceIn(0, 255)
                val outB = (b * (1f - smoothingAmount) + bb * smoothingAmount).roundToInt().coerceIn(0, 255)

                pixels[i] = (Color.alpha(p) shl 24) or (outR shl 16) or (outG shl 8) or outB
            }
        }

        dest.setPixels(pixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * Fast local on-device Box Blur implementation for smoothing
     */
    private fun boxBlur(src: Bitmap, radius: Int): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val outPixels = IntArray(size)
        val r = radius.coerceAtLeast(1)

        // Horizontal blur pass
        for (y in 0 until h) {
            val offset = y * w
            var sumA = 0
            var sumR = 0
            var sumG = 0
            var sumB = 0

            for (x in -r..r) {
                val p = pixels[offset + x.coerceIn(0, w - 1)]
                sumA += Color.alpha(p)
                sumR += Color.red(p)
                sumG += Color.green(p)
                sumB += Color.blue(p)
            }

            val count = 2 * r + 1
            for (x in 0 until w) {
                outPixels[offset + x] = ((sumA / count) shl 24) or
                        ((sumR / count) shl 16) or
                        ((sumG / count) shl 8) or
                        (sumB / count)

                if (x < w - 1) {
                    val pOut = pixels[offset + (x - r).coerceIn(0, w - 1)]
                    val pIn = pixels[offset + (x + r + 1).coerceIn(0, w - 1)]
                    sumA += Color.alpha(pIn) - Color.alpha(pOut)
                    sumR += Color.red(pIn) - Color.red(pOut)
                    sumG += Color.green(pIn) - Color.green(pOut)
                    sumB += Color.blue(pIn) - Color.blue(pOut)
                }
            }
        }

        // Vertical blur pass
        val outPixels2 = IntArray(size)
        for (x in 0 until w) {
            var sumA = 0
            var sumR = 0
            var sumG = 0
            var sumB = 0

            for (y in -r..r) {
                val p = outPixels[y.coerceIn(0, h - 1) * w + x]
                sumA += Color.alpha(p)
                sumR += Color.red(p)
                sumG += Color.green(p)
                sumB += Color.blue(p)
            }

            val count = 2 * r + 1
            for (y in 0 until h) {
                outPixels2[y * w + x] = ((sumA / count) shl 24) or
                        ((sumR / count) shl 16) or
                        ((sumG / count) shl 8) or
                        (sumB / count)

                if (y < h - 1) {
                    val pOut = outPixels[(y - r).coerceIn(0, h - 1) * w + x]
                    val pIn = outPixels[(y + r + 1).coerceIn(0, h - 1) * w + x]
                    sumA += Color.alpha(pIn) - Color.alpha(pOut)
                    sumR += Color.red(pIn) - Color.red(pOut)
                    sumG += Color.green(pIn) - Color.green(pOut)
                    sumB += Color.blue(pIn) - Color.blue(pOut)
                }
            }
        }

        dest.setPixels(outPixels2, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Object Removal (Inpainting): Paints over the brush selection, fills the mask area from surrounding boundaries.
     */
    fun removeObject(src: Bitmap, maskPoints: List<Point2D>, brushSize: Float): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h

        // 1. Render mask onto a black/white 1-channel buffer
        val maskBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        val maskCanvas = Canvas(maskBmp)
        val maskPaint = Paint().apply {
            color = Color.WHITE
            strokeWidth = brushSize
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val path = Path()
        if (maskPoints.isNotEmpty()) {
            val first = maskPoints.first()
            path.moveTo(first.x, first.y)
            for (i in 1 until maskPoints.size) {
                val p = maskPoints[i]
                path.lineTo(p.x, p.y)
            }
            maskCanvas.drawPath(path, maskPaint)
        }

        val pixels = IntArray(size)
        dest.getPixels(pixels, 0, w, 0, 0, w, h)

        val maskBytes = ByteArray(size)
        val tempBmp = maskBmp.copy(Bitmap.Config.ARGB_8888, true)
        val tempPixels = IntArray(size)
        tempBmp.getPixels(tempPixels, 0, w, 0, 0, w, h)
        for (i in 0 until size) {
            maskBytes[i] = if (Color.alpha(tempPixels[i]) > 10) 1 else 0
        }

        // Fast Content-Aware Fill:
        // Identify all mask pixel indices. Queue them.
        // For each pixel in queue, check if it has unmasked neighbors.
        // If yes, copy/interpolate neighbor values and unmask.
        val queue: Queue<Int> = LinkedList()
        val visited = BooleanArray(size)

        for (i in 0 until size) {
            if (maskBytes[i] == 1.toByte()) {
                // If it touches any non-mask boundary pixel, prioritize it
                val x = i % w
                val y = i / w
                var touchesBoundary = false
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val nx = x + dx
                        val ny = y + dy
                        if (nx in 0 until w && ny in 0 until h) {
                            val nIdx = ny * w + nx
                            if (maskBytes[nIdx] == 0.toByte()) {
                                touchesBoundary = true
                            }
                        }
                    }
                }
                if (touchesBoundary) {
                    queue.add(i)
                    visited[i] = true
                }
            }
        }

        // Processing queue (Inpainting propagation)
        while (queue.isNotEmpty()) {
            val idx = queue.poll()
            val x = idx % w
            val y = idx / w

            // Collect neighboring valid pixel values
            var rSum = 0
            var gSum = 0
            var bSum = 0
            var count = 0

            for (dy in -2..2) {
                for (dx in -2..2) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx in 0 until w && ny in 0 until h) {
                        val nIdx = ny * w + nx
                        if (maskBytes[nIdx] == 0.toByte()) {
                            val np = pixels[nIdx]
                            rSum += Color.red(np)
                            gSum += Color.green(np)
                            bSum += Color.blue(np)
                            count++
                        }
                    }
                }
            }

            if (count > 0) {
                val r = (rSum / count).coerceIn(0, 255)
                val g = (gSum / count).coerceIn(0, 255)
                val b = (bSum / count).coerceIn(0, 255)
                pixels[idx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                maskBytes[idx] = 0 // Mask is filled

                // Propagate further inside the mask
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val nx = x + dx
                        val ny = y + dy
                        if (nx in 0 until w && ny in 0 until h) {
                            val nIdx = ny * w + nx
                            if (maskBytes[nIdx] == 1.toByte() && !visited[nIdx]) {
                                queue.add(nIdx)
                                visited[nIdx] = true
                            }
                        }
                    }
                }
            }
        }

        dest.setPixels(pixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Background Removal: Extracts foreground subjects and makes background pixels transparent.
     */
    fun removeBackground(src: Bitmap): Bitmap {
        val dest = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val outPixels = IntArray(size)

        // Segment background: Seeds start from corners (top-left, top-right, bottom-left, bottom-right)
        // We run a flood-fill or simple distance segmentation.
        // Corner colors are analyzed. Most backgrounds are relatively uniform in corners.
        val cornerColors = intArrayOf(pixels[0], pixels[w - 1], pixels[size - w], pixels[size - 1])
        val avgR = cornerColors.map { Color.red(it) }.average()
        val avgG = cornerColors.map { Color.green(it) }.average()
        val avgB = cornerColors.map { Color.blue(it) }.average()

        // Distance threshold for background matching
        val threshold = 40.0

        for (i in 0 until size) {
            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)

            val dist = sqrt((r - avgR).pow(2) + (g - avgG).pow(2) + (b - avgB).pow(2))

            if (dist < threshold) {
                // Background pixel
                outPixels[i] = Color.TRANSPARENT
            } else {
                // Keep foreground intact
                outPixels[i] = p
            }
        }

        // Feather edges slightly
        dest.setPixels(outPixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Background Blur: Simulates dynamic portrait mode depth of field.
     */
    fun backgroundBlur(src: Bitmap, intensity: Float): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height

        val blurRadius = (4 + (intensity * 25)).toInt()
        val blurred = boxBlur(src, blurRadius)

        // Create canvas and apply a circular/elliptical vignette mask centering on typical human portrait zones
        val canvas = Canvas(dest)
        val paint = Paint().apply {
            isAntiAlias = true
        }

        // Bottom blurred image is drawn
        canvas.drawBitmap(blurred, 0f, 0f, null)

        // Draw clear subject in the middle
        val subjectBmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val subCanvas = Canvas(subjectBmp)

        val maskPaint = Paint().apply {
            isAntiAlias = true
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }

        // Radial gradient where inside is clear, outside is fully transparent
        val colors = intArrayOf(Color.WHITE, Color.WHITE, Color.TRANSPARENT)
        val stops = floatArrayOf(0.0f, 0.4f, 0.85f)
        val gradient = RadialGradient(
            w / 2f, h * 0.45f,
            w * 0.5f,
            colors, stops,
            Shader.TileMode.CLAMP
        )

        val gradientPaint = Paint().apply {
            shader = gradient
        }

        // Draw mask on subjectBmp
        subCanvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), maskPaint)
        subCanvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), gradientPaint)

        // Composite clear subject on top of blurred canvas
        canvas.drawBitmap(subjectBmp, 0f, 0f, null)

        return dest
    }

    /**
     * AI Sky Replacement: Replaces flat, bright, or blue skies with a scenic sunrise/sunset backdrop.
     */
    fun replaceSky(src: Bitmap, skyType: String): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h

        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        // Create sky texture bitmap
        val skyBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val skyCanvas = Canvas(skyBmp)
        val skyPaint = Paint().apply { isAntiAlias = true }

        val startColor: Int
        val endColor: Int
        when (skyType) {
            "Sunset Red" -> {
                startColor = Color.rgb(255, 94, 58)
                endColor = Color.rgb(255, 149, 0)
            }
            "Cosmic Nebula" -> {
                startColor = Color.rgb(26, 42, 108)
                endColor = Color.rgb(178, 31, 151)
            }
            "Golden Hour" -> {
                startColor = Color.rgb(255, 179, 71)
                endColor = Color.rgb(253, 251, 212)
            }
            else -> { // Dramatic Storm
                startColor = Color.rgb(44, 62, 80)
                endColor = Color.rgb(189, 195, 199)
            }
        }

        skyPaint.shader = LinearGradient(0f, 0f, 0f, h * 0.6f, startColor, endColor, Shader.TileMode.CLAMP)
        skyCanvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), skyPaint)

        // Analyze sky region (typically bright, high-chroma blue, or top gradient)
        for (i in 0 until size) {
            val x = i % w
            val y = i / w
            if (y > h * 0.65f) continue // Skip bottom grounds entirely

            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)

            val isSkyColor = (b > g && g > r && b > 110) || (r > 200 && g > 200 && b > 200) // Blue sky or bright white clouds

            if (isSkyColor) {
                // Linear blending gradient transition towards ground
                val skyP = skyBmp.getPixel(x, y)
                pixels[i] = skyP
            }
        }

        dest.setPixels(pixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Image Sharpening: Boosts micro-contrast along edges.
     */
    fun sharpenImage(src: Bitmap, intensity: Float): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val outPixels = IntArray(size)

        // 3x3 Sharpening kernel:
        //  0  -1  0
        // -1   5 -1
        //  0  -1  0
        val kCenter = 1.0f + 4f * intensity
        val kEdge = -intensity

        for (y in 1 until h - 1) {
            val offset = y * w
            for (x in 1 until w - 1) {
                val idx = offset + x
                val c = pixels[idx]
                val t = pixels[idx - w]
                val b = pixels[idx + w]
                val l = pixels[idx - 1]
                val r = pixels[idx + 1]

                var red = (Color.red(c) * kCenter + (Color.red(t) + Color.red(b) + Color.red(l) + Color.red(r)) * kEdge).roundToInt()
                var green = (Color.green(c) * kCenter + (Color.green(t) + Color.green(b) + Color.green(l) + Color.green(r)) * kEdge).roundToInt()
                var blue = (Color.blue(c) * kCenter + (Color.blue(t) + Color.blue(b) + Color.blue(l) + Color.blue(r)) * kEdge).roundToInt()

                outPixels[idx] = (Color.alpha(c) shl 24) or
                        (red.coerceIn(0, 255) shl 16) or
                        (green.coerceIn(0, 255) shl 8) or
                        blue.coerceIn(0, 255)
            }
        }

        // Match borders
        for (x in 0 until w) {
            outPixels[x] = pixels[x]
            outPixels[(h - 1) * w + x] = pixels[(h - 1) * w + x]
        }
        for (y in 0 until h) {
            outPixels[y * w] = pixels[y * w]
            outPixels[y * w + (w - 1)] = pixels[y * w + (w - 1)]
        }

        dest.setPixels(outPixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Upscaling (Super Resolution approximation): Bicubic/ Lanczos-like edge-preserving scale reconstruction.
     */
    fun upscaleImage(src: Bitmap, factor: Int): Bitmap {
        val nw = src.width * factor
        val nh = src.height * factor
        val dest = Bitmap.createScaledBitmap(src, nw, nh, true)
        // Enhance details after scaling using an unsharp mask
        return sharpenImage(dest, 0.4f)
    }

    /**
     * AI Cartoon Effect: Sobel line drawing overlaid on bilateral posterization.
     */
    fun cartoonStyle(src: Bitmap): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h

        // 1. Bilateral posterization (Color quantization)
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val outPixels = IntArray(size)
        val steps = 5 // Levels of posterization

        // 2. Sobel edge detection
        for (y in 1 until h - 1) {
            val offset = y * w
            for (x in 1 until w - 1) {
                val idx = offset + x

                // Pixels surrounding
                val c = pixels[idx]
                val t = pixels[idx - w]
                val b = pixels[idx + w]
                val l = pixels[idx - 1]
                val r = pixels[idx + 1]

                // Bilateral Quantization
                var cr = Color.red(c)
                var cg = Color.green(c)
                var cb = Color.blue(c)

                cr = (cr / 255.0f * steps).roundToInt() * (255 / steps)
                cg = (cg / 255.0f * steps).roundToInt() * (255 / steps)
                cb = (cb / 255.0f * steps).roundToInt() * (255 / steps)

                // Sobel intensity gradients
                val lumC = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3f
                val lumT = (Color.red(t) + Color.green(t) + Color.blue(t)) / 3f
                val lumB = (Color.red(b) + Color.green(b) + Color.blue(b)) / 3f
                val lumL = (Color.red(l) + Color.green(l) + Color.blue(l)) / 3f
                val lumR = (Color.red(r) + Color.green(r) + Color.blue(r)) / 3f

                val dx = lumR - lumL
                val dy = lumB - lumT
                val edge = sqrt(dx * dx + dy * dy)

                if (edge > 32) {
                    // Cartoon outline: Draw solid dark outline
                    outPixels[idx] = (0xFF shl 24) or (15 shl 16) or (15 shl 8) or 15
                } else {
                    outPixels[idx] = (Color.alpha(c) shl 24) or (cr shl 16) or (cg shl 8) or cb
                }
            }
        }

        dest.setPixels(outPixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Sketch Style: Master pencil drawing. Grayscale + Blur-Invert + Dodge Blend.
     */
    fun sketchStyle(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val size = w * h

        // 1. Grayscale
        val grayBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val grayCanvas = Canvas(grayBmp)
        val cm = ColorMatrix().apply { setSaturation(0f) }
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
        grayCanvas.drawBitmap(src, 0f, 0f, paint)

        // 2. Invert Grayscale
        val invBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val invCanvas = Canvas(invBmp)
        val invCm = ColorMatrix(floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        ))
        val invPaint = Paint().apply { colorFilter = ColorMatrixColorFilter(invCm) }
        invCanvas.drawBitmap(grayBmp, 0f, 0f, invPaint)

        // 3. Gaussian/Box Blur the inverted image
        val blurredInvBmp = boxBlur(invBmp, 8)

        // 4. Color Dodge Blend (Gray + BlurredInverted)
        val finalBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val gPixels = IntArray(size)
        val bPixels = IntArray(size)
        grayBmp.getPixels(gPixels, 0, w, 0, 0, w, h)
        blurredInvBmp.getPixels(bPixels, 0, w, 0, 0, w, h)

        val outPixels = IntArray(size)
        for (i in 0 until size) {
            val gp = gPixels[i]
            val bp = bPixels[i]

            val gr = Color.red(gp)
            val br = Color.red(bp)

            // Color Dodge formula: Target = Base / (1 - Blend)
            val outVal = if (br == 255) 255 else min(255, (gr * 255) / (255 - br))
            outPixels[i] = (0xFF shl 24) or (outVal shl 16) or (outVal shl 8) or outVal
        }

        finalBmp.setPixels(outPixels, 0, w, 0, 0, w, h)
        return finalBmp
    }

    /**
     * AI Painting / Oil Style: Classic Kuwahara Filter.
     */
    fun oilPaintingStyle(src: Bitmap): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val outPixels = IntArray(size)
        val radius = 4 // Kuwahara window radius

        // Pre-calculate luminance
        val lums = FloatArray(size)
        for (i in 0 until size) {
            val p = pixels[i]
            lums[i] = (0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p))
        }

        for (y in radius until h - radius) {
            val offset = y * w
            for (x in radius until w - radius) {
                val idx = offset + x

                // 4 Quadrants:
                // Q1: top-left, Q2: top-right, Q3: bottom-left, Q4: bottom-right
                var r1 = 0; var g1 = 0; var b1 = 0; var sq1 = 0f; var m1 = 0f
                var r2 = 0; var g2 = 0; var b2 = 0; var sq2 = 0f; var m2 = 0f
                var r3 = 0; var g3 = 0; var b3 = 0; var sq3 = 0f; var m3 = 0f
                var r4 = 0; var g4 = 0; var b4 = 0; var sq4 = 0f; var m4 = 0f

                val n = ((radius + 1) * (radius + 1)).toFloat()

                // Calculate mean & variance for Q1 (-r to 0, -r to 0)
                for (dy in -radius..0) {
                    for (dx in -radius..0) {
                        val p = pixels[(y + dy) * w + (x + dx)]
                        r1 += Color.red(p); g1 += Color.green(p); b1 += Color.blue(p)
                        val l = lums[(y + dy) * w + (x + dx)]
                        m1 += l; sq1 += l * l
                    }
                }
                val mean1 = m1 / n
                val var1 = (sq1 / n) - (mean1 * mean1)

                // Q2 (0 to r, -r to 0)
                for (dy in -radius..0) {
                    for (dx in 0..radius) {
                        val p = pixels[(y + dy) * w + (x + dx)]
                        r2 += Color.red(p); g2 += Color.green(p); b2 += Color.blue(p)
                        val l = lums[(y + dy) * w + (x + dx)]
                        m2 += l; sq2 += l * l
                    }
                }
                val mean2 = m2 / n
                val var2 = (sq2 / n) - (mean2 * mean2)

                // Q3 (-r to 0, 0 to r)
                for (dy in 0..radius) {
                    for (dx in -radius..0) {
                        val p = pixels[(y + dy) * w + (x + dx)]
                        r3 += Color.red(p); g3 += Color.green(p); b3 += Color.blue(p)
                        val l = lums[(y + dy) * w + (x + dx)]
                        m3 += l; sq3 += l * l
                    }
                }
                val mean3 = m3 / n
                val var3 = (sq3 / n) - (mean3 * mean3)

                // Q4 (0 to r, 0 to r)
                for (dy in 0..radius) {
                    for (dx in 0..radius) {
                        val p = pixels[(y + dy) * w + (x + dx)]
                        r4 += Color.red(p); g4 += Color.green(p); b4 += Color.blue(p)
                        val l = lums[(y + dy) * w + (x + dx)]
                        m4 += l; sq4 += l * l
                    }
                }
                val mean4 = m4 / n
                val var4 = (sq4 / n) - (mean4 * mean4)

                // Select quadrant with minimal variance
                var minVar = var1
                var finalR = r1; var finalG = g1; var finalB = b1

                if (var2 < minVar) {
                    minVar = var2
                    finalR = r2; finalG = g2; finalB = b2
                }
                if (var3 < minVar) {
                    minVar = var3
                    finalR = r3; finalG = g3; finalB = b3
                }
                if (var4 < minVar) {
                    minVar = var4
                    finalR = r4; finalG = g4; finalB = b4
                }

                val outR = (finalR / n).roundToInt().coerceIn(0, 255)
                val outG = (finalG / n).roundToInt().coerceIn(0, 255)
                val outB = (finalB / n).roundToInt().coerceIn(0, 255)

                outPixels[idx] = (Color.alpha(pixels[idx]) shl 24) or (outR shl 16) or (outG shl 8) or outB
            }
        }

        // Fill borders
        for (i in 0 until size) {
            if (outPixels[i] == 0) outPixels[i] = pixels[i]
        }

        dest.setPixels(outPixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Colorization: Intelligent conversion of grayscale matrices into lively, warm-graded color balances.
     */
    fun colorize(src: Bitmap): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        for (i in 0 until size) {
            val p = pixels[i]
            val a = Color.alpha(p)
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)

            // Convert to grayscale first to ensure clean canvas
            val gray = (0.299f * r + 0.587f * g + 0.114f * b).roundToInt()

            // Map gray tones to highly aesthetic color bands:
            // High highlight -> sky/soft yellow sunset glow
            // Mid highlights -> warm skin tone pink/orange
            // Shadow mids -> rich vegetation teal/blue
            // Deep shadows -> navy indigo
            val outR: Int
            val outG: Int
            val outB: Int

            if (gray > 200) {
                outR = (gray * 1.05f).roundToInt().coerceIn(0, 255)
                outG = (gray * 0.98f).roundToInt().coerceIn(0, 255)
                outB = (gray * 0.90f).roundToInt().coerceIn(0, 255)
            } else if (gray > 120) {
                outR = (gray * 1.10f).roundToInt().coerceIn(0, 255)
                outG = (gray * 0.92f).roundToInt().coerceIn(0, 255)
                outB = (gray * 0.80f).roundToInt().coerceIn(0, 255)
            } else if (gray > 50) {
                outR = (gray * 0.75f).roundToInt().coerceIn(0, 255)
                outG = (gray * 0.95f).roundToInt().coerceIn(0, 255)
                outB = (gray * 0.82f).roundToInt().coerceIn(0, 255)
            } else {
                outR = (gray * 0.60f).roundToInt().coerceIn(0, 255)
                outG = (gray * 0.70f).roundToInt().coerceIn(0, 255)
                outB = (gray * 0.95f).roundToInt().coerceIn(0, 255)
            }

            pixels[i] = (a shl 24) or (outR shl 16) or (outG shl 8) or outB
        }

        dest.setPixels(pixels, 0, w, 0, 0, w, h)
        return dest
    }

    /**
     * AI Old Photo Restoration: Cleans salt-and-pepper outliers (dust/scratches), aligns contrast ratios.
     */
    fun restoreOldPhoto(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val size = w * h
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val outPixels = IntArray(size)

        // Median filter (3x3 window) to discard tiny white/black scratches
        for (y in 1 until h - 1) {
            val offset = y * w
            for (x in 1 until w - 1) {
                val idx = offset + x

                val windowR = IntArray(9)
                val windowG = IntArray(9)
                val windowB = IntArray(9)
                var count = 0

                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val p = pixels[(y + dy) * w + (x + dx)]
                        windowR[count] = Color.red(p)
                        windowG[count] = Color.green(p)
                        windowB[count] = Color.blue(p)
                        count++
                    }
                }

                windowR.sort()
                windowG.sort()
                windowB.sort()

                // Median index
                val mr = windowR[4]
                val mg = windowG[4]
                val mb = windowB[4]

                // Re-apply a beautiful warm retro restoration tone
                val restoredR = (mr * 1.04f).roundToInt().coerceIn(0, 255)
                val restoredG = (mg * 1.01f).roundToInt().coerceIn(0, 255)
                val restoredB = (mb * 0.95f).roundToInt().coerceIn(0, 255)

                outPixels[idx] = (Color.alpha(pixels[idx]) shl 24) or (restoredR shl 16) or (restoredG shl 8) or restoredB
            }
        }

        // Fill boundaries
        for (x in 0 until w) {
            outPixels[x] = pixels[x]
            outPixels[(h - 1) * w + x] = pixels[(h - 1) * w + x]
        }
        for (y in 0 until h) {
            outPixels[y * w] = pixels[y * w]
            outPixels[y * w + (w - 1)] = pixels[y * w + (w - 1)]
        }

        val restoredBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        restoredBmp.setPixels(outPixels, 0, w, 0, 0, w, h)

        // Boost details
        return sharpenImage(restoredBmp, 0.25f)
    }
}
