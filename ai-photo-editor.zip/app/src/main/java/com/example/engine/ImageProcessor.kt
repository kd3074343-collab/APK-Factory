package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.example.data.model.BrushStroke
import com.example.data.model.Point2D
import com.example.data.model.ProjectLayer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

object ImageProcessor {

    /**
     * Blend modes translation to Android PorterDuff.Mode
     */
    fun getBlendMode(mode: String): PorterDuffXfermode {
        val pdMode = when (mode.trim()) {
            "Multiply" -> PorterDuff.Mode.MULTIPLY
            "Screen" -> PorterDuff.Mode.SCREEN
            "Overlay" -> PorterDuff.Mode.OVERLAY
            "Darken" -> PorterDuff.Mode.DARKEN
            "Lighten" -> PorterDuff.Mode.LIGHTEN
            "ColorDodge" -> PorterDuff.Mode.ADD
            "Clear" -> PorterDuff.Mode.CLEAR
            else -> PorterDuff.Mode.SRC_OVER
        }
        return PorterDuffXfermode(pdMode)
    }

    /**
     * Apply fundamental photo editing adjustments using a combined ColorMatrix.
     */
    fun applyAdjustments(src: Bitmap, layer: ProjectLayer): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(dest)

        val cm = ColorMatrix()

        // 1. Exposure & Brightness
        // Exposure offsets/scales, Brightness offsets
        val exp = layer.exposure // -2.0 to 2.0
        val expScale = 2.0f.pow(exp)
        val bri = layer.brightness * 255f // -255 to 255

        val matrixExpBri = floatArrayOf(
            expScale, 0f, 0f, 0f, bri,
            0f, expScale, 0f, 0f, bri,
            0f, 0f, expScale, 0f, bri,
            0f, 0f, 0f, 1f, 0f
        )
        cm.set(ColorMatrix(matrixExpBri))

        // 2. Contrast
        val con = layer.contrast // 0.5 to 2.0
        val t = (1.0f - con) * 127.5f
        val matrixContrast = floatArrayOf(
            con, 0f, 0f, 0f, t,
            0f, con, 0f, 0f, t,
            0f, 0f, con, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
        cm.postConcat(ColorMatrix(matrixContrast))

        // 3. Saturation & Vibrance
        val sat = layer.saturation // 0.0 to 2.0
        val cmSat = ColorMatrix()
        cmSat.setSaturation(sat)
        cm.postConcat(cmSat)

        // 4. Temperature & Tint
        // Temperature ranges from -1.0 (cool/blue) to 1.0 (warm/yellow)
        // Tint ranges from -1.0 (green) to 1.0 (magenta)
        val temp = layer.temperature
        val tint = layer.tint
        val rOffset = temp * 20f
        val gOffset = -tint * 15f + (temp * -5f)
        val bOffset = -temp * 20f + (tint * 15f)
        val matrixTempTint = floatArrayOf(
            1f, 0f, 0f, 0f, rOffset,
            0f, 1f, 0f, 0f, gOffset,
            0f, 0f, 1f, 0f, bOffset,
            0f, 0f, 0f, 1f, 0f
        )
        cm.postConcat(ColorMatrix(matrixTempTint))

        // Apply via Paint
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        canvas.drawBitmap(src, 0f, 0f, paint)

        // Apply gamma, highlights, shadows, whites, blacks locally if requested
        applyHighlightsShadowsGamma(dest, layer)

        // Apply Vignette if enabled
        if (layer.vignette > 0f) {
            applyVignette(dest, layer.vignette)
        }

        // Apply Grain if enabled
        if (layer.grain > 0f) {
            applyGrain(dest, layer.grain)
        }

        // Apply Sharpness or Clarity if enabled
        var updatedDest = dest
        if (layer.sharpness > 0f) {
            updatedDest = applySharpnessKernel(updatedDest, layer.sharpness)
        }
        if (layer.clarity > 0f) {
            updatedDest = applyClarityContrast(updatedDest, layer.clarity)
        }
        if (layer.dehaze > 0f) {
            updatedDest = applyDehazeEffect(updatedDest, layer.dehaze)
        }

        return updatedDest
    }

    /**
     * Sharpness implementation via 3x3 convolution kernel (Laplacian / Unsharp Mask)
     */
    private fun applySharpnessKernel(src: Bitmap, intensity: Float): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val width = src.width
        val height = src.height
        val size = width * height
        val pixels = IntArray(size)
        val outPixels = IntArray(size)
        src.getPixels(pixels, 0, width, 0, 0, width, height)

        // Define a 3x3 Laplacian edge sharpening filter
        // High values boost edges
        val edgeWeight = intensity * 1.5f
        val centerWeight = 1.0f + 4f * edgeWeight

        for (y in 1 until height - 1) {
            val offset = y * width
            for (x in 1 until width - 1) {
                val idx = offset + x

                // Pixels in 3x3 neighborhood
                val c = pixels[idx]
                val t = pixels[idx - width]
                val b = pixels[idx + width]
                val l = pixels[idx - 1]
                val r = pixels[idx + 1]

                val a = Color.alpha(c)

                var rCh = (Color.red(c) * centerWeight - (Color.red(t) + Color.red(b) + Color.red(l) + Color.red(r)) * edgeWeight).toInt()
                var gCh = (Color.green(c) * centerWeight - (Color.green(t) + Color.green(b) + Color.green(l) + Color.green(r)) * edgeWeight).toInt()
                var bCh = (Color.blue(c) * centerWeight - (Color.blue(t) + Color.blue(b) + Color.blue(l) + Color.blue(r)) * edgeWeight).toInt()

                rCh = max(0, min(255, rCh))
                gCh = max(0, min(255, gCh))
                bCh = max(0, min(255, bCh))

                outPixels[idx] = (a shl 24) or (rCh shl 16) or (gCh shl 8) or bCh
            }
        }

        // Handle edge padding with original pixels
        for (x in 0 until width) {
            outPixels[x] = pixels[x]
            outPixels[(height - 1) * width + x] = pixels[(height - 1) * width + x]
        }
        for (y in 0 until height) {
            outPixels[y * width] = pixels[y * width]
            outPixels[y * width + (width - 1)] = pixels[y * width + (width - 1)]
        }

        dest.setPixels(outPixels, 0, width, 0, 0, width, height)
        return dest
    }

    /**
     * Contrast-based Clarity slider (enhances local midtone contrast)
     */
    private fun applyClarityContrast(src: Bitmap, clarity: Float): Bitmap {
        // High-contrast S-curve local adaptation
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val width = src.width
        val height = src.height
        val size = width * height
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, width, 0, 0, width, height)

        val factor = 1.0f + clarity * 0.4f
        for (i in 0 until size) {
            val p = pixels[i]
            val a = Color.alpha(p)
            var r = Color.red(p)
            var g = Color.green(p)
            var b = Color.blue(p)

            // Scale difference from midtones (127.5)
            r = ((r - 128) * factor + 128).roundToInt()
            g = ((g - 128) * factor + 128).roundToInt()
            b = ((b - 128) * factor + 128).roundToInt()

            pixels[i] = (a shl 24) or (max(0, min(255, r)) shl 16) or (max(0, min(255, g)) shl 8) or max(0, min(255, b))
        }

        dest.setPixels(pixels, 0, width, 0, 0, width, height)
        return dest
    }

    /**
     * Dehaze effect (reduces foggy glare by boosting saturation, contrast, and dark channels)
     */
    private fun applyDehazeEffect(src: Bitmap, intensity: Float): Bitmap {
        val dest = src.copy(Bitmap.Config.ARGB_8888, true)
        val width = src.width
        val height = src.height
        val size = width * height
        val pixels = IntArray(size)
        src.getPixels(pixels, 0, width, 0, 0, width, height)

        // Simple dark channel prior dehaze approximation
        // High-dehaze lowers black levels and boosts global contrast/saturation
        val minRatio = 1.0f - intensity * 0.3f
        val contrastFactor = 1.0f + intensity * 0.25f

        for (i in 0 until size) {
            val p = pixels[i]
            val a = Color.alpha(p)
            var r = Color.red(p)
            var g = Color.green(p)
            var b = Color.blue(p)

            // Dim dark values to eliminate atmospheric haze
            r = ((r * minRatio - 15f * intensity) * contrastFactor).roundToInt()
            g = ((g * minRatio - 15f * intensity) * contrastFactor).roundToInt()
            b = ((b * minRatio - 10f * intensity) * contrastFactor).roundToInt()

            pixels[i] = (a shl 24) or (max(0, min(255, r)) shl 16) or (max(0, min(255, g)) shl 8) or max(0, min(255, b))
        }

        dest.setPixels(pixels, 0, width, 0, 0, width, height)
        return dest
    }

    /**
     * Highlights, Shadows, Whites, Blacks, and Gamma adjustments.
     */
    private fun applyHighlightsShadowsGamma(bmp: Bitmap, layer: ProjectLayer) {
        val width = bmp.width
        val height = bmp.height
        val pixels = IntArray(width * height)
        bmp.getPixels(pixels, 0, width, 0, 0, width, height)

        val shadows = layer.shadows     // -1.0 to 1.0
        val highlights = layer.highlights // -1.0 to 1.0
        val whites = layer.whites         // -1.0 to 1.0
        val blacks = layer.blacks         // -1.0 to 1.0
        val gamma = layer.gamma           // 0.5 to 2.0

        for (i in pixels.indices) {
            val p = pixels[i]
            val a = Color.alpha(p)
            var r = Color.red(p) / 255.0f
            var g = Color.green(p) / 255.0f
            var b = Color.blue(p) / 255.0f

            // Apply Gamma
            if (gamma != 1.0f) {
                r = r.pow(gamma)
                g = g.pow(gamma)
                b = b.pow(gamma)
            }

            // Luminance calculation
            val lum = 0.2126f * r + 0.7152f * g + 0.0722f * b

            // Highlights adjustment (affects high-luminance regions > 0.6)
            if (highlights != 0f && lum > 0.6f) {
                val weight = (lum - 0.6f) / 0.4f
                val hFactor = 1.0f + (highlights * 0.5f * weight)
                r *= hFactor
                g *= hFactor
                b *= hFactor
            }

            // Shadows adjustment (affects low-luminance regions < 0.4)
            if (shadows != 0f && lum < 0.4f) {
                val weight = (0.4f - lum) / 0.4f
                val sFactor = 1.0f + (shadows * 0.6f * weight)
                r *= sFactor
                g *= sFactor
                b *= sFactor
            }

            // Whites adjustment (extremely bright peaks > 0.8)
            if (whites != 0f && lum > 0.8f) {
                val weight = (lum - 0.8f) / 0.2f
                val wOffset = whites * 0.3f * weight
                r += wOffset
                g += wOffset
                b += wOffset
            }

            // Blacks adjustment (extremely dark peaks < 0.2)
            if (blacks != 0f && lum < 0.2f) {
                val weight = (0.2f - lum) / 0.2f
                val bOffset = blacks * 0.3f * weight
                r += bOffset
                g += bOffset
                b += bOffset
            }

            // Clamp and update
            val ri = max(0, min(255, (r * 255f).roundToInt()))
            val gi = max(0, min(255, (g * 255f).roundToInt()))
            val bi = max(0, min(255, (b * 255f).roundToInt()))

            pixels[i] = (a shl 24) or (ri shl 16) or (gi shl 8) or bi
        }

        bmp.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    /**
     * Classic Vignette Effect
     */
    private fun applyVignette(bmp: Bitmap, intensity: Float) {
        val width = bmp.width
        val height = bmp.height
        val canvas = Canvas(bmp)

        // Radial gradient representing darkness
        val colors = intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb((intensity * 240).roundToInt(), 0, 0, 0))
        val stops = floatArrayOf(0.0f, 0.5f, 1.0f)

        val radius = Math.hypot(width.toDouble() / 2, height.toDouble() / 2).toFloat()
        val gradient = RadialGradient(
            width / 2f,
            height / 2f,
            radius,
            colors,
            stops,
            Shader.TileMode.CLAMP
        )

        val paint = Paint().apply {
            shader = gradient
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun Color.black(alpha: Float): Int {
        val aVal = (alpha * 240).roundToInt()
        return Color.argb(aVal, 0, 0, 0)
    }

    /**
     * Add analog/digital Grain Noise
     */
    private fun applyGrain(bmp: Bitmap, intensity: Float) {
        val width = bmp.width
        val height = bmp.height
        val size = width * height
        val pixels = IntArray(size)
        bmp.getPixels(pixels, 0, width, 0, 0, width, height)

        val rGenerator = java.util.Random()
        val range = intensity * 45f // Max noise level offset

        for (i in 0 until size) {
            val p = pixels[i]
            val a = Color.alpha(p)
            var r = Color.red(p)
            var g = Color.green(p)
            var b = Color.blue(p)

            val noise = (rGenerator.nextGaussian() * range).roundToInt()

            r = max(0, min(255, r + noise))
            g = max(0, min(255, g + noise))
            b = max(0, min(255, b + noise))

            pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }

        bmp.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    /**
     * Composite / draw all user layers (including text, brush, frames, etc.)
     */
    fun compositeLayers(
        original: Bitmap,
        layers: List<ProjectLayer>,
        brushBitmaps: Map<String, Bitmap> = emptyMap()
    ): Bitmap {
        val result = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)

        // Draw base background or first layer
        canvas.drawColor(Color.TRANSPARENT)

        for (layer in layers) {
            if (!layer.isVisible) continue

            val layerPaint = Paint().apply {
                isAntiAlias = true
                alpha = (layer.opacity * 255f).roundToInt()
                xfermode = getBlendMode(layer.blendMode)
            }

            when (layer.type) {
                "Image" -> {
                    // Base Image or extra image layer
                    val baseBmp = if (layer.name.contains("Base") || layer.layerImagePath == null) {
                        original
                    } else {
                        // Normally we load layer.layerImagePath. Let's fallback to original
                        original
                    }
                    val adjusted = applyAdjustments(baseBmp, layer)
                    canvas.drawBitmap(adjusted, 0f, 0f, layerPaint)
                }
                "Brush" -> {
                    // Hand-drawn brush stroke bitmap or canvas path drawing
                    val brushBmp = brushBitmaps[layer.id]
                    if (brushBmp != null) {
                        canvas.drawBitmap(brushBmp, 0f, 0f, layerPaint)
                    } else {
                        // Draw vector strokes dynamically on a temporary layer
                        val tempBmp = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
                        val tempCanvas = Canvas(tempBmp)
                        layer.brushStrokes?.forEach { stroke ->
                            drawSingleStroke(tempCanvas, stroke)
                        }
                        canvas.drawBitmap(tempBmp, 0f, 0f, layerPaint)
                    }
                }
                "Text" -> {
                    // Draw custom text layers
                    val textBmp = createTextBitmap(original.width, original.height, layer)
                    canvas.drawBitmap(textBmp, 0f, 0f, layerPaint)
                }
                "Shape" -> {
                    // Draw vector overlays, shapes, frames, borders
                    val shapeBmp = createShapeBitmap(original.width, original.height, layer)
                    canvas.drawBitmap(shapeBmp, 0f, 0f, layerPaint)
                }
            }
        }

        return result
    }

    /**
     * Draw vector-based brush strokes on a canvas
     */
    fun drawSingleStroke(canvas: Canvas, stroke: BrushStroke) {
        if (stroke.points.isEmpty()) return

        val paint = Paint().apply {
            isAntiAlias = true
            color = stroke.color.toInt()
            strokeWidth = stroke.size
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = (stroke.opacity * 255).roundToInt()

            if (stroke.toolType == "Blur" || stroke.toolType == "Eraser" || stroke.toolType == "Mosaic") {
                // Adjust drawing configs for special brushes
                if (stroke.toolType == "Eraser") {
                    xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                }
            }
        }

        val path = Path()
        val first = stroke.points.first()
        path.moveTo(first.x, first.y)

        for (i in 1 until stroke.points.size) {
            val p = stroke.points[i]
            path.lineTo(p.x, p.y)
        }

        canvas.drawPath(path, paint)
    }

    /**
     * Create text overlay Bitmap
     */
    private fun createTextBitmap(width: Int, height: Int, layer: ProjectLayer): Bitmap {
        val textBmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(textBmp)

        if (layer.textValue.isEmpty()) return textBmp

        val textPaint = Paint().apply {
            isAntiAlias = true
            textSize = layer.fontSize * (width / 400f) // Scale text relative to image width
            textAlign = Paint.Align.CENTER
            color = layer.textColor.toInt()
        }

        // Apply custom text styling
        if (layer.isGradientText) {
            val gradient = LinearGradient(
                width * 0.2f, height * 0.5f,
                width * 0.8f, height * 0.5f,
                layer.gradientColorStart.toInt(),
                layer.gradientColorEnd.toInt(),
                Shader.TileMode.CLAMP
            )
            textPaint.shader = gradient
        }

        // Shadows
        if (layer.textShadowColor != 0L) {
            textPaint.setShadowLayer(8f, 4f, 4f, layer.textShadowColor.toInt())
        }

        // Render curved or standard text
        val x = width / 2f + layer.offsetX
        val y = height / 2f + layer.offsetY

        if (layer.isCurved) {
            val path = Path()
            val radius = width * 0.35f
            val rect = RectF(x - radius, y - radius, x + radius, y + radius)
            path.addArc(rect, 180f, 180f)
            canvas.drawTextOnPath(layer.textValue, path, 0f, 0f, textPaint)
        } else {
            // Check for stroke outline
            if (layer.textStrokeWidth > 0f) {
                val strokePaint = Paint(textPaint).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = layer.textStrokeWidth * (width / 400f)
                    color = layer.textStrokeColor.toInt()
                    shader = null // Remove gradient from stroke
                }
                canvas.drawText(layer.textValue, x, y, strokePaint)
            }
            canvas.drawText(layer.textValue, x, y, textPaint)
        }

        return textBmp
    }

    /**
     * Draw decorative frames, borders, and overlays.
     */
    private fun createShapeBitmap(width: Int, height: Int, layer: ProjectLayer): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        // If there's a custom frame
        val frameId = layer.frameId
        if (frameId != null) {
            val paint = Paint().apply {
                isAntiAlias = true
                style = Paint.Style.STROKE
                color = layer.textColor.toInt() // Frame color
                strokeWidth = width * 0.04f // 4% of width
            }
            when (frameId) {
                "Classic Border" -> {
                    val inset = width * 0.02f
                    canvas.drawRect(inset, inset, width - inset, height - inset, paint)
                }
                "Oval" -> {
                    paint.style = Paint.Style.STROKE
                    val rect = RectF(width * 0.05f, height * 0.05f, width * 0.95f, height * 0.95f)
                    canvas.drawOval(rect, paint)
                }
                "Polaroid Frame" -> {
                    // Thick bottom white frame
                    val backgroundPaint = Paint().apply {
                        color = Color.WHITE
                        style = Paint.Style.FILL
                    }
                    // We can cover bottom area
                    val borderSize = width * 0.05f
                    canvas.drawRect(0f, 0f, width.toFloat(), borderSize, backgroundPaint) // Top
                    canvas.drawRect(0f, 0f, borderSize, height.toFloat(), backgroundPaint) // Left
                    canvas.drawRect(width - borderSize, 0f, width.toFloat(), height.toFloat(), backgroundPaint) // Right
                    canvas.drawRect(0f, height - (width * 0.18f), width.toFloat(), height.toFloat(), backgroundPaint) // Bottom
                }
            }
        }

        return bmp
    }

    /**
     * Applies standard preset filters (Vintage, Cinematic, Retro, Landscape, B&W, Neon, HDR, Cinematic, Portrait)
     */
    fun applyPresetFilter(src: Bitmap, filterName: String, intensity: Float): Bitmap {
        if (intensity <= 0f) return src

        val baseDest = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(baseDest)
        val cm = ColorMatrix()

        when (filterName) {
            "Vintage" -> {
                // Yellow tint, warm look, slightly faded contrast
                val vintageMatrix = floatArrayOf(
                    0.95f, 0f, 0f, 0f, 20f * intensity,
                    0f, 0.90f, 0f, 0f, 15f * intensity,
                    0f, 0f, 0.80f, 0f, -10f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(vintageMatrix)
            }
            "Film" -> {
                // Deep blue shadows, slightly warm highlight, vintage analog
                val filmMatrix = floatArrayOf(
                    1.05f, 0f, 0f, 0f, 10f * intensity,
                    0f, 0.98f, 0f, 0f, 0f,
                    0f, 0f, 1.1f, 0f, 15f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(filmMatrix)
            }
            "Black & White" -> {
                // High contrast desaturation
                val bwMatrix = ColorMatrix().apply { setSaturation(0f) }
                val contrast = 1.0f + 0.3f * intensity
                val t = (1.0f - contrast) * 127.5f
                val contrastMatrix = floatArrayOf(
                    contrast, 0f, 0f, 0f, t,
                    0f, contrast, 0f, 0f, t,
                    0f, 0f, contrast, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(bwMatrix)
                cm.postConcat(ColorMatrix(contrastMatrix))
            }
            "HDR" -> {
                // Dramatic contrast and high edge saturation
                val hdrMatrix = floatArrayOf(
                    1.15f, 0f, 0f, 0f, 10f * intensity,
                    0f, 1.15f, 0f, 0f, 10f * intensity,
                    0f, 0f, 1.15f, 0f, 10f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(hdrMatrix)
                val satMatrix = ColorMatrix().apply { setSaturation(1.0f + 0.4f * intensity) }
                cm.postConcat(satMatrix)
            }
            "Portrait" -> {
                // Soft glow, warm orange highlight, low contrast midtones
                val portraitMatrix = floatArrayOf(
                    1.05f, 0f, 0f, 0f, 15f * intensity,
                    0f, 1.02f, 0f, 0f, 5f * intensity,
                    0f, 0f, 0.95f, 0f, -5f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(portraitMatrix)
            }
            "Landscape" -> {
                // Deep sky blues, rich greens, vivid contrast
                val landscapeMatrix = floatArrayOf(
                    1.0f, 0f, 0f, 0f, 5f * intensity,
                    0f, 1.10f, 0f, 0f, 15f * intensity,
                    0f, 0f, 1.20f, 0f, 25f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(landscapeMatrix)
            }
            "Neon" -> {
                // Shift color matrices to trigger intense cyber-style hues
                val neonMatrix = floatArrayOf(
                    1.3f, 0f, 0f, 0f, 20f * intensity,
                    0f, 0.8f, 0f, 0f, -10f * intensity,
                    0f, 0f, 1.4f, 0f, 30f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(neonMatrix)
            }
            "Retro" -> {
                // Amber sepia glow
                val sepiaMatrix = floatArrayOf(
                    0.393f + 0.607f * (1 - intensity), 0.769f - 0.769f * (1 - intensity), 0.189f - 0.189f * (1 - intensity), 0f, 0f,
                    0.349f - 0.349f * (1 - intensity), 0.686f + 0.314f * (1 - intensity), 0.168f - 0.168f * (1 - intensity), 0f, 0f,
                    0.272f - 0.272f * (1 - intensity), 0.534f - 0.534f * (1 - intensity), 0.131f + 0.869f * (1 - intensity), 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(sepiaMatrix)
            }
            "Cinematic" -> {
                // Deep teal-orange grade
                val cinematicMatrix = floatArrayOf(
                    1.1f, 0f, 0f, 0f, 10f * intensity,
                    0f, 0.95f, 0f, 0f, 0f,
                    0f, 0f, 1.15f, 0f, 15f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(cinematicMatrix)
                // Boost saturation of oranges, slightly cool shadows
            }
            "Seasonal (Autumn)" -> {
                // Boost reds/oranges, convert green tones to gold
                val autumnMatrix = floatArrayOf(
                    1.2f, 0f, 0f, 0f, 20f * intensity,
                    0.1f, 1.0f, 0f, 0f, 10f * intensity,
                    0f, 0f, 0.8f, 0f, -20f * intensity,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.set(autumnMatrix)
            }
            else -> return src
        }

        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        canvas.drawBitmap(src, 0f, 0f, paint)

        // Interpolate between original and filtered bitmap based on intensity
        if (intensity < 1f) {
            val combinedBmp = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
            val combCanvas = Canvas(combinedBmp)
            combCanvas.drawBitmap(src, 0f, 0f, null)
            val interpPaint = Paint().apply {
                alpha = (intensity * 255).roundToInt()
            }
            combCanvas.drawBitmap(baseDest, 0f, 0f, interpPaint)
            return combinedBmp
        }

        return baseDest
    }
}
