package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ProjectViewModel
import com.example.ui.screens.ProjectListScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: ProjectViewModel = viewModel()
                val activeProject by viewModel.currentProject.collectAsState()

                // Safe dynamic runtime permission requester
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissions ->
                    val allGranted = permissions.values.all { it }
                    if (!allGranted) {
                        Toast.makeText(
                            this,
                            "Some permissions were denied. Certain local studio tools may be restricted.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                LaunchedEffect(Unit) {
                    val permissionsNeeded = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        arrayOf(
                            Manifest.permission.READ_MEDIA_IMAGES,
                            Manifest.permission.CAMERA
                        )
                    } else {
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.CAMERA
                        )
                    }
                    permissionLauncher.launch(permissionsNeeded)
                }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Switch screen seamlessly using subtle animations
                    AnimatedContent(
                        targetState = activeProject,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "studio_navigation"
                    ) { project ->
                        if (project == null) {
                            ProjectListScreen(
                                viewModel = viewModel,
                                onProjectSelected = {},
                                modifier = Modifier.padding(innerPadding)
                            )
                        } else {
                            StudioScreen(
                                viewModel = viewModel,
                                onBackToList = {
                                    viewModel.closeProject()
                                },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }
                    }
                }
            }
        }
    }
}
