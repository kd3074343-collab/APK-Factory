package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import com.example.data.model.BrushStroke
import com.example.data.model.Point2D
import kotlin.math.roundToInt

@Composable
fun DrawingCanvas(
    compositeBitmap: Bitmap?,
    isDrawMode: Boolean,
    brushColor: Long,
    brushSize: Float,
    brushOpacity: Float,
    brushToolType: String, // "Brush", "Eraser", "Blur", "ObjectRemoval"
    onStrokeDrawn: (BrushStroke) -> Unit,
    onObjectRemovalMaskDrawn: (List<Point2D>) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    // Live active stroke points being drawn in real-time
    var activePoints = remember { mutableStateListOf<Point2D>() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E))
            .pointerInput(isDrawMode) {
                if (isDrawMode) {
                    // Record brush drawing gestures
                    detectDragGestures(
                        onDragStart = { startOffset ->
                            activePoints.clear()
                            // Map screen coordinate to canvas coordinates based on zoom/pan matrices
                            val mappedX = (startOffset.x - offset.x) / scale
                            val mappedY = (startOffset.y - offset.y) / scale
                            activePoints.add(Point2D(mappedX, mappedY))
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val mappedX = (change.position.x - offset.x) / scale
                            val mappedY = (change.position.y - offset.y) / scale
                            activePoints.add(Point2D(mappedX, mappedY))
                        },
                        onDragEnd = {
                            if (activePoints.isNotEmpty()) {
                                val stroke = BrushStroke(
                                    points = activePoints.toList(),
                                    color = brushColor,
                                    size = brushSize,
                                    opacity = brushOpacity,
                                    toolType = brushToolType
                                )
                                if (brushToolType == "ObjectRemoval") {
                                    onObjectRemovalMaskDrawn(activePoints.toList())
                                } else {
                                    onStrokeDrawn(stroke)
                                }
                                activePoints.clear()
                            }
                        }
                    )
                } else {
                    // Handle panning and zooming gestures
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 6.0f)
                        offset += pan
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            if (compositeBitmap != null) {
                val bmpW = compositeBitmap.width.toFloat()
                val bmpH = compositeBitmap.height.toFloat()

                // Center the image within available space initially
                val scaleFit = kotlin.math.min(canvasWidth / bmpW, canvasHeight / bmpH) * 0.9f
                val initialScale = if (scale == 1f && offset == Offset.Zero) scaleFit else scale

                val dx = if (offset == Offset.Zero) (canvasWidth - bmpW * initialScale) / 2f else offset.x
                val dy = if (offset == Offset.Zero) (canvasHeight - bmpH * initialScale) / 2f else offset.y

                // Set local variables if they were reset
                if (scale == 1f && offset == Offset.Zero) {
                    scale = initialScale
                    offset = Offset(dx, dy)
                }

                // Draw Composite Image with scale and translation matrix
                drawContext.canvas.save()
                drawContext.canvas.translate(offset.x, offset.y)
                drawContext.canvas.scale(scale, scale)

                // Render main image bitmap
                drawImage(
                    image = compositeBitmap.asImageBitmap(),
                    dstSize = IntSize(bmpW.roundToInt(), bmpH.roundToInt())
                )

                // Render active in-progress drawing points
                if (isDrawMode && activePoints.isNotEmpty()) {
                    val strokePaint = android.graphics.Paint().apply {
                        isAntiAlias = true
                        color = if (brushToolType == "ObjectRemoval") {
                            0x80FF007F.toInt() // Transparent pink highlight for object mask selection
                        } else {
                            brushColor.toInt()
                        }
                        strokeWidth = brushSize
                        style = android.graphics.Paint.Style.STROKE
                        strokeCap = android.graphics.Paint.Cap.ROUND
                        strokeJoin = android.graphics.Paint.Join.ROUND
                        alpha = (brushOpacity * 255).roundToInt()
                    }

                    val path = android.graphics.Path()
                    path.moveTo(activePoints.first().x, activePoints.first().y)
                    for (i in 1 until activePoints.size) {
                        path.lineTo(activePoints[i].x, activePoints[i].y)
                    }

                    drawContext.canvas.nativeCanvas.drawPath(path, strokePaint)
                }

                drawContext.canvas.restore()
            }
        }
    }
}
