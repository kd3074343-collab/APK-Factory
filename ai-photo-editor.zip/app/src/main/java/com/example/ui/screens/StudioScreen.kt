package com.example.ui.screens

import android.app.Application
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrushStroke
import com.example.data.model.Point2D
import com.example.data.model.ProjectLayer
import com.example.ui.ProjectViewModel
import com.example.ui.components.CurvesEditor
import com.example.ui.components.DrawingCanvas

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(
    viewModel: ProjectViewModel,
    onBackToList: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val project by viewModel.currentProject.collectAsState()
    val compositeBitmap by viewModel.compositeBitmap.collectAsState()
    val layers by viewModel.layers.collectAsState()
    val selectedLayerId by viewModel.selectedLayerId.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()

    // Studio active tab state
    var activeTab by remember { mutableStateOf("Adjust") } // Adjust, Layers, Curves, HSL, Brush, AI Lab, Text, Filters

    // Selected sub-tabs/sub-sliders
    var activeAdjustParam by remember { mutableStateOf("Exposure") }
    var activeCurveChannel by remember { mutableStateOf("Composite") }
    var activeHslChannel by remember { mutableStateOf("Red") }

    // Brush Tool Configs
    var brushToolType by remember { mutableStateOf("Brush") } // Brush, Eraser, Blur, ObjectRemoval
    var brushColor by remember { mutableStateOf(0xFFFF0000) }
    var brushSize by remember { mutableStateOf(15f) }
    var brushOpacity by remember { mutableStateOf(1.0f) }

    // Text Overlay Form Creator Dialog state
    var showTextCreator by remember { mutableStateOf(false) }
    var textValueInput by remember { mutableStateOf("") }
    var textColorInput by remember { mutableStateOf(0xFFFFFFFF) }

    // Export Dialog state
    var showExportModal by remember { mutableStateOf(false) }
    var exportFormat by remember { mutableStateOf("JPG") }
    var exportQuality by remember { mutableStateOf("High") }

    // Active Selected Layer Reference
    val selectedLayer = remember(layers, selectedLayerId) {
        layers.find { it.id == selectedLayerId }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project?.name ?: "Studio", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBackToList) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.undo() }, enabled = canUndo) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { viewModel.redo() }, enabled = canRedo) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo")
                    }
                    Button(
                        onClick = { showExportModal = true },
                        modifier = Modifier.testTag("export_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF151515))
        ) {
            // 1. Image View Canvas Box Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                DrawingCanvas(
                    compositeBitmap = compositeBitmap,
                    isDrawMode = activeTab == "Brush",
                    brushColor = brushColor,
                    brushSize = brushSize,
                    brushOpacity = brushOpacity,
                    brushToolType = brushToolType,
                    onStrokeDrawn = { stroke ->
                        viewModel.commitBrushStroke(stroke)
                    },
                    onObjectRemovalMaskDrawn = { points ->
                        viewModel.applyAIObjectRemoval(points, brushSize)
                        Toast.makeText(context, "AI Object Removal in progress...", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxSize()
                )

                if (isProcessing) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            }

            // 2. Dynamic Control & Configuration Workspace Tab
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // TAB CONTENTS
                    when (activeTab) {
                        "Adjust" -> {
                            if (selectedLayer != null) {
                                AdjustmentsTab(
                                    selectedLayer = selectedLayer,
                                    activeParam = activeAdjustParam,
                                    onParamSelected = { activeAdjustParam = it },
                                    onValueChange = { updated ->
                                        viewModel.updateSelectedLayer { updated }
                                    },
                                    onSliderRelease = {
                                        viewModel.commitAdjustmentChange()
                                    }
                                )
                            }
                        }
                        "Curves" -> {
                            CurvesTab(
                                activeChannel = activeCurveChannel,
                                onChannelSelected = { activeCurveChannel = it },
                                selectedLayer = selectedLayer,
                                onCurvePointsChanged = { updatedLayer ->
                                    viewModel.updateSelectedLayer { updatedLayer }
                                    viewModel.commitAdjustmentChange()
                                }
                            )
                        }
                        "HSL" -> {
                            HslTab(
                                activeChannel = activeHslChannel,
                                onChannelSelected = { activeHslChannel = it },
                                selectedLayer = selectedLayer,
                                onHslChanged = { updatedLayer ->
                                    viewModel.updateSelectedLayer { updatedLayer }
                                },
                                onSliderRelease = {
                                    viewModel.commitAdjustmentChange()
                                }
                            )
                        }
                        "Brush" -> {
                            BrushTab(
                                toolType = brushToolType,
                                onToolTypeSelected = { brushToolType = it },
                                brushColor = brushColor,
                                onColorSelected = { brushColor = it },
                                brushSize = brushSize,
                                onSizeChanged = { brushSize = it },
                                brushOpacity = brushOpacity,
                                onOpacityChanged = { brushOpacity = it },
                                onAddBrushLayer = { viewModel.addBrushLayer() }
                            )
                        }
                        "AI Lab" -> {
                            AiLabTab(
                                onApplyFeature = { featureName, intensity ->
                                    viewModel.applyAIFeature(featureName, intensity)
                                    Toast.makeText(context, "Applying $featureName locally...", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                        "Layers" -> {
                            LayersTab(
                                layers = layers,
                                selectedLayerId = selectedLayerId,
                                onLayerSelected = { viewModel.updateSelectedLayer { it } },
                                onDeleteLayer = { viewModel.deleteActiveLayer() },
                                onMoveLayer = { id, up -> viewModel.moveLayer(id, up) },
                                onAddText = { showTextCreator = true },
                                onAddFrame = { frameName -> viewModel.addFrameLayer(frameName) }
                            )
                        }
                        "Filters" -> {
                            FiltersTab(
                                onApplyPreset = { presetName, intensity ->
                                    viewModel.applyAIFeature(presetName, intensity)
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // BOTTOM WORKSPACE MODE TAB BUTTONS
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val tabs = listOf("Adjust", "Curves", "HSL", "Brush", "AI Lab", "Layers", "Filters")
                        tabs.forEach { tab ->
                            val isSelected = activeTab == tab
                            FilterChip(
                                selected = isSelected,
                                onClick = { activeTab = tab },
                                label = { Text(tab, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    // Text Creator Modal
    if (showTextCreator) {
        AlertDialog(
            onDismissRequest = { showTextCreator = false },
            title = { Text("Add Text Layer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = textValueInput,
                        onValueChange = { textValueInput = it },
                        label = { Text("Enter text") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Select Font Color", style = MaterialTheme.typography.bodySmall)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val colors = listOf(0xFFFFFFFF, 0xFFFF0000, 0xFFFFCC00, 0xFF00FFCC, 0xFFCC00FF)
                        colors.forEach { col ->
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(col))
                                    .border(
                                        width = if (textColorInput == col) 2.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = CircleShape
                                    )
                                    .clickable { textColorInput = col }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textValueInput.isNotBlank()) {
                            viewModel.addTextLayer(textValueInput, textColorInput)
                        }
                        showTextCreator = false
                        textValueInput = ""
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTextCreator = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Export Sheet Modal
    if (showExportModal) {
        AlertDialog(
            onDismissRequest = { showExportModal = false },
            title = { Text("Export Quality Settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Format", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("JPG", "PNG", "WEBP", "TIFF").forEach { fmt ->
                            ElevatedFilterChip(
                                selected = exportFormat == fmt,
                                onClick = { exportFormat = fmt },
                                label = { Text(fmt) }
                            )
                        }
                    }

                    Text("Resolution Quality", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Low", "Medium", "High", "Ultra HD").forEach { q ->
                            ElevatedFilterChip(
                                selected = exportQuality == q,
                                onClick = { exportQuality = q },
                                label = { Text(q) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExportModal = false
                        viewModel.exportComposedImage(context, exportFormat, exportQuality) { outPath ->
                            Toast.makeText(context, "Saved successfully: $outPath", Toast.LENGTH_LONG).show()
                        }
                    }
                ) {
                    Text("Download to Gallery")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportModal = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AdjustmentsTab(
    selectedLayer: ProjectLayer,
    activeParam: String,
    onParamSelected: (String) -> Unit,
    onValueChange: (ProjectLayer) -> Unit,
    onSliderRelease: () -> Unit
) {
    val params = listOf(
        "Exposure", "Brightness", "Contrast", "Saturation", "Vibrance",
        "Temperature", "Tint", "Shadows", "Highlights", "Whites", "Blacks",
        "Sharpness", "Clarity", "Dehaze", "Vignette", "Grain", "Gamma"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            params.forEach { param ->
                ElevatedAssistChip(
                    onClick = { onParamSelected(param) },
                    label = { Text(param) },
                    colors = if (activeParam == param) {
                        AssistChipDefaults.elevatedAssistChipColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    } else {
                        AssistChipDefaults.elevatedAssistChipColors()
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Range Mapping & Active Slider Rendering
        val sliderValue: Float
        val rangeStart: Float
        val rangeEnd: Float
        when (activeParam) {
            "Brightness" -> { sliderValue = selectedLayer.brightness; rangeStart = -1.0f; rangeEnd = 1.0f }
            "Contrast" -> { sliderValue = selectedLayer.contrast; rangeStart = 0.5f; rangeEnd = 2.0f }
            "Saturation" -> { sliderValue = selectedLayer.saturation; rangeStart = 0.0f; rangeEnd = 2.0f }
            "Vibrance" -> { sliderValue = selectedLayer.vibrance; rangeStart = 0.0f; rangeEnd = 2.0f }
            "Exposure" -> { sliderValue = selectedLayer.exposure; rangeStart = -2.0f; rangeEnd = 2.0f }
            "Temperature" -> { sliderValue = selectedLayer.temperature; rangeStart = -1.0f; rangeEnd = 1.0f }
            "Tint" -> { sliderValue = selectedLayer.tint; rangeStart = -1.0f; rangeEnd = 1.0f }
            "Shadows" -> { sliderValue = selectedLayer.shadows; rangeStart = -1.0f; rangeEnd = 1.0f }
            "Highlights" -> { sliderValue = selectedLayer.highlights; rangeStart = -1.0f; rangeEnd = 1.0f }
            "Whites" -> { sliderValue = selectedLayer.whites; rangeStart = -1.0f; rangeEnd = 1.0f }
            "Blacks" -> { sliderValue = selectedLayer.blacks; rangeStart = -1.0f; rangeEnd = 1.0f }
            "Sharpness" -> { sliderValue = selectedLayer.sharpness; rangeStart = 0.0f; rangeEnd = 1.0f }
            "Clarity" -> { sliderValue = selectedLayer.clarity; rangeStart = 0.0f; rangeEnd = 1.0f }
            "Dehaze" -> { sliderValue = selectedLayer.dehaze; rangeStart = 0.0f; rangeEnd = 1.0f }
            "Vignette" -> { sliderValue = selectedLayer.vignette; rangeStart = 0.0f; rangeEnd = 1.0f }
            "Grain" -> { sliderValue = selectedLayer.grain; rangeStart = 0.0f; rangeEnd = 1.0f }
            else -> { sliderValue = selectedLayer.gamma; rangeStart = 0.5f; rangeEnd = 2.0f } // Gamma
        }

        Text("$activeParam: ${String.format("%.2f", sliderValue)}", style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = sliderValue,
            onValueChange = { value ->
                val updated = when (activeParam) {
                    "Brightness" -> selectedLayer.copy(brightness = value)
                    "Contrast" -> selectedLayer.copy(contrast = value)
                    "Saturation" -> selectedLayer.copy(saturation = value)
                    "Vibrance" -> selectedLayer.copy(vibrance = value)
                    "Exposure" -> selectedLayer.copy(exposure = value)
                    "Temperature" -> selectedLayer.copy(temperature = value)
                    "Tint" -> selectedLayer.copy(tint = value)
                    "Shadows" -> selectedLayer.copy(shadows = value)
                    "Highlights" -> selectedLayer.copy(highlights = value)
                    "Whites" -> selectedLayer.copy(whites = value)
                    "Blacks" -> selectedLayer.copy(blacks = value)
                    "Sharpness" -> selectedLayer.copy(sharpness = value)
                    "Clarity" -> selectedLayer.copy(clarity = value)
                    "Dehaze" -> selectedLayer.copy(dehaze = value)
                    "Vignette" -> selectedLayer.copy(vignette = value)
                    "Grain" -> selectedLayer.copy(grain = value)
                    else -> selectedLayer.copy(gamma = value)
                }
                onValueChange(updated)
            },
            valueRange = rangeStart..rangeEnd,
            onValueChangeFinished = onSliderRelease
        )
    }
}

@Composable
fun CurvesTab(
    activeChannel: String,
    onChannelSelected: (String) -> Unit,
    selectedLayer: ProjectLayer?,
    onCurvePointsChanged: (ProjectLayer) -> Unit
) {
    val channels = listOf("Composite", "Red", "Green", "Blue")
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            channels.forEach { ch ->
                val isSelected = activeChannel == ch
                FilterChip(
                    selected = isSelected,
                    onClick = { onChannelSelected(ch) },
                    label = { Text(ch) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (selectedLayer != null) {
            val activePoints = when (activeChannel) {
                "Red" -> selectedLayer.curvePointsRed ?: emptyList()
                "Green" -> selectedLayer.curvePointsGreen ?: emptyList()
                "Blue" -> selectedLayer.curvePointsBlue ?: emptyList()
                else -> selectedLayer.curvePointsComposite ?: emptyList()
            }

            val channelColor = when (activeChannel) {
                "Red" -> Color.Red
                "Green" -> Color.Green
                "Blue" -> Color.Blue
                else -> Color.White
            }

            CurvesEditor(
                points = activePoints,
                curveColor = channelColor,
                onPointsChanged = { updatedPoints ->
                    val updatedLayer = when (activeChannel) {
                        "Red" -> selectedLayer.copy(curvePointsRed = updatedPoints)
                        "Green" -> selectedLayer.copy(curvePointsGreen = updatedPoints)
                        "Blue" -> selectedLayer.copy(curvePointsBlue = updatedPoints)
                        else -> selectedLayer.copy(curvePointsComposite = updatedPoints)
                    }
                    onCurvePointsChanged(updatedLayer)
                }
            )
        }
    }
}

@Composable
fun HslTab(
    activeChannel: String,
    onChannelSelected: (String) -> Unit,
    selectedLayer: ProjectLayer?,
    onHslChanged: (ProjectLayer) -> Unit,
    onSliderRelease: () -> Unit
) {
    val channels = listOf("Red", "Orange", "Yellow", "Green", "Aqua", "Blue", "Purple", "Magenta")
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            channels.forEach { ch ->
                ElevatedFilterChip(
                    selected = activeChannel == ch,
                    onClick = { onChannelSelected(ch) },
                    label = { Text(ch) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedLayer != null) {
            // Render H, S, L sliders for active channel
            val channelAdjustments = selectedLayer.hslChannels?.get(activeChannel)
                ?: com.example.data.model.HslAdjustments()

            // Hue
            Text("Hue Offset: ${channelAdjustments.hue.roundToInt()}°", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = channelAdjustments.hue,
                onValueChange = { h ->
                    val map = selectedLayer.hslChannels?.toMutableMap() ?: mutableMapOf()
                    map[activeChannel] = channelAdjustments.copy(hue = h)
                    onHslChanged(selectedLayer.copy(hslChannels = map))
                },
                valueRange = -180f..180f,
                onValueChangeFinished = onSliderRelease
            )

            // Saturation
            Text("Saturation Offset: ${channelAdjustments.saturation.roundToInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = channelAdjustments.saturation,
                onValueChange = { s ->
                    val map = selectedLayer.hslChannels?.toMutableMap() ?: mutableMapOf()
                    map[activeChannel] = channelAdjustments.copy(saturation = s)
                    onHslChanged(selectedLayer.copy(hslChannels = map))
                },
                valueRange = -100f..100f,
                onValueChangeFinished = onSliderRelease
            )

            // Lightness
            Text("Lightness Offset: ${channelAdjustments.lightness.roundToInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = channelAdjustments.lightness,
                onValueChange = { l ->
                    val map = selectedLayer.hslChannels?.toMutableMap() ?: mutableMapOf()
                    map[activeChannel] = channelAdjustments.copy(lightness = l)
                    onHslChanged(selectedLayer.copy(hslChannels = map))
                },
                valueRange = -100f..100f,
                onValueChangeFinished = onSliderRelease
            )
        }
    }
}

@Composable
fun BrushTab(
    toolType: String,
    onToolTypeSelected: (String) -> Unit,
    brushColor: Long,
    onColorSelected: (Long) -> Unit,
    brushSize: Float,
    onSizeChanged: (Float) -> Unit,
    brushOpacity: Float,
    onOpacityChanged: (Float) -> Unit,
    onAddBrushLayer: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Brush Utilities", fontWeight = FontWeight.Bold)
            Button(onClick = onAddBrushLayer, shape = RoundedCornerShape(8.dp)) {
                Icon(Icons.Default.Add, null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Sketch Layer")
            }
        }

        // Tool Type Picker
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Brush", "Eraser", "Blur", "ObjectRemoval").forEach { type ->
                val display = if (type == "ObjectRemoval") "Object Removal" else type
                ElevatedFilterChip(
                    selected = toolType == type,
                    onClick = { onToolTypeSelected(type) },
                    label = { Text(display) }
                )
            }
        }

        // Color Palettes (only if standard brush selected)
        if (toolType == "Brush") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val palettes = listOf(0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFFFF00, 0xFFFF00FF, 0xFF00FFFF, 0xFFFFFFFF, 0xFF000000)
                palettes.forEach { col ->
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(col))
                            .border(
                                width = if (brushColor == col) 2.dp else 0.dp,
                                color = MaterialTheme.colorScheme.primary,
                                shape = CircleShape
                            )
                            .clickable { onColorSelected(col) }
                    )
                }
            }
        }

        // Sliders
        Text("Size: ${brushSize.roundToInt()}px", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = brushSize,
            onValueChange = onSizeChanged,
            valueRange = 5f..120f
        )

        Text("Flow Opacity: ${(brushOpacity * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = brushOpacity,
            onValueChange = onOpacityChanged,
            valueRange = 0.1f..1.0f
        )
    }
}

@Composable
fun AiLabTab(
    onApplyFeature: (String, Float) -> Unit
) {
    val aiFeatures = listOf(
        "AI Auto Enhance", "AI Skin Smoothing", "AI Background Blur",
        "AI Background Removal", "AI Sky: Sunset", "AI Sky: Nebula", "AI Sky: Golden",
        "AI Colorization", "AI Old Photo Restoration", "AI Denoising", "AI Image Sharpening",
        "AI Upscaling (2×)", "AI Upscaling (4×)", "AI Cartoon Effect", "AI Sketch Effect", "AI Painting Styles"
    )

    var selectedFeature by remember { mutableStateOf("AI Auto Enhance") }
    var featureParam by remember { mutableStateOf(0.5f) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Offline Intelligent Coprocessor", fontWeight = FontWeight.Bold)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(aiFeatures) { feat ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedFeature = feat }
                            .background(
                                if (selectedFeature == feat) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when {
                                feat.contains("Enhance") -> Icons.Default.AutoAwesome
                                feat.contains("Smoothing") -> Icons.Default.Face
                                feat.contains("Removal") -> Icons.Default.ContentCut
                                feat.contains("Sky") -> Icons.Default.CloudQueue
                                feat.contains("Cartoon") -> Icons.Default.Brush
                                feat.contains("Sketch") -> Icons.Default.Edit
                                feat.contains("Painting") -> Icons.Default.Palette
                                else -> Icons.Default.Psychology
                            },
                            contentDescription = null,
                            tint = if (selectedFeature == feat) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            feat,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (selectedFeature == feat) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedFeature == feat) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Adjustable intensity slider (only if applicable to the selected tool)
        val supportsParam = selectedFeature.contains("Smoothing") ||
                selectedFeature.contains("Blur") ||
                selectedFeature.contains("Sharpening")

        if (supportsParam) {
            Text("Strength Slider: ${(featureParam * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = featureParam,
                onValueChange = { featureParam = it },
                valueRange = 0.1f..1.0f
            )
        }

        Button(
            onClick = { onApplyFeature(selectedFeature, featureParam) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("apply_ai_feature_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.FlashOn, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Run AI Compute Model")
        }
    }
}

@Composable
fun LayersTab(
    layers: List<ProjectLayer>,
    selectedLayerId: String?,
    onLayerSelected: (ProjectLayer) -> Unit,
    onDeleteLayer: () -> Unit,
    onMoveLayer: (String, Boolean) -> Unit,
    onAddText: () -> Unit,
    onAddFrame: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Layers Stack Manager", fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = onAddText, colors = IconButtonDefaults.filledIconButtonColors()) {
                    Icon(Icons.Default.TextFields, contentDescription = "Add Text Layer")
                }
                IconButton(
                    onClick = { onAddFrame("Classic Border") },
                    colors = IconButtonDefaults.filledIconButtonColors()
                ) {
                    Icon(Icons.Default.BorderOuter, contentDescription = "Add Border")
                }
            }
        }

        Box(modifier = Modifier.height(110.dp)) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(layers.asReversed()) { layer ->
                    val isSelected = selectedLayerId == layer.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onLayerSelected(layer) }
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            )
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (layer.type) {
                                "Text" -> Icons.Default.TextFields
                                "Brush" -> Icons.Default.Gesture
                                "Shape" -> Icons.Default.CropOriginal
                                else -> Icons.Default.Image
                            },
                            contentDescription = null,
                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            layer.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.weight(1f),
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        )

                        // Layer ordering arrow adjusters
                        IconButton(onClick = { onMoveLayer(layer.id, true) }, enabled = layers.indexOf(layer) < layers.size - 1) {
                            Icon(Icons.Default.ArrowUpward, null, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { onMoveLayer(layer.id, false) }, enabled = layers.indexOf(layer) > 0) {
                            Icon(Icons.Default.ArrowDownward, null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        if (layers.size > 1 && selectedLayerId != null) {
            Button(
                onClick = onDeleteLayer,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Delete, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Discard Selected Layer")
            }
        }
    }
}

@Composable
fun FiltersTab(
    onApplyPreset: (String, Float) -> Unit
) {
    val filters = listOf(
        "Vintage", "Film", "Black & White", "HDR", "Portrait", "Landscape", "Neon", "Retro", "Cinematic", "Seasonal (Autumn)"
    )

    var selectedFilter by remember { mutableStateOf("Vintage") }
    var filterIntensity by remember { mutableStateOf(1.0f) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Preset Artistic Filters", fontWeight = FontWeight.Bold)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filters.forEach { filter ->
                val isSelected = selectedFilter == filter
                ElevatedFilterChip(
                    selected = isSelected,
                    onClick = { selectedFilter = filter },
                    label = { Text(filter) }
                )
            }
        }

        Text("Filter Intensity: ${(filterIntensity * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = filterIntensity,
            onValueChange = { filterIntensity = it },
            valueRange = 0.1f..1.0f
        )

        Button(
            onClick = { onApplyPreset(selectedFilter, filterIntensity) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.ColorLens, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Bake Filter Preset")
        }
    }
}
