package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Point2D
import kotlin.math.roundToInt

@Composable
fun CurvesEditor(
    points: List<Point2D>,
    curveColor: Color,
    onPointsChanged: (List<Point2D>) -> Unit,
    modifier: Modifier = Modifier
) {
    // Current active curves points sorted by x
    val activePoints = remember(points) {
        if (points.isEmpty()) {
            listOf(Point2D(0f, 0f), Point2D(1f, 1f))
        } else {
            points.sortedBy { it.x }
        }
    }

    var selectedIndex by remember { mutableStateOf(-1) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(220.dp)
                .background(Color(0xFF121212))
                .pointerInput(activePoints) {
                    // Tap to add or select points
                    detectTapGestures(
                        onTap = { offset ->
                            val sizePx = size.width.toFloat()
                            val tapX = (offset.x / sizePx).coerceIn(0f, 1f)
                            val tapY = (1f - (offset.y / sizePx)).coerceIn(0f, 1f)

                            // Check if tapped near an existing point
                            val threshold = 0.08f
                            val existingIndex = activePoints.indexOfFirst {
                                kotlin.math.abs(it.x - tapX) < threshold && kotlin.math.abs(it.y - tapY) < threshold
                            }

                            if (existingIndex != -1) {
                                selectedIndex = existingIndex
                            } else {
                                // Add a new control point
                                val updated = (activePoints + Point2D(tapX, tapY)).sortedBy { it.x }
                                onPointsChanged(updated)
                                selectedIndex = updated.indexOfFirst { it.x == tapX }
                            }
                        }
                    )
                }
                .pointerInput(activePoints, selectedIndex) {
                    // Drag points to deform curves
                    detectDragGestures(
                        onDragStart = { offset ->
                            val sizePx = size.width.toFloat()
                            val dragX = (offset.x / sizePx).coerceIn(0f, 1f)
                            val dragY = (1f - (offset.y / sizePx)).coerceIn(0f, 1f)

                            val threshold = 0.1f
                            selectedIndex = activePoints.indexOfFirst {
                                kotlin.math.abs(it.x - dragX) < threshold && kotlin.math.abs(it.y - dragY) < threshold
                            }
                        },
                        onDrag = { change, _ ->
                            if (selectedIndex != -1 && selectedIndex != 0 && selectedIndex != activePoints.size - 1) {
                                val sizePx = size.width.toFloat()
                                val dragX = (change.position.x / sizePx).coerceIn(0.01f, 0.99f)
                                val dragY = (1f - (change.position.y / sizePx)).coerceIn(0f, 1f)

                                val updated = activePoints.toMutableList()
                                updated[selectedIndex] = Point2D(dragX, dragY)
                                onPointsChanged(updated.sortedBy { it.x })
                            }
                        },
                        onDragEnd = {
                            selectedIndex = -1
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // 1. Draw grid guidelines
                val gridPaint = Color.Gray.copy(alpha = 0.2f)
                drawLine(gridPaint, Offset(w / 4f, 0f), Offset(w / 4f, h), strokeWidth = 1f)
                drawLine(gridPaint, Offset(w / 2f, 0f), Offset(w / 2f, h), strokeWidth = 1f)
                drawLine(gridPaint, Offset(3 * w / 4f, 0f), Offset(3 * w / 4f, h), strokeWidth = 1f)

                drawLine(gridPaint, Offset(0f, h / 4f), Offset(w, h / 4f), strokeWidth = 1f)
                drawLine(gridPaint, Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1f)
                drawLine(gridPaint, Offset(0f, 3 * h / 4f), Offset(w, 3 * h / 4f), strokeWidth = 1f)

                // 2. Draw Curves line connecting control points with cubic bezier paths
                val path = Path()
                if (activePoints.isNotEmpty()) {
                    val first = activePoints.first()
                    path.moveTo(first.x * w, (1f - first.y) * h)

                    for (i in 0 until activePoints.size - 1) {
                        val p0 = activePoints[i]
                        val p1 = activePoints[i + 1]

                        // Linear fallback/interpolation
                        path.lineTo(p1.x * w, (1f - p1.y) * h)
                    }
                }
                drawPath(path, color = curveColor, style = Stroke(width = 3.dp.toPx()))

                // 3. Render node circles representing control points
                activePoints.forEachIndexed { idx, pt ->
                    val circleCol = if (idx == selectedIndex) Color.White else curveColor
                    val circleRadius = if (idx == selectedIndex) 8.dp.toPx() else 5.dp.toPx()
                    drawCircle(
                        color = circleCol,
                        radius = circleRadius,
                        center = Offset(pt.x * w, (1f - pt.y) * h)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Tap grid to add nodes. Drag nodes to reshape tones.",
            fontSize = 11.sp,
            fontWeight = FontWeight.Light,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
