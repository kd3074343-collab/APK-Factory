package com.example.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BrushStroke
import com.example.data.model.Point2D
import com.example.data.model.Project
import com.example.data.model.ProjectLayer
import com.example.data.repository.ProjectRepository
import com.example.engine.ImageProcessor
import com.example.engine.LocalAIEngine
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Stack
import java.util.UUID

class ProjectViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProjectRepository
    val allProjects: StateFlow<List<Project>>

    // Active session state
    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject = _currentProject.asStateFlow()

    // Active canvas bitmap (original base, used as source)
    private val _baseBitmap = MutableStateFlow<Bitmap?>(null)
    val baseBitmap = _baseBitmap.asStateFlow()

    // Composed visual bitmap showing all layers in real-time
    private val _compositeBitmap = MutableStateFlow<Bitmap?>(null)
    val compositeBitmap = _compositeBitmap.asStateFlow()

    // Layers stack of the active session
    private val _layers = MutableStateFlow<List<ProjectLayer>>(emptyList())
    val layers = _layers.asStateFlow()

    // Selected Layer index/ID for adjustment sliders
    private val _selectedLayerId = MutableStateFlow<String?>(null)
    val selectedLayerId = _selectedLayerId.asStateFlow()

    // Undo/Redo stacks for non-destructive history
    private val undoStack = Stack<List<ProjectLayer>>()
    private val redoStack = Stack<List<ProjectLayer>>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo = _canRedo.asStateFlow()

    // UI state states
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()

    private val moshi = Moshi.Builder().build()
    private val layersListType = Types.newParameterizedType(List::class.java, ProjectLayer::class.java)
    private val jsonAdapter = moshi.adapter<List<ProjectLayer>>(layersListType)

    init {
        val projectDao = AppDatabase.getDatabase(application).projectDao()
        repository = ProjectRepository(projectDao)
        allProjects = repository.allProjects.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Preload sample photos if DB is empty to satisfy Onboarding/Empty state rules
        viewModelScope.launch {
            repository.allProjects.collect { projects ->
                if (projects.isEmpty()) {
                    preloadSampleProjects()
                }
            }
        }
    }

    /**
     * Create beautiful preloaded gradient art projects on first start.
     */
    private suspend fun preloadSampleProjects() = withContext(Dispatchers.IO) {
        val sampleNames = listOf("Mountain Glow Peak", "Ocean Twilight Breeze", "Cyberpunk Neon Grid")
        val context = getApplication<Application>().applicationContext

        for ((index, name) in sampleNames.withIndex()) {
            val bmp = Bitmap.createBitmap(800, 600, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val paint = Paint()

            // Different vibrant dynamic linear gradients
            val colors = when (index) {
                0 -> intArrayOf(Color.rgb(241, 39, 17), Color.rgb(245, 175, 25))
                1 -> intArrayOf(Color.rgb(26, 41, 128), Color.rgb(38, 208, 206))
                else -> intArrayOf(Color.rgb(18, 18, 18), Color.rgb(230, 3, 18))
            }
            paint.shader = LinearGradient(0f, 0f, 800f, 600f, colors, null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, 800f, 600f, paint)

            // Draw vector sun or grids
            if (index == 0) {
                paint.shader = null
                paint.color = Color.rgb(255, 222, 0)
                canvas.drawCircle(400f, 300f, 150f, paint)
            } else if (index == 2) {
                // Draw neon grid lines
                paint.shader = null
                paint.color = Color.rgb(0, 245, 255)
                paint.strokeWidth = 3f
                for (x in 0..800 step 80) {
                    canvas.drawLine(x.toFloat(), 0f, x.toFloat(), 600f, paint)
                }
                for (y in 0..600 step 60) {
                    canvas.drawLine(0f, y.toFloat(), 800f, y.toFloat(), paint)
                }
            }

            val imgFile = File(context.filesDir, "sample_${System.currentTimeMillis()}_$index.jpg")
            FileOutputStream(imgFile).use { fos ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            }

            val layers = listOf(
                ProjectLayer(
                    id = UUID.randomUUID().toString(),
                    name = "Base Landscape Layer",
                    type = "Image",
                    brightness = 0.05f,
                    contrast = 1.05f
                )
            )

            val p = Project(
                name = name,
                originalImagePath = imgFile.absolutePath,
                thumbnailPath = imgFile.absolutePath,
                layersJson = jsonAdapter.toJson(layers)
            )
            repository.insertProject(p)
        }
    }

    /**
     * Start a new editing project from an Android Uri (Camera, Gallery, or File explorer)
     */
    fun startProjectFromUri(uri: Uri, context: Context, name: String = "My Masterpiece") {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val cachedFile = saveUriToInternalStorage(uri, context)
                if (cachedFile != null) {
                    val layers = listOf(
                        ProjectLayer(
                            id = UUID.randomUUID().toString(),
                            name = "Base Image Layer",
                            type = "Image"
                        )
                    )

                    val p = Project(
                        name = name,
                        originalImagePath = cachedFile.absolutePath,
                        thumbnailPath = cachedFile.absolutePath,
                        layersJson = jsonAdapter.toJson(layers)
                    )

                    val id = repository.insertProject(p)
                    val insertedProject = p.copy(id = id.toInt())
                    loadProject(insertedProject)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isProcessing.value = false
            }
        }
    }

    /**
     * Load an existing editing project session
     */
    fun loadProject(project: Project) {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                _currentProject.value = project

                val originalPath = project.originalImagePath
                if (originalPath != null) {
                    val file = File(originalPath)
                    if (file.exists()) {
                        val baseBmp = BitmapFactory.decodeFile(originalPath)
                        _baseBitmap.value = baseBmp

                        // Deserialize layers
                        val layersList = if (project.layersJson != null) {
                            jsonAdapter.fromJson(project.layersJson) ?: emptyList()
                        } else {
                            listOf(ProjectLayer(id = UUID.randomUUID().toString(), name = "Base Image", type = "Image"))
                        }

                        _layers.value = layersList
                        _selectedLayerId.value = layersList.firstOrNull()?.id

                        // Clear history on session start
                        undoStack.clear()
                        redoStack.clear()
                        updateHistoryState()

                        rebuildComposite()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isProcessing.value = false
            }
        }
    }

    /**
     * Close active session and return to projects listing screen.
     */
    fun closeProject() {
        _currentProject.value = null
        _baseBitmap.value = null
        _compositeBitmap.value = null
        _layers.value = emptyList()
        _selectedLayerId.value = null
        undoStack.clear()
        redoStack.clear()
        updateHistoryState()
    }

    /**
     * Save current layers stack and updates database non-destructively
     */
    fun saveActiveProject() {
        val current = _currentProject.value ?: return
        viewModelScope.launch {
            val json = jsonAdapter.toJson(_layers.value)
            val updated = current.copy(
                layersJson = json,
                updatedTimestamp = System.currentTimeMillis()
            )
            repository.updateProject(updated)
            _currentProject.value = updated
        }
    }

    /**
     * Delete a project
     */
    fun deleteProject(project: Project) {
        viewModelScope.launch {
            repository.deleteProjectById(project.id)
            if (_currentProject.value?.id == project.id) {
                _currentProject.value = null
                _baseBitmap.value = null
                _compositeBitmap.value = null
                _layers.value = emptyList()
                _selectedLayerId.value = null
            }
        }
    }

    /**
     * Duplicate project session
     */
    fun duplicateProject(project: Project) {
        viewModelScope.launch {
            val newProj = project.copy(
                id = 0,
                name = "${project.name} Copy",
                createdTimestamp = System.currentTimeMillis(),
                updatedTimestamp = System.currentTimeMillis()
            )
            repository.insertProject(newProj)
        }
    }

    /**
     * Rename active project
     */
    fun renameProject(project: Project, newName: String) {
        viewModelScope.launch {
            val renamed = project.copy(name = newName)
            repository.updateProject(renamed)
            if (_currentProject.value?.id == project.id) {
                _currentProject.value = renamed
            }
        }
    }

    /**
     * Rebuild the visual canvas by compositing all layers.
     */
    private suspend fun rebuildComposite() = withContext(Dispatchers.Default) {
        val original = _baseBitmap.value ?: return@withContext
        val activeLayers = _layers.value

        val composed = ImageProcessor.compositeLayers(original, activeLayers)
        _compositeBitmap.value = composed
    }

    /**
     * Pushes current state into Undo Stack.
     */
    private fun pushHistory() {
        undoStack.push(_layers.value.toList())
        redoStack.clear()
        updateHistoryState()
    }

    private fun updateHistoryState() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val current = _layers.value
            redoStack.push(current)

            val previous = undoStack.pop()
            _layers.value = previous
            updateHistoryState()

            viewModelScope.launch {
                rebuildComposite()
                saveActiveProject()
            }
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val current = _layers.value
            undoStack.push(current)

            val next = redoStack.pop()
            _layers.value = next
            updateHistoryState()

            viewModelScope.launch {
                rebuildComposite()
                saveActiveProject()
            }
        }
    }

    /**
     * Update active layer adjustments (sliders)
     */
    fun updateSelectedLayer(adjustBlock: (ProjectLayer) -> ProjectLayer) {
        val selId = _selectedLayerId.value ?: return
        val currentLayers = _layers.value.map { layer ->
            if (layer.id == selId) adjustBlock(layer) else layer
        }
        _layers.value = currentLayers

        viewModelScope.launch {
            rebuildComposite()
        }
    }

    /**
     * High performance saving of slider releases for history undo/redo points.
     */
    fun commitAdjustmentChange() {
        pushHistory()
        saveActiveProject()
    }

    /**
     * Add a drawing / Brush stroke layer
     */
    fun addBrushLayer() {
        pushHistory()
        val newLayer = ProjectLayer(
            id = UUID.randomUUID().toString(),
            name = "Brush Sketch Layer ${_layers.value.filter { it.type == "Brush" }.size + 1}",
            type = "Brush",
            brushStrokes = emptyList()
        )
        val updatedList = _layers.value + newLayer
        _layers.value = updatedList
        _selectedLayerId.value = newLayer.id
        saveActiveProject()
    }

    /**
     * Commit hand-drawn strokes to the active brush layer.
     */
    fun commitBrushStroke(stroke: BrushStroke) {
        val selId = _selectedLayerId.value ?: return
        val updated = _layers.value.map { layer ->
            if (layer.id == selId && layer.type == "Brush") {
                val existing = layer.brushStrokes ?: emptyList()
                layer.copy(brushStrokes = existing + stroke)
            } else layer
        }
        _layers.value = updated
        viewModelScope.launch {
            rebuildComposite()
            saveActiveProject()
        }
    }

    /**
     * Add a custom styled text overlay
     */
    fun addTextLayer(text: String, color: Long = 0xFFFFFFFF) {
        pushHistory()
        val newLayer = ProjectLayer(
            id = UUID.randomUUID().toString(),
            name = "Text: $text",
            type = "Text",
            textValue = text,
            textColor = color,
            fontSize = 42f
        )
        _layers.value = _layers.value + newLayer
        _selectedLayerId.value = newLayer.id
        viewModelScope.launch {
            rebuildComposite()
            saveActiveProject()
        }
    }

    /**
     * Add custom borders or shape frames
     */
    fun addFrameLayer(frameName: String, color: Long = 0xFFFFFFFF) {
        pushHistory()
        val newLayer = ProjectLayer(
            id = UUID.randomUUID().toString(),
            name = frameName,
            type = "Shape",
            frameId = frameName,
            textColor = color
        )
        _layers.value = _layers.value + newLayer
        _selectedLayerId.value = newLayer.id
        viewModelScope.launch {
            rebuildComposite()
            saveActiveProject()
        }
    }

    /**
     * Delete the active layer
     */
    fun deleteActiveLayer() {
        val selId = _selectedLayerId.value ?: return
        if (_layers.value.size <= 1) return // Keep at least base

        pushHistory()
        val updated = _layers.value.filter { it.id != selId }
        _layers.value = updated
        _selectedLayerId.value = updated.firstOrNull()?.id
        viewModelScope.launch {
            rebuildComposite()
            saveActiveProject()
        }
    }

    /**
     * Reorder layer position (move up / down)
     */
    fun moveLayer(layerId: String, moveUp: Boolean) {
        val current = _layers.value.toMutableList()
        val index = current.indexOfFirst { it.id == layerId }
        if (index == -1) return

        val newIndex = if (moveUp) index + 1 else index - 1
        if (newIndex in 0 until current.size) {
            pushHistory()
            val temp = current[index]
            current[index] = current[newIndex]
            current[newIndex] = temp
            _layers.value = current
            viewModelScope.launch {
                rebuildComposite()
                saveActiveProject()
            }
        }
    }

    /**
     * Apply offline AI processes locally
     */
    fun applyAIFeature(featureName: String, param: Float = 0.5f) {
        val baseBmp = _baseBitmap.value ?: return
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                // Apply the AI processing block to the base image
                val processed = when (featureName) {
                    "AI Auto Enhance" -> LocalAIEngine.autoEnhance(baseBmp)
                    "AI Portrait Enhancement", "AI Skin Smoothing" -> LocalAIEngine.skinSmoothing(baseBmp, param)
                    "AI Background Blur" -> LocalAIEngine.backgroundBlur(baseBmp, param)
                    "AI Background Removal" -> LocalAIEngine.removeBackground(baseBmp)
                    "AI Sky: Sunset" -> LocalAIEngine.replaceSky(baseBmp, "Sunset Red")
                    "AI Sky: Nebula" -> LocalAIEngine.replaceSky(baseBmp, "Cosmic Nebula")
                    "AI Sky: Golden" -> LocalAIEngine.replaceSky(baseBmp, "Golden Hour")
                    "AI Colorization" -> LocalAIEngine.colorize(baseBmp)
                    "AI Old Photo Restoration" -> LocalAIEngine.restoreOldPhoto(baseBmp)
                    "AI Denoising" -> LocalAIEngine.skinSmoothing(baseBmp, 0.4f) // Uses smart smoothing kernel
                    "AI Image Sharpening" -> LocalAIEngine.sharpenImage(baseBmp, param)
                    "AI Upscaling (2×)" -> LocalAIEngine.upscaleImage(baseBmp, 2)
                    "AI Upscaling (4×)" -> LocalAIEngine.upscaleImage(baseBmp, 4)
                    "AI Cartoon Effect" -> LocalAIEngine.cartoonStyle(baseBmp)
                    "AI Sketch Effect" -> LocalAIEngine.sketchStyle(baseBmp)
                    "AI Painting Styles" -> LocalAIEngine.oilPaintingStyle(baseBmp)
                    else -> baseBmp
                }

                pushHistory()
                _baseBitmap.value = processed

                // Set thumbnail to updated path
                saveBitmapToPath(processed, _currentProject.value?.originalImagePath ?: "")

                rebuildComposite()
                saveActiveProject()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isProcessing.value = false
            }
        }
    }

    /**
     * Apply Object Removal inpainting using points painted
     */
    fun applyAIObjectRemoval(points: List<Point2D>, size: Float) {
        val baseBmp = _baseBitmap.value ?: return
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val processed = LocalAIEngine.removeObject(baseBmp, points, size)
                pushHistory()
                _baseBitmap.value = processed
                saveBitmapToPath(processed, _currentProject.value?.originalImagePath ?: "")
                rebuildComposite()
                saveActiveProject()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isProcessing.value = false
            }
        }
    }

    /**
     * Export final composed Image
     */
    fun exportComposedImage(
        context: Context,
        format: String, // "JPG", "PNG", "WEBP", "TIFF"
        quality: String, // "Low", "Medium", "High", "Ultra HD"
        onComplete: (String) -> Unit
    ) {
        val composite = _compositeBitmap.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val formatEnum = when (format) {
                    "PNG" -> Bitmap.CompressFormat.PNG
                    "WEBP" -> Bitmap.CompressFormat.WEBP
                    else -> Bitmap.CompressFormat.JPEG
                }

                val qualityVal = when (quality) {
                    "Low" -> 50
                    "Medium" -> 75
                    "High" -> 90
                    else -> 100 // Ultra / Original
                }

                // Create exports folder
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val appDir = File(downloadsDir, "AIPictureEditor")
                if (!appDir.exists()) appDir.mkdirs()

                val ext = format.lowercase()
                val filename = "Edit_${System.currentTimeMillis()}.$ext"
                val outFile = File(appDir, filename)

                FileOutputStream(outFile).use { fos ->
                    composite.compress(formatEnum, qualityVal, fos)
                }

                withContext(Dispatchers.Main) {
                    onComplete(outFile.absolutePath)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Helper utilities
    private fun saveBitmapToPath(bmp: Bitmap, path: String) {
        try {
            val file = File(path)
            FileOutputStream(file).use { fos ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 95, fos)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun saveUriToInternalStorage(uri: Uri, context: Context): File? {
        return try {
            val resolver = context.contentResolver
            val inputStream: InputStream? = resolver.openInputStream(uri)
            val file = File(context.filesDir, "imported_${System.currentTimeMillis()}.jpg")
            if (inputStream != null) {
                FileOutputStream(file).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
                file
            } else null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
