package com.example.data.repository

import com.example.data.local.ProjectDao
import com.example.data.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<Project>> = projectDao.getAllProjectsFlow()

    suspend fun getProjectById(id: Int): Project? = withContext(Dispatchers.IO) {
        projectDao.getProjectById(id)
    }

    suspend fun insertProject(project: Project): Int = withContext(Dispatchers.IO) {
        projectDao.insertProject(project).toInt()
    }

    suspend fun updateProject(project: Project) = withContext(Dispatchers.IO) {
        projectDao.updateProject(project)
    }

    suspend fun deleteProjectById(id: Int) = withContext(Dispatchers.IO) {
        projectDao.deleteProjectById(id)
    }
}
