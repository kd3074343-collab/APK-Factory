package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "projects")
@JsonClass(generateAdapter = true)
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val createdTimestamp: Long = System.currentTimeMillis(),
    val updatedTimestamp: Long = System.currentTimeMillis(),
    val originalImagePath: String?, // Location of local offline original image
    val thumbnailPath: String? = null, // Path to small cache preview
    val layersJson: String? = null // Serialized list of layers & adjustments
)

@JsonClass(generateAdapter = true)
data class ProjectLayer(
    val id: String,
    val name: String,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val opacity: Float = 1.0f,
    val blendMode: String = "Normal", // Normal, Multiply, Screen, Overlay, Lighten, Darken, ColorDodge
    val type: String = "Image", // Image, Brush, Text, Shape, Sticker
    
    // Position & Scale
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotation: Float = 0f,

    // Image/Layer Source identifier (if separate from base original)
    val layerImagePath: String? = null,

    // Adjustment states (values centered at 0 or 1 depending on parameter)
    val brightness: Float = 0.0f,   // -1.0 to 1.0
    val contrast: Float = 1.0f,     // 0.5 to 2.0
    val saturation: Float = 1.0f,   // 0.0 to 2.0
    val vibrance: Float = 1.0f,     // 0.0 to 2.0
    val exposure: Float = 0.0f,     // -2.0 to 2.0
    val temperature: Float = 0.0f,  // -1.0 to 1.0 (Cool to Warm)
    val tint: Float = 0.0f,         // -1.0 to 1.0 (Green to Magenta)
    val vignette: Float = 0.0f,     // 0.0 to 1.0
    val grain: Float = 0.0f,        // 0.0 to 1.0
    val sharpness: Float = 0.0f,    // 0.0 to 1.0
    val clarity: Float = 0.0f,      // 0.0 to 1.0
    val dehaze: Float = 0.0f,       // 0.0 to 1.0
    val shadows: Float = 0.0f,      // -1.0 to 1.0
    val highlights: Float = 0.0f,   // -1.0 to 1.0
    val blacks: Float = 0.0f,       // -1.0 to 1.0
    val whites: Float = 0.0f,       // -1.0 to 1.0
    val gamma: Float = 1.0f,        // 0.5 to 2.0

    // Text properties (applicable if type is "Text")
    val textValue: String = "",
    val textColor: Long = 0xFFFFFFFF,
    val fontSize: Float = 24f,
    val isGradientText: Boolean = false,
    val gradientColorStart: Long = 0xFFFF007F,
    val gradientColorEnd: Long = 0xFF7F00FF,
    val isCurved: Boolean = false,
    val fontName: String = "SansSerif",
    val textShadowColor: Long = 0x80000000,
    val textStrokeColor: Long = 0xFF000000,
    val textStrokeWidth: Float = 0f,

    // Curve controls: coordinates for RED, GREEN, BLUE, and COMPOSITE RGB curves
    // Serialized as a list of control points
    val curvePointsComposite: List<Point2D>? = null,
    val curvePointsRed: List<Point2D>? = null,
    val curvePointsGreen: List<Point2D>? = null,
    val curvePointsBlue: List<Point2D>? = null,

    // HSL adjustment parameters (Hue, Saturation, Lightness offset for 8 standard color channels)
    // Red, Orange, Yellow, Green, Aqua, Blue, Purple, Magenta
    val hslChannels: Map<String, HslAdjustments>? = null,

    // Sticker or Frame index/source
    val stickerId: String? = null,
    val frameId: String? = null,

    // Custom hand-drawn paths & brush strokes
    val brushStrokes: List<BrushStroke>? = null
)

@JsonClass(generateAdapter = true)
data class Point2D(val x: Float, val y: Float)

@JsonClass(generateAdapter = true)
data class HslAdjustments(
    val hue: Float = 0f,        // -180 to 180
    val saturation: Float = 0f, // -100 to 100
    val lightness: Float = 0f   // -100 to 100
)

@JsonClass(generateAdapter = true)
data class BrushStroke(
    val points: List<Point2D>,
    val color: Long = 0xFFFF0000,
    val size: Float = 15f,
    val hardness: Float = 0.8f,
    val opacity: Float = 1.0f,
    val toolType: String = "Brush" // Brush, Eraser, Blur, Healing, CloneStamp, Dodge, Burn, Smudge, Mosaic
)
