package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MatchmakingScreen
import com.example.ui.screens.PrivateWaitingScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.GameViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0)
                ) { innerPadding ->
                    val viewModel: GameViewModel = viewModel()
                    val screenState by viewModel.currentScreen.collectAsState()

                    val currentModifier = Modifier.padding(innerPadding)

                    when (val screen = screenState) {
                        is Screen.Login -> {
                            LoginScreen(
                                viewModel = viewModel,
                                modifier = currentModifier
                            )
                        }
                        is Screen.Home -> {
                            HomeScreen(
                                viewModel = viewModel,
                                modifier = currentModifier
                            )
                        }
                        is Screen.Matchmaking -> {
                            MatchmakingScreen(
                                viewModel = viewModel,
                                modifier = currentModifier
                            )
                        }
                        is Screen.PrivateWaiting -> {
                            PrivateWaitingScreen(
                                roomId = screen.roomId,
                                viewModel = viewModel,
                                modifier = currentModifier
                            )
                        }
                        is Screen.Game -> {
                            GameScreen(
                                viewModel = viewModel,
                                modifier = currentModifier
                            )
                        }
                    }
                }
            }
        }
    }
}
