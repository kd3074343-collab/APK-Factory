package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.GameRoom
import com.example.data.model.User
import com.example.data.repository.GameRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GameViewModel : ViewModel() {

    private val repository = GameRepository()

    // Screen State
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Login)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Current logged-in User
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // Active Game Room State
    private val _activeRoom = MutableStateFlow<GameRoom?>(null)
    val activeRoom: StateFlow<GameRoom?> = _activeRoom.asStateFlow()

    // Matchmaking or overall loading status
    private val _statusText = MutableStateFlow("")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    // Error messages
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var roomJob: Job? = null

    init {
        // Check current login state
        FirebaseAuth.getInstance().addAuthStateListener { firebaseAuth ->
            val user = repository.getCurrentUser()
            _currentUser.value = user
            if (user != null) {
                if (_currentScreen.value is Screen.Login) {
                    _currentScreen.value = Screen.Home
                }
            } else {
                _currentScreen.value = Screen.Login
                cleanup()
            }
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun setError(message: String) {
        _errorMessage.value = message
    }

    fun startMatchmaking() {
        val user = _currentUser.value ?: return
        _currentScreen.value = Screen.Matchmaking
        _statusText.value = "Searching for Opponent..."

        repository.startMatchmaking(
            user = user,
            onMatched = { roomId ->
                enterGame(roomId)
            },
            onSearching = {
                _statusText.value = "Searching for Opponent...\nWaiting for a match."
            },
            onError = { err ->
                _errorMessage.value = err
                _currentScreen.value = Screen.Home
            }
        )
    }

    fun cancelMatchmaking() {
        val user = _currentUser.value ?: return
        repository.cancelMatchmaking(user.uid)
        _currentScreen.value = Screen.Home
    }

    fun createPrivateRoom() {
        val user = _currentUser.value ?: return
        _statusText.value = "Creating Private Room..."
        repository.createPrivateRoom(
            user = user,
            onRoomCreated = { roomId ->
                _currentScreen.value = Screen.PrivateWaiting(roomId)
                observeRoom(roomId)
            },
            onError = { err ->
                _errorMessage.value = err
            }
        )
    }

    fun joinPrivateRoom(roomId: String) {
        val user = _currentUser.value ?: return
        if (roomId.isBlank()) {
            _errorMessage.value = "Please enter a valid Room ID"
            return
        }
        _statusText.value = "Joining Private Room..."
        repository.joinPrivateRoom(
            roomId = roomId,
            user = user,
            onSuccess = { rId ->
                enterGame(rId)
            },
            onError = { err ->
                _errorMessage.value = err
            }
        )
    }

    fun makeMove(index: Int) {
        val room = _activeRoom.value ?: return
        val user = _currentUser.value ?: return
        if (room.status != "PLAYING" || room.turn != user.uid) return
        repository.makeMove(room.roomId, index, user.uid)
    }

    fun requestRematch() {
        val room = _activeRoom.value ?: return
        val user = _currentUser.value ?: return
        val isPlayerX = room.playerX?.uid == user.uid
        repository.requestRematch(room.roomId, isPlayerX)
    }

    fun leaveRoom() {
        val room = _activeRoom.value ?: return
        val user = _currentUser.value ?: return
        val isPlayerX = room.playerX?.uid == user.uid
        repository.leaveRoom(room.roomId, isPlayerX)
        _currentScreen.value = Screen.Home
        cleanup()
    }

    fun logout() {
        FirebaseAuth.getInstance().signOut()
    }

    private fun enterGame(roomId: String) {
        _currentScreen.value = Screen.Game(roomId)
        observeRoom(roomId)
    }

    private fun observeRoom(roomId: String) {
        roomJob?.cancel()
        val user = _currentUser.value ?: return
        
        roomJob = viewModelScope.launch {
            repository.observeRoom(roomId).collect { room ->
                _activeRoom.value = room
                if (room != null) {
                    val isPlayerX = room.playerX?.uid == user.uid
                    val isPlayerO = room.playerO?.uid == user.uid
                    if (isPlayerX || isPlayerO) {
                        repository.setupPresence(roomId, isPlayerX)
                    }

                    // If private waiting and opponent joined, auto enter game
                    if (_currentScreen.value is Screen.PrivateWaiting && room.status == "PLAYING" && room.playerO != null) {
                        _currentScreen.value = Screen.Game(roomId)
                    }
                }
            }
        }
    }

    private fun cleanup() {
        roomJob?.cancel()
        roomJob = null
        _activeRoom.value = null
    }

    override fun onCleared() {
        super.onCleared()
        cleanup()
    }
}

sealed class Screen {
    object Login : Screen()
    object Home : Screen()
    object Matchmaking : Screen()
    data class PrivateWaiting(val roomId: String) : Screen()
    data class Game(val roomId: String) : Screen()
}
