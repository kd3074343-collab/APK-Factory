package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.GameRoom
import com.example.data.model.User
import com.example.ui.viewmodel.GameViewModel

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val room by viewModel.activeRoom.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val currentRoom = room
    val activeUser = currentUser

    if (currentRoom == null || activeUser == null) {
        Box(
            modifier = Modifier.fillMaxSize().background(Color(0xFF0F0C1B)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Color(0xFF00E5FF))
        }
        return
    }

    val isPlayerX = currentRoom.playerX?.uid == activeUser.uid
    val isPlayerO = currentRoom.playerO?.uid == activeUser.uid
    val isOurTurn = currentRoom.turn == activeUser.uid

    // Check if opponent is present
    val isOpponentPresent = if (isPlayerX) currentRoom.playerOPresent else currentRoom.playerXPresent

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0C1B),
                        Color(0xFF05050A)
                    )
                )
            ),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Game Top bar / Room info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ROOM ID",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E5FF),
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = currentRoom.roomId,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }

                // Leave match button
                IconButton(
                    onClick = { viewModel.leaveRoom() },
                    modifier = Modifier
                        .background(Color(0x1FFF4D4D), CircleShape)
                        .size(40.dp)
                        .testTag("leave_match_top_button")
                ) {
                    Text(
                        text = "X",
                        color = Color(0xFFFF4D4D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Players status cards row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Player X Card
                PlayerStatusCard(
                    user = currentRoom.playerX,
                    symbol = "X",
                    symbolColor = Color(0xFFFF007F), // Neon Pink
                    isActive = currentRoom.turn == currentRoom.playerX?.uid && currentRoom.status == "PLAYING",
                    isPresent = currentRoom.playerXPresent
                )

                // VS indicator
                Text(
                    text = "VS",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF706E92),
                    letterSpacing = 2.sp
                )

                // Player O Card
                PlayerStatusCard(
                    user = currentRoom.playerO,
                    symbol = "O",
                    symbolColor = Color(0xFF00E5FF), // Neon Cyan
                    isActive = currentRoom.turn == currentRoom.playerO?.uid && currentRoom.status == "PLAYING",
                    isPresent = currentRoom.playerOPresent
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Real-Time Turn Indicator Banner
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isOurTurn && currentRoom.status == "PLAYING") Color(0x2200E5FF) else Color(0xFF161528)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isOurTurn && currentRoom.status == "PLAYING") Color(0xFF00E5FF) else Color(0x1F706E92),
                        RoundedCornerShape(12.dp)
                    )
                    .testTag("turn_indicator_banner")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val turnText = when {
                        currentRoom.status == "WAITING_FOR_PLAYER" -> "Waiting for Player O..."
                        currentRoom.status == "OPPONENT_LEFT" || !isOpponentPresent -> "Opponent Left the Game!"
                        !currentRoom.status.endsWith("WON") && currentRoom.status != "DRAW" -> {
                            if (isOurTurn) "YOUR TURN (${if (isPlayerX) "X" else "O"})"
                            else "OPPONENT'S TURN (${if (isPlayerX) "O" else "X"})"
                        }
                        else -> "GAME OVER"
                    }

                    Text(
                        text = turnText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isOurTurn && currentRoom.status == "PLAYING") Color(0xFF00E5FF) else Color.White,
                        textAlign = TextAlign.Center,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Standard 3x3 Tic-Tac-Toe Grid
            Box(
                modifier = Modifier
                    .size(310.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF100F21))
                    .border(2.dp, Color(0xFF1F1D38), RoundedCornerShape(24.dp))
                    .padding(12.dp)
            ) {
                // Background grid lines using Spacer/Canvas or simple row/column divisions
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    for (row in 0..2) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (col in 0..2) {
                                val index = row * 3 + col
                                val value = currentRoom.board.getOrNull(index) ?: ""

                                // Cell Box
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .padding(6.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Color(0xFF161528))
                                        .border(
                                            1.dp,
                                            when (value) {
                                                "X" -> Color(0x4DFF007F)
                                                "O" -> Color(0x4D00E5FF)
                                                else -> Color(0xFF22203F)
                                            },
                                            RoundedCornerShape(16.dp)
                                        )
                                        .clickable(enabled = currentRoom.status == "PLAYING" && isOurTurn && value.isEmpty()) {
                                            viewModel.makeMove(index)
                                        }
                                        .testTag("cell_$index"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = value,
                                        fontSize = 44.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = when (value) {
                                            "X" -> Color(0xFFFF007F)
                                            "O" -> Color(0xFF00E5FF)
                                            else -> Color.Transparent
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Rematch and Leave Controls (Always present if game is over)
            val isGameOver = currentRoom.status.endsWith("WON") || currentRoom.status == "DRAW" || currentRoom.status == "OPPONENT_LEFT" || !isOpponentPresent

            if (isGameOver) {
                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161528)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0x33FF007F), RoundedCornerShape(20.dp))
                        .testTag("game_over_card")
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val gameOverTitle = when {
                            currentRoom.status == "OPPONENT_LEFT" || !isOpponentPresent -> "Opponent Left!"
                            currentRoom.status == "DRAW" -> "It's a Draw!"
                            currentRoom.status == "X_WON" -> {
                                if (isPlayerX) "YOU WON! 🎉" else "${currentRoom.playerX?.displayName ?: "Player X"} Won!"
                            }
                            currentRoom.status == "O_WON" -> {
                                if (isPlayerO) "YOU WON! 🎉" else "${currentRoom.playerO?.displayName ?: "Player O"} Won!"
                            }
                            else -> "Game Ended"
                        }

                        Text(
                            text = gameOverTitle,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        val weRequestedRematch = if (isPlayerX) currentRoom.rematchX else currentRoom.rematchO
                        val theyRequestedRematch = if (isPlayerX) currentRoom.rematchO else currentRoom.rematchX

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            // Rematch/Play Again button (only visible if opponent didn't disconnect)
                            if (currentRoom.status != "OPPONENT_LEFT" && isOpponentPresent) {
                                Button(
                                    onClick = { viewModel.requestRematch() },
                                    enabled = !weRequestedRematch,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF00E5FF),
                                        contentColor = Color(0xFF05050A)
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp)
                                        .padding(horizontal = 4.dp)
                                        .testTag("rematch_button")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (weRequestedRematch) "Waiting..." else "PLAY AGAIN",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            // Return Home Button
                            Button(
                                onClick = { viewModel.leaveRoom() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0x22FFFFFF),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .padding(horizontal = 4.dp)
                                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp))
                                    .testTag("return_home_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Home,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "LEAVE MATCH",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                            }
                        }

                        // Status of rematch requests
                        if (currentRoom.status != "OPPONENT_LEFT" && isOpponentPresent) {
                            Spacer(modifier = Modifier.height(12.dp))
                            val rematchStatusText = when {
                                weRequestedRematch && theyRequestedRematch -> "Both players agreed, restarting..."
                                weRequestedRematch -> "Rematch requested! Waiting for opponent's response..."
                                theyRequestedRematch -> "Opponent wants a rematch! Click Play Again to accept."
                                else -> "Request a rematch to play again."
                            }
                            Text(
                                text = rematchStatusText,
                                fontSize = 12.sp,
                                color = Color(0xFFB0AEC6),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerStatusCard(
    user: User?,
    symbol: String,
    symbolColor: Color,
    isActive: Boolean,
    isPresent: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(110.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (isActive) Color(0x1F00E5FF) else Color(0xFF161528))
            .border(
                width = 1.5.dp,
                color = when {
                    !isPresent -> Color(0xFFFF4D4D)
                    isActive -> Color(0xFF00E5FF)
                    else -> Color.Transparent
                },
                shape = RoundedCornerShape(16.dp)
            )
            .padding(12.dp)
    ) {
        // Player Avatar
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .border(1.5.dp, symbolColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (!user?.photoUrl.isNullOrEmpty()) {
                AsyncImage(
                    model = user?.photoUrl,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1E2940)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = user?.displayName?.firstOrNull()?.uppercase() ?: "?",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Offline overlay dot
            if (!isPresent) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "OUT",
                        color = Color.Red,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Name
        Text(
            text = user?.displayName ?: "Searching...",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isPresent) Color.White else Color(0xFF706E92),
            maxLines = 1,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Symbol label
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(symbolColor.copy(alpha = 0.15f))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = symbol,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = symbolColor
            )
        }
    }
}
