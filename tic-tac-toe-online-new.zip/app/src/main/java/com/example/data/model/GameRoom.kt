package com.example.data.model

data class GameRoom(
    val roomId: String = "",
    val playerX: User? = null,
    val playerO: User? = null,
    val board: List<String> = List(9) { "" },
    val turn: String = "", // UID of player whose turn it is
    val status: String = "WAITING_FOR_PLAYER", // WAITING_FOR_PLAYER, PLAYING, X_WON, O_WON, DRAW, OPPONENT_LEFT
    val winner: String = "", // UID of the winner
    val rematchX: Boolean = false,
    val rematchO: Boolean = false,
    val playerXPresent: Boolean = true,
    val playerOPresent: Boolean = true,
    val lastUpdated: Long = 0
)
