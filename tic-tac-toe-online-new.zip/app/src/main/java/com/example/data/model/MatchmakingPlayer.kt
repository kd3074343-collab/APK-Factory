package com.example.data.model

data class MatchmakingPlayer(
    val uid: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val matchedRoomId: String = ""
)
