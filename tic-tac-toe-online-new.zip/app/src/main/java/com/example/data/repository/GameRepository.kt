package com.example.data.repository

import com.example.data.model.GameRoom
import com.example.data.model.MatchmakingPlayer
import com.example.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlin.random.Random

class GameRepository {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val database: FirebaseDatabase by lazy { FirebaseDatabase.getInstance() }

    fun getCurrentUser(): User? {
        val fbUser = auth.currentUser ?: return null
        return User(
            uid = fbUser.uid,
            displayName = fbUser.displayName ?: "Anonymous",
            email = fbUser.email ?: "",
            photoUrl = fbUser.photoUrl?.toString() ?: ""
        )
    }

    fun startMatchmaking(
        user: User,
        onMatched: (String) -> Unit,
        onSearching: () -> Unit,
        onError: (String) -> Unit
    ) {
        val queueRef = database.getReference("queue")

        // 1. Look for an available player
        queueRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var otherPlayer: MatchmakingPlayer? = null
                for (child in snapshot.children) {
                    val p = child.getValue(MatchmakingPlayer::class.java)
                    if (p != null && p.uid != user.uid && p.matchedRoomId.isEmpty()) {
                        otherPlayer = p
                        break
                    }
                }

                if (otherPlayer != null) {
                    // Match found! Create a new room
                    val roomId = database.getReference("rooms").push().key ?: Random.nextInt(100000, 999999).toString()
                    val newRoom = GameRoom(
                        roomId = roomId,
                        playerX = User(
                            uid = otherPlayer.uid,
                            displayName = otherPlayer.displayName,
                            email = otherPlayer.email,
                            photoUrl = otherPlayer.photoUrl
                        ),
                        playerO = user,
                        turn = otherPlayer.uid, // Player X starts
                        status = "PLAYING",
                        playerXPresent = true,
                        playerOPresent = true,
                        lastUpdated = System.currentTimeMillis()
                    )

                    // Write room to database
                    database.getReference("rooms").child(roomId).setValue(newRoom)
                        .addOnSuccessListener {
                            // Notify other player by updating their matchmaking node with the roomId
                            queueRef.child(otherPlayer.uid).child("matchedRoomId").setValue(roomId)
                                .addOnSuccessListener {
                                    // Successfully matched!
                                    onMatched(roomId)
                                }
                                .addOnFailureListener { e ->
                                    onError(e.message ?: "Failed to complete matchmaking match")
                                }
                        }
                        .addOnFailureListener { e ->
                            onError(e.message ?: "Failed to create game room")
                        }
                } else {
                    // No players waiting, put ourselves in queue
                    val matchmakingPlayer = MatchmakingPlayer(
                        uid = user.uid,
                        displayName = user.displayName,
                        email = user.email,
                        photoUrl = user.photoUrl,
                        matchedRoomId = ""
                    )

                    queueRef.child(user.uid).setValue(matchmakingPlayer)
                        .addOnSuccessListener {
                            onSearching()

                            // Listen for matching updates
                            queueRef.child(user.uid).child("matchedRoomId")
                                .addValueEventListener(object : ValueEventListener {
                                    override fun onDataChange(matchedSnapshot: DataSnapshot) {
                                        val roomId = matchedSnapshot.getValue(String::class.java)
                                        if (!roomId.isNullOrEmpty()) {
                                            // Matched! Clean up matchmaking queue node and stop listening
                                            queueRef.child(user.uid).removeValue()
                                            queueRef.child(user.uid).child("matchedRoomId").removeEventListener(this)
                                            onMatched(roomId)
                                        }
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        onError(error.message)
                                    }
                                })
                        }
                        .addOnFailureListener { e ->
                            onError(e.message ?: "Failed to join matchmaking queue")
                        }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        })
    }

    fun cancelMatchmaking(uid: String) {
        database.getReference("queue").child(uid).removeValue()
    }

    fun createPrivateRoom(
        user: User,
        onRoomCreated: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val roomId = Random.nextInt(100000, 999999).toString()
        val roomRef = database.getReference("rooms").child(roomId)

        val newRoom = GameRoom(
            roomId = roomId,
            playerX = user,
            playerO = null,
            turn = user.uid,
            status = "WAITING_FOR_PLAYER",
            playerXPresent = true,
            playerOPresent = false,
            lastUpdated = System.currentTimeMillis()
        )

        roomRef.setValue(newRoom)
            .addOnSuccessListener {
                onRoomCreated(roomId)
            }
            .addOnFailureListener { e ->
                onError(e.message ?: "Failed to create room")
            }
    }

    fun joinPrivateRoom(
        roomId: String,
        user: User,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val roomRef = database.getReference("rooms").child(roomId)

        roomRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    onError("Invalid Room ID")
                    return
                }

                val room = snapshot.getValue(GameRoom::class.java)
                if (room == null) {
                    onError("Failed to read Room details")
                    return
                }

                if (room.status != "WAITING_FOR_PLAYER" || room.playerO != null) {
                    onError("Room is full or game has already started")
                    return
                }

                if (room.playerX?.uid == user.uid) {
                    onError("You are already in this room as Player X")
                    return
                }

                // Update room to join
                val updates = mapOf(
                    "playerO" to user,
                    "playerOPresent" to true,
                    "status" to "PLAYING",
                    "lastUpdated" to System.currentTimeMillis()
                )

                roomRef.updateChildren(updates)
                    .addOnSuccessListener {
                        onSuccess(roomId)
                    }
                    .addOnFailureListener { e ->
                        onError(e.message ?: "Failed to join room")
                    }
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        })
    }

    fun observeRoom(roomId: String): Flow<GameRoom?> = callbackFlow {
        val roomRef = database.getReference("rooms").child(roomId)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java)
                trySend(room)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        roomRef.addValueEventListener(listener)
        awaitClose { roomRef.removeEventListener(listener) }
    }

    fun setupPresence(roomId: String, isPlayerX: Boolean) {
        val presenceRef = database.getReference("rooms").child(roomId).child(
            if (isPlayerX) "playerXPresent" else "playerOPresent"
        )
        // Mark present now
        presenceRef.setValue(true)
        // Automatically set false on disconnect
        presenceRef.onDisconnect().setValue(false)
    }

    fun makeMove(roomId: String, index: Int, playerUid: String) {
        val roomRef = database.getReference("rooms").child(roomId)

        roomRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java) ?: return
                if (room.status != "PLAYING" || room.turn != playerUid) return

                val cellValue = if (room.playerX?.uid == playerUid) "X" else "O"
                if (index < 0 || index >= room.board.size || room.board[index].isNotEmpty()) return

                // Generate new board
                val newBoard = room.board.toMutableList()
                newBoard[index] = cellValue

                // Check winner or draw
                val winCombos = listOf(
                    listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8), // rows
                    listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8), // columns
                    listOf(0, 4, 8), listOf(2, 4, 6) // diagonals
                )

                var isWinner = false
                for (combo in winCombos) {
                    if (newBoard[combo[0]] == cellValue &&
                        newBoard[combo[1]] == cellValue &&
                        newBoard[combo[2]] == cellValue
                    ) {
                        isWinner = true
                        break
                    }
                }

                val nextTurn = if (playerUid == room.playerX?.uid) room.playerO?.uid ?: "" else room.playerX?.uid ?: ""

                val (status, winner) = when {
                    isWinner -> {
                        val finalStatus = if (cellValue == "X") "X_WON" else "O_WON"
                        Pair(finalStatus, playerUid)
                    }
                    newBoard.none { it.isEmpty() } -> {
                        Pair("DRAW", "DRAW")
                    }
                    else -> {
                        Pair("PLAYING", "")
                    }
                }

                val updates = mapOf(
                    "board" to newBoard,
                    "turn" to nextTurn,
                    "status" to status,
                    "winner" to winner,
                    "lastUpdated" to System.currentTimeMillis()
                )

                roomRef.updateChildren(updates)
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun requestRematch(roomId: String, isPlayerX: Boolean) {
        val roomRef = database.getReference("rooms").child(roomId)

        roomRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java) ?: return

                val rematchX = if (isPlayerX) true else room.rematchX
                val rematchO = if (!isPlayerX) true else room.rematchO

                if (rematchX && rematchO) {
                    // Both agreed! Reset board and start a new game
                    val firstTurn = room.playerX?.uid ?: "" // Let X start again
                    val updates = mapOf(
                        "board" to List(9) { "" },
                        "turn" to firstTurn,
                        "status" to "PLAYING",
                        "winner" to "",
                        "rematchX" to false,
                        "rematchO" to false,
                        "lastUpdated" to System.currentTimeMillis()
                    )
                    roomRef.updateChildren(updates)
                } else {
                    // Only one agreed, just update the single flag
                    val key = if (isPlayerX) "rematchX" else "rematchO"
                    roomRef.child(key).setValue(true)
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun leaveRoom(roomId: String, isPlayerX: Boolean) {
        val roomRef = database.getReference("rooms").child(roomId)

        // Mark present as false
        val presenceKey = if (isPlayerX) "playerXPresent" else "playerOPresent"
        roomRef.child(presenceKey).setValue(false)

        roomRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java) ?: return
                if (room.status == "PLAYING" || room.status == "WAITING_FOR_PLAYER") {
                    roomRef.child("status").setValue("OPPONENT_LEFT")
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }
}
