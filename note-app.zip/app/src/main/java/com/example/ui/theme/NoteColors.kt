package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class NoteColorPalette(
    val key: String,
    val name: String,
    val lightColor: Color,
    val darkColor: Color
)

object NoteColors {
    val list = listOf(
        NoteColorPalette("default", "Default", Color.Transparent, Color.Transparent),
        NoteColorPalette("red", "Rose", Color(0xFFFFEBEE), Color(0xFF421E20)),
        NoteColorPalette("orange", "Amber", Color(0xFFFFF3E0), Color(0xFF422F1E)),
        NoteColorPalette("yellow", "Lemon", Color(0xFFFFFDE7), Color(0xFF42401E)),
        NoteColorPalette("green", "Mint", Color(0xFFE8F5E9), Color(0xFF1E4226)),
        NoteColorPalette("blue", "Sky", Color(0xFFE1F5FE), Color(0xFF1E3542)),
        NoteColorPalette("purple", "Lavender", Color(0xFFF3E5F5), Color(0xFF331E42)),
        NoteColorPalette("pink", "Sakura", Color(0xFFFCE4EC), Color(0xFF421E2D))
    )

    private val map = list.associateBy { it.key }

    @Composable
    fun getBackgroundColor(key: String, defaultColor: Color): Color {
        val palette = map[key] ?: return defaultColor
        if (palette.key == "default") return defaultColor
        return if (isSystemInDarkTheme()) palette.darkColor else palette.lightColor
    }

    @Composable
    fun getCardBackgroundColor(key: String, defaultColor: Color): Color {
        val palette = map[key] ?: return defaultColor
        if (palette.key == "default") return defaultColor
        return if (isSystemInDarkTheme()) palette.darkColor else palette.lightColor
    }
}
