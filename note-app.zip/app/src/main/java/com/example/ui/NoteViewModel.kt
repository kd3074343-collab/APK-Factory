package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Note
import com.example.data.NoteRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NoteViewModel(private val repository: NoteRepository) : ViewModel() {

    // Notes list from Database
    val allNotes: StateFlow<List<Note>> = repository.allNotes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Search and Category Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    // Dynamic categories extracted from standard list + user notes
    val categories: StateFlow<List<String>> = allNotes
        .map { notes ->
            val defaultCategories = listOf("Personal", "Work", "Study", "Ideas")
            val noteCategories = notes.map { it.category }
                .filter { it.isNotBlank() && it != "Uncategorized" }
            (listOf("All") + defaultCategories + noteCategories).distinct()
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = listOf("All", "Personal", "Work", "Study", "Ideas")
        )

    // Filtered Notes to display on home screen
    val filteredNotes: StateFlow<List<Note>> = combine(allNotes, _searchQuery, _selectedCategory) { notes, query, category ->
        notes.filter { note ->
            val matchesSearch = note.title.contains(query, ignoreCase = true) ||
                    note.content.contains(query, ignoreCase = true)
            val matchesCategory = category == "All" || note.category == category
            matchesSearch && matchesCategory
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Navigation and Editing State
    // If null: showing list. If non-null: editing/adding the note with this ID.
    private val _currentEditingNoteId = MutableStateFlow<Int?>(null)
    val currentEditingNoteId = _currentEditingNoteId.asStateFlow()

    private val _editingTitle = MutableStateFlow("")
    val editingTitle = _editingTitle.asStateFlow()

    private val _editingContent = MutableStateFlow("")
    val editingContent = _editingContent.asStateFlow()

    private val _editingCategory = MutableStateFlow("Uncategorized")
    val editingCategory = _editingCategory.asStateFlow()

    private val _editingColorKey = MutableStateFlow("default")
    val editingColorKey = _editingColorKey.asStateFlow()

    private val _editingIsPinned = MutableStateFlow(false)
    val editingIsPinned = _editingIsPinned.asStateFlow()

    private val _editingUpdatedAt = MutableStateFlow(System.currentTimeMillis())
    val editingUpdatedAt = _editingUpdatedAt.asStateFlow()

    private var autoSaveJob: Job? = null

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    // Create a new note and switch to edit screen
    fun createNewNote() {
        viewModelScope.launch {
            val initialCategory = if (_selectedCategory.value != "All") _selectedCategory.value else "Personal"
            val newNote = Note(
                title = "",
                content = "",
                category = initialCategory,
                colorKey = "default",
                isPinned = false,
                updatedAt = System.currentTimeMillis()
            )
            val noteId = repository.insert(newNote).toInt()
            
            // Initialize edit states
            _editingTitle.value = ""
            _editingContent.value = ""
            _editingCategory.value = initialCategory
            _editingColorKey.value = "default"
            _editingIsPinned.value = false
            _editingUpdatedAt.value = System.currentTimeMillis()
            
            _currentEditingNoteId.value = noteId
        }
    }

    // Select existing note to edit
    fun selectNoteToEdit(note: Note) {
        _editingTitle.value = note.title
        _editingContent.value = note.content
        _editingCategory.value = note.category
        _editingColorKey.value = note.colorKey
        _editingIsPinned.value = note.isPinned
        _editingUpdatedAt.value = note.updatedAt
        _currentEditingNoteId.value = note.id
    }

    // Input state setters called from UI
    fun updateTitle(title: String) {
        _editingTitle.value = title
        _editingUpdatedAt.value = System.currentTimeMillis()
        triggerAutoSave()
    }

    fun updateContent(content: String) {
        _editingContent.value = content
        _editingUpdatedAt.value = System.currentTimeMillis()
        triggerAutoSave()
    }

    fun updateCategory(category: String) {
        _editingCategory.value = category
        _editingUpdatedAt.value = System.currentTimeMillis()
        // Save category changes instantly
        saveCurrentNoteImmediately()
    }

    fun updateColorKey(colorKey: String) {
        _editingColorKey.value = colorKey
        _editingUpdatedAt.value = System.currentTimeMillis()
        // Save color changes instantly
        saveCurrentNoteImmediately()
    }

    fun togglePinned() {
        _editingIsPinned.value = !_editingIsPinned.value
        _editingUpdatedAt.value = System.currentTimeMillis()
        // Save pin changes instantly
        saveCurrentNoteImmediately()
    }

    // Save note after 500ms debounce
    private fun triggerAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(500)
            saveCurrentNoteImmediately()
        }
    }

    // Immediate database write
    private fun saveCurrentNoteImmediately() {
        val noteId = _currentEditingNoteId.value ?: return
        val currentTitle = _editingTitle.value
        val currentContent = _editingContent.value
        val currentCategory = _editingCategory.value
        val currentColorKey = _editingColorKey.value
        val currentPinned = _editingIsPinned.value
        val currentTimestamp = _editingUpdatedAt.value

        viewModelScope.launch {
            val note = Note(
                id = noteId,
                title = currentTitle,
                content = currentContent,
                category = currentCategory,
                colorKey = currentColorKey,
                isPinned = currentPinned,
                updatedAt = currentTimestamp
            )
            repository.insert(note)
        }
    }

    // Deletes note currently being edited
    fun deleteCurrentNote() {
        val noteId = _currentEditingNoteId.value ?: return
        autoSaveJob?.cancel()
        viewModelScope.launch {
            repository.deleteById(noteId)
            _currentEditingNoteId.value = null
        }
    }

    // Deletes an arbitrary note from the list
    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.delete(note)
        }
    }

    // Toggle Pin status of any note directly from list
    fun toggleNotePin(note: Note) {
        viewModelScope.launch {
            repository.insert(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    // Called when navigating away from NoteDetailScreen back to Home
    fun saveAndExit() {
        autoSaveJob?.cancel()
        val noteId = _currentEditingNoteId.value
        if (noteId != null) {
            val title = _editingTitle.value.trim()
            val content = _editingContent.value.trim()
            val category = _editingCategory.value
            val colorKey = _editingColorKey.value
            val isPinned = _editingIsPinned.value
            val timestamp = _editingUpdatedAt.value

            viewModelScope.launch {
                if (title.isEmpty() && content.isEmpty()) {
                    // Automatically clean up/delete blank notes to keep the UX clean
                    repository.deleteById(noteId)
                } else {
                    // Final commit
                    val note = Note(
                        id = noteId,
                        title = title,
                        content = content,
                        category = category,
                        colorKey = colorKey,
                        isPinned = isPinned,
                        updatedAt = timestamp
                    )
                    repository.insert(note)
                }
                _currentEditingNoteId.value = null
            }
        } else {
            _currentEditingNoteId.value = null
        }
    }
}

class NoteViewModelFactory(private val repository: NoteRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NoteViewModel::class.java)) {
            return NoteViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
