package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val category: String = "Uncategorized",
    val colorKey: String = "default",
    val isPinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
