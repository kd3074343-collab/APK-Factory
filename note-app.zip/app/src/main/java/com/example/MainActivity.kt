package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.data.NoteDatabase
import com.example.data.NoteRepository
import com.example.ui.NoteViewModel
import com.example.ui.NoteViewModelFactory
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NoteDetailScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Edge-to-edge layout is enabled by default
        enableEdgeToEdge()

        // Core Room dependency instantiation
        val database = NoteDatabase.getDatabase(applicationContext)
        val repository = NoteRepository(database.noteDao())
        
        // Obtain NoteViewModel with Factory
        val viewModel: NoteViewModel by viewModels {
            NoteViewModelFactory(repository)
        }

        setContent {
            MyApplicationTheme {
                val currentEditingNoteId by viewModel.currentEditingNoteId.collectAsState()

                // Intercept hardware/gestural back presses during note writing
                BackHandler(enabled = currentEditingNoteId != null) {
                    viewModel.saveAndExit()
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    // High-performance screen transition animation
                    Crossfade(
                        targetState = currentEditingNoteId,
                        label = "screen_navigation_crossfade",
                        modifier = Modifier.padding(innerPadding)
                    ) { noteId ->
                        if (noteId == null) {
                            HomeScreen(viewModel = viewModel)
                        } else {
                            NoteDetailScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
