package com.example.game

import android.graphics.PointF
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.game.GameViewModel.ToolMode
import kotlin.math.*

// Hit polygon structure for Canvas interaction
data class FacePoly(
    val cx: Int,
    val cy: Int,
    val cz: Int,
    val face: String, // "top", "left", "right"
    val points: List<Offset>
) {
    // Raycast check: Ray-Crossing algorithm detects if tapped coordinate is inside the face polygon bound
    fun contains(pt: Offset): Boolean {
        var intersects = 0
        val count = points.size
        for (i in 0 until count) {
            val p1 = points[i]
            val p2 = points[(i + 1) % count]
            if (((p1.y > pt.y) != (p2.y > pt.y)) &&
                (pt.x < (p2.x - p1.x) * (pt.y - p1.y) / (p2.y - p1.y) + p1.x)) {
                intersects++
            }
        }
        return intersects % 2 != 0
    }
}

@Composable
fun PocketCraftApp(viewModel: GameViewModel) {
    val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()
    val savedWorlds by viewModel.savedWorlds.collectAsStateWithLifecycle()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        when (activeScreen) {
            "main_menu" -> MainMenuScreen(viewModel, savedWorlds)
            "gameplay" -> GameplayScreen(viewModel)
            "inventory" -> FullInventoryScreen(viewModel)
            "crafting" -> AdvancedCraftingScreen(viewModel)
            "chest" -> ChestScreen(viewModel)
            "death_screen" -> DeathScreen(viewModel)
        }
    }
}

@Composable
fun MainMenuScreen(viewModel: GameViewModel, savedWorlds: List<WorldMetadata>) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var worldNameInput by remember { mutableStateOf("My Sandbox Haven") }
    var seedInput by remember { mutableStateOf("12345") }
    var isCreativeSelection by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF1A1A24), Color(0xFF0F0F13))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Decorative Pixel-art blocks flow background
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            // Draw background stars
            for (i in 1..40) {
                val seedOffset = i * 2932L
                val starX = (Math.abs(Math.sin(seedOffset.toDouble() + 42)) * w).toFloat()
                val starY = (Math.abs(Math.cos(seedOffset.toDouble() + 99)) * h).toFloat()
                val opacity = 0.2f + 0.5f * sin((System.currentTimeMillis() / 400.0) + i).toFloat()
                drawCircle(Color.White.copy(alpha = opacity), radius = (2..5).random().dp.toPx(), center = Offset(starX, starY))
            }
        }

        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth(0.9f)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Title Header using beautiful Minecraft-like displays
            Text(
                text = "BLOCK CRAFT",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    color = Color(0xFF4FC3F7)
                ),
                textAlign = TextAlign.Center
            )
            Text(
                text = "STUDIO",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFA1887F)
                ),
                modifier = Modifier.padding(bottom = 32.dp)
            )

            Button(
                onClick = { showCreateDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("create_world_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E9C23)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create", tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("Generate New World", fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = "Saves Files",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(Modifier.height(8.dp))

            // Saves List
            if (savedWorlds.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No worlds found.\nClick generate to start your journey!",
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp)
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    items(savedWorlds) { world ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { viewModel.loadSavedWorld(world) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26))
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        world.name,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        "Mode: ${world.gameMode.uppercase()} | Seed: ${world.seed}",
                                        color = Color.LightGray,
                                        fontSize = 12.sp
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.deleteSavedWorld(world.id) }
                                ) {
                                    Icon(Icons.Default.Delete, "Delete world", tint = Color(0xFFEF5350))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // World creation popup modal
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Generate New World") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    OutlinedTextField(
                        value = worldNameInput,
                        onValueChange = { worldNameInput = it },
                        label = { Text("World Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = seedInput,
                        onValueChange = { seedInput = it.filter { c -> c.isDigit() } },
                        label = { Text("Seed (Numeric)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Game Mode: ${if (isCreativeSelection) "Creative (Infinite)" else "Survival (Real)"}")
                        Switch(
                            checked = isCreativeSelection,
                            onCheckedChange = { isCreativeSelection = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val s = seedInput.toLongOrNull() ?: 12345L
                        viewModel.startNewWorld(worldNameInput, s, isCreativeSelection)
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4FC3F7))
                ) {
                    Text("Assemble!")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Back")
                }
            }
        )
    }
}

@Composable
fun GameplayScreen(viewModel: GameViewModel) {
    val activeWorldName by viewModel.activeWorldName.collectAsStateWithLifecycle()
    val blocks by viewModel.blocks.collectAsStateWithLifecycle()
    val playerX by viewModel.playerX.collectAsStateWithLifecycle()
    val playerY by viewModel.playerY.collectAsStateWithLifecycle()
    val playerZ by viewModel.playerZ.collectAsStateWithLifecycle()
    val playerHealth by viewModel.playerHealth.collectAsStateWithLifecycle()
    val playerHunger by viewModel.playerHunger.collectAsStateWithLifecycle()
    val activeToolMode by viewModel.activeToolMode.collectAsStateWithLifecycle()
    val currentHeightSlice by viewModel.currentHeightSlice.collectAsStateWithLifecycle()

    val wordTime by viewModel.worldTime.collectAsStateWithLifecycle()
    val cameraOffsetX by viewModel.cameraOffsetX.collectAsStateWithLifecycle()
    val cameraOffsetY by viewModel.cameraOffsetY.collectAsStateWithLifecycle()
    val cameraZoom by viewModel.cameraZoom.collectAsStateWithLifecycle()
    val cameraRotation by viewModel.cameraRotation.collectAsStateWithLifecycle()

    val hotbar by viewModel.hotbar.collectAsStateWithLifecycle()
    val activeHotbarIndex by viewModel.selectedHotbarIndex.collectAsStateWithLifecycle()

    val surfaceLocalDensity = LocalDensity.current

    // Canvas depth lists
    val facePolys = remember { mutableStateListOf<FacePoly>() }

    // Sky cycle calculations
    val skyColor = getSkyColor(wordTime)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(skyColor)
    ) {
        // Render 3D Canvas Engine
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { offset ->
                            // Traverse face polys backwards to hit the topmost item face first!
                            var hitFound = false
                            for (i in facePolys.indices.reversed()) {
                                val poly = facePolys[i]
                                if (poly.contains(offset)) {
                                    val coord = "${poly.cx},${poly.cy},${poly.cz}"
                                    if (activeToolMode == ToolMode.MINE) {
                                        viewModel.handleBlockInteraction(coord, false)
                                    } else {
                                        // Build block attaches to the face polygon clicked
                                        viewModel.buildBlockOnFace(coord, poly.face)
                                    }
                                    hitFound = true
                                    break
                                }
                            }
                            if (!hitFound) {
                                // Simple walk pathing on surface when tapping on ground space
                                // convert tap offset coordinate back to grid coords relative to player
                                val px = playerX
                                val py = playerY
                                val cx = size.width / 2f + cameraOffsetX
                                val cy = size.height / 2f + cameraOffsetY
                                val sizeUnit = 30f * cameraZoom

                                // Isometric conversion math: reverse-projection
                                val localX = (offset.x - cx) / (sizeUnit * 1.5f)
                                val localY = (offset.y - cy) / (sizeUnit * 0.75f)

                                val gridDx = (localX + localY).coerceIn(-10f, 10f)
                                val gridDy = (localY - localX).coerceIn(-10f, 10f)

                                viewModel.initiateWalkTo(
                                    (px + gridDx).coerceIn(0.5f, 31.5f),
                                    (py + gridDy).coerceIn(0.5f, 31.5f)
                                )
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        viewModel.setCameraOffset(dragAmount.x, dragAmount.y)
                    }
                }
        ) {
            val drawW = size.width
            val drawH = size.height

            // 1. Draw Star constellations at night
            if (wordTime in 12000L..23000L) {
                val moonOpacity = if (wordTime in 12000L..13000L) {
                    (wordTime - 12000L) / 1000f
                } else if (wordTime in 22000L..23000L) {
                    1f - ((wordTime - 22000L) / 1000f)
                } else 1f

                for (i in 1..25) {
                    val starOffset = i * 4392L
                    val starX = (Math.abs(Math.sin(starOffset.toDouble() + 11)) * drawW).toFloat()
                    val starY = (Math.abs(Math.cos(starOffset.toDouble() + 71)) * (drawH / 2f)).toFloat()
                    drawCircle(Color.White.copy(alpha = moonOpacity), radius = 2f, center = Offset(starX, starY))
                }
                // Little glowing moon
                drawCircle(Color(0xFFE0F7FA).copy(alpha = moonOpacity * 0.9f), radius = 32.dp.toPx(), center = Offset(drawW * 0.8f, drawH * 0.2f))
            }

            // Glowing daytime Sun
            if (wordTime in 23000L..24000L || wordTime in 0L..13000L) {
                val sunOpacity = if (wordTime in 23000L..24000L) {
                    (wordTime - 23000L) / 1000f
                } else if (wordTime in 12000L..13000L) {
                    1f - ((wordTime - 12000L) / 1000f)
                } else 1f
                drawCircle(Color(0xFFFFEE58).copy(alpha = sunOpacity), radius = 40.dp.toPx(), center = Offset(drawW * 0.2f, drawH * 0.25f))
            }

            // Clear interactive face polygons buffer
            facePolys.clear()

            val sizeBlock = 30f * cameraZoom
            val halfW = sizeBlock * 1.5f
            val halfH = sizeBlock * 0.75f

            // Camera Projection Center
            val centerX = drawW / 2f + cameraOffsetX
            val centerY = drawH / 2f + cameraOffsetY

            // Base ambient light value
            val daylightMultiplier = getDaylightMultiplier(wordTime)

            // Render box centers on player position
            val px = playerX.toInt()
            val py = playerY.toInt()

            val renderRadius = 6
            val minX = (px - renderRadius).coerceAtLeast(0)
            val maxX = (px + renderRadius).coerceAtMost(31)
            val minY = (py - renderRadius).coerceAtLeast(0)
            val maxY = (py + renderRadius).coerceAtMost(31)

            // Depth sorting loops depending on active cameraRotation angle
            val xRange = if (cameraRotation == 180 || cameraRotation == 270) (maxX downTo minX) else (minX..maxX)
            val yRange = if (cameraRotation == 90 || cameraRotation == 180) (maxY downTo minY) else (minY..maxY)

            // RENDER BLOCKS IN SORTED ORDER
            for (z in 1..currentHeightSlice) {
                for (x in xRange) {
                    for (y in yRange) {
                        val block = viewModel.getBlockAt(x, y, z)
                        if (block == BlockType.AIR) continue

                        // Adjust coordinates based on rotation angles
                        val finalX = when (cameraRotation) {
                            90 -> (py - y) + px
                            180 -> px - (x - px)
                            270 -> px - (py - y)
                            else -> x
                        }
                        val finalY = when (cameraRotation) {
                            90 -> (x - px) + py
                            180 -> py - (y - py)
                            270 -> py - (x - px)
                            else -> y
                        }

                        // Relativize coords centered on player coordinate state (offsets)
                        val rx = finalX - playerX
                        val ry = finalY - playerY
                        val rz = z - playerZ

                        // Iso projection coordinate formula mapping
                        val scX = (rx - ry) * (halfW) + centerX
                        val scY = (rx + ry) * (halfH) - rz * sizeBlock + centerY

                        // Distance check for fog fading out
                        val distance = sqrt((rx * rx + ry * ry).toDouble()).toFloat()
                        if (distance > 7.5f) continue // Fog radius cull

                        val opacity = (1.0f - ((distance - 5.5f) / 2.0f)).coerceIn(0f, 1f)

                        // Calculate ambient points lighting
                        val lightLevel = getBlockLightingIntensity(viewModel, finalX, finalY, z, daylightMultiplier)

                        // Render single cube faces
                        drawIsometricCube(
                            x = finalX, y = finalY, z = z,
                            scX = scX, scY = scY,
                            halfW = halfW, halfH = halfH, sizeZ = sizeBlock,
                            block = block,
                            light = lightLevel,
                            opacity = opacity,
                            onPolyDrawn = { face, pathPoints ->
                                facePolys.add(FacePoly(finalX, finalY, z, face, pathPoints))
                            }
                        )
                    }
                }
            }

            // 3. Draw Player Adorable Steve/Alex Character representation
            val pscX = centerX
            val pscY = centerY // Centered precisely in screen viewport
            drawPlayerAvatar(
                scX = pscX, scY = pscY,
                sizeBlock = sizeBlock,
                swimOffset = if (viewModel.getBlockAt(playerX.toInt(), playerY.toInt(), playerZ.toInt()) == BlockType.WATER) 15f else 0f,
                gameMode = viewModel.gameMode.value
            )

            // 4. Draw Hostile and Peaceful Mobs
            for (mob in viewModel.activeMobs) {
                val rx = mob.x - playerX
                val ry = mob.y - playerY
                val rz = mob.z - playerZ

                // Only render inside camera view boundaries
                if (abs(rx) > 8 || abs(ry) > 8) continue

                val scX = (rx - ry) * (halfW) + centerX
                val scY = (rx + ry) * (halfH) - rz * sizeBlock + centerY

                drawMobAvatar(scX, scY, sizeBlock, mob)
            }

            // 5. Draw mining selection overlay progress if active
            viewModel.miningTarget?.let { coord ->
                val parts = coord.split(",")
                if (parts.size == 3) {
                    val targetX = parts[0].toInt()
                    val targetY = parts[1].toInt()
                    val targetZ = parts[2].toInt()

                    val rx = targetX - playerX
                    val ry = targetY - playerY
                    val rz = targetZ - playerZ

                    val scX = (rx - ry) * (halfW) + centerX
                    val scY = (rx + ry) * (halfH) - rz * sizeBlock + centerY

                    // Draw crack lines overlay on coordinate
                    drawMiningCracks(scX, scY, halfW, halfH, sizeBlock, viewModel.miningProgress)
                }
            }

            // 6. Draw floating particles
            for (p in viewModel.activeParticles) {
                val rx = p.x - playerX
                val ry = p.y - playerY
                val rz = p.z - playerZ

                if (abs(rx) > 8 || abs(ry) > 8) continue

                val scX = (rx - ry) * (halfW) + centerX
                val scY = (rx + ry) * (halfH) - rz * sizeBlock + centerY

                drawCircle(
                    Color(p.color),
                    radius = (2..4).random().dp.toPx() * (p.life.toFloat() / p.maxLife),
                    center = Offset(scX, scY)
                )
            }

            // 7. Render Floating floating texts in 3D
            for (text in viewModel.floatingTexts) {
                val rx = text.x - playerX
                val ry = text.y - playerY
                val rz = text.z - playerZ

                if (abs(rx) > 8 || abs(ry) > 8) continue

                val scX = (rx - ry) * (halfW) + centerX
                val scY = (rx + ry) * (halfH) - rz * sizeBlock + centerY

                // Text drawing inside Compose is optimal via native Canvas drawText
                val paint = android.graphics.Paint().apply {
                    color = text.color.toInt()
                    textSize = 14.dp.toPx()
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.MONOSPACE
                    setShadowLayer(4f, 2f, 2f, Color.Black.toArgb())
                }
                drawContext.canvas.nativeCanvas.drawText(
                    text.text,
                    scX,
                    scY - (20 - text.life),
                    paint
                )
            }
        }

        // --- GAME HUD HOVER OVERLAYS ---
        // Upper Status stats layout
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xCC1A1A24)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column {
                        Text(
                            activeWorldName,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Text(
                            "XYZ: ${playerX.toInt()}, ${playerY.toInt()}, ${playerZ.toInt()}",
                            color = Color(0xFF4FC3F7),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }

                    // Height Slice controller
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.KeyboardArrowUp, "Height Slice", tint = Color.LightGray)
                        Text(
                            "Slice: $currentHeightSlice",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(4.dp))
                        IconButton(
                            onClick = {
                                val next = (currentHeightSlice + 1)
                                viewModel.setHeightSlice(if (next > 10) 5 else next)
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Refresh, "change slice", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    // Rotation control
                    IconButton(
                        onClick = { viewModel.rotateCameraRight() },
                        modifier = Modifier
                            .size(36.dp)
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, "Rotate Map", tint = Color.White)
                    }

                    // Reset camera
                    IconButton(
                        onClick = { viewModel.resetCamera() },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, "Snap Camera", tint = Color.White)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // SURVIVAL HEARTS AND HUNGER BARS
            if (viewModel.gameMode.value == "survival") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0x99000000)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.padding(horizontal = 24.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Life Hearts display (10 hearts)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Favorite,
                                "Health",
                                tint = Color(0xFFEF5350),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "HP: ${playerHealth.toInt()}/20",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Hunger Leg bars
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Star,
                                "Hunger",
                                tint = Color(0xFFFFB300),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "Hunger: ${playerHunger.toInt()}/20",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Left vertical toolbox triggers
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 12.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Dig/Mine Mode Toggler
                FloatingActionButton(
                    onClick = { viewModel.setToolMode(ToolMode.MINE) },
                    containerColor = if (activeToolMode == ToolMode.MINE) Color(0xFF4FC3F7) else Color(0xBB1A1A24),
                    contentColor = Color.White,
                    modifier = Modifier.size(44.dp).testTag("tool_mine_button")
                ) {
                    Icon(Icons.Default.Build, "Mine Mode")
                }

                // Place Mode Toggler
                FloatingActionButton(
                    onClick = { viewModel.setToolMode(ToolMode.BUILD) },
                    containerColor = if (activeToolMode == ToolMode.BUILD) Color(0xFF4E9C23) else Color(0xBB1A1A24),
                    contentColor = Color.White,
                    modifier = Modifier.size(44.dp).testTag("tool_build_button")
                ) {
                    Icon(Icons.Default.Add, "Place Mode")
                }

                // Inventory Bag screen opener
                FloatingActionButton(
                    onClick = { viewModel.navigateTo("inventory") },
                    containerColor = Color(0xCCFFB300),
                    contentColor = Color.Black,
                    modifier = Modifier.size(44.dp).testTag("backpack_button")
                ) {
                    Icon(Icons.Default.Menu, "Backpack Bag")
                }

                // Quit button to main menu
                FloatingActionButton(
                    onClick = { viewModel.navigateTo("main_menu") },
                    containerColor = Color(0xCCEF5350),
                    contentColor = Color.White,
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(Icons.Default.Home, "Quit Game")
                }
            }
        }

        // ZOOM CONTROLLER IN RIGHT FOREGROUND
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { viewModel.setCameraZoom(1.2f) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xAA1E1E26)),
                    modifier = Modifier.size(40.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }

                Button(
                    onClick = { viewModel.setCameraZoom(0.8f) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xAA1E1E26)),
                    modifier = Modifier.size(40.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
            }
        }

        // --- REAR HOTBAR FOOTER BANNER ---
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 12.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Secondary prompt for selected block details or active tools
                val itemSelected = hotbar.getOrNull(activeHotbarIndex)
                if (itemSelected != null && itemSelected.blockType != BlockType.AIR) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xDD2E303F)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                itemSelected.displayName,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                            if (itemSelected.type == ItemType.FOOD) {
                                Spacer(Modifier.width(8.dp))
                                Button(
                                    onClick = { viewModel.eatSelectedItem() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4FC3F7)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                    modifier = Modifier.height(20.dp).testTag("eat_food_button")
                                ) {
                                    Text("Eat Food", fontSize = 10.sp, color = Color.Black)
                                }
                            }
                        }
                    }
                }

                // Grid of 9 hotbar slots
                Row(
                    modifier = Modifier
                        .background(Color(0xFF151522), RoundedCornerShape(12.dp))
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0..8) {
                        val item = hotbar.getOrNull(i) ?: InventoryItem.block(BlockType.AIR, 0)
                        val isSlotSelected = i == activeHotbarIndex

                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    if (isSlotSelected) Color(0xFF4FC3F7) else Color(0xFF2E2E3E),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    width = if (isSlotSelected) 2.dp else 1.dp,
                                    color = if (isSlotSelected) Color.White else Color.Gray,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.selectHotbarIndex(i) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (item.blockType != BlockType.AIR && item.count > 0) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    // Custom visual block display color swatch or label icon
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .background(Color(item.iconColor), RoundedCornerShape(2.dp))
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = if (item.maxStack == 1) "1" else item.count.toString(),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FullInventoryScreen(viewModel: GameViewModel) {
    val hotbar by viewModel.hotbar.collectAsStateWithLifecycle()
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()
    var selectedHotbarIndexToSwap by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F13))
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Backpack Inventory",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            IconButton(
                onClick = { viewModel.navigateTo("gameplay") }
            ) {
                Icon(Icons.Default.Close, "Close", tint = Color.White)
            }
        }

        Text(
            "Quick Crafting & Storage table matches adjacent table types. Select items below to place into active hotbar keys.",
            color = Color.LightGray,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Swap instructions
        Text(
            text = if (selectedHotbarIndexToSwap == null) "Step 1: Choose Hotbar Slot below to swap" else "Step 2: Choose Item from Backpack below to place!",
            fontWeight = FontWeight.SemiBold,
            color = if (selectedHotbarIndexToSwap == null) Color(0xFFFFB300) else Color(0xFF4FC3F7),
            fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Hotbar strip
        Text("Active Hotbar", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .background(Color(0xFF151522), RoundedCornerShape(10.dp))
                .padding(8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (i in 0..8) {
                val item = hotbar.getOrNull(i) ?: InventoryItem.block(BlockType.AIR, 0)
                val isSelected = selectedHotbarIndexToSwap == i

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .background(
                            if (isSelected) Color(0xFFFFB300) else Color(0xFF2E2E3E),
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            if (isSelected) Color.White else Color.Gray,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedHotbarIndexToSwap = i },
                    contentAlignment = Alignment.Center
                ) {
                    if (item.blockType != BlockType.AIR) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(modifier = Modifier.size(12.dp).background(Color(item.iconColor), RoundedCornerShape(2.dp)))
                            Text("${item.count}", color = Color.White, fontSize = 10.sp)
                        }
                    } else {
                        Text("-", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // Backpack Inventory Grid
        Text("Backpack Stash", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))

        if (inventory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("Backpack is empty.\nMine blocks with tools to earn resources!", color = Color.Gray, textAlign = TextAlign.Center)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(items = inventory) { index, item: InventoryItem ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .background(Color(0xFF1E1E26), RoundedCornerShape(8.dp))
                            .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                            .clickable {
                                val hotbarIndex = selectedHotbarIndexToSwap
                                if (hotbarIndex != null) {
                                    viewModel.swapInventoryItemWithHotbar(index, hotbarIndex)
                                    selectedHotbarIndexToSwap = null // Swap complete!
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .background(Color(item.iconColor), RoundedCornerShape(3.dp))
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                item.displayName,
                                color = Color.White,
                                fontSize = 9.sp,
                                maxLines = 1,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                "x${item.count}",
                                color = Color.LightGray,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdvancedCraftingScreen(viewModel: GameViewModel) {
    val hotbar by viewModel.hotbar.collectAsStateWithLifecycle()
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()

    val combinedInv = remember(hotbar, inventory) {
        hotbar + inventory
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101018))
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "3x3 Crafting Table",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            IconButton(
                onClick = { viewModel.navigateTo("gameplay") }
            ) {
                Icon(Icons.Default.Close, "Close", tint = Color.White)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(CraftingRegistry.recipes) { recipe ->
                val canCraft = recipe.canPlayerCraft(combinedInv)

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (canCraft) Color(0xFF233020) else Color(0xFF1E1E26)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .background(Color(recipe.result.iconColor), RoundedCornerShape(2.dp))
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "${recipe.result.displayName} x${recipe.result.count}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            // Recipe Ingredients Summary list
                            Text(
                                text = "Requires: " + recipe.ingredients.joinToString(", ") { "${it.displayName} (${it.count})" },
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.craftRecipe(recipe) },
                            enabled = canCraft,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (canCraft) Color(0xFF4FC3F7) else Color.Gray,
                                contentColor = Color.Black
                            )
                        ) {
                            Text("Craft", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChestScreen(viewModel: GameViewModel) {
    val chestInv by viewModel.chestInventory.collectAsStateWithLifecycle()
    val hotbar by viewModel.hotbar.collectAsStateWithLifecycle()
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()

    val combinedBackpack = remember(hotbar, inventory) {
        hotbar.filter { it.blockType != BlockType.AIR } + inventory
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF12121A))
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Secure Iron Chest",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Button(onClick = { viewModel.closeChest() }) {
                Text("Lock Chest")
            }
        }

        // Chest Stash Block Grid
        Text("Chest Inventory", color = Color(0xFFFFF176), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            modifier = Modifier.weight(1f).background(Color(0xFF1E1E26), RoundedCornerShape(8.dp)).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items = chestInv) { item: InventoryItem ->
                Box(
                    modifier = Modifier
                        .aspectRatio(1f).background(Color(0xFF2A2A35), RoundedCornerShape(6.dp))
                        .clickable { viewModel.transferItemChestToInventory(item) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.size(14.dp).background(Color(item.iconColor), RoundedCornerShape(2.dp)))
                        Text(item.displayName, color = Color.White, fontSize = 9.sp, maxLines = 1)
                        Text("x${item.count}", color = Color.LightGray, fontSize = 9.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Personal backpack Grid
        Text("Your Backpack Stash", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            modifier = Modifier.weight(1f).background(Color(0xFF1E1E26), RoundedCornerShape(8.dp)).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items = combinedBackpack) { item: InventoryItem ->
                Box(
                    modifier = Modifier
                        .aspectRatio(1f).background(Color(0xFF2A2A35), RoundedCornerShape(6.dp))
                        .clickable { viewModel.transferItemInventoryToChest(item) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.size(14.dp).background(Color(item.iconColor), RoundedCornerShape(2.dp)))
                        Text(item.displayName, color = Color.White, fontSize = 9.sp, maxLines = 1)
                        Text("x${item.count}", color = Color.LightGray, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun DeathScreen(viewModel: GameViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE4E0D0D)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                "YOU DIED!",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFEF5350)
                )
            )

            Spacer(Modifier.height(16.dp))

            Text(
                "A zombie or creeper got the best of you. Respawning recovers full vital stats and restarts at your mountain center coordinates safely.",
                color = Color.LightGray,
                textAlign = TextAlign.Center,
                fontSize = 14.sp
            )

            Spacer(Modifier.height(32.dp))

            Button(
                onClick = { viewModel.respawnPlayer() },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4FC3F7))
            ) {
                Text("RESPAWN!", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 16.sp)
            }
        }
    }
}

// ENVIRONMENT RENDERING MATHEMATICS
private fun getSkyColor(time: Long): Color {
    return when {
        // Daytime high
        time in 0L..11000L -> Color(0xFF81D4FA) // Sky Blue
        // Dusk/Sunset transition
        time in 11000L..13000L -> {
            val fraction = (time - 11000L) / 2000f
            lerpSkyColor(Color(0xFF81D4FA), Color(0xFFE65100), fraction)
        }
        // Midnight Dark sky
        time in 13000L..23000L -> {
            if (time < 14000L) {
                val fraction = (time - 13000L) / 1000f
                lerpSkyColor(Color(0xFFE65100), Color(0xFF0D0D15), fraction)
            } else if (time > 22000L) {
                val fraction = (time - 22000L) / 1000f
                lerpSkyColor(Color(0xFF0D0D15), Color(0xFFFF5722), fraction)
            } else {
                Color(0xFF0D0D15)
            }
        }
        // Dawn/Sunrise
        else -> {
            val fraction = (time - 23000L) / 1000f
            lerpSkyColor(Color(0xFFFF5722), Color(0xFF81D4FA), fraction)
        }
    }
}

private fun lerpSkyColor(c1: Color, c2: Color, f: Float): Color {
    val r = c1.red + (c2.red - c1.red) * f
    val g = c1.green + (c2.green - c1.green) * f
    val b = c1.blue + (c2.blue - c1.blue) * f
    return Color(r, g, b, 1f)
}

private fun getDaylightMultiplier(time: Long): Float {
    return when {
        time in 0L..10000L -> 1.0f // Fully lit
        time in 10000L..13000L -> {
            // sunset drop to 0.45
            val f = (time - 10000L) / 3000f
            1.0f - (0.65f * f)
        }
        time in 13000L..22000L -> 0.35f // Midnight
        else -> {
            // sunrise rise
            val f = (time - 22000L) / 2000f
            0.35f + (0.65f * f)
        }
    }
}

private fun getBlockLightingIntensity(
    viewModel: GameViewModel,
    x: Int, y: Int, z: Int,
    ambientMultiplier: Float
): Float {
    // Check if coord has any nearby placed torches (Point lighting system)
    var maxTorchEffect = 0.0f
    
    // Check adjacent coordinates Manhattan sweep
    val range = 2
    for (dx in -range..range) {
        for (dy in -range..range) {
            for (dz in -range..range) {
                val bx = x + dx
                val by = y + dy
                val bz = z + dz
                if (viewModel.getBlockAt(bx, by, bz) == BlockType.TORCH) {
                    val dist = abs(dx) + abs(dy) + abs(dz)
                    val factor = (3f - dist) / 3f
                    if (factor > maxTorchEffect) maxTorchEffect = factor
                }
            }
        }
    }

    return maxOf(ambientMultiplier, maxTorchEffect).coerceIn(0.2f, 1.0f)
}

// 3D ISOMETRIC VECTOR RENDERING
private fun DrawScope.drawIsometricCube(
    x: Int, y: Int, z: Int,
    scX: Float, scY: Float,
    halfW: Float, halfH: Float, sizeZ: Float,
    block: BlockType,
    light: Float,
    opacity: Float,
    onPolyDrawn: (String, List<Offset>) -> Unit
) {
    if (block == BlockType.AIR) return

    val topColor = Color(block.colorTop).adjustBrightness(light).copy(alpha = opacity)
    val leftColor = Color(block.colorLeft).adjustBrightness(light * 0.82f).copy(alpha = opacity)
    val rightColor = Color(block.colorRight).adjustBrightness(light * 0.65f).copy(alpha = opacity)

    val topPath = Path().apply {
        moveTo(scX, scY - sizeZ)
        lineTo(scX + halfW, scY - sizeZ - halfH)
        lineTo(scX, scY - sizeZ - 2f * halfH)
        lineTo(scX - halfW, scY - sizeZ - halfH)
        close()
    }
    drawPath(topPath, topColor)
    onPolyDrawn("top", listOf(
        Offset(scX, scY - sizeZ),
        Offset(scX + halfW, scY - sizeZ - halfH),
        Offset(scX, scY - sizeZ - 2f * halfH),
        Offset(scX - halfW, scY - sizeZ - halfH)
    ))

    // Water, Leaves, Glass do not need full solid side faces if partially obscured
    val leftPath = Path().apply {
        moveTo(scX - halfW, scY - sizeZ - halfH)
        lineTo(scX, scY - sizeZ)
        lineTo(scX, scY)
        lineTo(scX - halfW, scY - halfH)
        close()
    }
    drawPath(leftPath, leftColor)
    onPolyDrawn("left", listOf(
        Offset(scX - halfW, scY - sizeZ - halfH),
        Offset(scX, scY - sizeZ),
        Offset(scX, scY),
        Offset(scX - halfW, scY - halfH)
    ))

    val rightPath = Path().apply {
        moveTo(scX, scY - sizeZ)
        lineTo(scX + halfW, scY - sizeZ - halfH)
        lineTo(scX + halfW, scY - halfH)
        lineTo(scX, scY)
        close()
    }
    drawPath(rightPath, rightColor)
    onPolyDrawn("right", listOf(
        Offset(scX, scY - sizeZ),
        Offset(scX + halfW, scY - sizeZ - halfH),
        Offset(scX + halfW, scY - halfH),
        Offset(scX, scY)
    ))

    // Draw Grass Green rim accent explicitly to give a professional detailed texture look!
    if (block == BlockType.GRASS) {
        val rimColor = Color(0xFF4E9C23).adjustBrightness(light).copy(alpha = opacity)
        val rimLeft = Path().apply {
            moveTo(scX, scY - sizeZ)
            lineTo(scX - halfW, scY - sizeZ - halfH)
            lineTo(scX - halfW, scY - sizeZ - halfH + (halfH * 0.4f))
            lineTo(scX, scY - sizeZ + (halfW * 0.15f))
            close()
        }
        drawPath(rimLeft, rimColor)

        val rimRight = Path().apply {
            moveTo(scX, scY - sizeZ)
            lineTo(scX + halfW, scY - sizeZ - halfH)
            lineTo(scX + halfW, scY - sizeZ - halfH + (halfH * 0.4f))
            lineTo(scX, scY - sizeZ + (halfW * 0.15f))
            close()
        }
        drawPath(rimRight, rimColor)
    }

    // Ore inclusions rendering
    if (block == BlockType.DIAMOND_ORE || block == BlockType.COAL_ORE || block == BlockType.IRON_ORE) {
        val oreColor = when (block) {
            BlockType.DIAMOND_ORE -> Color(0xFF00E5FF)
            BlockType.COAL_ORE -> Color(0xFF1E1E1E)
            else -> Color(0xFFD7CCC8)
        }.copy(alpha = opacity)

        drawCircle(oreColor, radius = (2..4).random().toFloat(), center = Offset(scX - halfW/2f, scY - sizeZ/1.5f))
        drawCircle(oreColor, radius = (1..3).random().toFloat(), center = Offset(scX + halfW/3f, scY - sizeZ/1.8f))
    }

    // Torch Fire particles
    if (block == BlockType.TORCH) {
        drawRect(Color(0xFF8D6E63), topLeft = Offset(scX - 3f, scY - sizeZ - 8f), size = Size(6f, 15f))
        drawCircle(Color(0xFFFFB300), radius = 5f, center = Offset(scX, scY - sizeZ - 11f))
        drawCircle(Color(0xFFFF3D00).copy(alpha = 0.8f), radius = 3f, center = Offset(scX, scY - sizeZ - 13f))
    }
}

// 3D CRACKED TEXTURE MINING OVERLAY
private fun DrawScope.drawMiningCracks(
    scX: Float, scY: Float,
    halfW: Float, halfH: Float, sizeZ: Float,
    progress: Float
) {
    if (progress <= 0.1f) return
    val count = (1..6).random()
    // draw crack lightning vectors on Top, Left, and Right face centers
    val col = Color.Black.copy(alpha = 0.7f * progress)
    
    // Center point of top face
    val topCY = scY - sizeZ - halfH
    drawLine(col, start = Offset(scX, topCY), end = Offset(scX - halfW/2f, topCY + halfH/2f), strokeWidth = 3f)
    drawLine(col, start = Offset(scX, topCY), end = Offset(scX + halfW/2f, topCY - halfH/2f), strokeWidth = 3f)

    // Side cracks
    drawLine(col, start = Offset(scX, scY - sizeZ/2f), end = Offset(scX - halfW/2f, scY - halfH/2f), strokeWidth = 3f)
    drawLine(col, start = Offset(scX, scY - sizeZ/2f), end = Offset(scX + halfW/2f, scY - halfH/2f), strokeWidth = 3f)
}

// STYLING AVATARS DRAWING
private fun DrawScope.drawPlayerAvatar(
    scX: Float, scY: Float,
    sizeBlock: Float,
    swimOffset: Float,
    gameMode: String
) {
    val h = sizeBlock * 1.5f // Height factor

    // Neck / Head (Skin colored cylinder)
    drawRect(Color(0xFFFFCCBC), topLeft = Offset(scX - sizeBlock * 0.25f, scY - h - sizeBlock * 0.5f + swimOffset), size = Size(sizeBlock * 0.5f, sizeBlock * 0.4f))
    // Cute Hair cap
    drawRect(Color(0xFF5D4037), topLeft = Offset(scX - sizeBlock * 0.3f, scY - h - sizeBlock * 0.62f + swimOffset), size = Size(sizeBlock * 0.6f, sizeBlock * 0.22f))

    // Body (Blue steve shirt)
    drawRect(Color(0xFF0288D1), topLeft = Offset(scX - sizeBlock * 0.35f, scY - h + swimOffset), size = Size(sizeBlock * 0.7f, sizeBlock * 0.7f))

    // Active weapon or tools representation
    drawRect(Color(0xFFA1887F), topLeft = Offset(scX + sizeBlock * 0.38f, scY - h + sizeBlock * 0.2f + swimOffset), size = Size(4f, sizeBlock * 0.6f))
    // pickaxe or sword head
    drawRect(Color(0xFFB0BEC5), topLeft = Offset(scX + sizeBlock * 0.3f, scY - h + sizeBlock * 0.1f + swimOffset), size = Size(sizeBlock * 0.3f, 4f))

    // Legs (Grey pants)
    if (swimOffset == 0f) {
        drawRect(Color(0xFF455A64), topLeft = Offset(scX - sizeBlock * 0.3f, scY - h + sizeBlock * 0.7f), size = Size(sizeBlock * 0.26f, sizeBlock * 0.6f))
        drawRect(Color(0xFF455A64), topLeft = Offset(scX + sizeBlock * 0.04f, scY - h + sizeBlock * 0.7f), size = Size(sizeBlock * 0.26f, sizeBlock * 0.6f))
    }
}

private fun DrawScope.drawMobAvatar(
    scX: Float, scY: Float,
    sizeBlock: Float,
    mob: GameMob
) {
    val h = sizeBlock * 1.5f

    when (mob.type) {
        MobType.ZOMBIE -> {
            val c = if (mob.isHurtTick > 0) Color.Red else Color(0xFF2E7D32)
            // Head
            drawRect(c, topLeft = Offset(scX - sizeBlock * 0.28f, scY - h - sizeBlock * 0.45f), size = Size(sizeBlock * 0.56f, sizeBlock * 0.4f))
            // Body
            drawRect(Color(0xFF00897B), topLeft = Offset(scX - sizeBlock * 0.35f, scY - h), size = Size(sizeBlock * 0.7f, sizeBlock * 0.7f))
            // Legs
            drawRect(Color(0xFF37474F), topLeft = Offset(scX - sizeBlock * 0.3f, scY - h + sizeBlock * 0.7f), size = Size(sizeBlock * 0.25f, sizeBlock * 0.55f))
            drawRect(Color(0xFF37474F), topLeft = Offset(scX + sizeBlock * 0.05f, scY - h + sizeBlock * 0.7f), size = Size(sizeBlock * 0.25f, sizeBlock * 0.55f))
        }
        MobType.CREEPER -> {
            // Animating flashing fuse color
            val isFlash = mob.explosionFuse != -1 && (mob.explosionFuse % 4 < 2)
            val c = if (isFlash) Color.White else (if (mob.isHurtTick > 0) Color.Red else Color(0xFF4CAF50))

            // Cube body
            drawRect(c, topLeft = Offset(scX - sizeBlock * 0.25f, scY - h - sizeBlock * 0.1f), size = Size(sizeBlock * 0.5f, sizeBlock * 0.95f))
            // creeper feet
            drawRect(Color(0xFF2E7D32), topLeft = Offset(scX - sizeBlock * 0.3f, scY - h + sizeBlock * 0.85f), size = Size(sizeBlock * 0.25f, sizeBlock * 0.25f))
            drawRect(Color(0xFF2E7D32), topLeft = Offset(scX + sizeBlock * 0.05f, scY - h + sizeBlock * 0.85f), size = Size(sizeBlock * 0.25f, sizeBlock * 0.25f))
        }
        MobType.COW -> {
            val c = if (mob.isHurtTick > 0) Color.Red else Color(0xFF5D4037)
            // spotted beefy body
            drawRect(c, topLeft = Offset(scX - sizeBlock * 0.5f, scY - h + sizeBlock * 0.2f), size = Size(sizeBlock * 1f, sizeBlock * 0.6f))
            // cow head
            drawRect(Color.White, topLeft = Offset(scX - sizeBlock * 0.35f, scY - h - sizeBlock * 0.15f), size = Size(sizeBlock * 0.4f, sizeBlock * 0.35f))
            // legs
            drawRect(c, topLeft = Offset(scX - sizeBlock * 0.4f, scY - h + sizeBlock * 0.8f), size = Size(sizeBlock * 0.18f, sizeBlock * 0.4f))
            drawRect(c, topLeft = Offset(scX + sizeBlock * 0.2f, scY - h + sizeBlock * 0.8f), size = Size(sizeBlock * 0.18f, sizeBlock * 0.4f))
        }
        MobType.SHEEP -> {
            val c = if (mob.isHurtTick > 0) Color.Red else Color(0xFFEEEEEE)
            // Fluffy white sheep coat
            drawRect(c, topLeft = Offset(scX - sizeBlock * 0.45f, scY - h + sizeBlock * 0.15f), size = Size(sizeBlock * 0.9f, sizeBlock * 0.65f))
            // pinkish small face
            drawRect(Color(0xFFFFCCBC), topLeft = Offset(scX - sizeBlock * 0.3f, scY - h - sizeBlock * 0.12f), size = Size(sizeBlock * 0.3f, sizeBlock * 0.28f))
            // legs
            drawRect(Color(0xFF7D7D7D), topLeft = Offset(scX - sizeBlock * 0.35f, scY - h + sizeBlock * 0.8f), size = Size(sizeBlock * 0.15f, sizeBlock * 0.35f))
            drawRect(Color(0xFF7D7D7D), topLeft = Offset(scX + sizeBlock * 0.2f, scY - h + sizeBlock * 0.8f), size = Size(sizeBlock * 0.15f, sizeBlock * 0.35f))
        }
    }
}

// COLOR SWATCH UTILITIES
private fun Color.adjustBrightness(factor: Float): Color {
    return Color(
        red = (this.red * factor).coerceIn(0f, 1f),
        green = (this.green * factor).coerceIn(0f, 1f),
        blue = (this.blue * factor).coerceIn(0f, 1f),
        alpha = this.alpha
    )
}
