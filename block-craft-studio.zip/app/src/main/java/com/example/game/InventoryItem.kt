package com.example.game

enum class ItemType {
    BLOCK,
    TOOL,
    RESOURCE,
    FOOD
}

data class InventoryItem(
    val id: String,
    val type: ItemType,
    val displayName: String,
    val blockType: BlockType? = null,
    val toolType: ToolType = ToolType.NONE,
    val toolMaterial: ToolMaterial = ToolMaterial.HAND,
    val maxStack: Int = 64,
    val foodHealHunger: Int = 0,
    val foodHealHealth: Int = 0,
    var count: Int = 1,
    val iconColor: Long = 0xFFFFFFFF
) {
    val isTool: Boolean get() = type == ItemType.TOOL

    fun copyOf(cnt: Int = count): InventoryItem {
        return this.copy(count = cnt)
    }

    companion object {
        // Handy builders for all standard game items
        fun block(blockType: BlockType, count: Int = 1): InventoryItem {
            return InventoryItem(
                id = "block_${blockType.name.lowercase()}",
                type = ItemType.BLOCK,
                displayName = blockType.displayName,
                blockType = blockType,
                count = count,
                iconColor = blockType.colorTop
            )
        }

        fun resource(id: String, displayName: String, color: Long): InventoryItem {
            return InventoryItem(
                id = id,
                type = ItemType.RESOURCE,
                displayName = displayName,
                iconColor = color
            )
        }

        fun food(id: String, displayName: String, healHunger: Int, healHealth: Int, color: Long): InventoryItem {
            return InventoryItem(
                id = id,
                type = ItemType.FOOD,
                displayName = displayName,
                foodHealHunger = healHunger,
                foodHealHealth = healHealth,
                iconColor = color
            )
        }

        fun tool(id: String, displayName: String, tType: ToolType, mat: ToolMaterial, color: Long): InventoryItem {
            return InventoryItem(
                id = id,
                type = ItemType.TOOL,
                displayName = displayName,
                toolType = tType,
                toolMaterial = mat,
                maxStack = 1,
                iconColor = color
            )
        }

        // Standard objects representing items
        val STICK = resource("stick", "Wood Stick", 0xFF8D6E63)
        val COAL = resource("coal", "Coal Nugget", 0xFF333333)
        val IRON_INGOT = resource("iron_ingot", "Iron Ingot", 0xFFE0E0E0)
        val DIAMOND = resource("diamond", "Flawless Diamond", 0xFF00E5FF)
        val APPLE = food("apple", "Red Apple", healHunger = 4, healHealth = 2, color = 0xFFF44336)
        val MEAT = food("meat", "Cooked Steak", healHunger = 8, healHealth = 6, color = 0xFF8D6E63)
        val ROTTEN_FLESH = food("rotten_flesh", "Rotten Flesh", healHunger = 2, healHealth = -2, color = 0xFF4E342E)

        // Tools
        val WOOD_PICKAXE = tool("wood_pickaxe", "Wooden Pickaxe", ToolType.PICKAXE, ToolMaterial.WOOD, 0xFF8D6E63)
        val STONE_PICKAXE = tool("stone_pickaxe", "Stone Pickaxe", ToolType.PICKAXE, ToolMaterial.STONE, 0xFF757575)
        val IRON_PICKAXE = tool("iron_pickaxe", "Iron Pickaxe", ToolType.PICKAXE, ToolMaterial.IRON, 0xFFE0E0E0)
        val DIAMOND_PICKAXE = tool("diamond_pickaxe", "Diamond Pickaxe", ToolType.PICKAXE, ToolMaterial.DIAMOND, 0xFF00E5FF)

        val WOOD_AXE = tool("wood_axe", "Wooden Hatchet", ToolType.AXE, ToolMaterial.WOOD, 0xFF8D6E63)
        val STONE_AXE = tool("stone_axe", "Stone Axe", ToolType.AXE, ToolMaterial.STONE, 0xFF757575)
        val IRON_AXE = tool("iron_axe", "Iron Cleaver", ToolType.AXE, ToolMaterial.IRON, 0xFFE0E0E0)
        val DIAMOND_AXE = tool("diamond_axe", "Diamond Battleaxe", ToolType.AXE, ToolMaterial.DIAMOND, 0xFF00E5FF)

        val WOOD_SWORD = tool("wood_sword", "Wooden Training Sword", ToolType.SWORD, ToolMaterial.WOOD, 0xFF8D6E63)
        val STONE_SWORD = tool("stone_sword", "Stone Dagger", ToolType.SWORD, ToolMaterial.STONE, 0xFF757575)
        val IRON_SWORD = tool("iron_sword", "Iron Broadsword", ToolType.SWORD, ToolMaterial.IRON, 0xFFE0E0E0)
        val DIAMOND_SWORD = tool("diamond_sword", "Diamond Claymore", ToolType.SWORD, ToolMaterial.DIAMOND, 0xFF00E5FF)

        // Hotbar Defaults
        val DEFAULT_HOTBAR = listOf(
            block(BlockType.GRASS, 64),
            block(BlockType.WOOD_LOG, 32),
            block(BlockType.STONE, 32),
            block(BlockType.TORCH, 16),
            WOOD_PICKAXE,
            WOOD_SWORD,
            APPLE.copyOf(5),
            block(BlockType.CRAFTING_TABLE, 2),
            block(BlockType.CHEST, 2)
        )
    }
}
