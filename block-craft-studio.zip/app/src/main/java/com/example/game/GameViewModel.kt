package com.example.game

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val worldManager = WorldManager(application)

    // UI Navigation State
    private val _activeScreen = MutableStateFlow("main_menu")
    val activeScreen: StateFlow<String> = _activeScreen.asStateFlow()

    // Saved Worlds
    private val _savedWorlds = MutableStateFlow<List<WorldMetadata>>(emptyList())
    val savedWorlds: StateFlow<List<WorldMetadata>> = _savedWorlds.asStateFlow()

    // Active World Parameters
    var activeWorldId: String = ""
    private val _activeWorldName = MutableStateFlow("New World")
    val activeWorldName: StateFlow<String> = _activeWorldName.asStateFlow()

    private val _gameMode = MutableStateFlow("survival") // survival or creative
    val gameMode: StateFlow<String> = _gameMode.asStateFlow()

    var worldSeed: Long = 12345L

    // 3D Block State Store
    private val _blocks = MutableStateFlow<Map<String, BlockType>>(emptyMap())
    val blocks: StateFlow<Map<String, BlockType>> = _blocks.asStateFlow()

    // Player State
    private val _playerX = MutableStateFlow(16.0f)
    val playerX: StateFlow<Float> = _playerX.asStateFlow()

    private val _playerY = MutableStateFlow(16.0f)
    val playerY: StateFlow<Float> = _playerY.asStateFlow()

    private val _playerZ = MutableStateFlow(6.0f)
    val playerZ: StateFlow<Float> = _playerZ.asStateFlow()

    private val _playerHealth = MutableStateFlow(20.0f) // 20.0 = 10 hearts
    val playerHealth: StateFlow<Float> = _playerHealth.asStateFlow()

    private val _playerHunger = MutableStateFlow(20.0f) // 20.0 = 10 chicken legs
    val playerHunger: StateFlow<Float> = _playerHunger.asStateFlow()

    private val _playerDirX = MutableStateFlow(1.0f)
    val playerDirX: StateFlow<Float> = _playerDirX.asStateFlow()

    private val _playerDirY = MutableStateFlow(0.0f)
    val playerDirY: StateFlow<Float> = _playerDirY.asStateFlow()

    // Inventories
    private val _hotbar = MutableStateFlow<List<InventoryItem>>(emptyList())
    val hotbar: StateFlow<List<InventoryItem>> = _hotbar.asStateFlow()

    private val _inventory = MutableStateFlow<List<InventoryItem>>(emptyList())
    val inventory: StateFlow<List<InventoryItem>> = _inventory.asStateFlow()

    private val _selectedHotbarIndex = MutableStateFlow(0)
    val selectedHotbarIndex: StateFlow<Int> = _selectedHotbarIndex.asStateFlow()

    // Chest Inventory (for chest interaction)
    private val _chestInventory = MutableStateFlow<List<InventoryItem>>(emptyList())
    val chestInventory: StateFlow<List<InventoryItem>> = _chestInventory.asStateFlow()
    var activeChestCoord: String? = null

    // Environment & Sun
    private val _worldTime = MutableStateFlow(6000L) // 0 to 24000 (0 = morning, 6000 = noon, 12000 = dusk, 18000 = midnight)
    val worldTime: StateFlow<Long> = _worldTime.asStateFlow()

    // Viewport Camera offsets (for dragging & rotating)
    private val _cameraOffsetX = MutableStateFlow(0f)
    val cameraOffsetX: StateFlow<Float> = _cameraOffsetX.asStateFlow()

    private val _cameraOffsetY = MutableStateFlow(0f)
    val cameraOffsetY: StateFlow<Float> = _cameraOffsetY.asStateFlow()

    private val _cameraZoom = MutableStateFlow(1.0f) // Zoom multiplier
    val cameraZoom: StateFlow<Float> = _cameraZoom.asStateFlow()

    private val _cameraRotation = MutableStateFlow(0) // 0, 90, 180, 270 degrees
    val cameraRotation: StateFlow<Int> = _cameraRotation.asStateFlow()

    private val _currentHeightSlice = MutableStateFlow(10) // Max render height (allows slicing down)
    val currentHeightSlice: StateFlow<Int> = _currentHeightSlice.asStateFlow()

    // Tool Mode: MINE, BUILD
    private val _activeToolMode = MutableStateFlow(ToolMode.MINE)
    val activeToolMode: StateFlow<ToolMode> = _activeToolMode.asStateFlow()

    // Transient list for mobs and visual effect arrays (not in StateFlow to avoid 60fps gc overhead)
    val activeMobs = mutableListOf<GameMob>()
    val activeParticles = mutableListOf<Particle>()
    val floatingTexts = mutableListOf<FloatingText>()

    // Block mining progress (x,y,z coordinate -> progress 0f..1.0f)
    var miningTarget: String? = null
    var miningProgress = 0f

    // Selected block to place
    private val _selectedPlacingBlock = MutableStateFlow(BlockType.WOOD_PLANKS)
    val selectedPlacingBlock: StateFlow<BlockType> = _selectedPlacingBlock.asStateFlow()

    // Game ticks control job
    private var gameLoopJob: Job? = null

    // Target position for tap-to-move
    var moveTargetX: Float? = null
    var moveTargetY: Float? = null

    init {
        refreshSavedWorlds()
    }

    enum class ToolMode {
        MINE,
        BUILD
    }

    fun setToolMode(mode: ToolMode) {
        _activeToolMode.value = mode
    }

    fun setSelectedPlacingBlock(block: BlockType) {
        _selectedPlacingBlock.value = block
    }

    fun rotateCameraRight() {
        _cameraRotation.value = (_cameraRotation.value + 90) % 360
    }

    fun setCameraOffset(dx: Float, dy: Float) {
        _cameraOffsetX.value += dx
        _cameraOffsetY.value += dy
    }

    fun setCameraZoom(factor: Float) {
        _cameraZoom.value = (_cameraZoom.value * factor).coerceIn(0.5f, 2.5f)
    }

    fun setHeightSlice(slice: Int) {
        _currentHeightSlice.value = slice.coerceIn(1, 10)
    }

    fun resetCamera() {
        _cameraOffsetX.value = 0f
        _cameraOffsetY.value = 0f
        _cameraZoom.value = 1.0f
    }

    fun refreshSavedWorlds() {
        _savedWorlds.value = worldManager.listWorlds()
    }

    fun startNewWorld(name: String, seed: Long, isCreative: Boolean) {
        activeWorldId = UUID.randomUUID().toString()
        _activeWorldName.value = name
        worldSeed = seed
        _gameMode.value = if (isCreative) "creative" else "survival"

        // Generate Terrain
        generateTerrain(seed, isCreative)

        // Setup player
        setupInitialPlayer(isCreative)

        // Clear state
        activeMobs.clear()
        activeParticles.clear()
        floatingTexts.clear()
        miningTarget = null
        miningProgress = 0f
        _activeScreen.value = "gameplay"

        // Start gameplay ticking
        startTicks()
        autoSaveWorld()
    }

    fun loadSavedWorld(meta: WorldMetadata) {
        val loaded = worldManager.loadWorld(meta.id)
        if (loaded != null) {
            activeWorldId = loaded.metadata.id
            _activeWorldName.value = loaded.metadata.name
            worldSeed = loaded.metadata.seed
            _gameMode.value = loaded.metadata.gameMode
            
            _blocks.value = loaded.blocks
            _hotbar.value = loaded.inventory.take(9)
            // pad hotbar
            if (_hotbar.value.size < 9) {
                val list = _hotbar.value.toMutableList()
                while (list.size < 9) {
                    list.add(InventoryItem.block(BlockType.AIR, 0))
                }
                _hotbar.value = list
            }
            _inventory.value = loaded.inventory.drop(9)

            _playerX.value = loaded.playerX
            _playerY.value = loaded.playerY
            _playerZ.value = loaded.playerZ
            _playerHealth.value = loaded.playerHealth
            _playerHunger.value = loaded.playerHunger
            _worldTime.value = loaded.worldTime

            activeMobs.clear()
            activeParticles.clear()
            floatingTexts.clear()
            miningTarget = null
            miningProgress = 0f
            _activeScreen.value = "gameplay"

            startTicks()
        }
    }

    fun deleteSavedWorld(id: String) {
        worldManager.deleteWorld(id)
        refreshSavedWorlds()
    }

    fun setupInitialPlayer(isCreative: Boolean) {
        _playerX.value = 16f
        _playerY.value = 16f
        
        // Find safe Z height at (16,16)
        val testZ = getSurfaceZ(16, 16)
        _playerZ.value = testZ + 1.0f
        
        _playerHealth.value = 20.0f
        _playerHunger.value = 20.0f
        _worldTime.value = 6000L // start at high noon

        if (isCreative) {
            // Hotbar with all block types
            val creativeHotbar = mutableListOf<InventoryItem>()
            val blocksToInclude = BlockType.values().filter { it != BlockType.AIR && it != BlockType.WATER }
            for (i in 0 until minOf(9, blocksToInclude.size)) {
                creativeHotbar.add(InventoryItem.block(blocksToInclude[i], 999))
            }
            _hotbar.value = creativeHotbar

            // Remaining blocks / items
            val creativeInv = mutableListOf<InventoryItem>()
            for (i in 9 until blocksToInclude.size) {
                creativeInv.add(InventoryItem.block(blocksToInclude[i], 999))
            }
            // Add tools & materials to inventory
            creativeInv.add(InventoryItem.DIAMOND_SWORD)
            creativeInv.add(InventoryItem.DIAMOND_PICKAXE)
            creativeInv.add(InventoryItem.DIAMOND_AXE)
            creativeInv.add(InventoryItem.APPLE.copyOf(999))
            creativeInv.add(InventoryItem.MEAT.copyOf(999))
            creativeInv.add(InventoryItem.DIAMOND.copyOf(999))
            _inventory.value = creativeInv
        } else {
            // Survival Inventory defaults
            _hotbar.value = InventoryItem.DEFAULT_HOTBAR.toMutableList()
            _inventory.value = mutableListOf(
                InventoryItem.STICK.copyOf(12),
                InventoryItem.APPLE.copyOf(3),
                InventoryItem.resource("iron_ingot", "Iron Ingot", 0xFFE0E0E0).copyOf(2)
            )
        }
    }

    fun generateTerrain(seed: Long, isCreative: Boolean) {
        val landscape = mutableMapOf<String, BlockType>()
        // Build 32 x 32 procedural map
        for (x in 0..31) {
            for (y in 0..31) {
                // Bedrock base layer
                landscape["$x,$y,0"] = BlockType.BEDROCK

                // Multi-octave smooth height cosine waves
                val w1 = Math.cos(x * 0.12 + seed * 0.05) * Math.sin(y * 0.12 + seed * 0.03) * 2.8
                val w2 = Math.cos(x * 0.5 - y * 0.4) * 0.6
                val base = 4.2f
                val h = (base + w1 + w2).toInt().coerceIn(1, 9)

                for (z in 1..9) {
                    when {
                        z < h - 2 -> {
                            // Depth is Stone, with random chances of Coal, Iron, or Diamond
                            val r = Math.random()
                            val rollBlock = when {
                                z <= 2 && r < 0.02 -> BlockType.DIAMOND_ORE
                                z <= 5 && r < 0.06 -> BlockType.IRON_ORE
                                z <= 7 && r < 0.12 -> BlockType.COAL_ORE
                                else -> BlockType.STONE
                            }
                            landscape["$x,$y,$z"] = rollBlock
                        }
                        z < h -> {
                            // Middle layers is Dirt
                            landscape["$x,$y,$z"] = BlockType.DIRT
                        }
                        z == h -> {
                            // Surface layer
                            if (h <= 3) {
                                // Low ground behaves as sand beaches Near water
                                landscape["$x,$y,$z"] = BlockType.SAND
                            } else {
                                landscape["$x,$y,$z"] = BlockType.GRASS
                            }
                        }
                        z > h -> {
                            // Air or Water
                            if (z <= 3) {
                                landscape["$x,$y,$z"] = BlockType.WATER
                            } else {
                                // Don't explicitly write air to save space
                            }
                        }
                    }
                }

                // Trees procedural spawn
                if (h > 3 && landscape["$x,$y,$h"] == BlockType.GRASS && Math.random() < 0.04) {
                    val th = (3..5).random()
                    // Trunk
                    for (tz in 1..th) {
                        landscape["$x,$y,${h + tz}"] = BlockType.WOOD_LOG
                    }
                    // Leaves Canopy
                    val topZ = h + th
                    for (lx in -2..2) {
                        for (ly in -2..2) {
                            for (lz in -1..1) {
                                val leafX = x + lx
                                val leafY = y + ly
                                val leafZ = topZ + lz
                                if (leafX in 0..31 && leafY in 0..31) {
                                    val dist = lx * lx + ly * ly + lz * lz
                                    if (dist <= 4 && landscape["$leafX,$leafY,$leafZ"] == null) {
                                        landscape["$leafX,$leafY,$leafZ"] = BlockType.LEAVES
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        _blocks.value = landscape
    }

    private fun getSurfaceZ(x: Int, y: Int): Int {
        for (z in 9 downTo 0) {
            val block = getBlockAt(x, y, z)
            if (block.isSolid) {
                return z
            }
        }
        return 0
    }

    fun getBlockAt(x: Int, y: Int, z: Int): BlockType {
        if (x !in 0..31 || y !in 0..31 || z !in 0..9) return BlockType.AIR
        return _blocks.value["$x,$y,$z"] ?: BlockType.AIR
    }

    private fun setBlockAt(x: Int, y: Int, z: Int, type: BlockType) {
        if (x !in 0..31 || y !in 0..31 || z !in 0..9) return
        val current = _blocks.value.toMutableMap()
        if (type == BlockType.AIR) {
            current.remove("$x,$y,$z")
        } else {
            current["$x,$y,$z"] = type
        }
        _blocks.value = current
    }

    // Hotbar/Inventory Slot selection
    fun selectHotbarIndex(index: Int) {
        _selectedHotbarIndex.value = index.coerceIn(0, 8)
        val selectedItem = _hotbar.value.getOrNull(index)
        if (selectedItem != null && selectedItem.type == ItemType.BLOCK && selectedItem.blockType != null) {
            setSelectedPlacingBlock(selectedItem.blockType)
        }
    }

    fun eatSelectedItem() {
        val index = _selectedHotbarIndex.value
        val items = _hotbar.value.toMutableList()
        val item = items.getOrNull(index) ?: return

        if (item.type == ItemType.FOOD) {
            // Restore Hunger and Health
            _playerHunger.value = (_playerHunger.value + item.foodHealHunger).coerceAtMost(20.0f)
            _playerHealth.value = (_playerHealth.value + item.foodHealHealth).coerceAtMost(20.0f)

            // Sparkle Particle animations
            createPlayerSparkles(0xFF4CAF50) // Green healing sparkles
            addFloatingText("Nutritious!", _playerX.value, _playerY.value, _playerZ.value + 1f, 0xFFE0E0E0)

            item.count--
            if (item.count <= 0) {
                items[index] = InventoryItem.block(BlockType.AIR, 0)
            } else {
                items[index] = item
            }
            _hotbar.value = items
        }
    }

    fun navigateTo(screen: String) {
        _activeScreen.value = screen
        if (screen == "main_menu") {
            stopTicks()
            refreshSavedWorlds()
        }
    }

    // GAMEPLAY TICK ENGINE
    fun startTicks() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            var autosaveCounter = 0
            while (true) {
                delay(50) // 20 ticks per second (50ms per tick)
                if (_activeScreen.value == "gameplay") {
                    gameTick()
                    autosaveCounter++
                    if (autosaveCounter >= 400) { // Every 20 seconds
                        autosaveCounter = 0
                        autoSaveWorld()
                    }
                }
            }
        }
    }

    fun stopTicks() {
        gameLoopJob?.cancel()
        gameLoopJob = null
    }

    private fun autoSaveWorld() {
        if (activeWorldId.isNotEmpty()) {
            val allInv = _hotbar.value + _inventory.value
            worldManager.saveWorld(
                id = activeWorldId,
                name = _activeWorldName.value,
                seed = worldSeed,
                gameMode = _gameMode.value,
                blocks = _blocks.value,
                inventory = allInv,
                px = _playerX.value,
                py = _playerY.value,
                pz = _playerZ.value,
                pHealth = _playerHealth.value,
                pHunger = _playerHunger.value,
                time = _worldTime.value
            )
        }
    }

    private var survivalHungerCounter = 0
    private fun gameTick() {
        // 1. Time cycle
        _worldTime.value = (_worldTime.value + 400) % 24000L // 2.5 minutes a full day

        val isSurvival = _gameMode.value == "survival"

        // 2. Hunger and health updates (survival only)
        if (isSurvival && _playerHealth.value > 0) {
            survivalHungerCounter++
            if (survivalHungerCounter >= 100) { // every 5 seconds
                survivalHungerCounter = 0

                // Hunger decay
                val currH = _playerHunger.value
                if (currH > 0f) {
                    _playerHunger.value = (currH - 0.2f).coerceAtLeast(0f)
                }

                // Health regenerates if hunger is nearly full (>= 18)
                if (_playerHunger.value >= 18f && _playerHealth.value < 20f) {
                    _playerHealth.value = (_playerHealth.value + 1.0f).coerceAtMost(20.0f)
                    createPlayerSparkles(0xFFF44336) // Red hearts sparkle
                }

                // If starving (hunger is 0), lose health
                if (_playerHunger.value <= 1.0f) {
                    damagePlayer(1.0f, "Starvation")
                }
            }
        }

        // 3. Automated walking pathing
        updateMoveDestination()

        // 4. Update dynamic Mobs
        updateMobsLogic(isSurvival)

        // 5. Update dynamic particle vectors and floating displays
        updateParticlesLogic()
    }

    fun initiateWalkTo(tx: Float, ty: Float) {
        moveTargetX = tx
        moveTargetY = ty
    }

    private fun updateMoveDestination() {
        val tx = moveTargetX ?: return
        val ty = moveTargetY ?: return

        val px = _playerX.value
        val py = _playerY.value

        val dx = tx - px
        val dy = ty - py
        val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()

        if (dist < 0.2f) {
            moveTargetX = null
            moveTargetY = null
            return
        }

        // Walk vector
        val step = 0.15f
        val walkX = (dx / dist) * step
        val walkY = (dy / dist) * step

        var nextX = px + walkX
        var nextY = py + walkY

        // Collision logic & Gravity
        val currZ = _playerZ.value
        val blockAtNext = getBlockAt(nextX.toInt(), nextY.toInt(), currZ.toInt())
        val blockBelow = getBlockAt(nextX.toInt(), nextY.toInt(), (currZ - 1f).toInt())

        // Can we make this step safely?
        if (blockAtNext.isSolid) {
            // Block is blocking. Can we jump over it?
            val blockAboveNext = getBlockAt(nextX.toInt(), nextY.toInt(), (currZ + 1f).toInt())
            if (!blockAboveNext.isSolid) {
                // Auto jump up!
                _playerZ.value += 1.0f
                nextX = px + walkX
                nextY = py + walkY
            } else {
                // block ahead is a tall wall, cancel walk pathing
                moveTargetX = null
                moveTargetY = null
                return
            }
        } else if (!blockBelow.isSolid && currZ > 1) {
            // Drop down step (Respecting gravity!)
            var dropTargetZ = currZ
            while (dropTargetZ > 1 && !getBlockAt(nextX.toInt(), nextY.toInt(), (dropTargetZ - 1f).toInt()).isSolid) {
                dropTargetZ -= 1.0f
            }
            if (currZ - dropTargetZ > 3f && _gameMode.value == "survival") {
                // Fall damage!
                damagePlayer((currZ - dropTargetZ - 2f) * 2f, "Impact")
            }
            _playerZ.value = dropTargetZ
        }

        // Apply new coordinates
        _playerX.value = nextX.coerceIn(0.5f, 31.5f)
        _playerY.value = nextY.coerceIn(0.5f, 31.5f)

        // Rotate facing direction towards destination
        if (Math.abs(walkX) > 0.01f || Math.abs(walkY) > 0.01f) {
            val len = Math.hypot(walkX.toDouble(), walkY.toDouble()).toFloat()
            _playerDirX.value = walkX / len
            _playerDirY.value = walkY / len
        }
    }

    fun damagePlayer(amount: Float, source: String) {
        if (_gameMode.value == "creative" || _playerHealth.value <= 0) return

        _playerHealth.value = (_playerHealth.value - amount).coerceAtLeast(0f)
        createPlayerSparkles(0xFF000000) // puff particles

        addFloatingText("-$amount HP ($source)", _playerX.value, _playerY.value, _playerZ.value + 1.2f, 0xFFF44336)

        if (_playerHealth.value <= 0) {
            _activeScreen.value = "death_screen"
        }
    }

    fun respawnPlayer() {
        _playerHealth.value = 20.0f
        _playerHunger.value = 20.0f
        setupInitialPlayer(_gameMode.value == "creative")
        _activeScreen.value = "gameplay"
    }

    private fun updateMobsLogic(isSurvival: Boolean) {
        val px = _playerX.value
        val py = _playerY.value
        val pz = _playerZ.value

        // Mob Spawning Mechanics (Night vs Day)
        val timeOfMap = _worldTime.value
        val isNight = timeOfMap in 13000..23000

        if (activeMobs.size < 12 && Math.random() < 0.04) {
            // Randomly spawn mob around player
            val range = 12
            val rx = (px.toInt() + (-range..range).random()).coerceIn(0, 31)
            val ry = (py.toInt() + (-range..range).random()).coerceIn(0, 31)
            val rz = getSurfaceZ(rx, ry)

            if (Math.hypot((rx - px).toDouble(), (ry - py).toDouble()) > 4.0) {
                val mobType = if (isNight) {
                    if (Math.random() < 0.4) MobType.CREEPER else MobType.ZOMBIE
                } else {
                    if (Math.random() < 0.5) MobType.COW else MobType.SHEEP
                }
                activeMobs.add(GameMob(type = mobType, x = rx.toFloat(), y = ry.toFloat(), z = rz + 1.0f))
            }
        }

        // De-spawn distant passive/hostile mobs
        activeMobs.removeAll {
            val dist = Math.hypot((it.x - px).toDouble(), (it.y - py).toDouble())
            dist > 25.0
        }

        // Update each Active Mob
        val removals = mutableListOf<GameMob>()
        for (mob in activeMobs) {
            if (mob.isHurtTick > 0) mob.isHurtTick--

            mob.walkCycle = (mob.walkCycle + 0.15f) % (2f * Math.PI.toFloat())

            val distToP = Math.hypot((mob.x - px).toDouble(), (mob.y - py).toDouble()).toFloat()

            if (mob.type.isHostile && isSurvival && _playerHealth.value > 0) {
                // Hunt!
                if (distToP < 12.0f) {
                    val dx = px - mob.x
                    val dy = py - mob.y
                    mob.dirX = dx / distToP
                    mob.dirY = dy / distToP

                    // Move step
                    val mx = mob.x + mob.dirX * mob.type.speed
                    val my = mob.y + mob.dirY * mob.type.speed

                    // Basic step-climb & fall collision
                    val mSurface = getSurfaceZ(mx.toInt(), my.toInt()).toFloat()
                    if (Math.abs(mSurface - (mob.z - 1.0f)) <= 1.5f) {
                        mob.x = mx
                        mob.y = my
                        mob.z = mSurface + 1.0f
                    }

                    // Attacking Logic
                    if (distToP <= 1f) {
                        if (mob.type == MobType.CREEPER) {
                            // Fuse ignites
                            if (mob.explosionFuse == -1) {
                                mob.explosionFuse = 20 // 1 second countdown
                                addFloatingText("TSSH!", mob.x, mob.y, mob.z + 1.2f, 0xFFFF0000)
                            } else {
                                mob.explosionFuse--
                                if (mob.explosionFuse <= 0) {
                                    // EXPLODE!
                                    executeCreeperExplosion(mob)
                                    removals.add(mob)
                                }
                            }
                        } else {
                            // Zombie damage tick
                            if (Math.random() < 0.1) {
                                damagePlayer(2.0f, "Zombie Attack")
                            }
                        }
                    } else {
                        // Reset fuse if player runs away
                        if (mob.type == MobType.CREEPER && mob.explosionFuse != -1) {
                            mob.explosionFuse = -1
                        }
                    }
                } else {
                    // Hostile wanders
                    mobWander(mob)
                }
            } else {
                // Peaceful wanders
                mobWander(mob)
            }
        }
        activeMobs.removeAll(removals)
    }

    private fun mobWander(mob: GameMob) {
        if (Math.random() < 0.05) {
            // Select new random direction
            val angle = Math.random() * 2 * Math.PI
            mob.dirX = Math.cos(angle).toFloat()
            mob.dirY = Math.sin(angle).toFloat()
        }

        val mx = (mob.x + mob.dirX * 0.02f).coerceIn(0.5f, 31.5f)
        val my = (mob.y + mob.dirY * 0.02f).coerceIn(0.5f, 31.5f)
        val mSurface = getSurfaceZ(mx.toInt(), my.toInt()).toFloat()

        if (Math.abs(mSurface - (mob.z - 1.0f)) <= 1.0f) {
            mob.x = mx
            mob.y = my
            mob.z = mSurface + 1.0f
        }
    }

    private fun executeCreeperExplosion(creeper: GameMob) {
        val cx = creeper.x.toInt()
        val cy = creeper.y.toInt()
        val cz = creeper.z.toInt()

        // Create heavy smoke & fire particulate splatters
        for (i in 0..40) {
            val vx = (Math.random() - 0.5f).toFloat() * 1.2f
            val vy = (Math.random() - 0.5f).toFloat() * 1.2f
            val vz = (Math.random() - 0.5f).toFloat() * 1.2f
            activeParticles.add(
                Particle(
                    creeper.x, creeper.y, creeper.z,
                    vx, vy, vz,
                    color = if (Math.random() < 0.4) 0xFFFF9800 else 0xFF424242,
                    life = (20..35).random(),
                    maxLife = 35
                )
            )
        }

        // Damage blocks in a 3-block sphere
        val rLimit = 3
        val updated = _blocks.value.toMutableMap()
        for (dx in -rLimit..rLimit) {
            for (dy in -rLimit..rLimit) {
                for (dz in -rLimit..rLimit) {
                    val bx = cx + dx
                    val by = cy + dy
                    val bz = cz + dz
                    if (bx in 0..31 && by in 0..31 && bz in 0..9) {
                        val distance = Math.sqrt((dx*dx + dy*dy + dz*dz).toDouble()).toFloat()
                        if (distance <= rLimit) {
                            val current = updated["$bx,$by,$bz"]
                            if (current != null && current != BlockType.BEDROCK) {
                                updated.remove("$bx,$by,$bz")
                            }
                        }
                    }
                }
            }
        }
        _blocks.value = updated

        // Damage Player if within range
        val pDist = Math.hypot((creeper.x - _playerX.value).toDouble(), (creeper.y - _playerY.value).toDouble()).toFloat()
        if (pDist <= 4.0f) {
            val rawDamage = (4.0f - pDist) * 6f
            damagePlayer(rawDamage.coerceAtLeast(1.0f), "Creeper Detonation")
        }
    }

    private fun updateParticlesLogic() {
        // Particles move and age
        val pIter = activeParticles.iterator()
        while (pIter.hasNext()) {
            val p = pIter.next()
            p.x += p.vx
            p.y += p.vy
            p.z += p.vz
            p.vy -= 0.02f // Simple gravity
            p.life--
            if (p.life <= 0) pIter.remove()
        }

        // Floating texts raise and age
        val tIter = floatingTexts.iterator()
        while (tIter.hasNext()) {
            val t = tIter.next()
            t.z += 0.03f
            t.life--
            if (t.life <= 0) tIter.remove()
        }
    }

    // HIT AND MINING CONTROL ACTIONS
    fun handleBlockInteraction(coord: String, isHoldPressState: Boolean) {
        val parts = coord.split(",")
        if (parts.size != 3) return
        val x = parts[0].toInt()
        val y = parts[1].toInt()
        val z = parts[2].toInt()

        val actualBlock = getBlockAt(x, y, z)
        if (actualBlock == BlockType.AIR) return

        if (_activeToolMode.value == ToolMode.MINE) {
            // Trigger breakage
            if (_gameMode.value == "creative") {
                mineBlockComplete(x, y, z, actualBlock)
            } else {
                // Survival: requires timing
                if (miningTarget != coord) {
                    miningTarget = coord
                    miningProgress = 0f
                }
                
                // Determine tool speed modifier
                val equipped = getEquippedItem()
                val speedMod = getMiningSpeedMultiplier(actualBlock, equipped)
                miningProgress += 0.15f * speedMod

                // Debris sparks!
                spawnMiningSparkParticles(x.toFloat(), y.toFloat(), z.toFloat(), actualBlock)

                if (miningProgress >= 1.0f) {
                    mineBlockComplete(x, y, z, actualBlock)
                    miningTarget = null
                    miningProgress = 0f
                }
            }
        } else {
            // BUILD Mode clicked. Trigger interactive screens or simple place mechanics if face selected.
            // When user taps on simple block in build mode, we open containers (chest, crafting table)
            if (actualBlock == BlockType.CRAFTING_TABLE) {
                navigateTo("crafting")
            } else if (actualBlock == BlockType.CHEST) {
                activeChestCoord = coord
                setupChestForInteraction(coord)
                navigateTo("chest")
            }
        }
    }

    // Build block on a specific face of double coordinates
    fun buildBlockOnFace(coord: String, face: String) {
        val parts = coord.split(",")
        if (parts.size != 3) return
        var x = parts[0].toInt()
        var y = parts[1].toInt()
        var z = parts[2].toInt()

        // Apply normal offset depending on coordinate face clicked
        when (face) {
            "top" -> z += 1
            "left" -> x -= 1
            "right" -> y += 1
            "bottom" -> z -= 1
            "front_left" -> x += 1 // adjustments depending on perspective
            "front_right" -> y -= 1
        }

        // Boundaries checks
        if (x !in 0..31 || y !in 0..31 || z !in 0..9) return

        val targetBlock = getBlockAt(x, y, z)
        if (targetBlock != BlockType.AIR && targetBlock != BlockType.WATER) return

        // Player Collision Checks: don't build inside player!
        val px = _playerX.value.toInt()
        val py = _playerY.value.toInt()
        val pz = _playerZ.value.toInt()
        if (x == px && y == py && (z == pz || z == pz + 1)) {
            addFloatingText("Cannot place inside self", x.toFloat(), y.toFloat(), z.toFloat() + 1.2f, 0xFFFF0000)
            return
        }

        // Get placed block type
        val currentPlacing = _selectedPlacingBlock.value
        if (currentPlacing == BlockType.AIR) return

        // Consume block from Survival Inventory
        if (_gameMode.value == "survival") {
            val hasConsumed = consumeItemFromHotbar(currentPlacing)
            if (!hasConsumed) {
                addFloatingText("Out of Blocks!", x.toFloat(), y.toFloat(), z.toFloat() + 1.2f, 0xFFFF0000)
                return
            }
        }

        // Set Block
        setBlockAt(x, y, z, currentPlacing)

        // Sparkle place particles
        for (i in 1..8) {
            val vx = (Math.random() - 0.5f).toFloat() * 0.3f
            val vy = (Math.random() - 0.5f).toFloat() * 0.3f
            val vz = Math.random().toFloat() * 0.4f
            activeParticles.add(
                Particle(
                    x + 0.5f, y + 0.5f, z + 0.5f,
                    vx, vy, vz,
                    color = 0xFFFFFFFF,
                    life = 12,
                    maxLife = 12
                )
            )
        }
    }

    private fun consumeItemFromHotbar(block: BlockType): Boolean {
        val index = _selectedHotbarIndex.value
        val hotList = _hotbar.value.toMutableList()
        val activeItem = hotList.getOrNull(index)

        if (activeItem != null && activeItem.blockType == block && activeItem.count > 0) {
            activeItem.count--
            if (activeItem.count <= 0) {
                hotList[index] = InventoryItem.block(BlockType.AIR, 0)
            } else {
                hotList[index] = activeItem
            }
            _hotbar.value = hotList
            return true
        }

        // Search other slots
        for (i in hotList.indices) {
            val item = hotList[i]
            if (item.blockType == block && item.count > 0) {
                item.count--
                if (item.count <= 0) {
                    hotList[i] = InventoryItem.block(BlockType.AIR, 0)
                } else {
                    hotList[i] = item
                }
                _hotbar.value = hotList
                return true
            }
        }
        return false
    }

    private fun mineBlockComplete(x: Int, y: Int, z: Int, type: BlockType) {
        // Set to air
        setBlockAt(x, y, z, BlockType.AIR)

        // Drop item in survival
        if (_gameMode.value == "survival") {
            val toolMat = getEquippedItem()?.toolMaterial ?: ToolMaterial.HAND
            val dropItem = type.getDrop(toolMat)

            if (dropItem != null) {
                // Grant item stack or resource
                val hotList = _hotbar.value.toMutableList()
                val invList = _inventory.value.toMutableList()
                var placed = false

                val fullInv = hotList + invList
                // Add apple randomly from Leaves breakage
                val finalizedItem = if (type == BlockType.LEAVES && Math.random() < 0.15) {
                    InventoryItem.APPLE.copyOf(1)
                } else if (type == BlockType.COAL_ORE) {
                    InventoryItem.COAL.copyOf(1)
                } else if (type == BlockType.DIAMOND_ORE) {
                    InventoryItem.DIAMOND.copyOf(1)
                } else {
                    InventoryItem.block(dropItem, 1)
                }

                // Try to stack in hotbar first
                for (item in hotList) {
                    if (item.id == finalizedItem.id && item.count < item.maxStack) {
                        item.count++
                        placed = true
                        _hotbar.value = hotList
                        break
                    }
                }

                if (!placed) {
                    // Stack in inventory
                    for (item in invList) {
                        if (item.id == finalizedItem.id && item.count < item.maxStack) {
                            item.count++
                            placed = true
                            _inventory.value = invList
                            break
                        }
                    }
                }

                if (!placed) {
                    // Find empty hotbar slot
                    for (i in hotList.indices) {
                        if (hotList[i].id == "block_air" || hotList[i].count <= 0) {
                            hotList[i] = finalizedItem
                            placed = true
                            _hotbar.value = hotList
                            break
                        }
                    }
                }

                if (!placed) {
                    // Put in main inventory
                    invList.add(finalizedItem)
                    _inventory.value = invList
                }

                addFloatingText("+1 ${finalizedItem.displayName}", x.toFloat(), y.toFloat(), z.toFloat() + 1.0f, 0xFFFFF9C4)
            }
        }

        // Heavy drop particles
        for (i in 1..15) {
            val vx = (Math.random() - 0.5f).toFloat() * 0.4f
            val vy = (Math.random() - 0.5f).toFloat() * 0.4f
            val vz = Math.random().toFloat() * 0.5f
            activeParticles.add(
                Particle(
                    x + 0.5f, y + 0.5f, z + 0.5f,
                    vx, vy, vz,
                    color = type.colorTop,
                    life = 15,
                    maxLife = 15
                )
            )
        }
    }

    private fun spawnMiningSparkParticles(x: Float, y: Float, z: Float, block: BlockType) {
        val count = 2
        for (i in 1..count) {
            val vx = (Math.random() - 0.5f).toFloat() * 0.15f
            val vy = (Math.random() - 0.5f).toFloat() * 0.15f
            val vz = Math.random().toFloat() * 0.2f
            activeParticles.add(
                Particle(
                    x + 0.5f, y + 0.5f, z + 0.8f,
                    vx, vy, vz,
                    color = block.colorTop,
                    life = 8,
                    maxLife = 8
                )
            )
        }
    }

    private fun getEquippedItem(): InventoryItem? {
        return _hotbar.value.getOrNull(_selectedHotbarIndex.value)
    }

    private fun getMiningSpeedMultiplier(block: BlockType, tool: InventoryItem?): Float {
        if (tool == null) return 1.0f

        val matchingTool = when (block.requiredTool) {
            ToolType.PICKAXE -> tool.toolType == ToolType.PICKAXE
            ToolType.AXE -> tool.toolType == ToolType.AXE
            ToolType.SHOVEL -> tool.toolType == ToolType.SHOVEL
            else -> true
        }

        if (!matchingTool) return 0.5f // very slow without right tool

        val matMultiplier = when (tool.toolMaterial) {
            ToolMaterial.HAND -> 1.0f
            ToolMaterial.WOOD -> 2.5f
            ToolMaterial.STONE -> 5.0f
            ToolMaterial.IRON -> 8.0f
            ToolMaterial.DIAMOND -> 14.0f
        }
        return matMultiplier
    }

    fun attackMob(mob: GameMob) {
        val px = _playerX.value
        val py = _playerY.value
        val pz = _playerZ.value

        val dist = Math.hypot((mob.x - px).toDouble(), (mob.y - py).toDouble()).toFloat()
        if (dist > 3.0f) {
            addFloatingText("Too far!", mob.x, mob.y, mob.z + 1f, 0xFFFFFFFF)
            return
        }

        // Deal damage based on tool
        val equipped = getEquippedItem()
        val dmg = when {
            equipped != null && equipped.toolType == ToolType.SWORD -> {
                when (equipped.toolMaterial) {
                    ToolMaterial.WOOD -> 4f
                    ToolMaterial.STONE -> 6f
                    ToolMaterial.IRON -> 8f
                    ToolMaterial.DIAMOND -> 12f
                    else -> 2f
                }
            }
            equipped != null && equipped.toolType == ToolType.PICKAXE -> 3f
            else -> 1f
        }

        mob.health -= dmg
        mob.isHurtTick = 5

        // Damage spark particles
        for (i in 1..10) {
            val vx = (Math.random() - 0.5f).toFloat() * 0.4f
            val vy = (Math.random() - 0.5f).toFloat() * 0.4f
            val vz = Math.random().toFloat() * 0.3f
            activeParticles.add(
                Particle(
                    mob.x, mob.y, mob.z + 0.5f,
                    vx, vy, vz,
                    color = 0xFFEF5350, // Crimson spark
                    life = 12,
                    maxLife = 12
                )
            )
        }

        // Knockback mob slightly
        mob.x -= mob.dirX * 0.5f
        mob.y -= mob.dirY * 0.5f

        addFloatingText("-$dmg HP", mob.x, mob.y, mob.z + 1.2f, 0xFFE53935)

        if (mob.health <= 0) {
            activeMobs.remove(mob)
            spawnMobDeathDrops(mob)
        }
    }

    private fun spawnMobDeathDrops(mob: GameMob) {
        val drop = when (mob.type) {
            MobType.COW -> InventoryItem.MEAT.copyOf((1..2).random())
            MobType.ZOMBIE -> InventoryItem.ROTTEN_FLESH.copyOf((1..2).random())
            MobType.CREEPER -> InventoryItem.COAL.copyOf((1..3).random()) // Creeper drops coal nugget
            MobType.SHEEP -> InventoryItem.block(BlockType.BRICK, (1..2).random()) // Sheep drops bricks (wool substitute)
        }

        // Add to player inventory
        val hotList = _hotbar.value.toMutableList()
        val invList = _inventory.value.toMutableList()
        var placed = false

        for (item in hotList) {
            if (item.id == drop.id && item.count < item.maxStack) {
                item.count += drop.count
                placed = true
                _hotbar.value = hotList
                break
            }
        }

        if (!placed) {
            for (item in invList) {
                if (item.id == drop.id && item.count < item.maxStack) {
                    item.count += drop.count
                    placed = true
                    _inventory.value = invList
                    break
                }
            }
        }

        if (!placed) {
            invList.add(drop)
            _inventory.value = invList
        }

        addFloatingText("+${drop.count} ${drop.displayName}", mob.x, mob.y, mob.z + 1.0f, 0xFFC5E1A5)
    }

    // CHEST MANAGEMENT SYSTEM
    private fun setupChestForInteraction(coord: String) {
        // Create random items or keep it empty
        if (_chestInventory.value.isEmpty()) {
            _chestInventory.value = listOf(
                InventoryItem.block(BlockType.GLASS, 12),
                InventoryItem.block(BlockType.BRICK, 14),
                InventoryItem.STICK.copyOf(8),
                InventoryItem.DIAMOND.copyOf(2)
            )
        }
    }

    fun transferItemChestToInventory(item: InventoryItem) {
        val chestList = _chestInventory.value.toMutableList()
        val invList = _inventory.value.toMutableList()

        if (item.count > 0) {
            chestList.remove(item)
            invList.add(item.copyOf())
            _chestInventory.value = chestList
            _inventory.value = invList
        }
    }

    fun transferItemInventoryToChest(item: InventoryItem) {
        val chestList = _chestInventory.value.toMutableList()
        val invList = _inventory.value.toMutableList()

        if (item.count > 0) {
            invList.remove(item)
            chestList.add(item.copyOf())
            _chestInventory.value = chestList
            _inventory.value = invList
        }
    }

    fun closeChest() {
        activeChestCoord = null
        navigateTo("gameplay")
    }

    // CRAFTING SYSTEM
    fun craftRecipe(recipe: CraftingRecipe) {
        val fullInv = (_hotbar.value + _inventory.value).filter { it.id != "block_air" }.toMutableList()
        val success = recipe.executeCraft(fullInv)
        if (success) {
            // Distribute updated inventory back to hotbar & main inventory
            val newHotbar = fullInv.take(9).toMutableList()
            while (newHotbar.size < 9) {
                newHotbar.add(InventoryItem.block(BlockType.AIR, 0))
            }
            _hotbar.value = newHotbar
            _inventory.value = fullInv.drop(9)

            createPlayerSparkles(0xFF4FC3F7) // Light blue magical craft sparkles
            addFloatingText("Crafted ${recipe.result.displayName}!", _playerX.value, _playerY.value, _playerZ.value + 1.2f, 0xFF4FC3F7)
        } else {
            addFloatingText("Missing materials!", _playerX.value, _playerY.value, _playerZ.value + 1.2f, 0xFFE53935)
        }
    }

    private fun createPlayerSparkles(color: Long) {
        val px = _playerX.value
        val py = _playerY.value
        val pz = _playerZ.value
        for (i in 1..12) {
            val vx = (Math.random() - 0.5f).toFloat() * 0.2f
            val vy = (Math.random() - 0.5f).toFloat() * 0.2f
            val vz = 0.15f + Math.random().toFloat() * 0.25f
            activeParticles.add(
                Particle(
                    px, py, pz + 0.5f,
                    vx, vy, vz,
                    color = color,
                    life = 15,
                    maxLife = 15
                )
            )
        }
    }

    private fun addFloatingText(text: String, x: Float, y: Float, z: Float, color: Long) {
        floatingTexts.add(FloatingText(text, x, y, z, color))
    }

    // SWAPPING SLOTS BETWEEN HOTBAR AND MAIN INVENTORY
    fun swapInventoryItemWithHotbar(invIndex: Int, hotbarIndex: Int) {
        val activeHotbar = _hotbar.value.toMutableList()
        val activeInv = _inventory.value.toMutableList()

        val invItem = activeInv.getOrNull(invIndex) ?: return
        val hotbarItem = activeHotbar.getOrNull(hotbarIndex) ?: InventoryItem.block(BlockType.AIR, 0)

        activeHotbar[hotbarIndex] = invItem
        if (hotbarItem.blockType == BlockType.AIR) {
            activeInv.removeAt(invIndex)
        } else {
            activeInv[invIndex] = hotbarItem
        }

        _hotbar.value = activeHotbar
        _inventory.value = activeInv
    }
}
