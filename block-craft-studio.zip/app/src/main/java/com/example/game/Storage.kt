package com.example.game

import android.content.Context
import android.util.Log
import java.io.File

data class WorldMetadata(
    val id: String,
    val name: String,
    val seed: Long,
    val gameMode: String,
    val lastPlayed: Long
)

class WorldManager(private val context: Context) {
    private val rootDir: File = File(context.filesDir, "block_craft_worlds")

    init {
        if (!rootDir.exists()) {
            rootDir.mkdirs()
        }
    }

    fun listWorlds(): List<WorldMetadata> {
        val files = rootDir.listFiles() ?: return emptyList()
        val list = mutableListOf<WorldMetadata>()
        for (f in files) {
            if (f.name.endsWith(".meta")) {
                try {
                    val lines = f.readLines()
                    if (lines.size >= 5) {
                        list.add(
                            WorldMetadata(
                                id = lines[0],
                                name = lines[1],
                                seed = lines[2].toLong(),
                                gameMode = lines[3],
                                lastPlayed = lines[4].toLong()
                            )
                        )
                    }
                } catch (e: Exception) {
                    Log.e("WorldManager", "Error parsing metadata for file: ${f.name}", e)
                }
            }
        }
        return list.sortedByDescending { it.lastPlayed }
    }

    fun saveWorld(
        id: String,
        name: String,
        seed: Long,
        gameMode: String,
        blocks: Map<String, BlockType>,
        inventory: List<InventoryItem>,
        px: Float, py: Float, pz: Float,
        pHealth: Float, pHunger: Float,
        time: Long
    ) {
        val metaFile = File(rootDir, "$id.meta")
        val dataFile = File(rootDir, "$id.dat")
        val now = System.currentTimeMillis()

        // 1. Save metadata
        metaFile.writeText(
            """
            $id
            $name
            $seed
            $gameMode
            $now
            """.trimIndent()
        )

        // 2. Serialize Data: blocks, inventory, player stats
        val builder = java.lang.StringBuilder()
        
        // Player part
        builder.append("PLAYER:$px,$py,$pz,$pHealth,$pHunger,$time\n")

        // Inventory part (format: id,type,count,blockType (or null);)
        builder.append("INV:")
        for (item in inventory) {
            val bName = item.blockType?.name ?: "null"
            builder.append("${item.id},${item.type.name},${item.count},$bName;")
        }
        builder.append("\n")

        // Blocks part
        builder.append("BLOCKS:")
        for ((key, block) in blocks) {
            // only save non-air blocks
            if (block != BlockType.AIR) {
                builder.append("$key:${block.name};")
            }
        }
        builder.append("\n")

        dataFile.writeText(builder.toString())
        Log.d("WorldManager", "Successfully saved world $name ($id)")
    }

    fun loadWorld(id: String): LoadedSavedWorld? {
        val metaFile = File(rootDir, "$id.meta")
        val dataFile = File(rootDir, "$id.dat")
        if (!metaFile.exists() || !dataFile.exists()) return null

        try {
            val metaLines = metaFile.readLines()
            val name = metaLines[1]
            val seed = metaLines[2].toLong()
            val gameMode = metaLines[3]

            val blocks = mutableMapOf<String, BlockType>()
            val inventory = mutableListOf<InventoryItem>()
            var px = 16f
            var py = 16f
            var pz = 5f
            var health = 20f
            var hunger = 20f
            var time = 6000L

            val dataLines = dataFile.readLines()
            for (line in dataLines) {
                when {
                    line.startsWith("PLAYER:") -> {
                        val parts = line.substring(7).split(",")
                        if (parts.size >= 5) {
                            px = parts[0].toFloat()
                            py = parts[1].toFloat()
                            pz = parts[2].toFloat()
                            health = parts[3].toFloat()
                            hunger = parts[4].toFloat()
                        }
                        if (parts.size >= 6) {
                            time = parts[5].toLong()
                        }
                    }
                    line.startsWith("INV:") -> {
                        val itemsStr = line.substring(4)
                        if (itemsStr.isNotEmpty()) {
                            val parts = itemsStr.split(";")
                            for (p in parts) {
                                if (p.trim().isEmpty()) continue
                                val sub = p.split(",")
                                if (sub.size >= 4) {
                                    val itemId = sub[0]
                                    val itemTypeName = sub[1]
                                    val count = sub[2].toInt()
                                    val bName = sub[3]

                                    val itemType = ItemType.valueOf(itemTypeName)
                                    val blockType = if (bName != "null") BlockType.valueOf(bName) else null

                                    // Reconstitute core items to keep proper colors and stats
                                    val item = when {
                                        itemType == ItemType.BLOCK && blockType != null -> {
                                            InventoryItem.block(blockType, count)
                                        }
                                        itemId == "stick" -> InventoryItem.STICK.copyOf(count)
                                        itemId == "coal" -> InventoryItem.COAL.copyOf(count)
                                        itemId == "iron_ingot" -> InventoryItem.IRON_INGOT.copyOf(count)
                                        itemId == "diamond" -> InventoryItem.DIAMOND.copyOf(count)
                                        itemId == "apple" -> InventoryItem.APPLE.copyOf(count)
                                        itemId == "meat" -> InventoryItem.MEAT.copyOf(count)
                                        itemId == "rotten_flesh" -> InventoryItem.ROTTEN_FLESH.copyOf(count)
                                        
                                        // Pickaxes
                                        itemId == "wood_pickaxe" -> InventoryItem.WOOD_PICKAXE
                                        itemId == "stone_pickaxe" -> InventoryItem.STONE_PICKAXE
                                        itemId == "iron_pickaxe" -> InventoryItem.IRON_PICKAXE
                                        itemId == "diamond_pickaxe" -> InventoryItem.DIAMOND_PICKAXE
                                        
                                        // Axes
                                        itemId == "wood_axe" -> InventoryItem.WOOD_AXE
                                        itemId == "stone_axe" -> InventoryItem.STONE_AXE
                                        itemId == "iron_axe" -> InventoryItem.IRON_AXE
                                        itemId == "diamond_axe" -> InventoryItem.DIAMOND_AXE
                                        
                                        // Swords
                                        itemId == "wood_sword" -> InventoryItem.WOOD_SWORD
                                        itemId == "stone_sword" -> InventoryItem.STONE_SWORD
                                        itemId == "iron_sword" -> InventoryItem.IRON_SWORD
                                        itemId == "diamond_sword" -> InventoryItem.DIAMOND_SWORD
                                        
                                        else -> {
                                            InventoryItem(
                                                id = itemId,
                                                type = itemType,
                                                displayName = itemId.replace("_", " ").capitalize(),
                                                blockType = blockType,
                                                count = count
                                            )
                                        }
                                    }
                                    inventory.add(item)
                                }
                            }
                        }
                    }
                    line.startsWith("BLOCKS:") -> {
                        val blocksStr = line.substring(7)
                        if (blocksStr.isNotEmpty()) {
                            val parts = blocksStr.split(";")
                            for (p in parts) {
                                if (p.trim().isEmpty()) continue
                                val sub = p.split(":")
                                if (sub.size == 2) {
                                    val coord = sub[0]
                                    val bType = BlockType.valueOf(sub[1])
                                    blocks[coord] = bType
                                }
                            }
                        }
                    }
                }
            }

            return LoadedSavedWorld(
                metadata = WorldMetadata(id, name, seed, gameMode, System.currentTimeMillis()),
                blocks = blocks,
                inventory = inventory,
                playerX = px,
                playerY = py,
                playerZ = pz,
                playerHealth = health,
                playerHunger = hunger,
                worldTime = time
            )

        } catch (e: Exception) {
            Log.e("WorldManager", "Error loading world $id", e)
            return null
        }
    }

    fun deleteWorld(id: String) {
        val metaFile = File(rootDir, "$id.meta")
        val dataFile = File(rootDir, "$id.dat")
        if (metaFile.exists()) metaFile.delete()
        if (dataFile.exists()) dataFile.delete()
    }
}

data class LoadedSavedWorld(
    val metadata: WorldMetadata,
    val blocks: Map<String, BlockType>,
    val inventory: List<InventoryItem>,
    val playerX: Float,
    val playerY: Float,
    val playerZ: Float,
    val playerHealth: Float,
    val playerHunger: Float,
    val worldTime: Long
)
