package com.example.game

import java.util.UUID

enum class MobType(
    val displayName: String,
    val maxHealth: Float,
    val isHostile: Boolean,
    val color: Long,
    val speed: Float = 0.05f
) {
    ZOMBIE("Zombie", maxHealth = 20f, isHostile = true, color = 0xFF2E7D32),
    CREEPER("Creeper", maxHealth = 15f, isHostile = true, color = 0xFF4CAF50),
    COW("Cow", maxHealth = 10f, isHostile = false, color = 0xFF5D4037),
    SHEEP("Sheep", maxHealth = 8f, isHostile = false, color = 0xFFEEEEEE)
}

data class GameMob(
    val id: String = UUID.randomUUID().toString(),
    val type: MobType,
    var x: Float,
    var y: Float,
    var z: Float,
    var health: Float = type.maxHealth,
    var dirX: Float = 1f,
    var dirY: Float = 0f,
    var targetX: Float? = null,
    var targetY: Float? = null,
    var isHurtTick: Int = 0,
    var explosionFuse: Int = -1, // -1 means inactive. Count down 20 ticks for Creeper explosion!
    var walkCycle: Float = 0f
)

data class Particle(
    var x: Float,
    var y: Float,
    var z: Float,
    var vx: Float,
    var vy: Float,
    var vz: Float,
    val color: Long,
    var life: Int = 15,
    val maxLife: Int = 15
)

data class FloatingText(
    val text: String,
    var x: Float,
    var y: Float,
    var z: Float,
    val color: Long,
    var life: Int = 20
)
