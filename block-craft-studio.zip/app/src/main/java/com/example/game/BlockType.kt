package com.example.game

enum class ToolType {
    NONE,
    PICKAXE,
    AXE,
    SHOVEL,
    SWORD
}

enum class ToolMaterial {
    HAND,
    WOOD,
    STONE,
    IRON,
    DIAMOND
}

enum class BlockType(
    val displayName: String,
    val isSolid: Boolean,
    val isPassable: Boolean,
    val isTransparent: Boolean,
    val hardness: Float, // fully broken at 1.0f base, modified by tools
    val colorTop: Long,
    val colorLeft: Long,
    val colorRight: Long,
    val requiredTool: ToolType = ToolType.NONE,
    val dropType: BlockType? = null
) {
    AIR("Air", isSolid = false, isPassable = true, isTransparent = true, hardness = 0.0f, 0L, 0L, 0L),
    
    GRASS("Grass Block", isSolid = true, isPassable = false, isTransparent = false, hardness = 0.5f,
        colorTop = 0xFF4E9C23, colorLeft = 0xFF795548, colorRight = 0xFF5D4037, // Special render for sides is done in drawing
        requiredTool = ToolType.SHOVEL),
        
    DIRT("Dirt", isSolid = true, isPassable = false, isTransparent = false, hardness = 0.5f,
        colorTop = 0xFF8D6E63, colorLeft = 0xFF6D4C41, colorRight = 0xFF4E342E,
        requiredTool = ToolType.SHOVEL),
        
    STONE("Stone", isSolid = true, isPassable = false, isTransparent = false, hardness = 1.5f,
        colorTop = 0xFF9E9E9E, colorLeft = 0xFF757575, colorRight = 0xFF616161,
        requiredTool = ToolType.PICKAXE),
        
    WOOD_LOG("Oak Log", isSolid = true, isPassable = false, isTransparent = false, hardness = 1.0f,
        colorTop = 0xFFD7CCC8, colorLeft = 0xFF5D4037, colorRight = 0xFF3E2723,
        requiredTool = ToolType.AXE),
        
    WOOD_PLANKS("Oak Planks", isSolid = true, isPassable = false, isTransparent = false, hardness = 0.8f,
        colorTop = 0xFFD7CCC8, colorLeft = 0xFFBCAAA4, colorRight = 0xFF8D6E63,
        requiredTool = ToolType.AXE),
        
    LEAVES("Oak Leaves", isSolid = true, isPassable = false, isTransparent = true, hardness = 0.2f,
        colorTop = 0xAA2E7D32, colorLeft = 0xAA1B5E20, colorRight = 0xAA0D47A1, // green hues
        requiredTool = ToolType.NONE),
        
    SAND("Sand", isSolid = true, isPassable = false, isTransparent = false, hardness = 0.4f,
        colorTop = 0xFFFFF59D, colorLeft = 0xFFFBC02D, colorRight = 0xFFF57F17,
        requiredTool = ToolType.SHOVEL),
        
    WATER("Water", isSolid = false, isPassable = true, isTransparent = true, hardness = 100.0f, // cannot break water
        colorTop = 0x882196F3, colorLeft = 0x881976D2, colorRight = 0x880D47A1),
        
    BRICK("Bricks", isSolid = true, isPassable = false, isTransparent = false, hardness = 1.2f,
        colorTop = 0xFFE53935, colorLeft = 0xFFC62828, colorRight = 0xFFB71C1C,
        requiredTool = ToolType.PICKAXE),
        
    GLASS("Glass", isSolid = true, isPassable = false, isTransparent = true, hardness = 0.2f,
        colorTop = 0x33FFFFFF, colorLeft = 0x22FFFFFF, colorRight = 0x44FFFFFF,
        requiredTool = ToolType.NONE),
        
    COAL_ORE("Coal Ore", isSolid = true, isPassable = false, isTransparent = false, hardness = 1.8f,
        colorTop = 0xFF757575, colorLeft = 0xFF555555, colorRight = 0xFF333333,
        requiredTool = ToolType.PICKAXE),
        
    IRON_ORE("Iron Ore", isSolid = true, isPassable = false, isTransparent = false, hardness = 2.0f,
        colorTop = 0xFF888888, colorLeft = 0xFF7A6B5D, colorRight = 0xFF5D4D3E,
        requiredTool = ToolType.PICKAXE),
        
    DIAMOND_ORE("Diamond Ore", isSolid = true, isPassable = false, isTransparent = false, hardness = 3.0f,
        colorTop = 0xFF757575, colorLeft = 0xFF00BCD4, colorRight = 0xFF00838F,
        requiredTool = ToolType.PICKAXE),
        
    TORCH("Torch", isSolid = false, isPassable = true, isTransparent = true, hardness = 0.0f,
        colorTop = 0xFFFFD54F, colorLeft = 0xFFFFB300, colorRight = 0xFFFFA000),
        
    CRAFTING_TABLE("Crafting Table", isSolid = true, isPassable = false, isTransparent = false, hardness = 1.0f,
        colorTop = 0xFFD7CCC8, colorLeft = 0xFF8D6E63, colorRight = 0xFF4E342E,
        requiredTool = ToolType.AXE),
        
    CHEST("Chest", isSolid = true, isPassable = false, isTransparent = false, hardness = 1.0f,
        colorTop = 0xFF8D6E63, colorLeft = 0xFF5D4037, colorRight = 0xFF3E2723,
        requiredTool = ToolType.AXE),
        
    BEDROCK("Bedrock", isSolid = true, isPassable = false, isTransparent = false, hardness = 99999f, // unbreakable
        colorTop = 0xFF1A1A1A, colorLeft = 0xFF111111, colorRight = 0xFF000000);

    init {
        // Resolve drop types where relevant (we assign these inside accessor or lazy to avoid circular initializer loops)
    }

    fun getDrop(toolUsed: ToolMaterial): BlockType? {
        if (this == BEDROCK || this == WATER || this == AIR) return null
        if (this == GRASS) return DIRT
        if (this == LEAVES) {
            // chance of food
            return if (Math.random() < 0.2) AIR else null // special handling in game logic
        }
        
        // Pickaxe ores dropping raw block, etc.
        if (requiredTool == ToolType.PICKAXE) {
            val tier = getToolTier(toolUsed)
            if (this == DIAMOND_ORE && tier < 3) return null // Needs iron pickaxe or better!
            if (this == IRON_ORE && tier < 2) return null // Needs stone pickaxe or better!
            return this
        }
        return this
    }

    private fun getToolTier(tool: ToolMaterial): Int = when (tool) {
        ToolMaterial.HAND -> 0
        ToolMaterial.WOOD -> 1
        ToolMaterial.STONE -> 2
        ToolMaterial.IRON -> 3
        ToolMaterial.DIAMOND -> 4
    }
}
