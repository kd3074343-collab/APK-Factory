package com.example.game

data class RecipeIngredient(
    val id: String, // item ID (block_grass, stick, wood_pickaxe, etc.)
    val count: Int,
    val displayName: String
)

data class CraftingRecipe(
    val result: InventoryItem,
    val ingredients: List<RecipeIngredient>,
    val requiresCraftingTable: Boolean = false,
    val category: String = "Blocks" // Blocks, Tools, Combat, Items
) {
    fun canPlayerCraft(inventory: List<InventoryItem>): Boolean {
        // Count total item occurrences in inventory
        for (needed in ingredients) {
            val totalInInventory = inventory.filter { it.id == needed.id }.sumOf { it.count }
            if (totalInInventory < needed.count) {
                return false
            }
        }
        return true
    }

    fun executeCraft(inventory: MutableList<InventoryItem>): Boolean {
        if (!canPlayerCraft(inventory)) return false
        
        // Consume ingredients
        for (needed in ingredients) {
            var remainingToRemove = needed.count
            for (i in inventory.indices) {
                val item = inventory[i]
                if (item.id == needed.id) {
                    if (item.count >= remainingToRemove) {
                        item.count -= remainingToRemove
                        remainingToRemove = 0
                    } else {
                        remainingToRemove -= item.count
                        item.count = 0
                    }
                }
                if (remainingToRemove <= 0) break
            }
        }
        
        // Remove empty item stacks from inventory (don't clear hotbar slots, just make them empty or placeholders, or clean them up)
        inventory.removeAll { it.count <= 0 && !it.isTool && it.type != ItemType.BLOCK }
        
        // Try to add the result to inventory or stack it
        var placed = false
        if (result.maxStack > 1) {
            for (item in inventory) {
                if (item.id == result.id && item.count < item.maxStack) {
                    val addable = minOf(result.maxStack - item.count, result.count)
                    item.count += addable
                    if (addable == result.count) {
                        placed = true
                        break
                    }
                }
            }
        }
        
        if (!placed) {
            inventory.add(result.copyOf())
        }
        return true
    }
}

object CraftingRegistry {
    val recipes = listOf(
        // Basic Wood conversions
        CraftingRecipe(
            result = InventoryItem.block(BlockType.WOOD_PLANKS, 4),
            ingredients = listOf(RecipeIngredient("block_wood_log", 1, "Oak Log")),
            requiresCraftingTable = false,
            category = "Blocks"
        ),
        CraftingRecipe(
            result = InventoryItem.STICK.copyOf(4),
            ingredients = listOf(RecipeIngredient("block_wood_planks", 2, "Oak Planks")),
            requiresCraftingTable = false,
            category = "Items"
        ),
        CraftingRecipe(
            result = InventoryItem.block(BlockType.CRAFTING_TABLE, 1),
            ingredients = listOf(RecipeIngredient("block_wood_planks", 4, "Oak Planks")),
            requiresCraftingTable = false,
            category = "Blocks"
        ),
        CraftingRecipe(
            result = InventoryItem.block(BlockType.CHEST, 1),
            ingredients = listOf(RecipeIngredient("block_wood_planks", 8, "Oak Planks")),
            requiresCraftingTable = true,
            category = "Blocks"
        ),
        // Torches
        CraftingRecipe(
            result = InventoryItem.block(BlockType.TORCH, 4),
            ingredients = listOf(
                RecipeIngredient("coal", 1, "Coal Nugget"),
                RecipeIngredient("stick", 1, "Wood Stick")
            ),
            requiresCraftingTable = false,
            category = "Items"
        ),
        // Bricks
        CraftingRecipe(
            result = InventoryItem.block(BlockType.BRICK, 4),
            ingredients = listOf(RecipeIngredient("block_stone", 4, "Stone")),
            requiresCraftingTable = true,
            category = "Blocks"
        ),
        // Glass
        CraftingRecipe(
            result = InventoryItem.block(BlockType.GLASS, 4),
            ingredients = listOf(RecipeIngredient("block_sand", 4, "Sand")),
            requiresCraftingTable = true,
            category = "Blocks"
        ),
        
        // Wooden Tools
        CraftingRecipe(
            result = InventoryItem.WOOD_PICKAXE,
            ingredients = listOf(
                RecipeIngredient("block_wood_planks", 3, "Oak Planks"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.WOOD_AXE,
            ingredients = listOf(
                RecipeIngredient("block_wood_planks", 3, "Oak Planks"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.WOOD_SWORD,
            ingredients = listOf(
                RecipeIngredient("block_wood_planks", 2, "Oak Planks"),
                RecipeIngredient("stick", 1, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Combat"
        ),

        // Stone Tools
        CraftingRecipe(
            result = InventoryItem.STONE_PICKAXE,
            ingredients = listOf(
                RecipeIngredient("block_stone", 3, "Stone"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.STONE_AXE,
            ingredients = listOf(
                RecipeIngredient("block_stone", 3, "Stone"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.STONE_SWORD,
            ingredients = listOf(
                RecipeIngredient("block_stone", 2, "Stone"),
                RecipeIngredient("stick", 1, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Combat"
        ),

        // Iron Tools
        CraftingRecipe(
            result = InventoryItem.IRON_PICKAXE,
            ingredients = listOf(
                RecipeIngredient("iron_ingot", 3, "Iron Ingot"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.IRON_AXE,
            ingredients = listOf(
                RecipeIngredient("iron_ingot", 3, "Iron Ingot"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.IRON_SWORD,
            ingredients = listOf(
                RecipeIngredient("iron_ingot", 2, "Iron Ingot"),
                RecipeIngredient("stick", 1, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Combat"
        ),

        // Diamond Tools
        CraftingRecipe(
            result = InventoryItem.DIAMOND_PICKAXE,
            ingredients = listOf(
                RecipeIngredient("diamond", 3, "Flawless Diamond"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.DIAMOND_AXE,
            ingredients = listOf(
                RecipeIngredient("diamond", 3, "Flawless Diamond"),
                RecipeIngredient("stick", 2, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Tools"
        ),
        CraftingRecipe(
            result = InventoryItem.DIAMOND_SWORD,
            ingredients = listOf(
                RecipeIngredient("diamond", 2, "Flawless Diamond"),
                RecipeIngredient("stick", 1, "Wood Stick")
            ),
            requiresCraftingTable = true,
            category = "Combat"
        ),
        
        // Diamond creation from raw items (smelting/crafting shortcut)
        CraftingRecipe(
            result = InventoryItem.DIAMOND,
            ingredients = listOf(
                RecipeIngredient("coal", 8, "Coal Nugget"),
                RecipeIngredient("iron_ingot", 2, "Iron Ingot")
            ),
            requiresCraftingTable = true,
            category = "Items"
        ),
        CraftingRecipe(
            result = InventoryItem.IRON_INGOT,
            ingredients = listOf(
                RecipeIngredient("block_iron_ore", 1, "Iron Ore") // Direct smelting shortcut
            ),
            requiresCraftingTable = false,
            category = "Items"
        )
    )
}
