package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.morse.MorseViewModel
import com.example.morse.data.MorseHistoryItem
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val model: MorseViewModel = viewModel()
                MorseApp(model)
            }
        }
    }
}

@Composable
fun MorseApp(viewModel: MorseViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val isSignalActive by viewModel.isSignalActive.collectAsState()
    val isFlashOn by viewModel.isFlashEnabled.collectAsState()

    var showLoadingScreen by remember { mutableStateOf(true) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(1200)
        showLoadingScreen = false
    }

    // Immersive screen-flash background overlay
    val animatedFlashAlpha by animateFloatAsState(
        targetValue = if (isSignalActive && isFlashOn) 0.25f else 0f,
        animationSpec = tween(durationMillis = 60),
        label = "FlashAlpha"
    )

    Crossfade(
        targetState = showLoadingScreen,
        animationSpec = tween(durationMillis = 400),
        label = "AppTransition"
    ) { loading ->
        if (loading) {
            LoadingScreen()
        } else {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                contentWindowInsets = WindowInsets.systemBars
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.background,
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.95f)
                                )
                            )
                        )
                        .padding(innerPadding)
                ) {
                    // Screen Flash Highlight layer (Optimized to prevent recompositions)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { alpha = animatedFlashAlpha }
                            .background(Color(0xFFFFD54F))
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        HeaderSection(viewModel)
                        SettingsCard(viewModel)
                        TabSelectionRow(viewModel)

                        Spacer(modifier = Modifier.height(16.dp))

                        Box(modifier = Modifier.weight(1f)) {
                            when (selectedTab) {
                                0 -> TextToMorseScreen(viewModel)
                                1 -> MorseToTextScreen(viewModel)
                                2 -> TacticalKeyScreen(viewModel)
                                3 -> LogsScreen(viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoadingScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(modifier = Modifier.scale(1.5f)) {
                GeometricMorseLogo()
            }
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = "MORSE ENGINE",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 4.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(36.dp))
            
            // Elegant real-time geometric animated dots loader
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "loading")
                for (i in 0..2) {
                    val delayMillis = i * 150
                    val scale by infiniteTransition.animateFloat(
                        initialValue = 0.4f,
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationMillis = 600, delayMillis = delayMillis),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "dot_scale"
                    )
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .graphicsLayer {
                                scaleX = scale
                                scaleY = scale
                            }
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
            }
        }
    }
}

@Composable
fun GeometricMorseLogo() {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                )
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.4f))
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White)
                )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.4f))
                )
            }
        }
    }
}

@Composable
fun HeaderSection(viewModel: MorseViewModel) {
    val isSignalActive by viewModel.isSignalActive.collectAsState()
    
    // Smooth pulse animation for the active signaling LED lamp
    val animatedLEDColor by animateColorAsState(
        targetValue = if (isSignalActive) Color(0xFF6750A4) else Color(0xFFCAC4D0),
        animationSpec = tween(durationMillis = 50),
        label = "LedColor"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GeometricMorseLogo()
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "MORSE ENGINE",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Realistic circular active LED transmitter bulb
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(animatedLEDColor)
                    .border(
                        1.dp,
                        if (isSignalActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f) else Color.Transparent,
                        CircleShape
                    )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isSignalActive) "TX" else "STBY",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (isSignalActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SettingsCard(viewModel: MorseViewModel) {
    val wpm by viewModel.wpm.collectAsState()
    val isSoundEnabled by viewModel.isSoundEnabled.collectAsState()
    val isVibrationEnabled by viewModel.isVibrationEnabled.collectAsState()
    val isFlashEnabled by viewModel.isFlashEnabled.collectAsState()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Speed (WPM) Slider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = "Speed icon",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TRANSMIT SPEED:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "$wpm WPM (${1200 / wpm}ms dot)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Slider(
                value = wpm.toFloat(),
                onValueChange = { viewModel.setWpm(it.toInt()) },
                valueRange = 5f..40f,
                steps = 35,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("speed_slider")
            )

            HorizontalDivider(
                color = MaterialTheme.colorScheme.surfaceVariant,
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Output Selector Toggles (Audio, Vibration, Screen Flash)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutputToggle(
                    icon = if (isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                    label = "SOUND",
                    isActive = isSoundEnabled,
                    onClick = { viewModel.setSoundEnabled(!isSoundEnabled) },
                    testTag = "sound_toggle"
                )
                OutputToggle(
                    icon = Icons.Default.Vibration,
                    label = "HAP-VIB",
                    isActive = isVibrationEnabled,
                    onClick = { viewModel.setVibrationEnabled(!isVibrationEnabled) },
                    testTag = "vib_toggle"
                )
                OutputToggle(
                    icon = if (isFlashEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                    label = "SCR-FLASH",
                    isActive = isFlashEnabled,
                    onClick = { viewModel.setFlashEnabled(!isFlashEnabled) },
                    testTag = "flash_toggle"
                )
            }
        }
    }
}

@Composable
fun OutputToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val containerColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
    val contentColor = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
    val borderColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f) else Color.Transparent

    Row(
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(10.dp))
            .background(containerColor)
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = contentColor
        )
    }
}

@Composable
fun TabSelectionRow(viewModel: MorseViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val tabs = listOf(
        TabItem("TXT → MC", Icons.Default.TextFields),
        TabItem("MC → TXT", Icons.Default.Keyboard),
        TabItem("KEYPAD", Icons.Default.RadioButtonChecked),
        TabItem("LOGS", Icons.Default.History)
    )

    TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                color = MaterialTheme.colorScheme.primary,
                height = 3.dp
            )
        },
        divider = {}
    ) {
        tabs.forEachIndexed { index, tab ->
            Tab(
                selected = selectedTab == index,
                onClick = { viewModel.selectTab(index) },
                modifier = Modifier
                    .height(48.dp)
                    .testTag("tab_$index"),
                selectedContentColor = MaterialTheme.colorScheme.primary,
                unselectedContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.title,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tab.title,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

data class TabItem(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun TextToMorseScreen(viewModel: MorseViewModel) {
    val context = LocalContext.current
    val textInput by viewModel.textInput.collectAsState()
    val morseOutput by viewModel.textToMorseOutput.collectAsState()
    val isTransmitting by viewModel.isTransmitting.collectAsState()
    val activeCharIndex by viewModel.activeCharIndex.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {}
    ) {
        // Plain Text Input
        OutlinedTextField(
            value = textInput,
            onValueChange = { viewModel.updateTextInput(it) },
            label = { Text("PLAIN TEXT INPUT", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            placeholder = { Text("Type English text here...", fontSize = 14.sp) },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .testTag("text_input_field"),
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            ),
            singleLine = false
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Morse Translation Output Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondary
            ),
            shape = RoundedCornerShape(24.dp),
            border = borderStroke()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "MORSE CODE OUTPUT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable highlighted output text
                Box(modifier = Modifier.weight(1f)) {
                    if (morseOutput.isEmpty()) {
                        Text(
                            text = "Translated dots and dashes will appear here...",
                            color = MaterialTheme.colorScheme.onSecondary.copy(alpha = 0.4f),
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            item {
                                Text(
                                    text = buildAnnotatedString {
                                        // Highlights currently active character/symbol if playing
                                        morseOutput.forEachIndexed { i, char ->
                                            if (isTransmitting && i == activeCharIndex) {
                                                withStyle(
                                                    style = SpanStyle(
                                                        color = MaterialTheme.colorScheme.secondary,
                                                        background = MaterialTheme.colorScheme.onSecondary,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                ) {
                                                    append(char)
                                                }
                                            } else {
                                                withStyle(
                                                    style = SpanStyle(
                                                        color = MaterialTheme.colorScheme.onSecondary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                ) {
                                                    append(char)
                                                }
                                            }
                                        }
                                    },
                                    fontSize = 22.sp,
                                    lineHeight = 32.sp,
                                    letterSpacing = 1.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action controls inside output card
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Copy & Save history buttons
                    Row {
                        IconButton(
                            onClick = {
                                if (morseOutput.isNotEmpty()) {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Morse Code", morseOutput))
                                    Toast.makeText(context, "Morse copied to clipboard", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.testTag("copy_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy code",
                                tint = MaterialTheme.colorScheme.onSecondary
                            )
                        }

                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank() && morseOutput.isNotEmpty()) {
                                    viewModel.saveToHistory(textInput, morseOutput, true)
                                    Toast.makeText(context, "Saved to history Log", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.testTag("save_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = "Save to history",
                                tint = MaterialTheme.colorScheme.onSecondary
                            )
                        }
                    }

                    // Large central Transmission Trigger button
                    Button(
                        onClick = {
                            if (isTransmitting) {
                                viewModel.stopPlayback()
                            } else {
                                viewModel.playTextToMorse()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isTransmitting) Color(0xFFBA1A1A) else MaterialTheme.colorScheme.primary,
                            contentColor = if (isTransmitting) Color.White else MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("play_button")
                    ) {
                        Icon(
                            imageVector = if (isTransmitting) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = if (isTransmitting) "Stop" else "Transmit Signal"
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isTransmitting) "STOP" else "TRANSMIT",
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MorseToTextScreen(viewModel: MorseViewModel) {
    val context = LocalContext.current
    val morseInput by viewModel.morseInput.collectAsState()
    val plainTextOutput by viewModel.morseToTextOutput.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Morse Input Box Display
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            shape = RoundedCornerShape(24.dp),
            border = borderStroke()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "MORSE INPUT BUFFER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(4.dp))
                LazyColumn(modifier = Modifier.weight(1f)) {
                    item {
                        Text(
                            text = if (morseInput.isEmpty()) "• • •  ---  • • •" else morseInput,
                            color = if (morseInput.isEmpty()) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f) else MaterialTheme.colorScheme.primary,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Decoded Text Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(24.dp),
            border = borderStroke()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DECODED TRANSLATION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    
                    if (plainTextOutput.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                viewModel.saveToHistory(plainTextOutput, morseInput, false)
                                Toast.makeText(context, "Saved translation to Log", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(32.dp).testTag("save_morse_to_text")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = "Save history",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(modifier = Modifier.weight(1f)) {
                    if (plainTextOutput.isEmpty()) {
                        Text(
                            text = "Alphabet translation will appear here...",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            fontSize = 14.sp
                        )
                    } else {
                        Text(
                            text = plainTextOutput,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Sub action row for decoded text
                if (plainTextOutput.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Decoded Text", plainTextOutput))
                                Toast.makeText(context, "Text copied", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy text",
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // High-fidelity Virtual Morse Typing Pad Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // DOT (.)
                MorseKeyboardButton(
                    symbol = "•",
                    sub = "DOT",
                    modifier = Modifier.weight(1f).testTag("btn_dot")
                ) { viewModel.appendMorseSymbolToInput(".") }

                // DASH (-)
                MorseKeyboardButton(
                    symbol = "—",
                    sub = "DASH",
                    modifier = Modifier.weight(1f).testTag("btn_dash")
                ) { viewModel.appendMorseSymbolToInput("-") }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // SPACE (Letter separator)
                MorseKeyboardButton(
                    symbol = "⎵",
                    sub = "LTR GAP",
                    modifier = Modifier.weight(1.2f).testTag("btn_space")
                ) { viewModel.appendMorseSymbolToInput(" ") }

                // SLASH (Word separator)
                MorseKeyboardButton(
                    symbol = " / ",
                    sub = "WORD GAP",
                    modifier = Modifier.weight(1.2f).testTag("btn_word_space")
                ) { viewModel.appendMorseSymbolToInput(" / ") }

                // BACKSPACE
                IconButton(
                    onClick = { viewModel.deleteLastMorseChar() },
                    modifier = Modifier
                        .height(54.dp)
                        .weight(0.8f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f))
                        .testTag("btn_backspace")
                ) {
                    Icon(
                        imageVector = Icons.Default.Backspace,
                        contentDescription = "Backspace",
                        tint = MaterialTheme.colorScheme.error
                    )
                }

                // CLEAR ALL
                IconButton(
                    onClick = { viewModel.clearMorseInput() },
                    modifier = Modifier
                        .height(54.dp)
                        .weight(0.8f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f))
                        .testTag("btn_clear")
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear all",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
fun MorseKeyboardButton(
    symbol: String,
    sub: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(54.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = symbol,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = sub,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
fun TacticalKeyScreen(viewModel: MorseViewModel) {
    val context = LocalContext.current
    val tapMorseBuffer by viewModel.tapMorseBuffer.collectAsState()
    val tapTextOutput by viewModel.tapTextOutput.collectAsState()
    val isKeyCurrentlyDown by viewModel.isKeyCurrentlyDown.collectAsState()
    val autoSpaceEnabled by viewModel.autoSpaceEnabled.collectAsState()

    // Smooth physical-press scale animation for the telegraph contact knob
    val knobScale by animateFloatAsState(
        targetValue = if (isKeyCurrentlyDown) 0.88f else 1.0f,
        animationSpec = tween(durationMillis = 40),
        label = "KnobScale"
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Output buffers
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ),
            shape = RoundedCornerShape(24.dp),
            border = borderStroke()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE TELEGRAPH BUFFER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AUTO GAP",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = if (autoSpaceEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                            modifier = Modifier.clickable { viewModel.setAutoSpaceEnabled(!autoSpaceEnabled) }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (autoSpaceEnabled) MaterialTheme.colorScheme.primary else Color.Gray)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Scrollable live morse buffer
                LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    item {
                        Text(
                            text = if (tapMorseBuffer.isEmpty()) "Tap the knob below..." else tapMorseBuffer,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (tapMorseBuffer.isEmpty()) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                // Live Text translation
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "DECODED: ",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    Text(
                        text = if (tapTextOutput.isEmpty()) "—" else tapTextOutput,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )

                    if (tapTextOutput.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                viewModel.saveToHistory(tapTextOutput, tapMorseBuffer, false)
                                Toast.makeText(context, "Saved Keypad Transmission", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(24.dp).testTag("save_keypad_log")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = "Save",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Manual controls row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { viewModel.appendManualSpace(" ") },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).height(38.dp),
                border = borderStroke()
            ) {
                Text("ADD GAP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            }
            Button(
                onClick = { viewModel.appendManualSpace(" / ") },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1.2f).height(38.dp),
                border = borderStroke()
            ) {
                Text("ADD WORD GAP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            }
            IconButton(
                onClick = { viewModel.deleteLastTapSymbol() },
                modifier = Modifier.size(38.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
            ) {
                Icon(Icons.Default.Backspace, "Backspace", modifier = Modifier.size(16.dp))
            }
            IconButton(
                onClick = { viewModel.clearTappingPad() },
                modifier = Modifier.size(38.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
            ) {
                Icon(Icons.Default.Clear, "Clear", modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big Tactile Telegraph Tapping Knob
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (isKeyCurrentlyDown) "TRANSMITTING..." else "HOLD DOWN KNOB",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = if (isKeyCurrentlyDown) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    modifier = Modifier.padding(bottom = 14.dp)
                )

                // Beautiful, circular multi-layered 3D key button
                Box(
                    modifier = Modifier
                        .scale(knobScale)
                        .size(170.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = if (isKeyCurrentlyDown) listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                    MaterialTheme.colorScheme.surfaceVariant
                                ) else listOf(
                                    MaterialTheme.colorScheme.surfaceVariant,
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                    MaterialTheme.colorScheme.background
                                )
                            )
                        )
                        .border(
                            4.dp,
                            if (isKeyCurrentlyDown) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                            CircleShape
                        )
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    viewModel.onTelegraphKeyDown()
                                    tryAwaitRelease()
                                    viewModel.onTelegraphKeyUp()
                                }
                            )
                        }
                        .testTag("tactile_knob"),
                    contentAlignment = Alignment.Center
                ) {
                    // Inner metallic solid contact plate
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.verticalGradient(
                                    colors = if (isKeyCurrentlyDown) listOf(
                                        MaterialTheme.colorScheme.primaryContainer,
                                        MaterialTheme.colorScheme.primary
                                    ) else listOf(
                                        MaterialTheme.colorScheme.background,
                                        MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )
                            )
                            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        // Tiny central copper cap
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (isKeyCurrentlyDown) Color(0xFFFF8F00) else MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LogsScreen(viewModel: MorseViewModel) {
    val context = LocalContext.current
    val historyList by viewModel.historyList.collectAsState()
    val favoritesList by viewModel.favoritesList.collectAsState()
    var showFavoritesOnly by remember { mutableStateOf(false) }

    val activeList = if (showFavoritesOnly) favoritesList else historyList

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Toggle Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (!showFavoritesOnly) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { showFavoritesOnly = false }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "ALL LOGS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (!showFavoritesOnly) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (showFavoritesOnly) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { showFavoritesOnly = true }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "FAVORITES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (showFavoritesOnly) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (historyList.isNotEmpty() && !showFavoritesOnly) {
                Text(
                    text = "CLEAR ALL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .clickable {
                            viewModel.clearAllHistory()
                            Toast.makeText(context, "Logs cleared", Toast.LENGTH_SHORT).show()
                        }
                        .testTag("clear_all_logs_btn")
                )
            }
        }

        // List
        if (activeList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = if (showFavoritesOnly) Icons.Default.Star else Icons.Default.History,
                        contentDescription = "Empty state icon",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f),
                        modifier = Modifier.size(60.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (showFavoritesOnly) "No saved favorite codes yet" else "No translation history yet",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                    Text(
                        text = "Your translated items will be logged here",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(activeList, key = { it.id }) { item ->
                    HistoryCardItem(item, viewModel, context)
                }
            }
        }
    }
}

@Composable
fun HistoryCardItem(item: MorseHistoryItem, viewModel: MorseViewModel, context: Context) {
    val coroutineScope = rememberCoroutineScope()
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("history_card_${item.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(24.dp),
        border = borderStroke()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Direction Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (item.isTextToMorse) "TEXT → MORSE CODE" else "MORSE CODE → TEXT",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )

                Row {
                    // Replay button
                    IconButton(
                        onClick = {
                            viewModel.transmitter.startTransmission(item.morseCode, coroutineScope)
                            Toast.makeText(context, "Transmitting audio signal...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play Morse",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    // Favorite Toggle button
                    IconButton(
                        onClick = { viewModel.toggleFavorite(item.id, !item.isFavorite) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Favorite",
                            tint = if (item.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    // Delete item button
                    IconButton(
                        onClick = { viewModel.deleteHistoryItem(item.id) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete record",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Text
            Text(
                text = item.originalText,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Morse
            Text(
                text = item.morseCode,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Clipboard copy row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "COPY",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    modifier = Modifier.clickable {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Morse text", "${item.originalText} \n ${item.morseCode}"))
                        Toast.makeText(context, "Copied translation content", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

@Composable
fun borderStroke() = androidx.compose.foundation.BorderStroke(
    width = 1.dp,
    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
)
