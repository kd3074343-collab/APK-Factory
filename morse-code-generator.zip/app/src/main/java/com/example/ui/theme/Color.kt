package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Geometric Balance design theme colors
val GeoBackground = Color(0xFFF7F2FA)
val GeoTextDark = Color(0xFF1D1B20)
val GeoPrimary = Color(0xFF6750A4)
val GeoOnPrimary = Color(0xFFFFFFFF)
val GeoSurface = Color(0xFFFFFFFF)
val GeoSurfaceVariant = Color(0xFFF3EDF7)
val GeoContainerDark = Color(0xFF21005D)
val GeoContainerLight = Color(0xFFEADDFF)
val GeoBorder = Color(0xFFCAC4D0)
val GeoMutedText = Color(0xFF49454F)
val GeoMutedLight = Color(0xFF938F99)
val GeoHighlight = Color(0xFFE8DEF8)

