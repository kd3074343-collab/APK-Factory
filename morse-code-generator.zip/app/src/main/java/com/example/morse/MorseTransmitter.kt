package com.example.morse

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.sin

class MorseTransmitter(private val context: Context) {
    
    // Configurable output channels
    var isSoundEnabled = true
    var isVibrationEnabled = true
    var isFlashEnabled = true // Screen flash / Visual indicator
    var wpm = 18

    // Realtime state flows
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _isSignalActive = MutableStateFlow(false)
    val isSignalActive: StateFlow<Boolean> = _isSignalActive

    private val _activeCharIndex = MutableStateFlow(-1)
    val activeCharIndex: StateFlow<Int> = _activeCharIndex

    private var playbackJob: Job? = null
    private val sampleRate = 44100
    private val frequency = 800.0 // comfortably clear sine wave pitch

    // Vibrator access
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    /**
     * Plays a complete Morse code string step-by-step.
     * Updates [isPlaying], [isSignalActive], and [activeCharIndex] in real-time.
     */
    fun startTransmission(morseCode: String, coroutineScope: CoroutineScope) {
        stopTransmission()
        
        playbackJob = coroutineScope.launch(Dispatchers.Default) {
            _isPlaying.value = true
            val dotMs = MorseEngine.getDotDurationMs(wpm)
            val dashMs = dotMs * 3
            val elementGap = dotMs
            val letterGap = dotMs * 3 - elementGap
            val wordGap = dotMs * 7 - elementGap

            // Parse Morse string into letters/symbols to track highlighting
            // Example input: "... --- ..."
            // Let's iterate character by character
            var index = 0
            while (index < morseCode.length && _isPlaying.value) {
                _activeCharIndex.value = index
                val char = morseCode[index]

                when (char) {
                    '.' -> {
                        transmitSignal(dotMs)
                        delay(elementGap.toLong())
                    }
                    '-', '—', '_' -> {
                        transmitSignal(dashMs)
                        delay(elementGap.toLong())
                    }
                    ' ' -> {
                        // Check if it's a word separator (multi-space or slash)
                        val nextChar = if (index + 1 < morseCode.length) morseCode[index + 1] else null
                        if (nextChar == '/' || (nextChar == ' ' && index + 2 < morseCode.length && morseCode[index + 2] == ' ')) {
                            // Word gap
                            delay(wordGap.toLong())
                            if (nextChar == '/') index++ // Skip the slash in loop
                        } else {
                            // Letter gap
                            delay(letterGap.toLong())
                        }
                    }
                    '/' -> {
                        delay(wordGap.toLong())
                    }
                    else -> {
                        // Unknown symbol, small pause
                        delay(elementGap.toLong())
                    }
                }
                index++
            }

            // Cleanup at end
            _activeCharIndex.value = -1
            _isSignalActive.value = false
            _isPlaying.value = false
        }
    }

    fun stopTransmission() {
        playbackJob?.cancel()
        playbackJob = null
        _isPlaying.value = false
        _isSignalActive.value = false
        _activeCharIndex.value = -1
    }

    /**
     * Helper to pulse the active outputs (Audio wave & Haptic engine) for a specific duration.
     */
    private suspend fun transmitSignal(durationMs: Int) {
        _isSignalActive.value = true

        // Audio Track generation (run asynchronously or wait)
        var audioTrack: AudioTrack? = null
        if (isSoundEnabled) {
            audioTrack = generateAudioTrack(durationMs)
            audioTrack?.play()
        }

        if (isVibrationEnabled) {
            triggerVibration(durationMs)
        }

        // Keep signal active for the duration of the dot/dash
        delay(durationMs.toLong())

        // Stop signal outputs
        _isSignalActive.value = false
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun triggerVibration(durationMs: Int) {
        try {
            vibrator?.let { vib ->
                if (vib.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createOneShot(durationMs.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        vib.vibrate(durationMs.toLong())
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun generateAudioTrack(durationMs: Int): AudioTrack? {
        try {
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val value = sin(2.0 * Math.PI * i / (sampleRate / frequency))
                
                // 5ms smooth envelope fade to avoid popping speaker noises
                val fadeRange = (sampleRate * 0.005).toInt()
                val envelope = when {
                    i < fadeRange -> i.toDouble() / fadeRange
                    i > numSamples - fadeRange -> (numSamples - i).toDouble() / fadeRange
                    else -> 1.0
                }
                buffer[i] = (value * 32767.0 * envelope).toInt().toShort()
            }

            val track = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                numSamples * 2,
                AudioTrack.MODE_STATIC
            )
            track.write(buffer, 0, numSamples)
            return track
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}
