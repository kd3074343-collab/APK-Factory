package com.example.morse.data

import kotlinx.coroutines.flow.Flow

class MorseRepository(private val dao: MorseHistoryDao) {
    val allHistory: Flow<List<MorseHistoryItem>> = dao.getAllHistory()
    val favorites: Flow<List<MorseHistoryItem>> = dao.getFavorites()

    suspend fun insertItem(item: MorseHistoryItem) {
        dao.insertItem(item)
    }

    suspend fun updateFavorite(itemId: Int, isFav: Boolean) {
        dao.updateFavorite(itemId, isFav)
    }

    suspend fun deleteItem(itemId: Int) {
        dao.deleteItem(itemId)
    }

    suspend fun clearHistory() {
        dao.clearAllHistory()
    }
}
