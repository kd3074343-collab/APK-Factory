package com.example.morse

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.morse.data.MorseDatabase
import com.example.morse.data.MorseHistoryItem
import com.example.morse.data.MorseRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MorseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MorseRepository
    val transmitter: MorseTransmitter

    init {
        val database = MorseDatabase.getDatabase(application)
        repository = MorseRepository(database.morseHistoryDao())
        transmitter = MorseTransmitter(application)
    }

    // Tab state (0 = Text-To-Morse, 1 = Morse-To-Text, 2 = Tactical Morse Key, 3 = History & Favorites)
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab

    // Configuration / Settings
    private val _wpm = MutableStateFlow(18)
    val wpm: StateFlow<Int> = _wpm

    private val _isSoundEnabled = MutableStateFlow(true)
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled

    private val _isVibrationEnabled = MutableStateFlow(true)
    val isVibrationEnabled: StateFlow<Boolean> = _isVibrationEnabled

    private val _isFlashEnabled = MutableStateFlow(true)
    val isFlashEnabled: StateFlow<Boolean> = _isFlashEnabled

    // Text to Morse screen state
    private val _textInput = MutableStateFlow("")
    val textInput: StateFlow<String> = _textInput

    private val _textToMorseOutput = MutableStateFlow("")
    val textToMorseOutput: StateFlow<String> = _textToMorseOutput

    // Morse to Text screen state
    private val _morseInput = MutableStateFlow("")
    val morseInput: StateFlow<String> = _morseInput

    private val _morseToTextOutput = MutableStateFlow("")
    val morseToTextOutput: StateFlow<String> = _morseToTextOutput

    // Tactical Morse Keyboard / Tapping pad states
    private val _tapMorseBuffer = MutableStateFlow("")
    val tapMorseBuffer: StateFlow<String> = _tapMorseBuffer

    private val _tapTextOutput = MutableStateFlow("")
    val tapTextOutput: StateFlow<String> = _tapTextOutput

    private val _isKeyCurrentlyDown = MutableStateFlow(false)
    val isKeyCurrentlyDown: StateFlow<Boolean> = _isKeyCurrentlyDown

    private val _autoSpaceEnabled = MutableStateFlow(true)
    val autoSpaceEnabled: StateFlow<Boolean> = _autoSpaceEnabled

    // Room Database Observation
    val historyList: StateFlow<List<MorseHistoryItem>> = repository.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoritesList: StateFlow<List<MorseHistoryItem>> = repository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Transmission status flows (linked directly to the Transmitter)
    val isTransmitting: StateFlow<Boolean> = transmitter.isPlaying
    val isSignalActive: StateFlow<Boolean> = transmitter.isSignalActive
    val activeCharIndex: StateFlow<Int> = transmitter.activeCharIndex

    // Timing helper for tapping key pad
    private var keyDownTimestamp: Long = 0
    private var lastKeyUpTimestamp: Long = 0
    private var spaceSchedulerJob: Job? = null

    fun selectTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
        // Stop playing when tab switches
        transmitter.stopTransmission()
    }

    fun setWpm(newWpm: Int) {
        _wpm.value = newWpm
        transmitter.wpm = newWpm
    }

    fun setSoundEnabled(enabled: Boolean) {
        _isSoundEnabled.value = enabled
        transmitter.isSoundEnabled = enabled
    }

    fun setVibrationEnabled(enabled: Boolean) {
        _isVibrationEnabled.value = enabled
        transmitter.isVibrationEnabled = enabled
    }

    fun setFlashEnabled(enabled: Boolean) {
        _isFlashEnabled.value = enabled
        transmitter.isFlashEnabled = enabled
    }

    // --- Text to Morse Actions ---
    fun updateTextInput(text: String) {
        _textInput.value = text
        _textToMorseOutput.value = MorseEngine.textToMorse(text)
    }

    fun playTextToMorse() {
        val code = _textToMorseOutput.value
        if (code.isNotEmpty()) {
            transmitter.startTransmission(code, viewModelScope)
        }
    }

    fun stopPlayback() {
        transmitter.stopTransmission()
    }

    fun saveToHistory(text: String, morse: String, isTextToMorse: Boolean) {
        if (text.isBlank() || morse.isBlank()) return
        viewModelScope.launch {
            repository.insertItem(
                MorseHistoryItem(
                    originalText = text,
                    morseCode = morse,
                    isTextToMorse = isTextToMorse
                )
            )
        }
    }

    // --- Morse to Text Actions ---
    fun updateMorseInput(morse: String) {
        _morseInput.value = morse
        _morseToTextOutput.value = MorseEngine.morseToText(morse)
    }

    fun appendMorseSymbolToInput(symbol: String) {
        val current = _morseInput.value
        val next = if (current.isEmpty() || current.endsWith(" ") || symbol == " ") {
            current + symbol
        } else {
            "$current$symbol"
        }
        updateMorseInput(next)
    }

    fun clearMorseInput() {
        updateMorseInput("")
    }

    fun deleteLastMorseChar() {
        val current = _morseInput.value
        if (current.isNotEmpty()) {
            val updated = if (current.endsWith(" / ")) {
                current.substring(0, current.length - 3)
            } else if (current.endsWith(" ")) {
                current.substring(0, current.length - 1)
            } else {
                current.substring(0, current.length - 1)
            }
            updateMorseInput(updated)
        }
    }

    // --- Tapping Key Pad Actions ---
    fun setAutoSpaceEnabled(enabled: Boolean) {
        _autoSpaceEnabled.value = enabled
    }

    fun onTelegraphKeyDown() {
        if (_isKeyCurrentlyDown.value) return
        _isKeyCurrentlyDown.value = true
        keyDownTimestamp = System.currentTimeMillis()
        spaceSchedulerJob?.cancel()

        // Trigger real-time sound and vibration on key down
        if (_isSoundEnabled.value) {
            // Beep as long as they hold? Since playTone takes exact duration,
            // we let the signal stay active.
            // For continuous beep, we toggle signal active. The UI can animate this.
        }
        // Let's trigger a short haptic feedback for initial key down
        transmitter.startTransmission("", viewModelScope) // resets active index
    }

    fun onTelegraphKeyUp() {
        if (!_isKeyCurrentlyDown.value) return
        _isKeyCurrentlyDown.value = false
        val now = System.currentTimeMillis()
        val duration = now - keyDownTimestamp
        lastKeyUpTimestamp = now

        val dotMs = MorseEngine.getDotDurationMs(_wpm.value)
        val dashThreshold = dotMs * 1.8

        // Decide if dot or dash
        val symbol = if (duration < dashThreshold) "." else "-"
        
        // Append to buffer
        val currentBuffer = _tapMorseBuffer.value
        val cleanBuffer = if (currentBuffer.endsWith(" ")) {
            currentBuffer + symbol
        } else {
            // Append directly (part of current letter)
            currentBuffer + symbol
        }
        
        _tapMorseBuffer.value = cleanBuffer
        _tapTextOutput.value = MorseEngine.morseToText(cleanBuffer)

        // Schedule auto-spacing if enabled
        if (_autoSpaceEnabled.value) {
            scheduleAutoSpacing(dotMs)
        }
    }

    fun appendManualSpace(symbol: String) {
        val current = _tapMorseBuffer.value
        if (current.isEmpty()) return
        if (symbol == " " && !current.endsWith(" ")) {
            _tapMorseBuffer.value = current + " "
        } else if (symbol == " / " && !current.endsWith(" / ") && !current.endsWith(" /")) {
            _tapMorseBuffer.value = current.trimEnd() + " / "
        }
        _tapTextOutput.value = MorseEngine.morseToText(_tapMorseBuffer.value)
    }

    fun clearTappingPad() {
        _tapMorseBuffer.value = ""
        _tapTextOutput.value = ""
    }

    fun deleteLastTapSymbol() {
        val current = _tapMorseBuffer.value
        if (current.isNotEmpty()) {
            val updated = if (current.endsWith(" / ")) {
                current.substring(0, current.length - 3)
            } else if (current.endsWith(" ")) {
                current.substring(0, current.length - 1)
            } else {
                current.substring(0, current.length - 1)
            }
            _tapMorseBuffer.value = updated
            _tapTextOutput.value = MorseEngine.morseToText(updated)
        }
    }

    private fun scheduleAutoSpacing(dotMs: Int) {
        spaceSchedulerJob?.cancel()
        spaceSchedulerJob = viewModelScope.launch {
            // Wait for letter gap (3 * dot duration)
            delay((dotMs * 3.0).toLong())
            val current = _tapMorseBuffer.value
            if (current.isNotEmpty() && !current.endsWith(" ")) {
                _tapMorseBuffer.value = "$current "
            }

            // Wait for word gap (7 * dot duration)
            delay((dotMs * 4.0).toLong())
            val current2 = _tapMorseBuffer.value
            if (current2.isNotEmpty() && !current2.endsWith(" / ")) {
                _tapMorseBuffer.value = current2.trimEnd() + " / "
            }
        }
    }

    // --- History / Favorites Management ---
    fun toggleFavorite(itemId: Int, isFav: Boolean) {
        viewModelScope.launch {
            repository.updateFavorite(itemId, isFav)
        }
    }

    fun deleteHistoryItem(itemId: Int) {
        viewModelScope.launch {
            repository.deleteItem(itemId)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }
}
