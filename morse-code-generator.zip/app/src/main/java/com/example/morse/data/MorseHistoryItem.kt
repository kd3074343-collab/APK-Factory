package com.example.morse.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "morse_history")
data class MorseHistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originalText: String,
    val morseCode: String,
    val isTextToMorse: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
