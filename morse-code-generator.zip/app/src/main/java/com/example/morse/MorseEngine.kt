package com.example.morse

import java.util.Locale

object MorseEngine {
    // Alphanumeric standard international Morse mappings
    private val CHAR_TO_MORSE = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
        'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
        'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
        'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
        'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
        'Z' to "--..",
        
        '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-", '5' to ".....",
        '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.", '0' to "-----",
        
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '\'' to ".----.", '!' to "-.-.--",
        '/' to "-..-.", '(' to "-.--.", ')' to "-.--.-", '&' to ".-...", ':' to "---...",
        ';' to "-.-.-.", '=' to "-...-", '+' to ".-.-.", '-' to "-....-", '_' to "..--.-",
        '"' to ".-..-.", '$' to "...-..-", '@' to ".--.-."
    )

    private val MORSE_TO_CHAR = CHAR_TO_MORSE.entries.associate { it.value to it.key }

    /**
     * Translates a plain text string to Morse Code.
     * [wordSeparator] defaults to " / " or "   " (three spaces).
     */
    fun textToMorse(text: String, wordSeparator: String = " / "): String {
        if (text.isBlank()) return ""
        val cleanText = text.uppercase(Locale.getDefault())
        val words = cleanText.split(Regex("\\s+"))
        
        return words.map { word ->
            word.mapNotNull { char ->
                CHAR_TO_MORSE[char]
            }.joinToString(" ")
        }.filter { it.isNotEmpty() }
            .joinToString(wordSeparator)
    }

    /**
     * Translates a Morse code string back to plain text.
     */
    fun morseToText(morse: String, wordSeparator: String = "/"): String {
        if (morse.isBlank()) return ""
        
        // Clean Morse input: replace custom symbols like bullet (•) or emdash (—) with standard dots and dashes
        val cleanMorse = morse
            .replace('•', '.')
            .replace('·', '.')
            .replace('—', '-')
            .replace('_', '-')
            .trim()

        // Normalize separators: handle " / ", "   ", or direct slash
        val separatorRegex = when {
            wordSeparator.contains("/") -> Regex("\\s*/\\s*")
            else -> Regex("\\s{3,}") // Fallback to 3+ spaces if no slash
        }

        val words = cleanMorse.split(separatorRegex)
        return words.map { word ->
            word.trim().split(Regex("\\s+")).map { symbol ->
                MORSE_TO_CHAR[symbol] ?: ""
            }.joinToString("")
        }.joinToString(" ").trim()
    }

    /**
     * Helper to get dot timing in ms based on Words Per Minute (WPM)
     * Standard PARIS formula: Dot duration = 1200 / WPM ms
     */
    fun getDotDurationMs(wpm: Int): Int {
        val safeWpm = wpm.coerceIn(5, 50)
        return 1200 / safeWpm
    }
}
