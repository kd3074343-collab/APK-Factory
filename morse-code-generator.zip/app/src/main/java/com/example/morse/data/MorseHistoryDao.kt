package com.example.morse.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MorseHistoryDao {
    @Query("SELECT * FROM morse_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<MorseHistoryItem>>

    @Query("SELECT * FROM morse_history WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavorites(): Flow<List<MorseHistoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: MorseHistoryItem)

    @Query("UPDATE morse_history SET isFavorite = :isFav WHERE id = :itemId")
    suspend fun updateFavorite(itemId: Int, isFav: Boolean)

    @Query("DELETE FROM morse_history WHERE id = :itemId")
    suspend fun deleteItem(itemId: Int)

    @Query("DELETE FROM morse_history")
    suspend fun clearAllHistory()
}
