package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class VideoViewModel(application: Application) : AndroidViewModel(application) {
    // Database & Repository init
    private val database = VideoDatabase.getDatabase(application)
    private val repository = VideoRepository(database.videoDao())

    // All videos (local + fallbacks)
    private val _allVideos = MutableStateFlow<List<LocalVideo>>(emptyList())
    val allVideos: StateFlow<List<LocalVideo>> = _allVideos.asStateFlow()

    // Filtered videos based on search & category
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    val filteredVideos: StateFlow<List<LocalVideo>> = combine(_allVideos, _searchQuery, _selectedCategory) { videos, query, category ->
        var list = videos
        if (category != "All") {
            list = list.filter { video ->
                when (category) {
                    "Tech Reviews" -> video.uploader.contains("Tech", ignoreCase = true) || video.uploader.contains("MKBHD", ignoreCase = true)
                    "Cinematic Arts" -> video.title.contains("Cinematic", ignoreCase = true) || video.uploader.contains("Cinephile", ignoreCase = true) || video.title.contains("Elephant", ignoreCase = true)
                    "Sintel" -> video.title.contains("Sintel", ignoreCase = true) || video.uploader.contains("Durian", ignoreCase = true)
                    "Adventure" -> video.title.contains("Adventure", ignoreCase = true) || video.uploader.contains("Overland", ignoreCase = true) || video.title.contains("Escape", ignoreCase = true)
                    "Vlogs" -> video.uploader.contains("Vlog", ignoreCase = true) || video.uploader.contains("Wanderlust", ignoreCase = true)
                    "Blender Studio" -> video.uploader.contains("Blender", ignoreCase = true) || video.uploader.contains("Orange", ignoreCase = true) || video.uploader.contains("Mango", ignoreCase = true)
                    else -> true
                }
            }
        }
        if (query.isNotBlank()) {
            list = list.filter { it.title.contains(query, ignoreCase = true) || it.uploader.contains(query, ignoreCase = true) }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active screen / Tab selection
    private val _currentTab = MutableStateFlow(YouTubeTab.HOME)
    val currentTab: StateFlow<YouTubeTab> = _currentTab.asStateFlow()

    // Selected playing video
    private val _activeVideo = MutableStateFlow<LocalVideo?>(null)
    val activeVideo: StateFlow<LocalVideo?> = _activeVideo.asStateFlow()

    // Watch history, liked, playlists, watch later flows from Room
    val watchHistory: StateFlow<List<WatchHistoryEntity>> = repository.watchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val likedVideos: StateFlow<List<LikedVideoEntity>> = repository.likedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchLaterVideos: StateFlow<List<WatchLaterEntity>> = repository.watchLater
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playlists: StateFlow<List<PlaylistEntity>> = repository.playlists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI States
    private val _permissionGranted = MutableStateFlow<Boolean?>(null)
    val permissionGranted: StateFlow<Boolean?> = _permissionGranted.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Dynamic Comments List
    private val _activeComments = MutableStateFlow<List<MockComment>>(emptyList())
    val activeComments: StateFlow<List<MockComment>> = _activeComments.asStateFlow()

    init {
        // Scanning is triggered upon permission confirmation
    }

    fun setPermissionState(granted: Boolean) {
        _permissionGranted.value = granted
        if (granted) {
            refreshVideos()
        } else {
            // Load fallbacks only if denied so app runs with ready content
            loadFallbackOnly()
        }
    }

    fun refreshVideos() {
        viewModelScope.launch {
            _isLoading.value = true
            val videos = repository.loadLocalAndRemoteVideos(getApplication())
            _allVideos.value = videos
            _isLoading.value = false
        }
    }

    private fun loadFallbackOnly() {
        viewModelScope.launch {
            _isLoading.value = true
            val fallbackVideos = repository.loadLocalAndRemoteVideos(getApplication()).filter { !it.isLocal }
            _allVideos.value = fallbackVideos
            _isLoading.value = false
        }
    }

    fun selectTab(tab: YouTubeTab) {
        _currentTab.value = tab
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private var _exoPlayer: ExoPlayer? = null

    fun getOrCreatePlayer(): ExoPlayer {
        if (_exoPlayer == null) {
            _exoPlayer = ExoPlayer.Builder(getApplication()).build().apply {
                repeatMode = Player.REPEAT_MODE_ONE
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _isPlaying.value = isPlaying
                    }
                })
            }
        }
        return _exoPlayer!!
    }

    fun togglePlayPause() {
        _exoPlayer?.let { player ->
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        }
    }

    fun playVideo(video: LocalVideo) {
        _activeVideo.value = video
        viewModelScope.launch {
            repository.insertWatchHistory(video)
        }
        generateCommentsFor(video)

        val player = getOrCreatePlayer()
        val mediaItem = MediaItem.fromUri(video.path)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = true
    }

    fun stopPlayback() {
        _activeVideo.value = null
        _exoPlayer?.stop()
    }

    override fun onCleared() {
        super.onCleared()
        _exoPlayer?.release()
        _exoPlayer = null
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun isVideoLiked(path: String): Flow<Boolean> = repository.isVideoLiked(path)

    fun toggleLike(video: LocalVideo, isCurrentlyLiked: Boolean) {
        viewModelScope.launch {
            repository.toggleLike(video, !isCurrentlyLiked)
        }
    }

    fun isVideoInWatchLater(path: String): Flow<Boolean> = repository.isVideoInWatchLater(path)

    fun toggleWatchLater(video: LocalVideo, isCurrentlyInWatchLater: Boolean) {
        viewModelScope.launch {
            repository.toggleWatchLater(video, !isCurrentlyInWatchLater)
        }
    }

    fun createPlaylist(name: String, onCreated: (Int) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.createPlaylist(name)
            onCreated(id.toInt())
        }
    }

    fun deletePlaylist(playlistId: Int) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun addVideoToPlaylist(playlistId: Int, video: LocalVideo) {
        viewModelScope.launch {
            repository.addVideoToPlaylist(playlistId, video)
        }
    }

    fun removeVideoFromPlaylist(playlistId: Int, videoPath: String) {
        viewModelScope.launch {
            repository.removeVideoFromPlaylist(playlistId, videoPath)
        }
    }

    fun getVideosInPlaylist(playlistId: Int): Flow<List<PlaylistVideoEntity>> {
        return repository.getVideosForPlaylist(playlistId)
    }

    fun deleteWatchHistory(path: String) {
        viewModelScope.launch {
            repository.deleteWatchHistory(path)
        }
    }

    fun clearWatchHistory() {
        viewModelScope.launch {
            repository.clearWatchHistory()
        }
    }

    private fun generateCommentsFor(video: LocalVideo) {
        val authors = listOf(
            "TechGeek99", "Sarah_Miller", "CinematicVibe", "AndroidDev_Pro", "PixelPerfect",
            "MKBHD_Fan", "AeroPilot", "CuriousMind", "GamingBeast", "DesignEnthusiast"
        )
        val textTemplates = listOf(
            "This is absolutely stunning! The visual fidelity is next level.",
            "Wow, I didn't expect this video to load so quickly in this player!",
            "Can you make a tutorial on how you built this player? The controls are super smooth.",
            "Loved the pacing and transition details. Top notch content here.",
            "Brings back so many memories! Thanks for sharing this masterpiece.",
            "Is it just me, or does the audio separation sound incredibly clear here?",
            "Amazing! Subscribed for more awesome stuff like this.",
            "Great explanation! Highly detailed and direct to the point.",
            "The design layout of this app is gorgeous. YouTube should hire you!",
            "Brilliant! Watched it three times already."
        )

        val commentsCount = 5 + (Math.abs(video.title.hashCode()) % 6)
        val list = mutableListOf<MockComment>()
        for (i in 0 until commentsCount) {
            val authorIndex = Math.abs(video.title.hashCode() + i * 3) % authors.size
            val textIndex = Math.abs(video.title.hashCode() + i * 7) % textTemplates.size
            val likes = Math.abs(video.title.hashCode() + i * 11) % 450 + 5
            val relativeTime = "${i + 1}h ago"

            list.add(
                MockComment(
                    author = authors[authorIndex],
                    avatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=${authors[authorIndex]}",
                    text = textTemplates[textIndex],
                    likesCount = likes,
                    timeRelative = relativeTime
                )
            )
        }
        _activeComments.value = list
    }
}

enum class YouTubeTab {
    HOME, SHORTS, SUBSCRIPTIONS, LIBRARY
}

data class MockComment(
    val author: String,
    val avatarUrl: String,
    val text: String,
    val likesCount: Int,
    val timeRelative: String
)
