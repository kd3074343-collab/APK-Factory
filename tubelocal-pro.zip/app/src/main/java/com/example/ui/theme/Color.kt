package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// YouTube Brand Red
val RedYouTube = Color(0xFFFF0000)

// Dark Theme Colors
val DarkBackground = Color(0xFF0F0F0F)
val DarkSurface = Color(0xFF1F1F1F)
val DarkSurfaceVariant = Color(0xFF282828)
val DarkOnBackground = Color(0xFFFFFFFF)
val DarkOnSurface = Color(0xFFFFFFFF)

// Light Theme Colors
val LightBackground = Color(0xFFF9F9F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F1F1)
val LightOnBackground = Color(0xFF0F0F0F)
val LightOnSurface = Color(0xFF0F0F0F)

// Auxiliary Colors
val GrayYouTube = Color(0xFFAAAAAA)
val GrayLightYouTube = Color(0xFF606060)

