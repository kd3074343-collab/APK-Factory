package com.example.ui

import android.Manifest
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.outlined.List
import androidx.compose.material.icons.automirrored.outlined.PlaylistAdd
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouTubeCloneApp(
    viewModel: VideoViewModel = viewModel()
) {
    val context = LocalContext.current
    val permissionGranted by viewModel.permissionGranted.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val activeVideo by viewModel.activeVideo.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val allVideos by viewModel.filteredVideos.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()

    var isSearchActive by remember { mutableStateOf(false) }
    var activePlayerExpanded by remember { mutableStateOf(true) }

    // Dialog state for playlist selection
    var showPlaylistDialogForVideo by remember { mutableStateOf<LocalVideo?>(null) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }

    // Launch permission request instantly on startup
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val readVideoGranted = permissions[Manifest.permission.READ_MEDIA_VIDEO] ?: false
        val readStorageGranted = permissions[Manifest.permission.READ_EXTERNAL_STORAGE] ?: false
        viewModel.setPermissionState(readVideoGranted || readStorageGranted)
    }

    LaunchedEffect(Unit) {
        val permissionsToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(permissionsToRequest)
    }

    // Handle back button on expanded video player
    if (activeVideo != null && activePlayerExpanded) {
        BackHandler {
            activePlayerExpanded = false
        }
    }

    Scaffold(
        topBar = {
            if (activeVideo == null || !activePlayerExpanded) {
                if (isSearchActive) {
                    SearchAppBar(
                        searchQuery = searchQuery,
                        onSearchQueryChanged = { viewModel.updateSearchQuery(it) },
                        onBackClicked = {
                            isSearchActive = false
                            viewModel.updateSearchQuery("")
                        }
                    )
                } else {
                    YouTubeTopAppBar(
                        onSearchClicked = { isSearchActive = true },
                        onProfileClicked = { viewModel.selectTab(YouTubeTab.LIBRARY) }
                    )
                }
            }
        },
        bottomBar = {
            if (activeVideo == null || !activePlayerExpanded) {
                YouTubeBottomNavigationBar(
                    currentTab = currentTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // If Home Tab, show horizontal categories row
                if (currentTab == YouTubeTab.HOME && !isSearchActive) {
                    CategoriesRow(
                        selectedCategory = selectedCategory,
                        onCategorySelected = { category ->
                            viewModel.selectCategory(category)
                        }
                    )
                }

                // Render Active Tab Content
                when (currentTab) {
                    YouTubeTab.HOME -> HomeFeedScreen(
                        videos = allVideos,
                        isLoading = isLoading,
                        permissionGranted = permissionGranted,
                        onVideoClick = { video ->
                            viewModel.playVideo(video)
                            activePlayerExpanded = true
                        },
                        onRequestPermission = {
                            val permissionsToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
                            } else {
                                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                            }
                            permissionLauncher.launch(permissionsToRequest)
                        },
                        onAddToPlaylist = { showPlaylistDialogForVideo = it },
                        onToggleWatchLater = { video, isInWatchLater ->
                            viewModel.toggleWatchLater(video, isInWatchLater)
                        }
                    )
                    YouTubeTab.SHORTS -> ShortsScreen(
                        videos = allVideos,
                        onBack = { viewModel.selectTab(YouTubeTab.HOME) }
                    )
                    YouTubeTab.SUBSCRIPTIONS -> SubscriptionsScreen(
                        onExploreClick = { viewModel.selectTab(YouTubeTab.HOME) }
                    )
                    YouTubeTab.LIBRARY -> LibraryScreen(
                        viewModel = viewModel,
                        onVideoClick = { video ->
                            viewModel.playVideo(video)
                            activePlayerExpanded = true
                        }
                    )
                }
            }

            // Custom Floating Video Player Sheet
            activeVideo?.let { video ->
                SlidingVideoPlayerSheet(
                    video = video,
                    isExpanded = activePlayerExpanded,
                    onCollapse = { activePlayerExpanded = false },
                    onClose = { viewModel.stopPlayback() },
                    viewModel = viewModel,
                    allVideos = allVideos
                )
            }

            // Playlist Dialog Selection Overlay
            showPlaylistDialogForVideo?.let { video ->
                PlaylistSelectionDialog(
                    video = video,
                    viewModel = viewModel,
                    onDismiss = { showPlaylistDialogForVideo = null },
                    onCreateNewPlaylist = { showCreatePlaylistDialog = true }
                )
            }

            // Create Playlist Input Dialog
            if (showCreatePlaylistDialog) {
                CreatePlaylistDialog(
                    onDismiss = { showCreatePlaylistDialog = false },
                    onConfirm = { name ->
                        viewModel.createPlaylist(name)
                        showCreatePlaylistDialog = false
                    }
                )
            }
        }
    }
}

@Composable
fun YouTubeTopAppBar(
    onSearchClicked: () -> Unit,
    onProfileClicked: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.background,
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Logo section
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {}
            ) {
                // Red play button logo
                Box(
                    modifier = Modifier
                        .size(30.dp, 22.dp)
                        .background(Color.Red, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Logo Play Icon",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ViewTube",
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                    letterSpacing = (-0.5).sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // Action Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                IconButton(
                    onClick = {},
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Cast,
                        contentDescription = "Cast",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(
                    onClick = {},
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = "Notifications",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(
                    onClick = onSearchClicked,
                    modifier = Modifier
                        .size(24.dp)
                        .testTag("search_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable { onProfileClicked() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "V",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SearchAppBar(
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    onBackClicked: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClicked) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back from Search",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
            TextField(
                value = searchQuery,
                onValueChange = onSearchQueryChanged,
                placeholder = { Text("Search ViewTube...", color = Color.Gray, fontSize = 16.sp) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    keyboardController?.hide()
                }),
                modifier = Modifier
                    .weight(1f)
                    .testTag("search_text_input")
            )
            if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { onSearchQueryChanged("") }) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Clear Search",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun CategoriesRow(
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    val categories = listOf("All", "Tech Reviews", "Cinematic Arts", "Sintel", "Adventure", "Vlogs", "Blender Studio")

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .padding(vertical = 8.dp),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories) { category ->
            val isSelected = category == selectedCategory
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.onBackground
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .clickable { onCategorySelected(category) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = category,
                    color = if (isSelected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun HomeFeedScreen(
    videos: List<LocalVideo>,
    isLoading: Boolean,
    permissionGranted: Boolean?,
    onVideoClick: (LocalVideo) -> Unit,
    onRequestPermission: () -> Unit,
    onAddToPlaylist: (LocalVideo) -> Unit,
    onToggleWatchLater: (LocalVideo, Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = MaterialTheme.colorScheme.primary
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // Permission Request Card if not granted
                if (permissionGranted == false) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SdCard,
                                    contentDescription = "Permission Storage",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Missing Media Permission",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "To scan and play your internal storage video files, allow media permissions. Falling back to streamable files for now.",
                                    fontSize = 13.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = onRequestPermission,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("Grant Permission", color = Color.White)
                                }
                            }
                        }
                    }
                }

                if (videos.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 100.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VideoLabel,
                                contentDescription = "No videos",
                                tint = Color.Gray,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No local videos found",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                } else {
                    items(videos) { video ->
                        VideoCard(
                            video = video,
                            onClick = { onVideoClick(video) },
                            onAddToPlaylist = { onAddToPlaylist(video) },
                            onToggleWatchLater = { onToggleWatchLater(video, it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VideoCard(
    video: LocalVideo,
    onClick: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onToggleWatchLater: (Boolean) -> Unit
) {
    var expandedMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(bottom = 16.dp)
    ) {
        // Thumbnail box (16:9)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(Color.DarkGray)
        ) {
            VideoThumbnailImage(video = video, modifier = Modifier.fillMaxSize())

            // Video duration overlay bottom right
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = formatDuration(video.duration),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Local Tag Badge
            if (video.isLocal) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.9f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "LOCAL FILE",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Details Section (Avatar, title, options)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Channel avatar
            AsyncImage(
                model = video.channelAvatarUrl,
                contentDescription = "Uploader Avatar",
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
            )

            // Title + Metadata
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = video.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "${video.uploader}  •  ${video.views}  •  ${video.uploadTime}",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Options menu button
            Box {
                IconButton(
                    onClick = { expandedMenu = true },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.MoreVert,
                        contentDescription = "Options",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }

                DropdownMenu(
                    expanded = expandedMenu,
                    onDismissRequest = { expandedMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Watch Later") },
                        leadingIcon = { Icon(Icons.Outlined.WatchLater, contentDescription = null) },
                        onClick = {
                            onToggleWatchLater(true)
                            expandedMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Save to Playlist") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Outlined.PlaylistAdd, contentDescription = null) },
                        onClick = {
                            onAddToPlaylist()
                            expandedMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Share Link") },
                        leadingIcon = { Icon(Icons.Outlined.Share, contentDescription = null) },
                        onClick = { expandedMenu = false }
                    )
                }
            }
        }
    }
}

object ThumbnailCache {
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Bitmap>()

    suspend fun getThumbnail(context: Context, videoPath: String): Bitmap? {
        cache[videoPath]?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val fileUri = Uri.parse(videoPath)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val bitmap = context.contentResolver.loadThumbnail(
                        fileUri,
                        Size(320, 180),
                        null
                    )
                    cache[videoPath] = bitmap
                    bitmap
                } else {
                    null
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}

@Composable
fun VideoThumbnailImage(
    video: LocalVideo,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var bitmapState by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(video.path) {
        if (video.isLocal) {
            val cached = ThumbnailCache.getThumbnail(context, video.path)
            if (cached != null) {
                bitmapState = cached
            }
        }
    }

    if (video.isLocal && bitmapState != null) {
        Image(
            bitmap = bitmapState!!.asImageBitmap(),
            contentDescription = "Local Thumbnail",
            modifier = modifier,
            contentScale = ContentScale.Crop
        )
    } else {
        // For online fallback videos, render beautiful high-fidelity abstract backgrounds if coil doesn't load immediately
        val isFirstWord = video.title.split(" ").firstOrNull() ?: "ViewTube"
        Box(
            modifier = modifier
                .drawBehind {
                    val color1 = Color(Math.abs(isFirstWord.hashCode() + 10) % 256, Math.abs(isFirstWord.hashCode() + 100) % 256, Math.abs(isFirstWord.hashCode() + 180) % 256)
                    val color2 = Color(Math.abs(isFirstWord.hashCode() + 130) % 256, Math.abs(isFirstWord.hashCode() + 40) % 256, Math.abs(isFirstWord.hashCode() + 210) % 256)
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(color1, color2),
                            start = Offset(0f, 0f),
                            end = Offset(size.width, size.height)
                        )
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            // Icon backdrop overlay
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayCircleFilled,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }
    }
}

@Composable
fun YouTubeBottomNavigationBar(
    currentTab: YouTubeTab,
    onTabSelected: (YouTubeTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        NavigationBarItem(
            selected = currentTab == YouTubeTab.HOME,
            onClick = { onTabSelected(YouTubeTab.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentTab == YouTubeTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = { Text("Home", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_home")
        )
        NavigationBarItem(
            selected = currentTab == YouTubeTab.SHORTS,
            onClick = { onTabSelected(YouTubeTab.SHORTS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == YouTubeTab.SHORTS) Icons.Filled.PlayCircleFilled else Icons.Outlined.PlayCircle,
                    contentDescription = "Shorts"
                )
            },
            label = { Text("Shorts", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_shorts")
        )
        NavigationBarItem(
            selected = currentTab == YouTubeTab.SUBSCRIPTIONS,
            onClick = { onTabSelected(YouTubeTab.SUBSCRIPTIONS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == YouTubeTab.SUBSCRIPTIONS) Icons.Filled.Subscriptions else Icons.Outlined.Subscriptions,
                    contentDescription = "Subscriptions"
                )
            },
            label = { Text("Subscriptions", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_subscriptions")
        )
        NavigationBarItem(
            selected = currentTab == YouTubeTab.LIBRARY,
            onClick = { onTabSelected(YouTubeTab.LIBRARY) },
            icon = {
                Icon(
                    imageVector = if (currentTab == YouTubeTab.LIBRARY) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                    contentDescription = "Library"
                )
            },
            label = { Text("You", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_library")
        )
    }
}

@Composable
fun ShortsScreen(
    videos: List<LocalVideo>,
    onBack: () -> Unit
) {
    // Filter down to shorter videos, or use general videos for swipe feed if none are short
    val shorts = remember(videos) {
        val filtered = videos.filter { it.duration < 180000 || it.duration == 15000L }
        if (filtered.isEmpty()) videos else filtered
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (shorts.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = Color.Red,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "No Short Videos Found",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Import local media under 3 minutes or check connection.",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) {
                    Text("Go Home Feed", color = Color.White)
                }
            }
        } else {
            val pagerState = rememberPagerState(pageCount = { shorts.size })

            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { pageIndex ->
                val activeShort = shorts[pageIndex]
                var isLiked by remember(activeShort.id) { mutableStateOf(false) }

                Box(modifier = Modifier.fillMaxSize()) {
                    val isPageActive = pagerState.currentPage == pageIndex

                    if (isPageActive) {
                        VideoPlayerView(
                            videoPath = activeShort.path,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        VideoThumbnailImage(
                            video = activeShort,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Top bar layout
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Shorts",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = {}) {
                            Icon(imageVector = Icons.Filled.CameraAlt, contentDescription = "Camera", tint = Color.White)
                        }
                    }

                    // Bottom Left Title Info
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                            .padding(bottom = 20.dp)
                            .fillMaxWidth(0.75f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color.Red),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(activeShort.uploader.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "@${activeShort.uploader.lowercase().replace(" ", "")}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Red)
                                    .clickable {}
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("SUBSCRIBE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = activeShort.title,
                            color = Color.White,
                            fontSize = 14.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Right Floating Icons Pane (Likes, comments, shares, etc.)
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                            .padding(bottom = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Like button
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = { isLiked = !isLiked },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                                    contentDescription = "Like",
                                    tint = if (isLiked) Color.Red else Color.White
                                )
                            }
                            Text(text = if (isLiked) "12K" else "11K", color = Color.White, fontSize = 12.sp)
                        }

                        // Dislike button
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = {},
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(imageVector = Icons.Outlined.ThumbDown, contentDescription = "Dislike", tint = Color.White)
                            }
                            Text(text = "Dislike", color = Color.White, fontSize = 12.sp)
                        }

                        // Comments button
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = {},
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.Comment, contentDescription = "Comments", tint = Color.White)
                            }
                            Text(text = "187", color = Color.White, fontSize = 12.sp)
                        }

                        // Share button
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = {},
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(imageVector = Icons.Filled.Share, contentDescription = "Share", tint = Color.White)
                            }
                            Text(text = "Share", color = Color.White, fontSize = 12.sp)
                        }

                        // Sound Track spinning record
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .border(2.dp, Color.White, CircleShape)
                                .padding(2.dp)
                                .background(Color.DarkGray, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Filled.MusicNote, contentDescription = "Sound Track", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubscriptionsScreen(
    onExploreClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.Subscriptions,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(80.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Your Subscriptions Feed",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Channels you subscribe to will list their uploads right here.",
            color = Color.Gray,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = onExploreClick,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Text("Explore Channels", color = Color.White)
        }
    }
}

@Composable
fun LibraryScreen(
    viewModel: VideoViewModel,
    onVideoClick: (LocalVideo) -> Unit
) {
    val history by viewModel.watchHistory.collectAsStateWithLifecycle()
    val liked by viewModel.likedVideos.collectAsStateWithLifecycle()
    val watchLater by viewModel.watchLaterVideos.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 80.dp)
    ) {
        // Watch history horizontal rail
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("History", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                if (history.isNotEmpty()) {
                    TextButton(onClick = { viewModel.clearWatchHistory() }) {
                        Text("Clear All", color = Color.Red, fontSize = 13.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            if (history.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No watch history", color = Color.Gray, fontSize = 14.sp)
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(history) { record ->
                        HistoryVideoItem(
                            record = record,
                            onClick = {
                                val dummyVideo = LocalVideo(
                                    id = record.videoPath.hashCode().toLong(),
                                    title = record.title,
                                    duration = record.duration,
                                    size = record.size,
                                    path = record.videoPath,
                                    resolution = "1080p",
                                    dateAdded = record.timestamp / 1000,
                                    views = "History",
                                    uploader = "My Media",
                                    uploadTime = "Watched",
                                    channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=MyMedia",
                                    isLocal = !record.videoPath.startsWith("http")
                                )
                                onVideoClick(dummyVideo)
                            }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Playlists Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.List, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Playlists", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            if (playlists.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No custom playlists", color = Color.Gray, fontSize = 14.sp)
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    playlists.forEach { playlist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                .clickable {}
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Outlined.List, contentDescription = null, tint = Color.Gray)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(playlist.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                    Text("Playlist Folder", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                            IconButton(onClick = { viewModel.deletePlaylist(playlist.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete Playlist", tint = Color.Red)
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Auxiliary folders (Liked, Watch Later)
        item {
            LibraryRowFolder(
                icon = Icons.Filled.ThumbUp,
                title = "Liked Videos",
                count = liked.size,
                onClick = {}
            )
            Spacer(modifier = Modifier.height(10.dp))
            LibraryRowFolder(
                icon = Icons.Filled.WatchLater,
                title = "Watch Later",
                count = watchLater.size,
                onClick = {}
            )
        }
    }
}

@Composable
fun LibraryRowFolder(
    icon: ImageVector,
    title: String,
    count: Int,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "$count videos", color = Color.Gray, fontSize = 13.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Icon(imageVector = Icons.Filled.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}

@Composable
fun HistoryVideoItem(
    record: WatchHistoryEntity,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(140.dp)
            .clickable { onClick() }
    ) {
        // Mock horizontal card thumbnail placeholder
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.DarkGray),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = record.title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "Watch History",
            fontSize = 11.sp,
            color = Color.Gray
        )
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun VideoPlayerView(
    videoPath: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            val mediaItem = MediaItem.fromUri(videoPath)
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
            repeatMode = Player.REPEAT_MODE_ONE // support looping for continuous plays
        }
    }

    // Handle path shifts dynamically
    LaunchedEffect(videoPath) {
        val mediaItem = MediaItem.fromUri(videoPath)
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
        }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = exoPlayer
                useController = true
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        modifier = modifier
    )
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun SharedVideoPlayerView(
    exoPlayer: ExoPlayer,
    modifier: Modifier = Modifier,
    useController: Boolean = true
) {
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = exoPlayer
                this.useController = useController
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        update = { view ->
            view.useController = useController
        },
        modifier = modifier
    )
}

@Composable
fun SlidingVideoPlayerSheet(
    video: LocalVideo,
    isExpanded: Boolean,
    onCollapse: () -> Unit,
    onClose: () -> Unit,
    viewModel: VideoViewModel,
    allVideos: List<LocalVideo>
) {
    val comments by viewModel.activeComments.collectAsStateWithLifecycle()
    val isLiked by viewModel.isVideoLiked(video.path).collectAsStateWithLifecycle(initialValue = false)
    val isInWatchLater by viewModel.isVideoInWatchLater(video.path).collectAsStateWithLifecycle(initialValue = false)

    var showCommentsSheet by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isExpanded) MaterialTheme.colorScheme.background else Color.Transparent)
            .testTag("video_player_drawer")
    ) {
        if (isExpanded) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Player area (16:9 ratio)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color.Black)
                ) {
                    SharedVideoPlayerView(
                        exoPlayer = viewModel.getOrCreatePlayer(),
                        modifier = Modifier.fillMaxSize()
                    )

                    // Minimal chevron down collapse icon
                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(imageVector = Icons.Filled.KeyboardArrowDown, contentDescription = "Minimize Player", tint = Color.White)
                    }
                }

                // Scrollable metadata and description area below player
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    // Title and statistics block
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Text(
                                text = video.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onBackground,
                                lineHeight = 22.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${video.views}  •  ${video.uploadTime}",
                                fontSize = 13.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    // Quick Action button bar (Like, Watch Later, Share, download)
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 14.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            ActionButton(
                                icon = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                                label = if (isLiked) "Liked" else "Like",
                                active = isLiked,
                                onClick = { viewModel.toggleLike(video, isLiked) }
                            )
                            ActionButton(
                                icon = if (isInWatchLater) Icons.Filled.WatchLater else Icons.Outlined.WatchLater,
                                label = if (isInWatchLater) "Saved" else "Save Later",
                                active = isInWatchLater,
                                onClick = { viewModel.toggleWatchLater(video, isInWatchLater) }
                            )
                            ActionButton(
                                icon = Icons.Outlined.Share,
                                label = "Share",
                                onClick = {}
                            )
                            ActionButton(
                                icon = Icons.Outlined.Download,
                                label = "Download",
                                onClick = {}
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                    }

                    // Uploader details block
                    item {
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = video.channelAvatarUrl,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.Gray)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(video.uploader, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text("1.2M subscribers", color = Color.Gray, fontSize = 12.sp)
                                }
                            }

                            Button(
                                onClick = {},
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onBackground)
                            ) {
                                Text(
                                    "SUBSCRIBE",
                                    color = MaterialTheme.colorScheme.background,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    }

                    // Comments section preview box
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showCommentsSheet = true }
                                .padding(14.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Comments  •  ${comments.size}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color.Gray)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            if (comments.isEmpty()) {
                                Text("No comments yet. Tap to start the discussion!", fontSize = 13.sp, color = Color.Gray)
                            } else {
                                val topComment = comments.first()
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(Color.Gray),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(topComment.author.take(1), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = topComment.text,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    // Up Next Video List
                    item {
                        Text(
                            text = "Up Next",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }

                    val upNext = allVideos.filter { it.path != video.path }
                    items(upNext) { nextVid ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.playVideo(nextVid) }
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(120.dp)
                                    .aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.DarkGray)
                            ) {
                                VideoThumbnailImage(video = nextVid, modifier = Modifier.fillMaxSize())
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = nextVid.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${nextVid.uploader}  •  ${nextVid.views}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Minimized slim floating video player bar (above Navigation tab)
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(64.dp)
                    .clickable { onCollapse() }
                    .padding(horizontal = 10.dp),
                shadowElevation = 8.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        // Tiny thumbnail preview
                        Box(
                            modifier = Modifier
                                .size(70.dp, 40.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black)
                        ) {
                            SharedVideoPlayerView(
                                exoPlayer = viewModel.getOrCreatePlayer(),
                                modifier = Modifier.fillMaxSize(),
                                useController = false
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = video.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = video.uploader,
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Row {
                        val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
                        IconButton(onClick = { viewModel.togglePlayPause() }) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        IconButton(onClick = onClose) {
                            Icon(imageVector = Icons.Filled.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }

        // Full Custom Comments Bottom Sheet
        if (showCommentsSheet) {
            CommentsDialog(
                comments = comments,
                onDismiss = { showCommentsSheet = false }
            )
        }
    }
}

@Composable
fun ActionButton(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surfaceVariant
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 13.sp,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun CommentsDialog(
    comments: List<MockComment>,
    onDismiss: () -> Unit
) {
    var newCommentText by remember { mutableStateOf("") }
    val localComments = remember { mutableStateListOf<MockComment>().apply { addAll(comments) } }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header of dialog
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Comments", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Dismiss Comments")
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                // Scrollable Comments lists
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 14.dp),
                    contentPadding = PaddingValues(vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(localComments) { comment ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color.Gray),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(comment.author.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("@${comment.author.lowercase()}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(comment.timeRelative, color = Color.Gray, fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(comment.text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.ThumbUp, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${comment.likesCount}", fontSize = 11.sp, color = Color.Gray)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Icon(Icons.Outlined.ThumbDown, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                // Public input field
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = newCommentText,
                        onValueChange = { newCommentText = it },
                        placeholder = { Text("Add a public comment...", fontSize = 14.sp) },
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (newCommentText.isNotBlank()) {
                                localComments.add(
                                    0,
                                    MockComment(
                                        author = "You",
                                        avatarUrl = "",
                                        text = newCommentText,
                                        likesCount = 0,
                                        timeRelative = "Just now"
                                    )
                                )
                                newCommentText = ""
                            }
                        },
                        enabled = newCommentText.isNotBlank()
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send Comment",
                            tint = if (newCommentText.isNotBlank()) MaterialTheme.colorScheme.primary else Color.Gray
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistSelectionDialog(
    video: LocalVideo,
    viewModel: VideoViewModel,
    onDismiss: () -> Unit,
    onCreateNewPlaylist: () -> Unit
) {
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Save to Playlist",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                if (playlists.isEmpty()) {
                    Text("No playlists found. Create one to organize your videos!", color = Color.Gray, fontSize = 14.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        playlists.forEach { playlist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.addVideoToPlaylist(playlist.id, video)
                                        onDismiss()
                                    }
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.AutoMirrored.Filled.List, contentDescription = null, tint = Color.Gray)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(playlist.name, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onCreateNewPlaylist) {
                        Text("+ New Playlist", color = MaterialTheme.colorScheme.primary)
                    }
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun CreatePlaylistDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var playlistName by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Create New Playlist", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(modifier = Modifier.height(12.dp))
                TextField(
                    value = playlistName,
                    onValueChange = { playlistName = it },
                    placeholder = { Text("Playlist name...") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { onConfirm(playlistName) },
                        enabled = playlistName.isNotBlank()
                    ) {
                        Text("Create")
                    }
                }
            }
        }
    }
}

// Utility formatting functions
fun formatDuration(durationMs: Long): String {
    if (durationMs <= 0) return "0:00"
    val totalSecs = durationMs / 1000
    val hours = totalSecs / 3600
    val minutes = (totalSecs % 3600) / 60
    val seconds = totalSecs % 60

    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%d:%02d", minutes, seconds)
    }
}
