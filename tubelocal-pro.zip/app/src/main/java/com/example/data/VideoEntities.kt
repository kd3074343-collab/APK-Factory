package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val videoPath: String,
    val title: String,
    val duration: Long,
    val size: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "liked_videos")
data class LikedVideoEntity(
    @PrimaryKey val videoPath: String,
    val title: String,
    val duration: Long,
    val size: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_later")
data class WatchLaterEntity(
    @PrimaryKey val videoPath: String,
    val title: String,
    val duration: Long,
    val size: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_videos")
data class PlaylistVideoEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val playlistId: Int,
    val videoPath: String,
    val title: String,
    val duration: Long,
    val size: Long,
    val timestamp: Long = System.currentTimeMillis()
)
