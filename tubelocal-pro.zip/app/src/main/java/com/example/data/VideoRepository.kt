package com.example.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

data class LocalVideo(
    val id: Long,
    val title: String,
    val duration: Long,
    val size: Long,
    val path: String,
    val resolution: String?,
    val dateAdded: Long,
    val views: String,
    val uploader: String,
    val uploadTime: String,
    val channelAvatarUrl: String,
    val isLocal: Boolean = true,
    val description: String = "This is a video loaded from local device storage."
)

class VideoRepository(private val videoDao: VideoDao) {

    val watchHistory: Flow<List<WatchHistoryEntity>> = videoDao.getWatchHistory()
    val likedVideos: Flow<List<LikedVideoEntity>> = videoDao.getLikedVideos()
    val watchLater: Flow<List<WatchLaterEntity>> = videoDao.getWatchLater()
    val playlists: Flow<List<PlaylistEntity>> = videoDao.getPlaylists()

    fun isVideoLiked(path: String): Flow<Boolean> = videoDao.isVideoLiked(path)
    fun isVideoInWatchLater(path: String): Flow<Boolean> = videoDao.isVideoInWatchLater(path)
    fun getVideosForPlaylist(playlistId: Int): Flow<List<PlaylistVideoEntity>> = videoDao.getVideosForPlaylist(playlistId)

    suspend fun insertWatchHistory(video: LocalVideo) {
        videoDao.insertWatchHistory(
            WatchHistoryEntity(
                videoPath = video.path,
                title = video.title,
                duration = video.duration,
                size = video.size
            )
        )
    }

    suspend fun deleteWatchHistory(path: String) = videoDao.deleteWatchHistory(path)
    suspend fun clearWatchHistory() = videoDao.clearWatchHistory()

    suspend fun toggleLike(video: LocalVideo, shouldLike: Boolean) {
        if (shouldLike) {
            videoDao.insertLikedVideo(
                LikedVideoEntity(
                    videoPath = video.path,
                    title = video.title,
                    duration = video.duration,
                    size = video.size
                )
            )
        } else {
            videoDao.deleteLikedVideo(video.path)
        }
    }

    suspend fun toggleWatchLater(video: LocalVideo, inWatchLater: Boolean) {
        if (inWatchLater) {
            videoDao.insertWatchLater(
                WatchLaterEntity(
                    videoPath = video.path,
                    title = video.title,
                    duration = video.duration,
                    size = video.size
                )
            )
        } else {
            videoDao.deleteWatchLater(video.path)
        }
    }

    suspend fun createPlaylist(name: String): Long {
        return videoDao.insertPlaylist(PlaylistEntity(name = name))
    }

    suspend fun deletePlaylist(playlistId: Int) {
        videoDao.deleteVideosInPlaylist(playlistId)
        videoDao.deletePlaylist(playlistId)
    }

    suspend fun addVideoToPlaylist(playlistId: Int, video: LocalVideo) {
        videoDao.insertPlaylistVideo(
            PlaylistVideoEntity(
                playlistId = playlistId,
                videoPath = video.path,
                title = video.title,
                duration = video.duration,
                size = video.size
            )
        )
    }

    suspend fun removeVideoFromPlaylist(playlistId: Int, videoPath: String) {
        videoDao.deleteVideoFromPlaylist(playlistId, videoPath)
    }

    suspend fun loadLocalAndRemoteVideos(context: Context): List<LocalVideo> = withContext(Dispatchers.IO) {
        val localList = mutableListOf<LocalVideo>()
        val contentResolver = context.contentResolver

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.RESOLUTION,
            MediaStore.Video.Media.DATE_ADDED
        )

        try {
            val cursor: Cursor? = contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )

            cursor?.use { c ->
                val idColumn = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameColumn = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationColumn = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeColumn = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val pathColumn = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val resolutionColumn = c.getColumnIndexOrThrow(MediaStore.Video.Media.RESOLUTION)
                val dateAddedColumn = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

                while (c.moveToNext()) {
                    val id = c.getLong(idColumn)
                    val displayName = c.getString(nameColumn) ?: "Video_$id"
                    val duration = c.getLong(durationColumn)
                    val size = c.getLong(sizeColumn)
                    val path = c.getString(pathColumn) ?: ""
                    val resolution = c.getString(resolutionColumn)
                    val dateAdded = c.getLong(dateAddedColumn)

                    val cleanTitle = if (displayName.contains(".")) {
                        displayName.substringBeforeLast(".")
                    } else {
                        displayName
                    }

                    val uploader = getCleanUploaderName(path, cleanTitle)
                    val viewsCount = generateViewsCount(id, size)
                    val relativeTime = getRelativeDate(dateAdded)

                    localList.add(
                        LocalVideo(
                            id = id,
                            title = cleanTitle,
                            duration = duration,
                            size = size,
                            path = path,
                            resolution = resolution,
                            dateAdded = dateAdded,
                            views = viewsCount,
                            uploader = uploader,
                            uploadTime = relativeTime,
                            channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=$uploader",
                            isLocal = true,
                            description = "Local file path: $path\nSize: ${formatFileSize(size)}"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Always append remote fallback videos so there is an awesome ready-to-play set of videos!
        val remoteList = getRemoteFallbackVideos()

        // Combine them: Local first, then remote fallbacks
        localList + remoteList
    }

    private fun getCleanUploaderName(path: String, title: String): String {
        if (path.isNotEmpty()) {
            val file = File(path)
            val parentName = file.parentFile?.name ?: ""
            if (parentName.isNotEmpty() && parentName != "0" && parentName != "emulated") {
                return parentName
            }
        }
        val creators = listOf(
            "RetroTech Reviews",
            "Wanderlust Diaries",
            "Creative Canvas",
            "The Cinephile",
            "MKBHD Enthusiast",
            "Fireside Coding",
            "Nature Symphony",
            "AeroVlogs"
        )
        val index = Math.abs(title.hashCode()) % creators.size
        return creators[index]
    }

    private fun generateViewsCount(id: Long, size: Long): String {
        val viewsSeed = Math.abs(id xor size) % 1000
        return when {
            viewsSeed > 800 -> "${viewsSeed / 100.0}M views"
            viewsSeed > 300 -> "${viewsSeed}K views"
            else -> "${viewsSeed + 10}K views"
        }
    }

    private fun getRelativeDate(dateAddedSec: Long): String {
        if (dateAddedSec == 0L) return "1 week ago"
        val nowSec = System.currentTimeMillis() / 1000
        val diffSec = nowSec - dateAddedSec
        if (diffSec < 0) return "Just now"

        val minutes = diffSec / 60
        val hours = minutes / 60
        val days = hours / 24
        val months = days / 30
        val years = months / 12

        return when {
            years > 0 -> if (years == 1L) "1 year ago" else "$years years ago"
            months > 0 -> if (months == 1L) "1 month ago" else "$months months ago"
            days > 0 -> if (days == 1L) "1 day ago" else "$days days ago"
            hours > 0 -> if (hours == 1L) "1 hour ago" else "$hours hours ago"
            minutes > 0 -> if (minutes == 1L) "1 minute ago" else "$minutes minutes ago"
            else -> "Just now"
        }
    }

    private fun formatFileSize(size: Long): String {
        if (size <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.2f %s", size / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }

    private fun getRemoteFallbackVideos(): List<LocalVideo> {
        return listOf(
            LocalVideo(
                id = -1,
                title = "Exploring the Forest: Ultimate Big Buck Bunny Cinematic",
                duration = 596000,
                size = 27610000,
                path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                resolution = "1920x1080",
                dateAdded = System.currentTimeMillis() / 1000 - 86400 * 3,
                views = "1.8M views",
                uploader = "Blender Studio",
                uploadTime = "3 days ago",
                channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=BlenderStudio",
                isLocal = false,
                description = "Big Buck Bunny tells the story of a giant rabbit with a heart bigger than himself. When one sunny day three rodents rudely harass him, something snaps... and the rabbit decides to take revenge in a series of hilarious traps."
            ),
            LocalVideo(
                id = -2,
                title = "Elephant's Dream - First Ever Open Movie Project Showcase",
                duration = 653000,
                size = 35100000,
                path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                resolution = "1920x1080",
                dateAdded = System.currentTimeMillis() / 1000 - 86400 * 30,
                views = "954K views",
                uploader = "Orange Open Movie",
                uploadTime = "1 month ago",
                channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=OrangeOpen",
                isLocal = false,
                description = "Elephants Dream is the world’s first open movie, made entirely with open-source 3D graphics software Blender. This story centers on Proog and Emo, two characters exploring a surreal, giant industrial mechanism."
            ),
            LocalVideo(
                id = -3,
                title = "Epic Sintel: High Fantasy Animation Trailer",
                duration = 52000,
                size = 6200000,
                path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                resolution = "1280x720",
                dateAdded = System.currentTimeMillis() / 1000 - 86400 * 2,
                views = "4.2M views",
                uploader = "Durian Project",
                uploadTime = "2 days ago",
                channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=DurianProject",
                isLocal = false,
                description = "The official cinematic trailer for Sintel, an independent open-source fantasy film made by the Blender Foundation."
            ),
            LocalVideo(
                id = -4,
                title = "Tears of Steel: Sci-Fi Visual Effects & CGI Mastery",
                duration = 734000,
                size = 48500000,
                path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                resolution = "1920x1080",
                dateAdded = System.currentTimeMillis() / 1000 - 86400 * 120,
                views = "312K views",
                uploader = "Mango VFX Lab",
                uploadTime = "4 months ago",
                channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=MangoVFX",
                isLocal = false,
                description = "Tears of Steel was realized in Amsterdam, Netherlands. It showcases how open-source technology can be utilized in top-tier science fiction filmmaking with live-action integration."
            ),
            LocalVideo(
                id = -5,
                title = "Off-Road Wilderness Adventure: Subaru Outback Chronicles",
                duration = 150000,
                size = 12000000,
                path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
                resolution = "1280x720",
                dateAdded = System.currentTimeMillis() / 1000 - 86400 * 7,
                views = "45K views",
                uploader = "Overland Journeys",
                uploadTime = "1 week ago",
                channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=Overland",
                isLocal = false,
                description = "Take a scenic journey from paved highway roads straight into the rugged, beautiful mountain passes. Testing the suspension, grip, and traction control under rough forest conditions."
            ),
            LocalVideo(
                id = -6,
                title = "For Bigger Escapes: A Relaxing Scenic Travel Short",
                duration = 15000,
                size = 1800000,
                path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                resolution = "1920x1080",
                dateAdded = System.currentTimeMillis() / 1000 - 86400,
                views = "11M views",
                uploader = "Wanderlust Vibe",
                uploadTime = "1 day ago",
                channelAvatarUrl = "https://api.dicebear.com/7.x/initials/svg?seed=Wanderlust",
                isLocal = false,
                description = "Escape from the hustle and bustle of city life with these gorgeous cinematic drone sequences over clear lake waters and mountain ranges."
            )
        )
    }
}
