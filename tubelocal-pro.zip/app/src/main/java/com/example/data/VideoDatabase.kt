package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    // Watch History
    @Query("SELECT * FROM watch_history ORDER BY timestamp DESC")
    fun getWatchHistory(): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchHistory(history: WatchHistoryEntity)

    @Query("DELETE FROM watch_history WHERE videoPath = :videoPath")
    suspend fun deleteWatchHistory(videoPath: String)

    @Query("DELETE FROM watch_history")
    suspend fun clearWatchHistory()

    // Liked Videos
    @Query("SELECT * FROM liked_videos ORDER BY timestamp DESC")
    fun getLikedVideos(): Flow<List<LikedVideoEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM liked_videos WHERE videoPath = :videoPath)")
    fun isVideoLiked(videoPath: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLikedVideo(liked: LikedVideoEntity)

    @Query("DELETE FROM liked_videos WHERE videoPath = :videoPath")
    suspend fun deleteLikedVideo(videoPath: String)

    // Watch Later
    @Query("SELECT * FROM watch_later ORDER BY timestamp DESC")
    fun getWatchLater(): Flow<List<WatchLaterEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM watch_later WHERE videoPath = :videoPath)")
    fun isVideoInWatchLater(videoPath: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchLater(watchLater: WatchLaterEntity)

    @Query("DELETE FROM watch_later WHERE videoPath = :videoPath")
    suspend fun deleteWatchLater(videoPath: String)

    // Playlists
    @Query("SELECT * FROM playlists ORDER BY timestamp DESC")
    fun getPlaylists(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Int)

    @Query("DELETE FROM playlist_videos WHERE playlistId = :playlistId")
    suspend fun deleteVideosInPlaylist(playlistId: Int)

    // Playlist Videos
    @Query("SELECT * FROM playlist_videos WHERE playlistId = :playlistId ORDER BY timestamp DESC")
    fun getVideosForPlaylist(playlistId: Int): Flow<List<PlaylistVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistVideo(playlistVideo: PlaylistVideoEntity)

    @Query("DELETE FROM playlist_videos WHERE playlistId = :playlistId AND videoPath = :videoPath")
    suspend fun deleteVideoFromPlaylist(playlistId: Int, videoPath: String)
}

@Database(
    entities = [
        WatchHistoryEntity::class,
        LikedVideoEntity::class,
        WatchLaterEntity::class,
        PlaylistEntity::class,
        PlaylistVideoEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class VideoDatabase : RoomDatabase() {
    abstract fun videoDao(): VideoDao

    companion object {
        @Volatile
        private var INSTANCE: VideoDatabase? = null

        fun getDatabase(context: Context): VideoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VideoDatabase::class.java,
                    "viewtube_database"
                )
                .fallbackToDestructiveMigration(dropAllTables = true)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
