package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val calculatorViewModel: CalculatorViewModel = viewModel()
            val darkModeEnabled by calculatorViewModel.darkModeEnabled.collectAsStateWithLifecycle()

            MyApplicationTheme(darkTheme = darkModeEnabled) {
                CalculatorScreen(viewModel = calculatorViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(viewModel: CalculatorViewModel) {
    // Collect flows lifecycle-awarely to prevent performance issues and leaks when backgrounded
    val displayText by viewModel.displayText.collectAsStateWithLifecycle()
    val expressionText by viewModel.expressionText.collectAsStateWithLifecycle()
    val vibrationEnabled by viewModel.vibrationEnabled.collectAsStateWithLifecycle()
    val darkModeEnabled by viewModel.darkModeEnabled.collectAsStateWithLifecycle()

    val haptic = LocalHapticFeedback.current
    var showSettings by remember { mutableStateOf(false) }

    // Optimization: Cache and remember all button press click lambdas
    // This stops Compose from re-instantiating callback closures on every display text updates,
    // which eliminates micro-stutters and input lags during fast typing.
    val onClearClick = remember(viewModel, vibrationEnabled) {
        {
            if (vibrationEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            viewModel.onClearPressed()
        }
    }

    val onBackspaceClick = remember(viewModel, vibrationEnabled) {
        {
            if (vibrationEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            viewModel.onBackspacePressed()
        }
    }

    val onPercentageClick = remember(viewModel, vibrationEnabled) {
        {
            if (vibrationEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            viewModel.onPercentagePressed()
        }
    }

    val onOperatorClick = remember(viewModel, vibrationEnabled) {
        { operator: String ->
            if (vibrationEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            viewModel.onOperatorPressed(operator)
        }
    }

    val onDigitClick = remember(viewModel, vibrationEnabled) {
        { digit: String ->
            if (vibrationEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            viewModel.onDigitPressed(digit)
        }
    }

    val onDecimalClick = remember(viewModel, vibrationEnabled) {
        {
            if (vibrationEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            viewModel.onDecimalPressed()
        }
    }

    val onEqualsClick = remember(viewModel, vibrationEnabled) {
        {
            if (vibrationEnabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            viewModel.onEqualsPressed()
        }
    }

    val acBg = if (darkModeEnabled) SleekDarkAcBg else SleekLightAcBg
    val acText = if (darkModeEnabled) SleekDarkAcText else SleekLightAcText

    val auxBg = if (darkModeEnabled) SleekDarkAuxBg else SleekLightAuxBg
    val auxText = if (darkModeEnabled) SleekDarkAuxText else SleekLightAuxText

    val opBg = if (darkModeEnabled) SleekDarkOpBg else SleekLightOpBg
    val opText = if (darkModeEnabled) SleekDarkOpText else SleekLightOpText

    val digitBg = if (darkModeEnabled) SleekDarkDigitBg else SleekLightDigitBg
    val digitText = if (darkModeEnabled) SleekDarkDigitText else SleekLightDigitText

    val equalsBg = if (darkModeEnabled) SleekDarkEqualsBg else SleekLightEqualsBg
    val equalsText = if (darkModeEnabled) SleekDarkEqualsText else SleekLightEqualsText

    val keypadContainerBg = if (darkModeEnabled) SleekDarkKeypadBg else SleekLightKeypadBg
    val textSecondary = if (darkModeEnabled) SleekDarkTextSecondary else SleekLightTextSecondary

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        // Adaptive Layout: Center contents on large screens/foldables/tablets
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .widthIn(max = 480.dp) // Beautiful maximum width to keep layouts centered and compact on landscape/tablets
                    .padding(innerPadding)
            ) {
                // Top Header + Display Area
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 24.dp)
                        .padding(top = 16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Calculator",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = (-0.5).sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                        IconButton(
                            onClick = {
                                if (vibrationEnabled) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                                showSettings = true
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("settings_button")
                        ) {
                            Text(
                                text = "⚙️",
                                fontSize = 24.sp
                            )
                        }
                    }

                    // Display Area
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 32.dp),
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.End
                    ) {
                        // Running Expression Display
                        Text(
                            text = expressionText,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Light,
                            color = textSecondary,
                            textAlign = TextAlign.End,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 4.dp)
                        )

                        // Main Digit Display
                        val fontSize = when {
                            displayText.length <= 6 -> 64.sp
                            displayText.length <= 9 -> 48.sp
                            displayText.length <= 12 -> 36.sp
                            else -> 28.sp
                        }
                        Text(
                            text = displayText,
                            fontSize = fontSize,
                            fontWeight = FontWeight.Normal,
                            letterSpacing = (-1.5).sp,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.End,
                            maxLines = 1,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("display_text")
                        )
                    }
                }

                // Keypad Container Box with rounded top corners and shadow
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp),
                    color = keypadContainerBg,
                    tonalElevation = 1.dp,
                    shadowElevation = if (darkModeEnabled) 16.dp else 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 20.dp, vertical = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Row 1: AC, ⌫, %, ÷
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val isClear = displayText != "0"
                            CalculatorButton(
                                text = if (isClear) "C" else "AC",
                                onClick = onClearClick,
                                backgroundColor = acBg,
                                contentColor = acText,
                                testTag = "button_ac",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "⌫",
                                onClick = onBackspaceClick,
                                backgroundColor = auxBg,
                                contentColor = auxText,
                                testTag = "button_backspace",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "%",
                                onClick = onPercentageClick,
                                backgroundColor = auxBg,
                                contentColor = auxText,
                                testTag = "button_percent",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "÷",
                                onClick = { onOperatorClick("÷") },
                                backgroundColor = opBg,
                                contentColor = opText,
                                testTag = "button_divide",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Row 2: 7, 8, 9, ×
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CalculatorButton(
                                text = "7",
                                onClick = { onDigitClick("7") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_7",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "8",
                                onClick = { onDigitClick("8") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_8",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "9",
                                onClick = { onDigitClick("9") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_9",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "×",
                                onClick = { onOperatorClick("×") },
                                backgroundColor = opBg,
                                contentColor = opText,
                                testTag = "button_multiply",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Row 3: 4, 5, 6, −
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CalculatorButton(
                                text = "4",
                                onClick = { onDigitClick("4") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_4",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "5",
                                onClick = { onDigitClick("5") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_5",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "6",
                                onClick = { onDigitClick("6") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_6",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "−",
                                onClick = { onOperatorClick("−") },
                                backgroundColor = opBg,
                                contentColor = opText,
                                testTag = "button_subtract",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Row 4: 1, 2, 3, +
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CalculatorButton(
                                text = "1",
                                onClick = { onDigitClick("1") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_1",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "2",
                                onClick = { onDigitClick("2") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_2",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "3",
                                onClick = { onDigitClick("3") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_3",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "+",
                                onClick = { onOperatorClick("+") },
                                backgroundColor = opBg,
                                contentColor = opText,
                                testTag = "button_add",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Row 5: 0, ., = (with = as weight(2f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CalculatorButton(
                                text = "0",
                                onClick = { onDigitClick("0") },
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_0",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = ".",
                                onClick = onDecimalClick,
                                backgroundColor = digitBg,
                                contentColor = digitText,
                                testTag = "button_decimal",
                                modifier = Modifier.weight(1f)
                            )
                            CalculatorButton(
                                text = "=",
                                onClick = onEqualsClick,
                                backgroundColor = equalsBg,
                                contentColor = equalsText,
                                testTag = "button_equals",
                                modifier = Modifier.weight(2f)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        SettingsBottomSheet(
            onDismissRequest = { showSettings = false },
            vibrationEnabled = vibrationEnabled,
            onVibrationToggle = { viewModel.toggleVibration() },
            darkModeEnabled = darkModeEnabled,
            onDarkModeToggle = { viewModel.toggleDarkMode() }
        )
    }
}

@Composable
fun CalculatorButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundColor: Color,
    contentColor: Color,
    testTag: String
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    // Performance Optimization: Defer the animation values read directly into layout/draw phase
    // using graphicsLayer rather than recomposing layout via .scale() modifier.
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "button_scale"
    )

    Card(
        modifier = modifier
            .padding(2.dp)
            .height(72.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp,
            pressedElevation = 0.dp
        )
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = interactionSource,
                    indication = LocalIndication.current,
                    onClick = onClick
                )
        ) {
            Text(
                text = text,
                fontSize = 24.sp,
                fontWeight = FontWeight.Medium,
                color = contentColor,
                textAlign = TextAlign.Center
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    onDismissRequest: () -> Unit,
    vibrationEnabled: Boolean,
    onVibrationToggle: () -> Unit,
    darkModeEnabled: Boolean,
    onDarkModeToggle: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.background,
        dragHandle = { BottomSheetDefaults.DragHandle(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 48.dp, top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Settings",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Vibration Row
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = if (darkModeEnabled) Color(0xFF1E2025) else Color(0xFFE1E2E9).copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Vibration",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Haptic feedback on button press",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = vibrationEnabled,
                        onCheckedChange = { onVibrationToggle() },
                        modifier = Modifier.testTag("vibration_toggle"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                            uncheckedThumbColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                            uncheckedTrackColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)
                        )
                    )
                }
            }

            // Dark Mode Row
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = if (darkModeEnabled) Color(0xFF1E2025) else Color(0xFFE1E2E9).copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Dark Mode",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Switch light or dark appearance",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = darkModeEnabled,
                        onCheckedChange = { onDarkModeToggle() },
                        modifier = Modifier.testTag("dark_mode_toggle"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                            uncheckedThumbColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                            uncheckedTrackColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f)
                        )
                    )
                }
            }
        }
    }
}
