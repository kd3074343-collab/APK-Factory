package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.AppRepository
import com.example.data.repository.OfflineDemoRepository
import com.example.data.repository.RepositoryProvider
import com.example.media.CallAudioManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository = RepositoryProvider.getRepository(application)
    private val audioManager = CallAudioManager(application)

    // Current Screens: "auth", "profile_setup", "app"
    private val _appScreenFlow = MutableStateFlow("auth")
    val appScreenFlow: StateFlow<String> = _appScreenFlow.asStateFlow()

    // Sub-sections of the App Bottom Nav: "home", "requests", "calls"
    private val _activeTabFlow = MutableStateFlow("home")
    val activeTabFlow: StateFlow<String> = _activeTabFlow.asStateFlow()

    // Slide Drawer visibility
    private val _isDrawerOpenFlow = MutableStateFlow(false)
    val isDrawerOpenFlow: StateFlow<Boolean> = _isDrawerOpenFlow.asStateFlow()

    // Overlay Dialogs: "profile_edit", "add_friend", "none"
    private val _activeDialogFlow = MutableStateFlow("none")
    val activeDialogFlow: StateFlow<String> = _activeDialogFlow.asStateFlow()

    // Active Chat Contact UID (Null if viewing list)
    private val _activeChatContactUid = MutableStateFlow<String?>(null)
    val activeChatContactUid: StateFlow<String?> = _activeChatContactUid.asStateFlow()

    // State flows mapped directly from repository
    val currentUserId: StateFlow<String?> = repository.currentUserIdFlow
    val currentUserProfile: StateFlow<UserProfile?> = repository.currentUserProfileFlow
    val contacts: StateFlow<List<ContactInfo>> = repository.contactsFlow
    val pendingRequests: StateFlow<List<FriendRequest>> = repository.pendingRequestsFlow
    val callLogs: StateFlow<List<CallLogEntry>> = repository.callLogsFlow
    val activeCall: StateFlow<CallSession?> = repository.activeCallFlow
    
    // Call UI State (Minimized floating glow banner vs fullscreen)
    val isCallMinimized = MutableStateFlow(false)

    // Auth screen states
    val isLiveFirebase = repository.isLiveFirebase
    var authEmail = MutableStateFlow("")
    var authPassword = MutableStateFlow("")
    var authIsSignUp = MutableStateFlow(false)
    var authError = MutableStateFlow<String?>(null)
    var authLoading = MutableStateFlow(false)

    // Profile Screen input states
    var profileNameInput = MutableStateFlow("")
    var profileBioInput = MutableStateFlow("")
    var profileEmojiInput = MutableStateFlow("")
    var profileLoading = MutableStateFlow(false)

    // Friends Screen search input
    var searchUserIdCode = MutableStateFlow("")
    var searchError = MutableStateFlow<String?>(null)
    var searchSuccess = MutableStateFlow<String?>(null)

    // Chat view inputs
    var chatMessageInput = MutableStateFlow("")
    private var typingJob: Job? = null

    // Monitor Calling States for Ringtone playing
    init {
        viewModelScope.launch {
            repository.activeCallFlow.collect { call ->
                if (call != null) {
                    val isReceiver = call.receiverId == repository.currentUserIdFlow.value
                    if (isReceiver && call.status == "ringing") {
                        audioManager.playRingtone()
                    } else if (call.status == "accepted" || call.status == "ended" || call.status == "rejected") {
                        audioManager.stopRingtone()
                    }
                } else {
                    audioManager.stopRingtone()
                    isCallMinimized.value = false
                }
            }
        }
    }

    // --- Authentication ---
    fun handleAuthAction() {
        val email = authEmail.value.trim()
        val password = authPassword.value.trim()

        if (email.isEmpty() || password.isEmpty()) {
            authError.value = "Email and Password cannot be empty."
            return
        }

        authLoading.value = true
        authError.value = null

        viewModelScope.launch {
            try {
                if (authIsSignUp.value) {
                    val result = repository.signUp(email, password)
                    if (result.isSuccess) {
                        _appScreenFlow.value = "profile_setup"
                    } else {
                        authError.value = result.exceptionOrNull()?.message ?: "Signup Failed"
                    }
                } else {
                    val result = repository.signIn(email, password)
                    if (result.isSuccess) {
                        val profile = result.getOrNull()
                        if (profile != null && profile.userId.isNotEmpty() && profile.name.isNotEmpty()) {
                            _appScreenFlow.value = "app"
                        } else {
                            _appScreenFlow.value = "profile_setup"
                        }
                    } else {
                        authError.value = result.exceptionOrNull()?.message ?: "Auth Failed"
                    }
                }
            } catch (e: Exception) {
                authError.value = e.message
            } finally {
                authLoading.value = false
            }
        }
    }

    fun handleProfileSetup() {
        val name = profileNameInput.value.trim()
        val bio = profileBioInput.value.trim()
        val emoji = profileEmojiInput.value.trim()

        if (name.isEmpty() || name.length > 20) {
            authError.value = "Name must be between 1 and 20 chars."
            return
        }
        if (bio.length > 100) {
            authError.value = "Bio cannot exceed 100 chars."
            return
        }
        if (emoji.isEmpty() || emoji.length > 2) {
            authError.value = "Pick 1 or 2 emoji chars."
            return
        }

        profileLoading.value = true
        viewModelScope.launch {
            val result = repository.setupProfile(name, bio, emoji)
            profileLoading.value = false
            if (result.isSuccess) {
                _appScreenFlow.value = "app"
            } else {
                authError.value = result.exceptionOrNull()?.message ?: "Setup Failed"
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.signOut()
            authEmail.value = ""
            authPassword.value = ""
            _appScreenFlow.value = "auth"
            _isDrawerOpenFlow.value = false
        }
    }

    // --- Bottom Tabs / Navigation UI ---
    fun setTab(tab: String) {
        _activeTabFlow.value = tab
    }

    fun toggleDrawer(open: Boolean) {
        _isDrawerOpenFlow.value = open
    }

    fun setDialog(dialog: String) {
        _activeDialogFlow.value = dialog
        searchError.value = null
        searchSuccess.value = null
        if (dialog == "profile_edit") {
            currentUserProfile.value?.let { p ->
                profileNameInput.value = p.name
                profileBioInput.value = p.bio
                profileEmojiInput.value = p.emoji
            }
        }
    }

    fun saveProfileEdit() {
        val name = profileNameInput.value.trim()
        val bio = profileBioInput.value.trim()
        val emoji = profileEmojiInput.value.trim()

        if (name.isEmpty() || name.length > 20) return
        if (bio.length > 100) return
        if (emoji.isEmpty() || emoji.length > 2) return

        viewModelScope.launch {
            repository.updateProfile(name, bio, emoji)
            setDialog("none")
        }
    }

    // --- Search & Request Friends ---
    fun submitFriendRequest() {
        val code = searchUserIdCode.value.trim()
        if (code.isEmpty()) {
            searchError.value = "Please enter a 4-digit code (ar-xxxx)."
            return
        }
        searchError.value = null
        searchSuccess.value = null

        viewModelScope.launch {
            val result = repository.sendFriendRequest(code)
            if (result.isSuccess) {
                searchSuccess.value = "Request sent successfully to $code!"
                searchUserIdCode.value = ""
            } else {
                searchError.value = result.exceptionOrNull()?.message ?: "Add friend failed."
            }
        }
    }

    fun acceptRequest(reqId: String) {
        viewModelScope.launch {
            repository.acceptFriendRequest(reqId)
        }
    }

    fun declineRequest(reqId: String) {
        viewModelScope.launch {
            repository.declineFriendRequest(reqId)
        }
    }

    // --- Chats ---
    fun setActiveChat(contactUid: String?) {
        _activeChatContactUid.value = contactUid
        chatMessageInput.value = ""
    }

    fun getActiveChatMessagesFlow(): Flow<List<ChatMessage>> {
        val uid = _activeChatContactUid.value ?: return emptyFlow()
        return repository.getMessagesFlow(uid)
    }

    fun getActiveChatTypingFlow(): Flow<Boolean> {
        val uid = _activeChatContactUid.value ?: return emptyFlow()
        return repository.getTypingFlow(uid)
    }

    fun onChatMessageChanged(txt: String) {
        chatMessageInput.value = txt
        val targetUid = _activeChatContactUid.value ?: return
        
        // Reset/Trigger typing timeouts (3 seconds duration indicator)
        typingJob?.cancel()
        viewModelScope.launch {
            repository.setTypingState(targetUid, true)
        }

        typingJob = viewModelScope.launch {
            delay(3000)
            repository.setTypingState(targetUid, false)
        }
    }

    fun sendChatMessage() {
        val contactUid = _activeChatContactUid.value ?: return
        val text = chatMessageInput.value.trim()
        if (text.isEmpty()) return

        chatMessageInput.value = ""
        typingJob?.cancel()
        
        viewModelScope.launch {
            repository.setTypingState(contactUid, false)
            repository.sendMessage(contactUid, text)
        }
    }

    fun clearActiveChat() {
        val contactUid = _activeChatContactUid.value ?: return
        viewModelScope.launch {
            repository.clearChat(contactUid)
        }
    }

    // --- WebRTC Calls ---
    fun startCall(contactUid: String, type: String) { // "voice" or "video"
        viewModelScope.launch {
            repository.initiateCall(contactUid, type)
        }
    }

    fun acceptActiveIncomingCall() {
        val active = repository.activeCallFlow.value ?: return
        viewModelScope.launch {
            repository.acceptCall(active.callId)
        }
    }

    fun rejectActiveIncomingCall() {
        val active = repository.activeCallFlow.value ?: return
        viewModelScope.launch {
            repository.rejectCall(active.callId)
        }
    }

    fun endActiveCall() {
        val active = repository.activeCallFlow.value ?: return
        viewModelScope.launch {
            repository.endCall(active.callId)
        }
    }

    // Dev action: Simulate incoming call
    fun simulateIncomingCall() {
        viewModelScope.launch {
            if (repository is OfflineDemoRepository) {
                repository.triggerSimulatedIncomingCall()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioManager.stopRingtone()
    }
}
