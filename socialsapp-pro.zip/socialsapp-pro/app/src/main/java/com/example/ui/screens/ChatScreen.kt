package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: MainViewModel) {
    val activeContactUid by viewModel.activeChatContactUid.collectAsState()
    val contact = viewModel.contacts.collectAsState().value.find { it.uid == activeContactUid }

    val messages by viewModel.getActiveChatMessagesFlow().collectAsState(initial = emptyList())
    val isTyping by viewModel.getActiveChatTypingFlow().collectAsState(initial = false)
    val textInput by viewModel.chatMessageInput.collectAsState()

    val myUid = viewModel.currentUserId.collectAsState().value ?: ""

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    var showMenu by remember { mutableStateOf(false) }

    // Scroll automatically to newest message on feed update
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            coroutineScope.launch {
                listState.animateScrollToItem(messages.size - 1)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProfileAvatar(emoji = contact?.emoji ?: "🦊", size = 40.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = contact?.name ?: "Chat Friend",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = if (contact?.status == "online") "online" else "offline",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (contact?.status == "online") EmeraldPrimary else TextSecondary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.setActiveChat(null) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Go Back", tint = EmeraldPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { activeContactUid?.let { viewModel.startCall(it, "voice") } }) {
                        Icon(Icons.Default.Phone, contentDescription = "Voice Call", tint = EmeraldPrimary)
                    }
                    IconButton(onClick = { activeContactUid?.let { viewModel.startCall(it, "video") } }) {
                        Icon(Icons.Default.VideoCall, contentDescription = "Video Call", tint = EmeraldPrimary)
                    }
                    Box {
                        IconButton(onClick = { showMenu = !showMenu }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = EmeraldPrimary)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(DarkSurface)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Clear Chat Messages", color = Color.Red, fontWeight = FontWeight.Bold) },
                                onClick = {
                                    showMenu = false
                                    viewModel.clearActiveChat()
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .imePadding()
        ) {
            val activeCall by viewModel.activeCall.collectAsState()
            val isCallMinimized by viewModel.isCallMinimized.collectAsState()

            if (activeCall != null && isCallMinimized) {
                InCallActiveGlowBar(viewModel = viewModel, activeCall = activeCall!!)
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (messages.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                            Text("👋", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Say Hello to ${contact?.name ?: "your friend"}!",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Send your first message. All chats are secured offline-first and on our Realtime database backend.",
                                fontSize = 13.sp,
                                color = TextSecondary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp).padding(top = 4.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            val isMe = msg.senderId == myUid
                            MessageBubble(msg = msg, isMe = isMe)
                        }
                    }
                }
            }

            // Typing Indicator message label
            AnimatedVisibility(visible = isTyping) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${contact?.name ?: "Someone"} is typing",
                        fontSize = 12.sp,
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "...", fontSize = 12.sp, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            }

            // Chat Input Area
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { viewModel.onChatMessageChanged(it) },
                    placeholder = { Text("Enter your message...") },
                    maxLines = 4,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = DarkSurface,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface
                    ),
                    shape = RoundedCornerShape(24.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                IconButton(
                    onClick = { viewModel.sendChatMessage() },
                    enabled = textInput.trim().isNotEmpty(),
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            color = if (textInput.trim().isNotEmpty()) EmeraldPrimary else DarkSurface,
                            shape = CircleShape
                        )
                        .testTag("send_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = if (textInput.trim().isNotEmpty()) Color.Black else TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun MessageBubble(msg: ChatMessage, isMe: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        if (!isMe) {
            ProfileAvatar(emoji = "🤖", size = 32.dp, modifier = Modifier.padding(top = 4.dp))
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (isMe) Alignment.End else Alignment.Start,
            modifier = Modifier.widthIn(max = 260.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isMe) MyBubbleColor else OtherBubbleColor
                ),
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isMe) 16.dp else 0.dp,
                    bottomEnd = if (isMe) 0.dp else 16.dp
                )
            ) {
                Text(
                    text = msg.message,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (isMe) MyBubbleText else OtherBubbleText,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(2.dp))
            
            // Format simple time
            val formatter = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
            val timeString = formatter.format(Date(msg.timestamp))
            Text(
                text = timeString,
                fontSize = 10.sp,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}
