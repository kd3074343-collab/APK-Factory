package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CallSession
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyBubbleText
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun CallScreen(viewModel: MainViewModel) {
    val activeCall by viewModel.activeCall.collectAsState()
    val myUid = viewModel.currentUserId.collectAsState().value ?: ""

    // Safe guarantee: if no active Call, do not draw
    val call = activeCall ?: return

    val isCaller = call.callerId == myUid
    val remoteName = if (isCaller) call.receiverName else call.callerName
    val remoteEmoji = if (isCaller) call.receiverEmoji else call.callerEmoji

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F0F))
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        when (call.status) {
            "dialing" -> OutboundCallingState(remoteName = remoteName, remoteEmoji = remoteEmoji, type = call.type, onHangup = { viewModel.endActiveCall() })
            "ringing" -> InboundCallingState(remoteName = remoteName, remoteEmoji = remoteEmoji, type = call.type, onAccept = { viewModel.acceptActiveIncomingCall() }, onDecline = { viewModel.rejectActiveIncomingCall() })
            "accepted" -> ActiveCallState(call = call, remoteName = remoteName, remoteEmoji = remoteEmoji, onHangup = { viewModel.endActiveCall() })
            else -> {
                // Ending or Rejected states: draw a fading notice
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Call Disconnected...", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
            }
        }

        // Floating Minimize Button
        IconButton(
            onClick = { viewModel.isCallMinimized.value = true },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                .testTag("minimize_call_button")
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = "Minimize Call",
                tint = EmeraldPrimary,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun OutboundCallingState(remoteName: String, remoteEmoji: String, type: String, onHangup: () -> Unit) {
    // Pulse animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (type == "video") "DIALING VIDEO CALL..." else "DIALING VOICE CALL...",
                fontSize = 12.sp,
                color = EmeraldPrimary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = remoteName,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        // Animated Pulsating Ring Avatar
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .scale(pulseScale)
                    .background(EmeraldPrimary.copy(alpha = 0.08f), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .scale(pulseScale * 0.85f)
                    .background(EmeraldPrimary.copy(alpha = 0.15f), CircleShape)
            )
            ProfileAvatar(emoji = remoteEmoji, size = 100.dp)
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "Calling...", color = TextSecondary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(32.dp))
            IconButton(
                onClick = onHangup,
                modifier = Modifier
                    .background(Color.Red, CircleShape)
                    .size(64.dp)
                    .testTag("dialing_decline_button")
            ) {
                Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        }
    }
}

@Composable
fun InboundCallingState(remoteName: String, remoteEmoji: String, type: String, onAccept: () -> Unit, onDecline: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (type == "video") "INCOMING VIDEO CALL" else "INCOMING VOICE CALL",
                fontSize = 12.sp,
                color = EmeraldPrimary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = remoteName,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .scale(pulseScale)
                    .background(Color.Red.copy(alpha = 0.08f), CircleShape)
            )
            ProfileAvatar(emoji = remoteEmoji, size = 110.dp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Decline Button
            IconButton(
                onClick = onDecline,
                modifier = Modifier
                    .background(Color.Red, CircleShape)
                    .size(64.dp)
                    .testTag("ringing_decline_button")
            ) {
                Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(28.dp))
            }

            // Accept Button
            IconButton(
                onClick = onAccept,
                modifier = Modifier
                    .background(EmeraldPrimary, CircleShape)
                    .size(64.dp)
                    .testTag("ringing_accept_button")
            ) {
                Icon(Icons.Default.Call, contentDescription = "Accept", tint = Color.Black, modifier = Modifier.size(28.dp))
            }
        }
    }
}

@Composable
fun ActiveCallState(call: CallSession, remoteName: String, remoteEmoji: String, onHangup: () -> Unit) {
    var isMuted by remember { mutableStateOf(false) }
    var isVideoMuted by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        if (call.type == "video" && !isVideoMuted) {
            // Video Active Layout: Full-Screen Remote Feed with Top Floating Local Card
            RemoteVideoFeedSimulation(remoteEmoji = remoteEmoji)

            // Local Camera Box Overlay top floating card
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp)
                    .size(width = 110.dp, height = 160.dp)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .border(2.dp, EmeraldPrimary, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Local webcam indicator
                LocalVideoFeedSimulation()
            }
        } else {
            // Voice Active Layout: Pulsing Sound Waves Center glows
            VoiceCallFeedSimulation(remoteName = remoteName, remoteEmoji = remoteEmoji)
        }

        // Floating Call Controls Block bottom aligned
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.85f)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(0.9f)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp, horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute Mic Toggle
                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .background(if (isMuted) Color.Red.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.1f), CircleShape)
                        .size(48.dp)
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute Microphone",
                        tint = if (isMuted) Color.Red else Color.White
                    )
                }

                // If Video Call, add Camera toggling button
                if (call.type == "video") {
                    IconButton(
                        onClick = { isVideoMuted = !isVideoMuted },
                        modifier = Modifier
                            .background(if (isVideoMuted) Color.Red.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.1f), CircleShape)
                            .size(48.dp)
                    ) {
                        Icon(
                            imageVector = if (isVideoMuted) Icons.Default.VideocamOff else Icons.Default.Videocam,
                            contentDescription = "Mute Camera",
                            tint = if (isVideoMuted) Color.Red else Color.White
                        )
                    }
                }

                // Hangup Button
                IconButton(
                    onClick = onHangup,
                    modifier = Modifier
                        .background(Color.Red, CircleShape)
                        .size(54.dp)
                        .testTag("active_hangup_button")
                ) {
                    Icon(Icons.Default.CallEnd, contentDescription = "End call session", tint = Color.White, modifier = Modifier.size(26.dp))
                }
            }
        }
    }
}

@Composable
fun VoiceCallFeedSimulation(remoteName: String, remoteEmoji: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_rings")
    val r1 by infiniteTransition.animateFloat(initialValue = 100f, targetValue = 280f, animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart), label = "r1")
    val r2 by infiniteTransition.animateFloat(initialValue = 100f, targetValue = 280f, animationSpec = infiniteRepeatable(tween(2000, delayMillis = 1000, easing = LinearEasing), RepeatMode.Restart), label = "r2")

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(300.dp)) {
            // Soundwave circles custom canvas drawing
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(color = EmeraldPrimary, radius = r1, alpha = (1f - (r1 - 100f) / 180f) * 0.25f, style = Stroke(width = 2.dp.toPx()))
                drawCircle(color = EmeraldPrimary, radius = r2, alpha = (1f - (r2 - 100f) / 180f) * 0.25f, style = Stroke(width = 2.dp.toPx()))
            }
            ProfileAvatar(emoji = remoteEmoji, size = 110.dp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(text = remoteName, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Color.White)
        Text(text = "STABLE AUDIO CONNECTION", color = EmeraldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun RemoteVideoFeedSimulation(remoteEmoji: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbits")
    val rot by infiniteTransition.animateFloat(initialValue = 0f, targetValue = 360f, animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "rot")

    // Dynamic background visualizer indicating incoming active feed
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize(0.8f)) {
            // Draw visual solar-like orbit elements representing synchronization
            drawArc(
                color = EmeraldPrimary,
                startAngle = rot,
                sweepAngle = 120f,
                useCenter = false,
                style = Stroke(width = 1.dp.toPx()),
                alpha = 0.15f
            )
            drawArc(
                color = EmeraldPrimary,
                startAngle = rot + 180f,
                sweepAngle = 60f,
                useCenter = false,
                style = Stroke(width = 1.5.dp.toPx()),
                alpha = 0.10f
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            ProfileAvatar(emoji = remoteEmoji, size = 90.dp)
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "LIVE VIDEO TRANSCEIVER READY", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = EmeraldPrimary, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun LocalVideoFeedSimulation() {
    val transition = rememberInfiniteTransition(label = "cam_osc")
    val scaleY by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "y"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF151515)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Face, contentDescription = "Self Webcam", tint = EmeraldPrimary.copy(alpha = 0.5f), modifier = Modifier.size(36.dp))
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.height(16.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(modifier = Modifier.size(4.dp, 16.dp * scaleY).background(EmeraldPrimary))
            Box(modifier = Modifier.size(4.dp, 16.dp * (scaleY * 0.7f)).background(EmeraldPrimary))
            Box(modifier = Modifier.size(4.dp, 16.dp * (scaleY * 1.2f)).background(EmeraldPrimary))
        }
    }
}
