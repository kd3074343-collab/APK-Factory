package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ProfileSetupScreen(viewModel: MainViewModel) {
    val name by viewModel.profileNameInput.collectAsState()
    val bio by viewModel.profileBioInput.collectAsState()
    val emoji by viewModel.profileEmojiInput.collectAsState()
    val error by viewModel.authError.collectAsState()
    val isLoading by viewModel.profileLoading.collectAsState()

    val emojiOptions = listOf("🦊", "🦁", "🐼", "🤖", "🥑", "🚀", "🎸", "🍍", "🎯", "💎", "🧩", "👽")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Setup Profile",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
            )

            Text(
                text = "Personalize how friends locate you",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Dynamic Emoji Avatar Preview!
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(Color.Black, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = emoji.ifEmpty { "🦊" }.take(2),
                    fontSize = 48.sp,
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Sub-Selection of recommended emoji identifiers
            Text(
                text = "Choose an profile identifier emoji",
                fontSize = 12.sp,
                color = TextSecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                emojiOptions.take(6).forEach { opt ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 6.dp)
                            .size(36.dp)
                            .background(if (emoji == opt) EmeraldPrimary.copy(alpha = 0.2f) else DarkSurface, CircleShape)
                            .clickable { viewModel.profileEmojiInput.value = opt },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = opt, fontSize = 20.sp)
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                emojiOptions.takeLast(6).forEach { opt ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 6.dp)
                            .size(36.dp)
                            .background(if (emoji == opt) EmeraldPrimary.copy(alpha = 0.2f) else DarkSurface, CircleShape)
                            .clickable { viewModel.profileEmojiInput.value = opt },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = opt, fontSize = 20.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Text box for custom manual 2-char key identifier input
            OutlinedTextField(
                value = emoji,
                onValueChange = { if (it.length <= 2) viewModel.profileEmojiInput.value = it },
                label = { Text("Profile Emoji / Text (Max 2 chars)") },
                leadingIcon = { Icon(Icons.Default.Face, contentDescription = "Face", tint = EmeraldPrimary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("profile_id_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = DarkSurface
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // User Name Input Box
            OutlinedTextField(
                value = name,
                onValueChange = { if (it.length <= 20) viewModel.profileNameInput.value = it },
                label = { Text("Display Name (${20 - name.length} remaining)") },
                leadingIcon = { Icon(Icons.Default.AlternateEmail, contentDescription = "Name", tint = EmeraldPrimary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("profile_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = DarkSurface
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // User Bio Input Box
            OutlinedTextField(
                value = bio,
                onValueChange = { if (it.length <= 100) viewModel.profileBioInput.value = it },
                label = { Text("Custom Bio (${100 - bio.length} remaining)") },
                leadingIcon = { Icon(Icons.Default.Info, contentDescription = "Bio", tint = EmeraldPrimary) },
                maxLines = 3,
                modifier = Modifier.fillMaxWidth().testTag("profile_bio_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = DarkSurface
                )
            )

            AnimatedVisibility(visible = error != null) {
                Text(
                    text = error ?: "",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Submit Button
            Button(
                onClick = { viewModel.handleProfileSetup() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_profile_button"),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(12.dp),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text(
                        text = "SAVE PROFILE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.Black
                    )
                }
            }
        }
    }
}
