package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.StateFlow

interface AppRepository {
    val isLiveFirebase: Boolean
    val currentUserIdFlow: StateFlow<String?>
    val currentUserProfileFlow: StateFlow<UserProfile?>
    val contactsFlow: StateFlow<List<ContactInfo>>
    val pendingRequestsFlow: StateFlow<List<FriendRequest>>
    val callLogsFlow: StateFlow<List<CallLogEntry>>
    val activeCallFlow: StateFlow<CallSession?>
    
    suspend fun signUp(email: String, password: String): Result<UserProfile>
    suspend fun signIn(email: String, password: String): Result<UserProfile>
    suspend fun signOut()
    
    suspend fun setupProfile(name: String, bio: String, emoji: String): Result<UserProfile>
    suspend fun updateProfile(name: String, bio: String, emoji: String): Result<Unit>
    
    suspend fun sendFriendRequest(targetUserIdCode: String): Result<Unit>
    suspend fun acceptFriendRequest(requestId: String): Result<Unit>
    suspend fun declineFriendRequest(requestId: String): Result<Unit>
    
    fun getMessagesFlow(contactUid: String): StateFlow<List<ChatMessage>>
    suspend fun sendMessage(contactUid: String, text: String): Result<Unit>
    suspend fun clearChat(contactUid: String): Result<Unit>
    
    suspend fun setTypingState(contactUid: String, isTyping: Boolean)
    fun getTypingFlow(contactUid: String): StateFlow<Boolean>
    
    suspend fun initiateCall(targetUid: String, type: String): Result<CallSession> // "voice" or "video"
    suspend fun acceptCall(callId: String): Result<Unit>
    suspend fun rejectCall(callId: String): Result<Unit>
    suspend fun endCall(callId: String): Result<Unit>
    
    // WebRTC connection signaling updates
    suspend fun updateSdp(callId: String, sdp: String, type: String): Result<Unit> // type: "offer" or "answer"
    suspend fun sendIceCandidate(callId: String, candidateJson: String, isCaller: Boolean): Result<Unit>
}
