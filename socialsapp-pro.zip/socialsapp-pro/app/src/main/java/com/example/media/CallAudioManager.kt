package com.example.media

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.util.Log

class CallAudioManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null

    fun playRingtone() {
        stopRingtone() // Stop if already playing
        try {
            var alert: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            if (alert == null) {
                alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                if (alert == null) {
                    alert = RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALL)
                }
            }

            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, alert!!)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
            Log.d("CallAudioManager", "Ringtone loop started successfully.")
        } catch (e: Exception) {
            Log.e("CallAudioManager", "Failed to play default system ringtone, starting fallback synthesizer bleeps", e)
            playFallbackBeep()
        }
    }

    private fun playFallbackBeep() {
        try {
            // High fidelity synth loop using android asset sound if possible or a safe audio file, 
            // but a simpler option is to let it fail silently or notify. Let's create an elegant synth loop
            // by playing notification fallback or short beep.
            val alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, alert)
                isLooping = true
                prepare()
                start()
            }
        } catch (ex: Exception) {
            Log.e("CallAudioManager", "Fallback scanner failed", ex)
        }
    }

    fun stopRingtone() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
            mediaPlayer = null
            Log.d("CallAudioManager", "Ringtone stopped and resources released.")
        } catch (e: Exception) {
            Log.e("CallAudioManager", "Error stopping ringtone", e)
        }
    }
}
