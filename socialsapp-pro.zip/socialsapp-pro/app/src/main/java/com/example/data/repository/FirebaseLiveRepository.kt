package com.example.data.repository

import android.content.Context
import com.example.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import java.util.UUID
import kotlin.random.Random

class FirebaseLiveRepository(private val context: Context) : AppRepository {
    override val isLiveFirebase: Boolean = true

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val db: FirebaseDatabase by lazy { FirebaseDatabase.getInstance() }
    
    private val ioScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _currentUserIdFlow = MutableStateFlow<String?>(null)
    override val currentUserIdFlow: StateFlow<String?> = _currentUserIdFlow.asStateFlow()

    private val _currentUserProfileFlow = MutableStateFlow<UserProfile?>(null)
    override val currentUserProfileFlow: StateFlow<UserProfile?> = _currentUserProfileFlow.asStateFlow()

    private val _contactsFlow = MutableStateFlow<List<ContactInfo>>(emptyList())
    override val contactsFlow: StateFlow<List<ContactInfo>> = _contactsFlow.asStateFlow()

    private val _pendingRequestsFlow = MutableStateFlow<List<FriendRequest>>(emptyList())
    override val pendingRequestsFlow: StateFlow<List<FriendRequest>> = _pendingRequestsFlow.asStateFlow()

    private val _callLogsFlow = MutableStateFlow<List<CallLogEntry>>(emptyList())
    override val callLogsFlow: StateFlow<List<CallLogEntry>> = _callLogsFlow.asStateFlow()

    private val _activeCallFlow = MutableStateFlow<CallSession?>(null)
    override val activeCallFlow: StateFlow<CallSession?> = _activeCallFlow.asStateFlow()

    private var profileListener: ValueEventListener? = null
    private var contactsListener: ValueEventListener? = null
    private var requestsListener: ValueEventListener? = null
    private var callLogsListener: ValueEventListener? = null
    private var activeCallListener: ValueEventListener? = null

    private val chatListenersMap = mutableMapOf<String, ValueEventListener>()
    private val chatFlowsMap = mutableMapOf<String, MutableStateFlow<List<ChatMessage>>>()
    private val typingListenersMap = mutableMapOf<String, ValueEventListener>()
    private val typingFlowsMap = mutableMapOf<String, MutableStateFlow<Boolean>>()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val firebaseUser = firebaseAuth.currentUser
            _currentUserIdFlow.value = firebaseUser?.uid
            if (firebaseUser != null) {
                setupUserObservers(firebaseUser.uid)
                setupPresence(firebaseUser.uid)
            } else {
                clearObservers()
                _currentUserProfileFlow.value = null
                _contactsFlow.value = emptyList()
                _pendingRequestsFlow.value = emptyList()
                _callLogsFlow.value = emptyList()
                _activeCallFlow.value = null
            }
        }
    }

    private fun setupUserObservers(uid: String) {
        clearObservers()

        // 1. Current Profile Listener
        val profileRef = db.getReference("users").child(uid)
        profileListener = profileRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val profile = snapshot.getValue(UserProfile::class.java)
                _currentUserProfileFlow.value = profile
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        // 2. Contacts Listener
        val contactsRef = db.getReference("contacts").child(uid)
        contactsListener = contactsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<ContactInfo>()
                for (child in snapshot.children) {
                    val contact = child.getValue(ContactInfo::class.java)
                    if (contact != null) list.add(contact)
                }
                _contactsFlow.value = list
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        // 3. Friend Requests Listener
        val requestsRef = db.getReference("requests").child(uid)
        requestsListener = requestsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<FriendRequest>()
                for (child in snapshot.children) {
                    val req = child.getValue(FriendRequest::class.java)
                    if (req != null && req.status == "pending") list.add(req)
                }
                _pendingRequestsFlow.value = list
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        // 4. Call Logs Listener
        val logsRef = db.getReference("callLogs").child(uid)
        callLogsListener = logsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<CallLogEntry>()
                for (child in snapshot.children) {
                    val log = child.getValue(CallLogEntry::class.java)
                    if (log != null) list.add(log)
                }
                _callLogsFlow.value = list.sortedByDescending { it.timestamp }
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        // 5. Active Call Signaling Stream
        val callsRef = db.getReference("calls")
        activeCallListener = callsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var foundCall: CallSession? = null
                for (child in snapshot.children) {
                    val session = child.getValue(CallSession::class.java)
                    if (session != null && (session.callerId == uid || session.receiverId == uid)) {
                        if (session.status != "ended" && session.status != "rejected") {
                            foundCall = session
                            break
                        }
                    }
                }
                _activeCallFlow.value = foundCall
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun setupPresence(uid: String) {
        val connectedRef = db.getReference(".info/connected")
        val statusRef = db.getReference("status").child(uid)

        connectedRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                if (connected) {
                    val presenceMap = mapOf(
                        "status" to "online",
                        "last_changed" to ServerValue.TIMESTAMP
                    )
                    statusRef.setValue(presenceMap)
                    statusRef.onDisconnect().setValue(mapOf(
                        "status" to "offline",
                        "last_changed" to ServerValue.TIMESTAMP
                    ))
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun clearObservers() {
        val uid = _currentUserIdFlow.value ?: return
        profileListener?.let { db.getReference("users").child(uid).removeEventListener(it) }
        contactsListener?.let { db.getReference("contacts").child(uid).removeEventListener(it) }
        requestsListener?.let { db.getReference("requests").child(uid).removeEventListener(it) }
        callLogsListener?.let { db.getReference("callLogs").child(uid).removeEventListener(it) }
        activeCallListener?.let { db.getReference("calls").removeEventListener(it) }

        chatListenersMap.forEach { (chatId, listener) ->
            db.getReference("messages").child(chatId).removeEventListener(listener)
        }
        chatListenersMap.clear()

        typingListenersMap.forEach { (chatId, listener) ->
            db.getReference("typing").child(chatId).removeEventListener(listener)
        }
        typingListenersMap.clear()
    }

    override suspend fun signUp(email: String, password: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        try {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            val firebaseUser = result.user ?: return@withContext Result.failure(Exception("Signup failed: empty user"))
            
            val uid = firebaseUser.uid
            val shortCode = String.format("ar-%04d", Random.nextInt(1000, 9999))
            
            val profile = UserProfile(
                uid = uid,
                name = email.substringBefore("@"),
                bio = "Set your bio here...",
                emoji = "👤",
                userId = shortCode,
                dpUrl = "👤",
                status = "online",
                lastChanged = System.currentTimeMillis()
            )

            db.getReference("users").child(uid).setValue(profile).await()
            // Map email inside secondary lookup for userId matching
            db.getReference("userIdMapping").child(shortCode).setValue(uid).await()

            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun signIn(email: String, password: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            val firebaseUser = result.user ?: return@withContext Result.failure(Exception("Signin returned null user"))
            
            val snapshot = db.getReference("users").child(firebaseUser.uid).get().await()
            val profile = snapshot.getValue(UserProfile::class.java) 
                ?: UserProfile(uid = firebaseUser.uid, name = email.substringBefore("@"))
            
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun signOut() {
        val uid = _currentUserIdFlow.value
        if (uid != null) {
            db.getReference("status").child(uid).setValue(mapOf(
                "status" to "offline",
                "last_changed" to ServerValue.TIMESTAMP
            ))
        }
        auth.signOut()
    }

    override suspend fun setupProfile(name: String, bio: String, emoji: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val uid = _currentUserIdFlow.value ?: return@withContext Result.failure(Exception("Unauthenticated"))
        try {
            val currentSnapshot = db.getReference("users").child(uid).get().await()
            val current = currentSnapshot.getValue(UserProfile::class.java) ?: UserProfile(uid = uid)
            
            val updated = current.copy(
                name = name.take(20),
                bio = bio.take(100),
                emoji = emoji.take(2),
                dpUrl = emoji.take(2)
            )
            db.getReference("users").child(uid).setValue(updated).await()
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateProfile(name: String, bio: String, emoji: String): Result<Unit> {
        return setupProfile(name, bio, emoji).map { Unit }
    }

    override suspend fun sendFriendRequest(targetUserIdCode: String): Result<Unit> = withContext(Dispatchers.IO) {
        val myUid = _currentUserIdFlow.value ?: return@withContext Result.failure(Exception("Unauthenticated"))
        val myProfile = _currentUserProfileFlow.value ?: return@withContext Result.failure(Exception("Profile load pending"))
        
        try {
            // Find target uid by checking mapping
            val mappingSnapshot = db.getReference("userIdMapping").child(targetUserIdCode.trim()).get().await()
            val targetUid = mappingSnapshot.getValue(String::class.java) 
                ?: return@withContext Result.failure(Exception("User with ID $targetUserIdCode not found."))
            
            if (targetUid == myUid) {
                return@withContext Result.failure(Exception("You cannot send friend requests to yourself."))
            }

            val request = FriendRequest(
                id = "req_${UUID.randomUUID()}",
                fromUid = myUid,
                fromName = myProfile.name,
                fromEmoji = myProfile.emoji,
                fromUserId = myProfile.userId,
                toUid = targetUid,
                status = "pending"
            )

            db.getReference("requests").child(targetUid).child(request.id).setValue(request).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun acceptFriendRequest(requestId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val myUid = _currentUserIdFlow.value ?: return@withContext Result.failure(Exception("Unauthenticated"))
        val myProfile = _currentUserProfileFlow.value ?: return@withContext Result.failure(Exception("Profile required"))
        try {
            // 1. Fetch request details
            val reqSnapshot = db.getReference("requests").child(myUid).child(requestId).get().await()
            val request = reqSnapshot.getValue(FriendRequest::class.java) 
                ?: return@withContext Result.failure(Exception("Request not found"))

            // 2. Add to contact books for both
            val contactForMe = ContactInfo(
                uid = request.fromUid,
                name = request.fromName,
                emoji = request.fromEmoji,
                userId = request.fromUserId,
                status = "online"
            )

            val contactForThem = ContactInfo(
                uid = myUid,
                name = myProfile.name,
                emoji = myProfile.emoji,
                userId = myProfile.userId,
                status = "online"
            )

            db.getReference("contacts").child(myUid).child(request.fromUid).setValue(contactForMe).await()
            db.getReference("contacts").child(request.fromUid).child(myUid).setValue(contactForThem).await()

            // 3. Delete Request
            db.getReference("requests").child(myUid).child(requestId).removeValue().await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun declineFriendRequest(requestId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val myUid = _currentUserIdFlow.value ?: return@withContext Result.failure(Exception("Unauthenticated"))
        try {
            db.getReference("requests").child(myUid).child(requestId).removeValue().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun getChatId(uid1: String, uid2: String): String {
        return if (uid1 < uid2) "${uid1}_${uid2}" else "${uid2}_${uid1}"
    }

    override fun getMessagesFlow(contactUid: String): StateFlow<List<ChatMessage>> {
        val myUid = _currentUserIdFlow.value ?: return MutableStateFlow(emptyList())
        val chatId = getChatId(myUid, contactUid)
        
        val stateFlow = chatFlowsMap.getOrPut(chatId) {
            val flow = MutableStateFlow<List<ChatMessage>>(emptyList())
            val messagesRef = db.getReference("messages").child(chatId)
            
            // Listen to clear timestamp
            val clearedAtRef = db.getReference("userChats").child(myUid).child(chatId).child("clearedAt")
            
            val listener = messagesRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    ioScope.launch {
                        val clearedAt = clearedAtRef.get().await().getValue(Long::class.java) ?: 0L
                        val list = mutableListOf<ChatMessage>()
                        for (child in snapshot.children) {
                            val msg = child.getValue(ChatMessage::class.java)
                            if (msg != null && msg.timestamp >= clearedAt) {
                                list.add(msg)
                            }
                        }
                        flow.value = list
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
            
            chatListenersMap[chatId] = listener
            flow
        }
        
        // Reset unread count when opening chat
        ioScope.launch {
            db.getReference("unreadCounts").child(myUid).child(chatId).setValue(0)
        }
        
        return stateFlow
    }

    override suspend fun sendMessage(contactUid: String, text: String): Result<Unit> = withContext(Dispatchers.IO) {
        val myUid = _currentUserIdFlow.value ?: return@withContext Result.failure(Exception("Unauthenticated"))
        val myProfile = _currentUserProfileFlow.value ?: return@withContext Result.failure(Exception("Profile not loaded"))
        val chatId = getChatId(myUid, contactUid)
        
        try {
            val msgId = db.getReference("messages").child(chatId).push().key ?: UUID.randomUUID().toString()
            val chatMessage = ChatMessage(
                id = msgId,
                senderId = myUid,
                senderName = myProfile.name,
                message = text,
                timestamp = System.currentTimeMillis()
            )

            // Save message
            db.getReference("messages").child(chatId).child(msgId).setValue(chatMessage).await()

            // Update unread count for other recipient
            val unreadRef = db.getReference("unreadCounts").child(contactUid).child(chatId)
            val currentUnread = unreadRef.get().await().getValue(Int::class.java) ?: 0
            unreadRef.setValue(currentUnread + 1)

            // Update contact references for recent message preview strings
            db.getReference("contacts").child(myUid).child(contactUid).child("lastMessage").setValue(text)
            db.getReference("contacts").child(myUid).child(contactUid).child("lastMessageTime").setValue(chatMessage.timestamp)
            db.getReference("contacts").child(contactUid).child(myUid).child("lastMessage").setValue(text)
            db.getReference("contacts").child(contactUid).child(myUid).child("lastMessageTime").setValue(chatMessage.timestamp)

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun clearChat(contactUid: String): Result<Unit> = withContext(Dispatchers.IO) {
        val myUid = _currentUserIdFlow.value ?: return@withContext Result.failure(Exception("Unauthenticated"))
        val chatId = getChatId(myUid, contactUid)
        try {
            db.getReference("userChats").child(myUid).child(chatId).child("clearedAt").setValue(System.currentTimeMillis()).await()
            // Force redraw empty
            chatFlowsMap[chatId]?.value = emptyList()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun setTypingState(contactUid: String, isTyping: Boolean) {
        val myUid = _currentUserIdFlow.value ?: return
        val chatId = getChatId(myUid, contactUid)
        db.getReference("typing").child(chatId).child(myUid).setValue(isTyping)
    }

    override fun getTypingFlow(contactUid: String): StateFlow<Boolean> {
        val myUid = _currentUserIdFlow.value ?: return MutableStateFlow(false)
        val chatId = getChatId(myUid, contactUid)
        
        return typingFlowsMap.getOrPut(chatId) {
            val flow = MutableStateFlow(false)
            val typingRef = db.getReference("typing").child(chatId).child(contactUid)
            val listener = typingRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    flow.value = snapshot.getValue(Boolean::class.java) ?: false
                }
                override fun onCancelled(error: DatabaseError) {}
            })
            typingListenersMap[chatId] = listener
            flow
        }.asStateFlow()
    }

    // Calling System
    override suspend fun initiateCall(targetUid: String, type: String): Result<CallSession> = withContext(Dispatchers.IO) {
        val myUid = _currentUserIdFlow.value ?: return@withContext Result.failure(Exception("Unauthenticated"))
        val myProfile = _currentUserProfileFlow.value ?: return@withContext Result.failure(Exception("Profile loading"))
        
        try {
            val targetProfileSnapshot = db.getReference("users").child(targetUid).get().await()
            val targetProfile = targetProfileSnapshot.getValue(UserProfile::class.java) ?: return@withContext Result.failure(Exception("User not found"))

            val callId = db.getReference("calls").push().key ?: UUID.randomUUID().toString()
            val session = CallSession(
                callId = callId,
                callerId = myUid,
                callerName = myProfile.name,
                callerEmoji = myProfile.emoji,
                receiverId = targetUid,
                receiverName = targetProfile.name,
                receiverEmoji = targetProfile.emoji,
                type = type,
                status = "dialing",
                timestamp = System.currentTimeMillis()
            )

            db.getReference("calls").child(callId).setValue(session).await()
            Result.success(session)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun acceptCall(callId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            db.getReference("calls").child(callId).child("status").setValue("accepted").await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun rejectCall(callId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            db.getReference("calls").child(callId).child("status").setValue("rejected").await()
            
            // Log log entry locally
            val sessionSnapshot = db.getReference("calls").child(callId).get().await()
            val session = sessionSnapshot.getValue(CallSession::class.java)
            if (session != null) {
                logCall(session, "missed", 0)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun endCall(callId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val snapshot = db.getReference("calls").child(callId).get().await()
            val session = snapshot.getValue(CallSession::class.java)
            
            if (session != null) {
                val duration = if (session.status == "accepted") (System.currentTimeMillis() - session.timestamp) / 1000 else 0L
                val logType = if (session.status == "accepted") session.type else "missed"
                
                db.getReference("calls").child(callId).child("status").setValue("ended").await()
                logCall(session, logType, duration)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun logCall(session: CallSession, type: String, duration: Long) {
        val myUid = _currentUserIdFlow.value ?: return
        val logId = db.getReference("callLogs").child(myUid).push().key ?: UUID.randomUUID().toString()
        
        val isCaller = session.callerId == myUid
        val otherUid = if (isCaller) session.receiverId else session.callerId
        val otherName = if (isCaller) session.receiverName else session.callerName
        val otherEmoji = if (isCaller) session.receiverEmoji else session.callerEmoji

        val logEntry = CallLogEntry(
            id = logId,
            type = type,
            otherUid = otherUid,
            otherName = otherName,
            otherEmoji = otherEmoji,
            duration = duration,
            timestamp = System.currentTimeMillis()
        )

        db.getReference("callLogs").child(myUid).child(logId).setValue(logEntry).await()
    }

    override suspend fun updateSdp(callId: String, sdp: String, type: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val targetField = if (type == "offer") "offerSdp" else "answerSdp"
            db.getReference("calls").child(callId).child(targetField).setValue(sdp).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun sendIceCandidate(callId: String, candidateJson: String, isCaller: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val targetField = if (isCaller) "callerCandidates" else "receiverCandidates"
            db.getReference("calls").child(callId).child(targetField).setValue(candidateJson).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

// Extension to await Firebase Task results using Coroutines
suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnCompleteListener { task ->
        if (task.isSuccessful) {
            cont.resume(task.result, onCancellation = null)
        } else {
            cont.resumeWith(Result.failure(task.exception ?: Exception("Firebase Task Failed")))
        }
    }
}
