package com.example.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val bio: String = "",
    val emoji: String = "👤",
    val userId: String = "", // e.g. "ar-1234"
    val dpUrl: String = "",
    val status: String = "offline", // "online" or "offline"
    val lastChanged: Long = 0L
)

@Immutable
data class FriendRequest(
    val id: String = "",
    val fromUid: String = "",
    val fromName: String = "",
    val fromEmoji: String = "",
    val fromUserId: String = "",
    val toUid: String = "",
    val status: String = "pending" // "pending", "accepted", "rejected"
)

@Immutable
data class ContactInfo(
    val uid: String = "",
    val name: String = "",
    val bio: String = "",
    val emoji: String = "",
    val userId: String = "",
    val status: String = "offline",
    val lastChanged: Long = 0L,
    val unreadCount: Int = 0,
    val lastMessage: String = "",
    val lastMessageTime: Long = 0L
)

@Immutable
data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Immutable
data class CallLogEntry(
    val id: String = "",
    val type: String = "voice", // "voice", "video", "missed"
    val otherUid: String = "",
    val otherName: String = "",
    val otherEmoji: String = "",
    val duration: Long = 0L, // seconds
    val timestamp: Long = System.currentTimeMillis()
)

@Immutable
data class CallSession(
    val callId: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callerEmoji: String = "",
    val receiverId: String = "",
    val receiverName: String = "",
    val receiverEmoji: String = "",
    val type: String = "voice", // "voice", "video"
    val status: String = "dialing", // "dialing", "ringing", "accepted", "rejected", "ended"
    val offerSdp: String? = null,
    val answerSdp: String? = null,
    val callerCandidates: String? = null, // JSON-serialized candidates
    val receiverCandidates: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
