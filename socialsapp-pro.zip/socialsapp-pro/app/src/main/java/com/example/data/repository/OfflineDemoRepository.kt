package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.random.Random

class OfflineDemoRepository : AppRepository {
    override val isLiveFirebase: Boolean = false

    private val ioScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _currentUserIdFlow = MutableStateFlow<String?>(null)
    override val currentUserIdFlow: StateFlow<String?> = _currentUserIdFlow.asStateFlow()

    private val _currentUserProfileFlow = MutableStateFlow<UserProfile?>(null)
    override val currentUserProfileFlow: StateFlow<UserProfile?> = _currentUserProfileFlow.asStateFlow()

    // Base in-memory contacts
    private val contactsMap = mutableMapOf<String, ContactInfo>(
        "zoe_uid" to ContactInfo(
            uid = "zoe_uid",
            name = "Zoe AI",
            bio = "I am an intelligent bot. Text me or try a Video/Voice Call! 🤖",
            emoji = "🤖",
            userId = "ar-1111",
            status = "online",
            lastChanged = System.currentTimeMillis() - 5000,
            unreadCount = 1,
            lastMessage = "Hi there! Welcome to SocialsApp Pro. Let's talk!",
            lastMessageTime = System.currentTimeMillis() - 100000
        ),
        "mila_uid" to ContactInfo(
            uid = "mila_uid",
            name = "Mila Green",
            bio = "Plant lover 🥑 Fitness & WebRTC developer",
            emoji = "🥑",
            userId = "ar-4321",
            status = "offline",
            lastChanged = System.currentTimeMillis() - 400000,
            unreadCount = 0,
            lastMessage = "Talk to you later",
            lastMessageTime = System.currentTimeMillis() - 1200000
        ),
        "dax_uid" to ContactInfo(
            uid = "dax_uid",
            name = "Dax Carter",
            bio = "Code & Design 🚀 Always up for calls",
            emoji = "🚀",
            userId = "ar-8899",
            status = "online",
            lastChanged = System.currentTimeMillis() - 10000,
            unreadCount = 0,
            lastMessage = "The native layout looks gorgeous!",
            lastMessageTime = System.currentTimeMillis() - 360000
        )
    )

    private val _contactsFlow = MutableStateFlow<List<ContactInfo>>(contactsMap.values.toList())
    override val contactsFlow: StateFlow<List<ContactInfo>> = _contactsFlow.asStateFlow()

    private val requestsList = mutableListOf<FriendRequest>(
        FriendRequest(
            id = "req_lucas",
            fromUid = "lucas_uid",
            fromName = "Lucas Finch",
            fromEmoji = "🎩",
            fromUserId = "ar-7722",
            toUid = "me_uid",
            status = "pending"
        )
    )

    private val _pendingRequestsFlow = MutableStateFlow<List<FriendRequest>>(requestsList)
    override val pendingRequestsFlow: StateFlow<List<FriendRequest>> = _pendingRequestsFlow.asStateFlow()

    private val callLogsList = mutableListOf<CallLogEntry>(
        CallLogEntry(
            id = "log_1",
            type = "missed",
            otherUid = "mila_uid",
            otherName = "Mila Green",
            otherEmoji = "🥑",
            duration = 0,
            timestamp = System.currentTimeMillis() - 7200000
        ),
        CallLogEntry(
            id = "log_2",
            type = "video",
            otherUid = "dax_uid",
            otherName = "Dax Carter",
            otherEmoji = "🚀",
            duration = 182,
            timestamp = System.currentTimeMillis() - 86450000
        )
    )

    private val _callLogsFlow = MutableStateFlow<List<CallLogEntry>>(callLogsList)
    override val callLogsFlow: StateFlow<List<CallLogEntry>> = _callLogsFlow.asStateFlow()

    private val _activeCallFlow = MutableStateFlow<CallSession?>(null)
    override val activeCallFlow: StateFlow<CallSession?> = _activeCallFlow.asStateFlow()

    // Holds chat histories in memory
    private val chatsMessages = mutableMapOf<String, MutableList<ChatMessage>>(
        "zoe_uid" to mutableListOf(
            ChatMessage("zoe_m1", "zoe_uid", "Zoe AI", "Hi there! Welcome to SocialsApp Pro. Let's talk!", System.currentTimeMillis() - 100000)
        ),
        "mila_uid" to mutableListOf(
            ChatMessage("mila_m1", "mila_uid", "Mila Green", "Hey, did you finish the WebRTC design?", System.currentTimeMillis() - 2000000),
            ChatMessage("mila_m2", "me_uid", "Me", "Yes, it uses material 3 emerald greens!", System.currentTimeMillis() - 1800000),
            ChatMessage("mila_m3", "mila_uid", "Mila Green", "Talk to you later", System.currentTimeMillis() - 1200000)
        ),
        "dax_uid" to mutableListOf(
            ChatMessage("dax_m1", "dax_uid", "Dax Carter", "Hey, check out the bottom nav!", System.currentTimeMillis() - 400000),
            ChatMessage("dax_m2", "dax_uid", "Dax Carter", "The native layout looks gorgeous!", System.currentTimeMillis() - 360000)
        )
    )

    private val chatFlowsMap = mutableMapOf<String, MutableStateFlow<List<ChatMessage>>>()
    private val typingStatesMap = mutableMapOf<String, MutableStateFlow<Boolean>>()

    override suspend fun signUp(email: String, password: String): Result<UserProfile> {
        delay(800)
        val uid = "me_" + Random.nextInt(1000, 9999)
        val shortCode = String.format("ar-%04d", Random.nextInt(1000, 9999))
        val profile = UserProfile(
            uid = uid,
            name = email.substringBefore("@"),
            bio = "New in SocialsApp Pro 🚀",
            emoji = "✨",
            userId = shortCode,
            dpUrl = "✨",
            status = "online",
            lastChanged = System.currentTimeMillis()
        )
        _currentUserIdFlow.value = uid
        _currentUserProfileFlow.value = profile
        return Result.success(profile)
    }

    override suspend fun signIn(email: String, password: String): Result<UserProfile> {
        delay(600)
        val uid = "me_1234"
        val profile = UserProfile(
            uid = uid,
            name = email.substringBefore("@"),
            bio = "Loving WebRTC on Compose!",
            emoji = "🦊",
            userId = "ar-5588",
            dpUrl = "🦊",
            status = "online",
            lastChanged = System.currentTimeMillis()
        )
        _currentUserIdFlow.value = uid
        _currentUserProfileFlow.value = profile
        
        // Let's trigger a delayed incoming call after user signs in to showcase Call Flow!
        scheduleSimulatedIncomingCall(5000)

        return Result.success(profile)
    }

    override suspend fun signOut() {
        _currentUserIdFlow.value = null
        _currentUserProfileFlow.value = null
    }

    override suspend fun setupProfile(name: String, bio: String, emoji: String): Result<UserProfile> {
        val current = _currentUserProfileFlow.value ?: return Result.failure(Exception("Not logged in"))
        val updated = current.copy(
            name = name.take(20),
            bio = bio.take(100),
            emoji = emoji.take(2),
            dpUrl = emoji.take(2)
        )
        _currentUserProfileFlow.value = updated
        return Result.success(updated)
    }

    override suspend fun updateProfile(name: String, bio: String, emoji: String): Result<Unit> {
        setupProfile(name, bio, emoji)
        return Result.success(Unit)
    }

    override suspend fun sendFriendRequest(targetUserIdCode: String): Result<Unit> {
        delay(600)
        // Check if matching any simulated users
        if (targetUserIdCode.trim().lowercase() == "ar-1111" || targetUserIdCode.trim().lowercase() == "ar-4321" || targetUserIdCode.trim().lowercase() == "ar-8899") {
            return Result.failure(Exception("This user is already in your contact list."))
        }
        
        // Create a new simulated contact upon request
        val randCode = targetUserIdCode.trim()
        val newUid = "sim_" + Random.nextInt(1000, 9999)
        
        // Append to request list
        val req = FriendRequest(
            id = "req_" + UUID.randomUUID().toString(),
            fromUid = _currentUserIdFlow.value ?: "me_uid",
            fromName = _currentUserProfileFlow.value?.name ?: "Me",
            fromEmoji = _currentUserProfileFlow.value?.emoji ?: "🦊",
            fromUserId = _currentUserProfileFlow.value?.userId ?: "ar-5588",
            toUid = newUid,
            status = "pending"
        )
        
        requestsList.add(0, req)
        _pendingRequestsFlow.value = requestsList.toList()

        // Fast auto-accept simulation
        ioScope.launch {
            delay(4000)
            acceptSimulatedFriend(req, newUid, randCode)
        }

        return Result.success(Unit)
    }

    private fun acceptSimulatedFriend(req: FriendRequest, uid: String, code: String) {
        val names = listOf("Alex Rivera", "Kira Vance", "Ray Sterling", "Nola Diaz")
        val emojis = listOf("🦁", "🦋", "🎸", "🍍")
        val bios = listOf("Riding the synthwave 🎵", "Capturing pixels 📷", "Stay wild, child 🌱", "Always building 🧱")
        
        val chosenIndex = Random.nextInt(names.size)
        val name = names[chosenIndex]
        val emoji = emojis[chosenIndex]
        val bio = bios[chosenIndex]

        // Remove from pending
        requestsList.removeAll { it.id == req.id }
        _pendingRequestsFlow.value = requestsList.toList()

        // Create contact
        val contact = ContactInfo(
            uid = uid,
            name = name,
            bio = bio,
            emoji = emoji,
            userId = code,
            status = "online",
            lastChanged = System.currentTimeMillis(),
            lastMessage = "Thanks for adding me! What's up? 🚀",
            lastMessageTime = System.currentTimeMillis()
        )
        
        contactsMap[uid] = contact
        _contactsFlow.value = contactsMap.values.toList()

        // Preload messages
        chatsMessages[uid] = mutableListOf(
            ChatMessage("msg_init_" + uid, uid, name, "Thanks for adding me! What's up? 🚀", System.currentTimeMillis())
        )
        chatFlowsMap.getOrPut(uid) { MutableStateFlow(emptyList()) }.value = chatsMessages[uid] ?: emptyList()
    }

    override suspend fun acceptFriendRequest(requestId: String): Result<Unit> {
        delay(400)
        val req = requestsList.find { it.id == requestId } ?: return Result.failure(Exception("Request not found"))
        
        requestsList.removeAll { it.id == requestId }
        _pendingRequestsFlow.value = requestsList.toList()

        // Map to contacts
        val contact = ContactInfo(
            uid = req.fromUid,
            name = req.fromName,
            emoji = req.fromEmoji,
            userId = req.fromUserId,
            status = "online",
            lastChanged = System.currentTimeMillis(),
            lastMessage = "We are now friends on SocialsApp Pro!",
            lastMessageTime = System.currentTimeMillis()
        )
        
        contactsMap[req.fromUid] = contact
        _contactsFlow.value = contactsMap.values.toList()

        chatsMessages[req.fromUid] = mutableListOf(
            ChatMessage("msg_init_" + req.fromUid, req.fromUid, req.fromName, "We are now friends on SocialsApp Pro!", System.currentTimeMillis())
        )
        chatFlowsMap.getOrPut(req.fromUid) { MutableStateFlow(emptyList()) }.value = chatsMessages[req.fromUid] ?: emptyList()

        return Result.success(Unit)
    }

    override suspend fun declineFriendRequest(requestId: String): Result<Unit> {
        delay(400)
        requestsList.removeAll { it.id == requestId }
        _pendingRequestsFlow.value = requestsList.toList()
        return Result.success(Unit)
    }

    override fun getMessagesFlow(contactUid: String): StateFlow<List<ChatMessage>> {
        val flow = chatFlowsMap.getOrPut(contactUid) {
            MutableStateFlow(chatsMessages[contactUid] ?: emptyList())
        }
        return flow
    }

    override suspend fun sendMessage(contactUid: String, text: String): Result<Unit> {
        if (text.trim().isEmpty()) return Result.failure(Exception("Empty message"))
        
        val meName = _currentUserProfileFlow.value?.name ?: "Me"
        val myUid = _currentUserIdFlow.value ?: "me_uid"
        
        val newMsg = ChatMessage(
            id = "msg_" + UUID.randomUUID().toString(),
            senderId = myUid,
            senderName = meName,
            message = text,
            timestamp = System.currentTimeMillis()
        )

        // Add locally
        val list = chatsMessages.getOrPut(contactUid) { mutableListOf() }
        list.add(newMsg)
        
        // Update unread count reference
        val c = contactsMap[contactUid]
        if (c != null) {
            contactsMap[contactUid] = c.copy(
                lastMessage = text,
                lastMessageTime = System.currentTimeMillis()
            )
            _contactsFlow.value = contactsMap.values.toList()
        }

        chatFlowsMap.getOrPut(contactUid) { MutableStateFlow(emptyList()) }.value = list.toList()

        // AI bot response triggering!
        if (contactUid == "zoe_uid") {
            ioScope.launch {
                delay(800)
                setTypingState("zoe_uid", true)
                delay(2200)
                setTypingState("zoe_uid", false)
                
                val suggestions = listOf(
                    "That is remarkable! SocialsApp Pro design uses smooth spring animations. 💚",
                    "I am powered by a local simulator on Android. Did you check our Voice & Video calls?",
                    "Indeed! The WebRTC signals are routed through our repository interface nicely.",
                    "Have you tried the side navigation drawer? It has bio settings!",
                    "Let's test an incoming WebRTC loop. Try calling me right now! 🤖"
                )
                val responseMsg = ChatMessage(
                    id = "msg_zoe_" + UUID.randomUUID().toString(),
                    senderId = "zoe_uid",
                    senderName = "Zoe AI",
                    message = suggestions.random(),
                    timestamp = System.currentTimeMillis()
                )
                list.add(responseMsg)
                chatFlowsMap.getOrPut("zoe_uid") { MutableStateFlow(emptyList()) }.value = list.toList()
                
                // Update lists
                contactsMap["zoe_uid"] = contactsMap["zoe_uid"]!!.copy(
                    lastMessage = responseMsg.message,
                    lastMessageTime = responseMsg.timestamp
                )
                _contactsFlow.value = contactsMap.values.toList()
            }
        }

        return Result.success(Unit)
    }

    override suspend fun clearChat(contactUid: String): Result<Unit> {
        delay(300)
        chatsMessages[contactUid]?.clear()
        chatFlowsMap.getOrPut(contactUid) { MutableStateFlow(emptyList()) }.value = emptyList()
        
        contactsMap[contactUid]?.let {
            contactsMap[contactUid] = it.copy(lastMessage = "Chat cleared", lastMessageTime = System.currentTimeMillis())
            _contactsFlow.value = contactsMap.values.toList()
        }
        return Result.success(Unit)
    }

    override suspend fun setTypingState(contactUid: String, isTyping: Boolean) {
        getTypingFlow(contactUid).value = isTyping
    }

    override fun getTypingFlow(contactUid: String): MutableStateFlow<Boolean> {
        return typingStatesMap.getOrPut(contactUid) {
            MutableStateFlow(false)
        }
    }

    // Call Actions
    override suspend fun initiateCall(targetUid: String, type: String): Result<CallSession> {
        val contact = contactsMap[targetUid] ?: return Result.failure(Exception("Contact not found"))
        
        val myUid = _currentUserIdFlow.value ?: "me_uid"
        val meProfile = _currentUserProfileFlow.value
        
        val session = CallSession(
            callId = "call_" + Random.nextInt(100000, 999999),
            callerId = myUid,
            callerName = meProfile?.name ?: "Me",
            callerEmoji = meProfile?.emoji ?: "✨",
            receiverId = contact.uid,
            receiverName = contact.name,
            receiverEmoji = contact.emoji,
            type = type,
            status = "dialing",
            offerSdp = "v=0\no=- 12345 23456 IN IP4 127.0.0.1\ns=SocialsApp WebRTC Offer\nt=0 0\nm=audio 49170 RTP/AVP 0\na=rtpmap:0 PCMU/8000",
            timestamp = System.currentTimeMillis()
        )

        _activeCallFlow.value = session

        // Simulating the remote friend answering the call
        ioScope.launch {
            delay(3500)
            val active = _activeCallFlow.value
            if (active != null && active.callId == session.callId && active.status == "dialing") {
                // Change status to ring then accept
                _activeCallFlow.value = active.copy(status = "ringing")
                delay(1500)
                val stillActive = _activeCallFlow.value
                if (stillActive != null && stillActive.callId == session.callId && stillActive.status == "ringing") {
                    _activeCallFlow.value = stillActive.copy(
                        status = "accepted",
                        answerSdp = "v=0\no=- 23456 34567 IN IP4 127.0.0.1\ns=SocialsApp WebRTC Answer\nt=0 0\nm=audio 49170 RTP/AVP 0\na=rtpmap:0 PCMU/8000"
                    )
                }
            }
        }

        return Result.success(session)
    }

    override suspend fun acceptCall(callId: String): Result<Unit> {
        val active = _activeCallFlow.value ?: return Result.failure(Exception("No call session active"))
        if (active.callId == callId) {
            _activeCallFlow.value = active.copy(
                status = "accepted",
                answerSdp = "v=0\no=- 23456 34567 IN IP4 127.0.0.1\ns=SocialsApp WebRTC Answer\nt=0 0\nm=audio 49170 RTP/AVP 0\na=rtpmap:0 PCMU/8000"
            )
            return Result.success(Unit)
        }
        return Result.failure(Exception("Session ID mismatches"))
    }

    override suspend fun rejectCall(callId: String): Result<Unit> {
        val active = _activeCallFlow.value ?: return Result.failure(Exception("No active call"))
        if (active.callId == callId) {
            _activeCallFlow.value = active.copy(status = "rejected")
            
            // Create Call Log
            val log = CallLogEntry(
                id = "log_" + UUID.randomUUID().toString(),
                type = "missed",
                otherUid = active.callerId,
                otherName = active.callerName,
                otherEmoji = active.callerEmoji,
                duration = 0,
                timestamp = System.currentTimeMillis()
            )
            callLogsList.add(0, log)
            _callLogsFlow.value = callLogsList.toList()
            
            _activeCallFlow.value = null
            return Result.success(Unit)
        }
        return Result.failure(Exception("Session ID mismatches"))
    }

    override suspend fun endCall(callId: String): Result<Unit> {
        val active = _activeCallFlow.value ?: return Result.failure(Exception("No active call"))
        if (active.callId == callId) {
            val finalStatus = active.status
            _activeCallFlow.value = active.copy(status = "ended")
            
            val durationSecs = if (finalStatus == "accepted") Random.nextLong(15, 300) else 0L
            val type = if (finalStatus == "accepted") active.type else "missed"
            
            // Log entry
            val otherUid = if (active.callerId == (_currentUserIdFlow.value ?: "me_uid")) active.receiverId else active.callerId
            val otherName = if (active.callerId == (_currentUserIdFlow.value ?: "me_uid")) active.receiverName else active.callerName
            val otherEmoji = if (active.callerId == (_currentUserIdFlow.value ?: "me_uid")) active.receiverEmoji else active.callerEmoji

            val log = CallLogEntry(
                id = "log_" + UUID.randomUUID().toString(),
                type = type,
                otherUid = otherUid,
                otherName = otherName,
                otherEmoji = otherEmoji,
                duration = durationSecs,
                timestamp = System.currentTimeMillis()
            )
            callLogsList.add(0, log)
            _callLogsFlow.value = callLogsList.toList()

            _activeCallFlow.value = null
            return Result.success(Unit)
        }
        return Result.failure(Exception("Session ID mismatches"))
    }

    override suspend fun updateSdp(callId: String, sdp: String, type: String): Result<Unit> {
        val active = _activeCallFlow.value ?: return Result.failure(Exception("No active call"))
        if (active.callId == callId) {
            if (type == "offer") {
                _activeCallFlow.value = active.copy(offerSdp = sdp)
            } else {
                _activeCallFlow.value = active.copy(answerSdp = sdp)
            }
            return Result.success(Unit)
        }
        return Result.failure(Exception("Session ID mismatches"))
    }

    override suspend fun sendIceCandidate(callId: String, candidateJson: String, isCaller: Boolean): Result<Unit> {
        val active = _activeCallFlow.value ?: return Result.failure(Exception("No active call"))
        if (active.callId == callId) {
            if (isCaller) {
                _activeCallFlow.value = active.copy(callerCandidates = candidateJson)
            } else {
                _activeCallFlow.value = active.copy(receiverCandidates = candidateJson)
            }
            return Result.success(Unit)
        }
        return Result.failure(Exception("Session ID mismatches"))
    }

    // Helper to mock an incoming call
    fun triggerSimulatedIncomingCall() {
        val callerUid = "mila_uid"
        val caller = contactsMap[callerUid]!!
        val session = CallSession(
            callId = "call_incoming_" + Random.nextInt(100000, 999999),
            callerId = caller.uid,
            callerName = caller.name,
            callerEmoji = caller.emoji,
            receiverId = _currentUserIdFlow.value ?: "me_uid",
            receiverName = _currentUserProfileFlow.value?.name ?: "Me",
            receiverEmoji = _currentUserProfileFlow.value?.emoji ?: "🦊",
            type = if (Random.nextBoolean()) "video" else "voice",
            status = "ringing",
            offerSdp = "v=0\no=- 98765 43210 IN IP4 127.0.0.1\ns=Incoming Offer\nt=0 0",
            timestamp = System.currentTimeMillis()
        )
        _activeCallFlow.value = session
    }

    private fun scheduleSimulatedIncomingCall(waitMs: Long) {
        ioScope.launch {
            delay(waitMs)
            if (_activeCallFlow.value == null && _currentUserIdFlow.value != null) {
                triggerSimulatedIncomingCall()
            }
        }
    }
}
