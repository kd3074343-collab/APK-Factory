package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ContactInfo
import com.example.data.model.CallLogEntry
import com.example.data.model.FriendRequest
import com.example.data.model.CallSession
import androidx.compose.animation.core.*
import androidx.compose.ui.draw.scale
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProfileAvatar(emoji: String, modifier: Modifier = Modifier, size: Dp = 48.dp) {
    Box(
        modifier = modifier
            .size(size)
            .background(Color.Black, shape = CircleShape)
            .border(1.dp, EmeraldPrimary.copy(alpha = 0.3f), shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = emoji.ifEmpty { "👤" }.take(2),
            fontSize = (size.value * 0.45).sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val activeTab by viewModel.activeTabFlow.collectAsState()
    val isDrawerOpen by viewModel.isDrawerOpenFlow.collectAsState()
    val activeDialog by viewModel.activeDialogFlow.collectAsState()
    val currentUser by viewModel.currentUserProfile.collectAsState()

    val contactsList by viewModel.contacts.collectAsState()
    val pendingRequestsList by viewModel.pendingRequests.collectAsState()
    val callLogsList by viewModel.callLogs.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Sync state between viewmodel flow and material drawerState
    LaunchedEffect(isDrawerOpen) {
        if (isDrawerOpen) {
            drawerState.open()
        } else {
            drawerState.close()
        }
    }

    // Keep state when dragging or clicking outside closes it
    LaunchedEffect(drawerState.isOpen) {
        viewModel.toggleDrawer(drawerState.isOpen)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DarkSurface,
                modifier = Modifier.width(300.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                ) {
                    // Profile Header
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 24.dp)
                    ) {
                        ProfileAvatar(emoji = currentUser?.emoji ?: "🦊", size = 64.dp)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = currentUser?.name ?: "Unknown User",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                            Text(
                                text = currentUser?.userId ?: "ar-0000",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Profile Details section
                    Text(
                        text = "ABOUT ME",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Text(
                        text = currentUser?.bio ?: "No bio specified.",
                        fontSize = 13.sp,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    Divider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(bottom = 24.dp))

                    // Drawer Action Buttons
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = EmeraldPrimary) },
                        label = { Text("Edit Bio Details", fontWeight = FontWeight.Bold) },
                        selected = false,
                        onClick = {
                            viewModel.toggleDrawer(false)
                            viewModel.setDialog("profile_edit")
                        },
                        colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Color.Transparent)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.PhoneCallback, contentDescription = "Mock Call", tint = EmeraldPrimary) },
                        label = { Text("Trigger Dummy Call", fontWeight = FontWeight.Bold) },
                        selected = false,
                        onClick = {
                            viewModel.toggleDrawer(false)
                            viewModel.simulateIncomingCall()
                        },
                        colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Color.Transparent),
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.ExitToApp, contentDescription = "Sign Out", tint = Color.Red) },
                        label = { Text("Log Out Account", color = Color.Red, fontWeight = FontWeight.Bold) },
                        selected = false,
                        onClick = { viewModel.logout() },
                        colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Color.Transparent)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = when (activeTab) {
                                "home" -> "SocialsApp Pro"
                                "requests" -> "Friend Requests"
                                else -> "Call History"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.toggleDrawer(true) }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu Drawer", tint = EmeraldPrimary)
                        }
                    },
                    actions = {
                        if (activeTab == "home") {
                            IconButton(onClick = { viewModel.setDialog("add_friend") }) {
                                Icon(Icons.Default.PersonAdd, contentDescription = "Add Friend", tint = EmeraldPrimary)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.ChatBubble, contentDescription = "Chats") },
                        label = { Text("Contacts") },
                        selected = activeTab == "home",
                        onClick = { viewModel.setTab("home") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                    NavigationBarItem(
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (pendingRequestsList.isNotEmpty()) {
                                        Badge(containerColor = Color.Red) {
                                            Text(pendingRequestsList.size.toString(), color = Color.White)
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.People, contentDescription = "Requests")
                            }
                        },
                        label = { Text("Requests") },
                        selected = activeTab == "requests",
                        onClick = { viewModel.setTab("requests") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Call, contentDescription = "Calls") },
                        label = { Text("Calls") },
                        selected = activeTab == "calls",
                        onClick = { viewModel.setTab("calls") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                val activeCall by viewModel.activeCall.collectAsState()
                val isCallMinimized by viewModel.isCallMinimized.collectAsState()

                Column(modifier = Modifier.fillMaxSize()) {
                    if (activeCall != null && isCallMinimized) {
                        InCallActiveGlowBar(viewModel = viewModel, activeCall = activeCall!!)
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        when (activeTab) {
                            "home" -> ContactsTab(contacts = contactsList, viewModel = viewModel, currentUserCode = currentUser?.userId ?: "")
                            "requests" -> RequestsTab(requests = pendingRequestsList, viewModel = viewModel)
                            else -> CallsTab(logs = callLogsList, viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }

    // Secondary Dialogs
    if (activeDialog == "profile_edit") {
        ProfileEditDialog(viewModel = viewModel)
    } else if (activeDialog == "add_friend") {
        AddFriendDialog(viewModel = viewModel)
    }
}

@Composable
fun ContactsTab(contacts: List<ContactInfo>, viewModel: MainViewModel, currentUserCode: String) {
    if (contacts.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Icon(Icons.Default.Search, contentDescription = "Empty", tint = TextSecondary, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "No friends added yet",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Press the + icon on top and search their unique four digit ID code to send requests! Sharing ID: $currentUserCode",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp).padding(top = 4.dp)
                )
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            // Share code card at the top
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Share your public code to get added: ",
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Text(
                        text = currentUserCode,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp)
            ) {
                items(contacts, key = { it.uid }) { contact ->
                    ContactRow(contact = contact, onClick = { viewModel.setActiveChat(contact.uid) })
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
fun ContactRow(contact: ContactInfo, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface, RoundedCornerShape(24.dp))
            .border(1.dp, Color(0x0DFFFFFF), RoundedCornerShape(24.dp))
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(contentAlignment = Alignment.BottomEnd) {
            ProfileAvatar(emoji = contact.emoji, size = 52.dp)
            
            // Presence status circular badge
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .background(
                        if (contact.status == "online") EmeraldPrimary else Color.Gray,
                        shape = CircleShape
                    )
                    .border(2.dp, DarkSurface, CircleShape)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = contact.name,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = contact.lastMessage.ifEmpty { contact.bio },
                fontSize = 13.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (contact.unreadCount > 0) {
            Box(
                modifier = Modifier
                    .padding(start = 8.dp)
                    .size(20.dp)
                    .background(EmeraldPrimary, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = contact.unreadCount.toString(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }
        }
    }
}

@Composable
fun RequestsTab(requests: List<FriendRequest>, viewModel: MainViewModel) {
    if (requests.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Icon(Icons.Default.PeopleOutline, contentDescription = "Empty", tint = TextSecondary, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "No pending friend requests",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Any incoming requests sent to your code will show up here immediately in real-time.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp).padding(top = 4.dp)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(requests, key = { it.id }) { req ->
                RequestRow(req = req, onAccept = { viewModel.acceptRequest(req.id) }, onDecline = { viewModel.declineRequest(req.id) })
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun RequestRow(req: FriendRequest, onAccept: () -> Unit, onDecline: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface, RoundedCornerShape(24.dp))
            .border(1.dp, Color(0x0DFFFFFF), RoundedCornerShape(24.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProfileAvatar(emoji = req.fromEmoji, size = 48.dp)
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = req.fromName,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 15.sp
            )
            Text(
                text = req.fromUserId,
                fontSize = 12.sp,
                color = TextSecondary
            )
        }
        Row {
            IconButton(
                onClick = onAccept,
                modifier = Modifier
                    .background(EmeraldPrimary, CircleShape)
                    .size(36.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = "Accept", tint = Color.Black, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onDecline,
                modifier = Modifier
                    .background(Color.Red.copy(alpha = 0.2f), CircleShape)
                    .size(36.dp)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Decline", tint = Color.Red, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
fun CallsTab(logs: List<CallLogEntry>, viewModel: MainViewModel) {
    if (logs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Icon(Icons.Default.PhoneMissed, contentDescription = "Empty", tint = TextSecondary, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "No calls made yet",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Click a friend in Contacts and press Voice or Video Call to launch a real WebRTC session!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp).padding(top = 4.dp)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(logs, key = { it.id }) { log ->
                CallLogRow(log = log, onCall = { viewModel.startCall(log.otherUid, log.type) })
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun CallLogRow(log: CallLogEntry, onCall: () -> Unit) {
    val formatter = remember { SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()) }
    val dateStr = formatter.format(Date(log.timestamp))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface, RoundedCornerShape(24.dp))
            .border(1.dp, Color(0x0DFFFFFF), RoundedCornerShape(24.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProfileAvatar(emoji = log.otherEmoji, size = 48.dp)
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = log.otherName,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = when (log.type) {
                        "missed" -> Icons.Default.PhoneMissed
                        "video" -> Icons.Default.VideoCall
                        else -> Icons.Default.CallReceived
                    },
                    contentDescription = "Call Type",
                    tint = if (log.type == "missed") Color.Red else EmeraldPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (log.type == "missed") "Missed" else "${log.duration}s • $dateStr",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }
        IconButton(onClick = onCall) {
            Icon(Icons.Default.Phone, contentDescription = "Return Call", tint = EmeraldPrimary)
        }
    }
}

@Composable
fun ProfileEditDialog(viewModel: MainViewModel) {
    val name by viewModel.profileNameInput.collectAsState()
    val bio by viewModel.profileBioInput.collectAsState()
    val emoji by viewModel.profileEmojiInput.collectAsState()

    Dialog(onDismissRequest = { viewModel.setDialog("none") }) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Edit Profile Bio", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = EmeraldPrimary)
                Spacer(modifier = Modifier.height(16.dp))

                Box(modifier = Modifier.size(64.dp).background(Color.Black, CircleShape), contentAlignment = Alignment.Center) {
                    Text(emoji.take(2), fontSize = 32.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = emoji,
                    onValueChange = { if (it.length <= 2) viewModel.profileEmojiInput.value = it },
                    label = { Text("Profile Emoji") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 20) viewModel.profileNameInput.value = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = bio,
                    onValueChange = { if (it.length <= 100) viewModel.profileBioInput.value = it },
                    label = { Text("Custom Bio") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { viewModel.setDialog("none") }) {
                        Text("CANCEL", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { viewModel.saveProfileEdit() },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("SAVE CHANGES", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddFriendDialog(viewModel: MainViewModel) {
    val code by viewModel.searchUserIdCode.collectAsState()
    val error by viewModel.searchError.collectAsState()
    val success by viewModel.searchSuccess.collectAsState()

    Dialog(onDismissRequest = { viewModel.setDialog("none") }) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add friend", tint = EmeraldPrimary, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("Search & Add Friend", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = EmeraldPrimary)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Request with target 4-digit code (ar-xxxx).",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { viewModel.searchUserIdCode.value = it },
                    placeholder = { Text("ar-1234") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("add_friend_input")
                )

                AnimatedVisibility(visible = error != null) {
                    Text(
                        text = error ?: "",
                        color = Color.Red,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }

                AnimatedVisibility(visible = success != null) {
                    Text(
                        text = success ?: "",
                        color = EmeraldPrimary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { viewModel.setDialog("none") }) {
                        Text("CLOSE", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { viewModel.submitFriendRequest() },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("SEND REQUEST", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun InCallActiveGlowBar(viewModel: MainViewModel, activeCall: CallSession) {
    val myUid = viewModel.currentUserId.collectAsState().value ?: ""
    val isCaller = activeCall.callerId == myUid
    val remoteName = if (isCaller) activeCall.receiverName else activeCall.callerName
    val remoteEmoji = if (isCaller) activeCall.receiverEmoji else activeCall.callerEmoji

    // Pulsating indicator
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .background(EmeraldPrimary.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
            .border(1.dp, EmeraldPrimary.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            .clickable { viewModel.isCallMinimized.value = false }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.Black, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(remoteEmoji.ifEmpty { "📞" }, fontSize = 18.sp)
                }
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .scale(pulseAlpha * 0.4f + 0.8f)
                        .background(EmeraldPrimary, CircleShape)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "ACTIVE VOICE CALL",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "$remoteName • Tap to Maximize",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }

        Button(
            onClick = { viewModel.endActiveCall() },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4444)),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 11.dp, vertical = 4.dp),
            modifier = Modifier.testTag("glowbar_hangup_button").height(32.dp)
        ) {
            Text("HANG UP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
