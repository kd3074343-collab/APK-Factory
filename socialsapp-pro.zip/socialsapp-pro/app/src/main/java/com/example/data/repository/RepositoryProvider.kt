package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

object RepositoryProvider {
    private const val TAG = "RepositoryProvider"
    private var instance: AppRepository? = null

    fun getRepository(context: Context): AppRepository {
        return instance ?: synchronized(this) {
            val repo = createRepository(context.applicationContext)
            instance = repo
            repo
        }
    }

    private fun createRepository(context: Context): AppRepository {
        val apiKey = try { BuildConfig.FIREBASE_API_KEY } catch (e: Exception) { "" }
        val dbUrl = try { BuildConfig.FIREBASE_DATABASE_URL } catch (e: Exception) { "" }
        val projectId = try { BuildConfig.FIREBASE_PROJECT_ID } catch (e: Exception) { "" }

        val isConfigured = apiKey.isNotEmpty() && 
                apiKey != "AIzaSyPlaceholderKeyForNativeBMSync" && 
                !apiKey.contains("Placeholder", ignoreCase = true) &&
                dbUrl.isNotEmpty() && 
                dbUrl != "https://your-firebase-db-id.firebaseio.com" &&
                !dbUrl.contains("your-firebase", ignoreCase = true)

        if (isConfigured) {
            try {
                Log.d(TAG, "Initializing Firebase manually with custom Secrets...")
                if (FirebaseApp.getApps(context).isEmpty()) {
                    val options = FirebaseOptions.Builder()
                        .setApiKey(apiKey)
                        .setDatabaseUrl(dbUrl)
                        .setProjectId(if (projectId.isEmpty()) "socialsapp-pro-custom" else projectId)
                        .setApplicationId(BuildConfig.APPLICATION_ID)
                        .build()
                    FirebaseApp.initializeApp(context, options)
                }
                Log.i(TAG, "Firebase initialized successfully. Yielding LiveFirebaseRepository.")
                return FirebaseLiveRepository(context)
            } catch (e: Exception) {
                Log.e(TAG, "Failed manual Firebase initialization. Falling back to Demo repository.", e)
            }
        } else {
            Log.d(TAG, "No live Firebase credentials detected in Secrets Panel. Starting OfflineDemoRepository.")
        }

        return OfflineDemoRepository()
    }
}
