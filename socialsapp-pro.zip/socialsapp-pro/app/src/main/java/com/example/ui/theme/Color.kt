package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF00A878)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val TextPrimary = Color(0xFFE0E0E0)
val TextSecondary = Color(0xFFA0A0A0)

val MyBubbleColor = Color(0xFF00A878)
val MyBubbleText = Color(0xFF121212)
val OtherBubbleColor = Color(0xFF1E1E1E)
val OtherBubbleText = Color(0xFFE0E0E0)

