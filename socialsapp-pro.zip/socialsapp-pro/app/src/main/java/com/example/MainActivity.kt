package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CallScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                val appScreen by viewModel.appScreenFlow.collectAsState()
                val activeChatContactUid by viewModel.activeChatContactUid.collectAsState()
                val activeCall by viewModel.activeCall.collectAsState()
                val isCallMinimized by viewModel.isCallMinimized.collectAsState()
                val isNetworkAvailable by viewModel.isNetworkAvailable.collectAsState()

                Box(modifier = Modifier.fillMaxSize()) {
                    // 1. Primary Workspaces Routing Layer
                    when (appScreen) {
                        "auth" -> AuthScreen(viewModel = viewModel)
                        "profile_setup" -> ProfileSetupScreen(viewModel = viewModel)
                        "app" -> {
                            if (activeChatContactUid == null) {
                                DashboardScreen(viewModel = viewModel)
                            } else {
                                ChatScreen(viewModel = viewModel)
                            }
                        }
                    }

                    // 2. Fullscreen WebRTC Calling Signaling Overlay (overrides any active screen)
                    if (activeCall != null && !isCallMinimized) {
                        CallScreen(viewModel = viewModel)
                    }

                    // 3. Internet Connectivity Offline Overlay Popup
                    if (!isNetworkAvailable) {
                        Dialog(onDismissRequest = { /* No dismiss */ }) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                                    .border(1.dp, Color.Red.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(24.dp)
                                        .fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WifiOff,
                                        contentDescription = "No Internet Connection",
                                        tint = Color.Red,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "No Internet Connection",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Please check your network connection. The app will automatically connect once internet is available.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

