package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CallScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                val appScreen by viewModel.appScreenFlow.collectAsState()
                val activeChatContactUid by viewModel.activeChatContactUid.collectAsState()
                val activeCall by viewModel.activeCall.collectAsState()
                val isCallMinimized by viewModel.isCallMinimized.collectAsState()

                Box(modifier = Modifier.fillMaxSize()) {
                    // 1. Primary Workspaces Routing Layer
                    when (appScreen) {
                        "auth" -> AuthScreen(viewModel = viewModel)
                        "profile_setup" -> ProfileSetupScreen(viewModel = viewModel)
                        "app" -> {
                            if (activeChatContactUid == null) {
                                DashboardScreen(viewModel = viewModel)
                            } else {
                                ChatScreen(viewModel = viewModel)
                            }
                        }
                    }

                    // 2. Fullscreen WebRTC Calling Signaling Overlay (overrides any active screen)
                    if (activeCall != null && !isCallMinimized) {
                        CallScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

