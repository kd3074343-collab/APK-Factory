package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Luxury Palette (Obsidian & Gold)
val ObsidianDarkBg = Color(0xFF090A0E)
val ObsidianSurface = Color(0xFF131620)
val ObsidianSurfaceVariant = Color(0xFF1D2232)
val ObsidianGlassBorder = Color(0x33FFFFFF)
val GoldAccent = Color(0xFFFFD700)
val GoldAccentDim = Color(0xB3FFD700)
val ChampagneGold = Color(0xFFF7E7CE)

// Titanium Light Palette
val LightBg = Color(0xFFF4F6FB)
val LightSurfaceBg = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8ECEF)
val LightGlassBorder = Color(0x1F000000)

// Vibrant Accent Colors for Notes
val NoteColorGold = Color(0xFFFFD700)
val NoteColorCyan = Color(0xFF00F2FE)
val NoteColorRose = Color(0xFFFF5252)
val NoteColorEmerald = Color(0xFF00E676)
val NoteColorPurple = Color(0xFFB388FF)
val NoteColorOrange = Color(0xFFFF9100)

// Standard M3 System Palette
val DarkPrimary = GoldAccent
val DarkOnPrimary = Color(0xFF000000)
val DarkBackground = ObsidianDarkBg
val DarkSurface = ObsidianSurface
val DarkOnSurface = Color(0xFFF3F5FA)
val DarkOnSurfaceVariant = Color(0xFF9EA6B8)

val LightPrimary = Color(0xFF000000)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightBackground = LightBg
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F1117)
val LightOnSurfaceVariant = Color(0xFF5C6370)
