package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.glassmorphicFloatingBar

@Composable
fun GlassSearchBar(
    query: String,
    onQueryChanged: (String) -> Unit,
    isGridView: Boolean,
    onToggleLayout: () -> Unit,
    modifier: Modifier = Modifier,
    isDark: Boolean = isSystemInDarkTheme()
) {
    val focusManager = LocalFocusManager.current

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .glassmorphicFloatingBar(isDark = isDark, cornerRadius = 26.dp)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = if (isDark) GoldAccent else MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .padding(start = 4.dp, end = 10.dp)
                .size(20.dp)
        )

        Box(
            modifier = Modifier.weight(1f),
            contentAlignment = Alignment.CenterStart
        ) {
            if (query.isEmpty()) {
                Text(
                    text = "Search notes...",
                    color = if (isDark) Color(0xFF7A8499) else Color(0xFF8C96A6),
                    fontSize = 14.sp
                )
            }

            BasicTextField(
                value = query,
                onValueChange = onQueryChanged,
                textStyle = TextStyle(
                    color = if (isDark) Color(0xFFF0F4FC) else Color(0xFF0F121C),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                ),
                cursorBrush = SolidColor(if (isDark) GoldAccent else MaterialTheme.colorScheme.primary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_input")
            )
        }

        AnimatedVisibility(
            visible = query.isNotEmpty(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            IconButton(
                onClick = { onQueryChanged("") },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Clear search",
                    tint = if (isDark) Color(0xFF9EA7B8) else Color(0xFF64748B),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Grid/List Layout Toggle
        IconButton(
            onClick = onToggleLayout,
            modifier = Modifier
                .testTag("toggle_layout_button")
                .size(36.dp)
                .clip(CircleShape)
                .background(if (isDark) Color(0x1AFFFFFF) else Color(0x0D000000))
        ) {
            Icon(
                imageVector = if (isGridView) Icons.Default.ViewAgenda else Icons.Default.GridView,
                contentDescription = if (isGridView) "Switch to List View" else "Switch to Grid View",
                tint = if (isDark) Color(0xFFE2E8F0) else Color(0xFF1E293B),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
