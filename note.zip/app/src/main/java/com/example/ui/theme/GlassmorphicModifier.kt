package com.example.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

fun Modifier.glassmorphicCard(
    isDark: Boolean,
    cornerRadius: Dp = 24.dp,
    accentColor: Color? = null,
    borderAlpha: Float = 0.18f
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    
    val bgBrush = if (isDark) {
        val base = accentColor?.copy(alpha = 0.08f) ?: Color(0xFF131722)
        Brush.verticalGradient(
            colors = listOf(
                base,
                Color(0xFF0D0F16).copy(alpha = 0.95f)
            )
        )
    } else {
        val base = accentColor?.copy(alpha = 0.06f) ?: Color(0xFFFFFFFF)
        Brush.verticalGradient(
            colors = listOf(
                base,
                Color(0xFFF8FAFC)
            )
        )
    }

    val borderBrush = if (isDark) {
        val startColor = accentColor?.copy(alpha = 0.4f) ?: Color.White.copy(alpha = borderAlpha)
        Brush.verticalGradient(
            colors = listOf(
                startColor,
                Color.White.copy(alpha = 0.03f)
            )
        )
    } else {
        val startColor = accentColor?.copy(alpha = 0.3f) ?: Color.Black.copy(alpha = borderAlpha)
        Brush.verticalGradient(
            colors = listOf(
                startColor,
                Color.Black.copy(alpha = 0.02f)
            )
        )
    }

    val shadowElevation = if (isDark) 8.dp else 4.dp
    val shadowColor = if (isDark) Color.Black.copy(alpha = 0.6f) else Color(0x1A000000)

    return this
        .shadow(elevation = shadowElevation, shape = shape, spotColor = shadowColor, ambientColor = shadowColor)
        .clip(shape)
        .background(bgBrush)
        .border(width = 1.dp, brush = borderBrush, shape = shape)
}

fun Modifier.glassmorphicFloatingBar(
    isDark: Boolean,
    cornerRadius: Dp = 28.dp
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    val bgBrush = if (isDark) {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xEE1A1E2B),
                Color(0xF00D0F17)
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xF2FFFFFF),
                Color(0xEEF0F4F8)
            )
        )
    }

    val borderBrush = if (isDark) {
        Brush.verticalGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.22f),
                Color.White.copy(alpha = 0.05f)
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                Color.Black.copy(alpha = 0.12f),
                Color.Black.copy(alpha = 0.03f)
            )
        )
    }

    return this
        .shadow(elevation = 12.dp, shape = shape, spotColor = Color.Black)
        .clip(shape)
        .background(bgBrush)
        .border(width = 1.dp, brush = borderBrush, shape = shape)
}
