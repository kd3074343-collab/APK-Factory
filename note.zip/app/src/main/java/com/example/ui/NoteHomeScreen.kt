package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Note
import com.example.ui.components.*
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NoteTheme
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.launch

@Composable
fun NoteHomeScreen(
    viewModel: NoteViewModel,
    modifier: Modifier = Modifier
) {
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isGridView by viewModel.isGridView.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val editingNote by viewModel.editingNote.collectAsStateWithLifecycle()
    val autoSaveStatus by viewModel.autoSaveStatus.collectAsStateWithLifecycle()

    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    NoteTheme(themeMode = themeMode) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    if (isDark) {
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF090A0E),
                                Color(0xFF11141D),
                                Color(0xFF08090C)
                            )
                        )
                    } else {
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFF4F6FB),
                                Color(0xFFE8EEF5)
                            )
                        )
                    }
                )
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.systemBars,
                snackbarHost = {
                    SnackbarHost(
                        hostState = snackbarHostState,
                        snackbar = { data ->
                            Snackbar(
                                snackbarData = data,
                                containerColor = if (isDark) Color(0xFF1E2330) else Color(0xFF1F2937),
                                contentColor = Color.White,
                                actionColor = GoldAccent,
                                shape = RoundedCornerShape(16.dp)
                            )
                        }
                    )
                },
                floatingActionButton = {
                    // Floating Action Button for New Note
                    FloatingActionButton(
                        onClick = { viewModel.openNewNote() },
                        containerColor = if (isDark) GoldAccent else MaterialTheme.colorScheme.primary,
                        contentColor = if (isDark) Color.Black else Color.White,
                        shape = RoundedCornerShape(20.dp),
                        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 10.dp),
                        modifier = Modifier
                            .testTag("fab_add_note")
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "New Note",
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Note",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    // App Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Note",
                                    style = MaterialTheme.typography.displayLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isDark) Color.White else Color(0xFF0F172A)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isDark) GoldAccent.copy(alpha = 0.2f)
                                            else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "KYNEX",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = if (isDark) GoldAccent else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Text(
                                text = "${notes.size} note${if (notes.size != 1) "s" else ""}",
                                fontSize = 12.sp,
                                color = if (isDark) Color(0xFF8895AA) else Color(0xFF64748B),
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Top Right Quick Action Badge
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (isDark) Color(0x1AFFFFFF) else Color(0x0D000000))
                                .padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EditNote,
                                contentDescription = "Note Studio",
                                tint = if (isDark) GoldAccent else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // Floating Glass Search Bar
                    GlassSearchBar(
                        query = searchQuery,
                        onQueryChanged = { viewModel.onSearchQueryChanged(it) },
                        isGridView = isGridView,
                        onToggleLayout = { viewModel.toggleLayoutMode() },
                        isDark = isDark
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Notes Content Grid or List
                    if (notes.isEmpty()) {
                        EmptyState(
                            isSearchEmpty = searchQuery.isNotBlank(),
                            onNewNote = { viewModel.openNewNote() },
                            isDark = isDark,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        AnimatedContent(
                            targetState = isGridView,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                            },
                            label = "layout_toggle",
                            modifier = Modifier.weight(1f)
                        ) { showGrid ->
                            if (showGrid) {
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(2),
                                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 100.dp),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(notes, key = { it.id }) { note ->
                                        NoteCard(
                                            note = note,
                                            onClick = { viewModel.openNoteForEdit(note) },
                                            isDark = isDark
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 100.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(notes, key = { it.id }) { note ->
                                        NoteCard(
                                            note = note,
                                            onClick = { viewModel.openNoteForEdit(note) },
                                            isDark = isDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Full-screen Note Editor Overlay with Slide Transition
            AnimatedVisibility(
                visible = editingNote != null,
                enter = slideInVertically(
                    initialOffsetY = { fullHeight -> fullHeight },
                    animationSpec = spring(stiffness = 350f)
                ) + fadeIn(),
                exit = slideOutVertically(
                    targetOffsetY = { fullHeight -> fullHeight },
                    animationSpec = spring(stiffness = 350f)
                ) + fadeOut()
            ) {
                editingNote?.let { currentNote ->
                    NoteEditorScreen(
                        note = currentNote,
                        autoSaveStatus = autoSaveStatus,
                        onDraftChanged = { title, content ->
                            viewModel.updateDraftNote(title, content)
                        },
                        onDelete = {
                            viewModel.deleteNote(currentNote) {
                                scope.launch {
                                    val result = snackbarHostState.showSnackbar(
                                        message = "Note deleted",
                                        actionLabel = "UNDO",
                                        duration = SnackbarDuration.Short
                                    )
                                    if (result == SnackbarResult.ActionPerformed) {
                                        viewModel.undoDelete()
                                    }
                                }
                            }
                        },
                        onClose = { viewModel.closeEditor() },
                        isDark = isDark
                    )
                }
            }
        }
    }
}
