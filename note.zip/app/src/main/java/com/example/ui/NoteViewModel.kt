package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Note
import com.example.data.NoteDatabase
import com.example.data.NoteRepository
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class AutoSaveStatus {
    object Idle : AutoSaveStatus()
    object Saving : AutoSaveStatus()
    data class Saved(val timeAgo: String = "Just now") : AutoSaveStatus()
}

class NoteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NoteRepository
    init {
        val noteDao = NoteDatabase.getDatabase(application).noteDao()
        repository = NoteRepository(noteDao)
    }

    // Search State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isGridView = MutableStateFlow(true)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.DARK)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Notes Flow
    @OptIn(FlowPreview::class)
    val notes: StateFlow<List<Note>> = _searchQuery
        .debounce(150)
        .flatMapLatest { query ->
            repository.searchNotes(query)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Editor & Auto Save State
    private val _editingNote = MutableStateFlow<Note?>(null)
    val editingNote: StateFlow<Note?> = _editingNote.asStateFlow()

    private val _autoSaveStatus = MutableStateFlow<AutoSaveStatus>(AutoSaveStatus.Idle)
    val autoSaveStatus: StateFlow<AutoSaveStatus> = _autoSaveStatus.asStateFlow()

    private var autoSaveJob: Job? = null
    private var lastDeletedNote: Note? = null

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun toggleLayoutMode() {
        _isGridView.value = !_isGridView.value
    }

    fun cycleThemeMode() {
        _themeMode.value = when (_themeMode.value) {
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.SYSTEM
            ThemeMode.SYSTEM -> ThemeMode.DARK
        }
    }

    fun openNewNote() {
        val newNote = Note(
            title = "",
            content = ""
        )
        _editingNote.value = newNote
        _autoSaveStatus.value = AutoSaveStatus.Idle
    }

    fun openNoteForEdit(note: Note) {
        _editingNote.value = note
        _autoSaveStatus.value = AutoSaveStatus.Idle
    }

    fun closeEditor() {
        autoSaveJob?.cancel()
        _editingNote.value?.let { note ->
            if (note.title.isNotBlank() || note.content.isNotBlank()) {
                viewModelScope.launch {
                    val updatedNote = note.copy(updatedAt = System.currentTimeMillis())
                    if (updatedNote.id == 0L) {
                        repository.insertNote(updatedNote)
                    } else {
                        repository.updateNote(updatedNote)
                    }
                }
            }
        }
        _editingNote.value = null
        _autoSaveStatus.value = AutoSaveStatus.Idle
    }

    fun updateDraftNote(title: String, content: String) {
        val current = _editingNote.value ?: return
        val updated = current.copy(
            title = title,
            content = content,
            updatedAt = System.currentTimeMillis()
        )
        _editingNote.value = updated

        // Trigger debounced real-time Auto Save
        scheduleAutoSave(updated)
    }

    private fun scheduleAutoSave(note: Note) {
        autoSaveJob?.cancel()

        autoSaveJob = viewModelScope.launch {
            delay(600) // Debounce delay before background save
            if (_editingNote.value == null) return@launch

            _autoSaveStatus.value = AutoSaveStatus.Saving
            if (note.title.isNotBlank() || note.content.isNotBlank()) {
                val savedId = if (note.id == 0L) {
                    val id = repository.insertNote(note)
                    if (_editingNote.value != null) {
                        _editingNote.value = note.copy(id = id)
                    }
                    id
                } else {
                    repository.updateNote(note)
                    note.id
                }
                if (_editingNote.value != null) {
                    _autoSaveStatus.value = AutoSaveStatus.Saved("Saved")
                }
            } else {
                _autoSaveStatus.value = AutoSaveStatus.Idle
            }
        }
    }

    fun deleteNote(note: Note, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            lastDeletedNote = note
            if (note.id != 0L) {
                repository.deleteNote(note)
            }
            if (_editingNote.value?.id == note.id) {
                _editingNote.value = null
            }
            onDeleted()
        }
    }

    fun undoDelete() {
        lastDeletedNote?.let { note ->
            viewModelScope.launch {
                repository.insertNote(note)
                lastDeletedNote = null
            }
        }
    }
}
