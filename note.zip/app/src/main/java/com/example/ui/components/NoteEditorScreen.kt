package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Note
import com.example.ui.AutoSaveStatus
import com.example.ui.theme.GoldAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    note: Note,
    autoSaveStatus: AutoSaveStatus,
    onDraftChanged: (title: String, content: String) -> Unit,
    onDelete: () -> Unit,
    onClose: () -> Unit,
    isDark: Boolean = isSystemInDarkTheme()
) {
    var title by remember(note.id) { mutableStateOf(note.title) }
    var content by remember(note.id) { mutableStateOf(note.content) }

    val accentColor = if (isDark) GoldAccent else MaterialTheme.colorScheme.primary

    val wordCount = remember(content) {
        if (content.isBlank()) 0 else content.trim().split("\\s+".toRegex()).size
    }
    val charCount = remember(content) { content.length }

    val bgColor = if (isDark) Color(0xFF090A0E) else Color(0xFFF4F6FB)

    Scaffold(
        containerColor = bgColor,
        contentWindowInsets = WindowInsets.systemBars,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = {
                    // Real-time Auto-Save Status Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                when (autoSaveStatus) {
                                    is AutoSaveStatus.Saving -> accentColor.copy(alpha = 0.2f)
                                    is AutoSaveStatus.Saved -> Color(0x2200E676)
                                    else -> if (isDark) Color(0x1AFFFFFF) else Color(0x0D000000)
                                }
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = when (autoSaveStatus) {
                                is AutoSaveStatus.Saving -> "🤖 Saving..."
                                is AutoSaveStatus.Saved -> "✓ Saved"
                                else -> "Draft"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = when (autoSaveStatus) {
                                is AutoSaveStatus.Saving -> accentColor
                                is AutoSaveStatus.Saved -> Color(0xFF00E676)
                                else -> if (isDark) Color(0xFF9EA6B8) else Color(0xFF64748B)
                            }
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .testTag("editor_back_button")
                            .padding(start = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (isDark) Color.White else Color.Black
                        )
                    }
                },
                actions = {
                    // Delete Note Button
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("editor_delete_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete Note",
                            tint = Color(0xFFFF5252)
                        )
                    }
                }
            )
        },
        bottomBar = {
            // Footer Stats Bar
            Surface(
                color = if (isDark) Color(0xFF131620) else Color(0xFFFFFFFF),
                tonalElevation = 6.dp,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                border = BorderStroke(1.dp, if (isDark) Color(0x22FFFFFF) else Color(0x11000000))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$wordCount words • $charCount characters",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isDark) Color(0xFF7A869A) else Color(0xFF94A3B8)
                    )

                    Text(
                        text = "Auto-Save ⚡",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Note Title Field
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.CenterStart
            ) {
                if (title.isEmpty()) {
                    Text(
                        text = "Title",
                        style = TextStyle(
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color(0xFF4A5568) else Color(0xFFCBD5E1)
                        )
                    )
                }

                BasicTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        onDraftChanged(title, content)
                    },
                    textStyle = TextStyle(
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
                    ),
                    cursorBrush = SolidColor(accentColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_title_input")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Subtle Divider Line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(if (isDark) Color(0x33FFFFFF) else Color(0x1F000000))
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Note Content Body Field
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 350.dp),
                contentAlignment = Alignment.TopStart
            ) {
                if (content.isEmpty()) {
                    Text(
                        text = "Note content...",
                        style = TextStyle(
                            fontSize = 16.sp,
                            lineHeight = 24.sp,
                            color = if (isDark) Color(0xFF4A5568) else Color(0xFFCBD5E1)
                        )
                    )
                }

                BasicTextField(
                    value = content,
                    onValueChange = {
                        content = it
                        onDraftChanged(title, content)
                    },
                    textStyle = TextStyle(
                        fontSize = 16.sp,
                        lineHeight = 24.sp,
                        color = if (isDark) Color(0xFFE2E8F0) else Color(0xFF1E293B)
                    ),
                    cursorBrush = SolidColor(accentColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 350.dp)
                        .testTag("editor_content_input")
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
