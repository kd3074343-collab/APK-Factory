package com.example

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material.icons.outlined.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: TicTacToeViewModel = viewModel()
            val state by viewModel.state.collectAsState()

            // Dynamic color schemes to match user preferences
            val darkColorScheme = darkColorScheme(
                primary = Color(0xFF00D2FF),     // Neon Blue
                secondary = Color(0xFFFF2E93),   // Neon Pink
                tertiary = Color(0xFFFFD700),    // Vibrant Gold
                background = Color(0xFF0F111A),  // Deep Space Dark
                surface = Color(0xFF161925),     // Dark Slate Surface
                onBackground = Color(0xFFF3F4F6),
                onSurface = Color(0xFFF3F4F6)
            )

            val lightColorScheme = lightColorScheme(
                primary = Color(0xFF0056B3),     // Classic Blue
                secondary = Color(0xFFD61F69),   // Crimson Pink
                tertiary = Color(0xFFD97706),    // Amber/Gold
                background = Color(0xFFF9FAFB),  // Crisp Clean White
                surface = Color(0xFFFFFFFF),     // Pure White Surface
                onBackground = Color(0xFF111827),
                onSurface = Color(0xFF111827)
            )

            val colorScheme = if (state.isDarkTheme) darkColorScheme else lightColorScheme

            MaterialTheme(colorScheme = colorScheme) {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = if (state.isDarkTheme) {
                                        listOf(Color(0xFF0F111A), Color(0xFF1E2235))
                                    } else {
                                        listOf(Color(0xFFF3F4F6), Color(0xFFE5E7EB))
                                    }
                                )
                            )
                            .padding(innerPadding)
                    ) {
                        TicTacToeApp(viewModel = viewModel, state = state)
                    }
                }
            }
        }
    }
}

@Composable
fun TicTacToeApp(viewModel: TicTacToeViewModel, state: TicTacToeState) {
    val context = LocalContext.current
    val onVibrateLoss = {
        triggerLossVibration(context)
    }

    // Dynamic strings object based on selected language
    val loc = remember(state.language) { Localization(state.language) }

    // Dialog state for language selector
    var showLanguageDialog by remember { mutableStateOf(false) }

    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguage = state.language,
            onDismiss = { showLanguageDialog = false },
            onSelect = {
                viewModel.setLanguage(it)
                showLanguageDialog = false
            },
            loc = loc
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (state.screenState) {
            ScreenState.HOME -> {
                HomeScreen(
                    viewModel = viewModel,
                    state = state,
                    loc = loc,
                    onOpenLanguageSelector = { showLanguageDialog = true }
                )
            }
            ScreenState.SELECTION -> {
                SelectionScreen(
                    viewModel = viewModel,
                    state = state,
                    loc = loc,
                    onVibrateLoss = onVibrateLoss
                )
            }
            ScreenState.GAME -> {
                GameScreen(
                    viewModel = viewModel,
                    state = state,
                    loc = loc,
                    onVibrateLoss = onVibrateLoss
                )
            }
        }
    }
}

// ---------------- HOME SCREEN ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TicTacToeViewModel,
    state: TicTacToeState,
    loc: Localization,
    onOpenLanguageSelector: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // App bar containing Settings dropdown
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                IconButton(
                    onClick = { showMenu = !showMenu },
                    modifier = Modifier.testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = loc.getString("settings"),
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Dropdown contains only exactly:
                // 1. Theme Change toggle
                // 2. Language Change option
                // 3. Vibration ON/OFF toggle
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surface)
                        .width(220.dp)
                ) {
                    // Theme toggle item
                    DropdownMenuItem(
                        text = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (state.isDarkTheme) Icons.Outlined.DarkMode else Icons.Outlined.LightMode,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (state.isDarkTheme) loc.getString("dark_theme") else loc.getString("light_theme"),
                                        fontSize = 14.sp
                                    )
                                }
                                Switch(
                                    checked = state.isDarkTheme,
                                    onCheckedChange = { viewModel.toggleTheme() },
                                    modifier = Modifier
                                        .scale(0.8f)
                                        .testTag("theme_toggle")
                                )
                            }
                        },
                        onClick = { viewModel.toggleTheme() }
                    )

                    // Language toggle item
                    DropdownMenuItem(
                        text = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.Translate,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = loc.getString("language"),
                                        fontSize = 14.sp
                                    )
                                }
                                Text(
                                    text = state.language.displayName,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        onClick = {
                            showMenu = false
                            onOpenLanguageSelector()
                        },
                        modifier = Modifier.testTag("language_toggle")
                    )

                    // Vibration toggle item
                    DropdownMenuItem(
                        text = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.Vibration,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = loc.getString("vibration"),
                                        fontSize = 14.sp
                                    )
                                }
                                Switch(
                                    checked = state.isVibrationEnabled,
                                    onCheckedChange = { viewModel.toggleVibration() },
                                    modifier = Modifier
                                        .scale(0.8f)
                                        .testTag("vibration_toggle")
                                )
                            }
                        },
                        onClick = { viewModel.toggleVibration() }
                    )
                }
            }
        }

        // Center visual hero content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Elegant Animated Floating App Branding
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer elegant circles
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = Color(0xFF00D2FF).copy(alpha = 0.15f),
                        radius = size.minDimension / 2f,
                        style = Stroke(width = 4f)
                    )
                }
                // Custom drawing representing a high tech Tic Tac Toe
                Canvas(modifier = Modifier.size(90.dp)) {
                    val w = size.width
                    val h = size.height
                    // Draw Tic Tac Toe Grid
                    drawLine(
                        color = Color.White.copy(alpha = 0.2f),
                        start = androidx.compose.ui.geometry.Offset(w / 3f, 0f),
                        end = androidx.compose.ui.geometry.Offset(w / 3f, h),
                        strokeWidth = 6f
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.2f),
                        start = androidx.compose.ui.geometry.Offset(2f * w / 3f, 0f),
                        end = androidx.compose.ui.geometry.Offset(2f * w / 3f, h),
                        strokeWidth = 6f
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.2f),
                        start = androidx.compose.ui.geometry.Offset(0f, h / 3f),
                        end = androidx.compose.ui.geometry.Offset(w, h / 3f),
                        strokeWidth = 6f
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.2f),
                        start = androidx.compose.ui.geometry.Offset(0f, 2f * h / 3f),
                        end = androidx.compose.ui.geometry.Offset(w, 2f * h / 3f),
                        strokeWidth = 6f
                    )

                    // Draw an X in top-left
                    drawLine(
                        color = Color(0xFF00D2FF),
                        start = androidx.compose.ui.geometry.Offset(w * 0.05f, h * 0.05f),
                        end = androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.28f),
                        strokeWidth = 8f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color(0xFF00D2FF),
                        start = androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.05f),
                        end = androidx.compose.ui.geometry.Offset(w * 0.05f, h * 0.28f),
                        strokeWidth = 8f,
                        cap = StrokeCap.Round
                    )

                    // Draw an O in bottom-right
                    drawArc(
                        color = Color(0xFFFF2E93),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = 8f, cap = StrokeCap.Round),
                        topLeft = androidx.compose.ui.geometry.Offset(w * 0.72f, h * 0.72f),
                        size = androidx.compose.ui.geometry.Size(w * 0.23f, h * 0.23f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Professional, sleek typography
            Text(
                text = "TIC TAC TOE",
                fontSize = 42.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 4.sp,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Text(
                text = "NEON EDITION",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 8.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(modifier = Modifier.height(60.dp))

            // Large, central play button
            Button(
                onClick = { viewModel.goToSelection() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .testTag("play_with_friends_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                shape = RoundedCornerShape(20.dp),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 8.dp,
                    pressedElevation = 2.dp
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = loc.getString("play_with_friends"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// ---------------- LANGUAGE DIALOG ----------------

@Composable
fun LanguageSelectionDialog(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onSelect: (AppLanguage) -> Unit,
    loc: Localization
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .width(320.dp)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = loc.getString("language"),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(16.dp))

                AppLanguage.values().forEach { lang ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(lang) }
                            .padding(vertical = 12.dp, horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = lang.displayName,
                            fontSize = 16.sp,
                            fontWeight = if (lang == currentLanguage) FontWeight.Bold else FontWeight.Normal,
                            color = if (lang == currentLanguage) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                        RadioButton(
                            selected = (lang == currentLanguage),
                            onClick = { onSelect(lang) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "OK", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- SELECTION SCREEN ----------------

@Composable
fun SelectionScreen(
    viewModel: TicTacToeViewModel,
    state: TicTacToeState,
    loc: Localization,
    onVibrateLoss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Simple back navigation or title
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
        ) {
            IconButton(
                onClick = { viewModel.goToHome() },
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                Canvas(modifier = Modifier.size(24.dp)) {
                    // Back arrow custom drawing
                    drawLine(
                        color = Color.White.copy(alpha = 0.8f),
                        start = androidx.compose.ui.geometry.Offset(size.width * 0.7f, size.height * 0.15f),
                        end = androidx.compose.ui.geometry.Offset(size.width * 0.3f, size.height * 0.5f),
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.8f),
                        start = androidx.compose.ui.geometry.Offset(size.width * 0.3f, size.height * 0.5f),
                        end = androidx.compose.ui.geometry.Offset(size.width * 0.7f, size.height * 0.85f),
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )
                }
            }

            Text(
                text = loc.getString("play_with_friends"),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Section 1: Choose piece (X or O)
            Text(
                text = loc.getString("select_piece"),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                // X Selection Card
                Card(
                    modifier = Modifier
                        .size(110.dp)
                        .clickable { viewModel.selectPiece(CellType.X) }
                        .testTag("piece_select_x"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (state.chosenPiece == CellType.X) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        }
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(
                        width = if (state.chosenPiece == CellType.X) 3.dp else 1.dp,
                        color = if (state.chosenPiece == CellType.X) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.3f)
                    )
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Canvas(modifier = Modifier.size(45.dp)) {
                            val w = size.width
                            val h = size.height
                            drawLine(
                                color = Color(0xFF00D2FF),
                                start = androidx.compose.ui.geometry.Offset(0f, 0f),
                                end = androidx.compose.ui.geometry.Offset(w, h),
                                strokeWidth = 10f,
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = Color(0xFF00D2FF),
                                start = androidx.compose.ui.geometry.Offset(w, 0f),
                                end = androidx.compose.ui.geometry.Offset(0f, h),
                                strokeWidth = 10f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(24.dp))

                // O Selection Card
                Card(
                    modifier = Modifier
                        .size(110.dp)
                        .clickable { viewModel.selectPiece(CellType.O) }
                        .testTag("piece_select_o"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (state.chosenPiece == CellType.O) {
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        }
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(
                        width = if (state.chosenPiece == CellType.O) 3.dp else 1.dp,
                        color = if (state.chosenPiece == CellType.O) MaterialTheme.colorScheme.secondary else Color.Gray.copy(alpha = 0.3f)
                    )
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Canvas(modifier = Modifier.size(45.dp)) {
                            drawArc(
                                color = Color(0xFFFF2E93),
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = 10f, cap = StrokeCap.Round)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Section 2: Play Mode (Human vs Computer)
            Text(
                text = loc.getString("play_mode"),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                // HUMAN button
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(85.dp)
                        .clickable { viewModel.selectPlayMode(PlayMode.HUMAN) }
                        .testTag("play_mode_human"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (state.playMode == PlayMode.HUMAN) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        }
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        width = if (state.playMode == PlayMode.HUMAN) 2.dp else 1.dp,
                        color = if (state.playMode == PlayMode.HUMAN) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f)
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = if (state.playMode == PlayMode.HUMAN) MaterialTheme.colorScheme.primary else Color.Gray,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = loc.getString("human"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.playMode == PlayMode.HUMAN) MaterialTheme.colorScheme.onBackground else Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // COMPUTER button
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(85.dp)
                        .clickable { viewModel.selectPlayMode(PlayMode.COMPUTER) }
                        .testTag("play_mode_computer"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (state.playMode == PlayMode.COMPUTER) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        }
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        width = if (state.playMode == PlayMode.COMPUTER) 2.dp else 1.dp,
                        color = if (state.playMode == PlayMode.COMPUTER) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f)
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Computer,
                            contentDescription = null,
                            tint = if (state.playMode == PlayMode.COMPUTER) MaterialTheme.colorScheme.primary else Color.Gray,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = loc.getString("computer"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.playMode == PlayMode.COMPUTER) MaterialTheme.colorScheme.onBackground else Color.Gray
                        )
                    }
                }
            }
        }

        // Bottom start play button
        Button(
            onClick = { viewModel.startGame(onVibrateLoss) },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .padding(bottom = 8.dp)
                .testTag("start_play_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            shape = RoundedCornerShape(16.dp),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
        ) {
            Text(
                text = loc.getString("play"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                color = Color.White
            )
        }
    }
}

// ---------------- GAME SCREEN ----------------

@Composable
fun GameScreen(
    viewModel: TicTacToeViewModel,
    state: TicTacToeState,
    loc: Localization,
    onVibrateLoss: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Info & Exit Option
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.exitMatch() },
                    modifier = Modifier.testTag("game_back_button")
                ) {
                    Canvas(modifier = Modifier.size(22.dp)) {
                        drawLine(
                            color = Color.White.copy(alpha = 0.7f),
                            start = androidx.compose.ui.geometry.Offset(0f, size.height * 0.5f),
                            end = androidx.compose.ui.geometry.Offset(size.width, size.height * 0.5f),
                            strokeWidth = 5f,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color.White.copy(alpha = 0.7f),
                            start = androidx.compose.ui.geometry.Offset(0f, size.height * 0.5f),
                            end = androidx.compose.ui.geometry.Offset(size.width * 0.4f, size.height * 0.2f),
                            strokeWidth = 5f,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color.White.copy(alpha = 0.7f),
                            start = androidx.compose.ui.geometry.Offset(0f, size.height * 0.5f),
                            end = androidx.compose.ui.geometry.Offset(size.width * 0.4f, size.height * 0.8f),
                            strokeWidth = 5f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Match details label (e.g. Human vs Computer)
                val modeLabel = if (state.playMode == PlayMode.COMPUTER) {
                    "${loc.getString("human")} VS ${loc.getString("computer")}"
                } else {
                    "${loc.getString("human")} VS ${loc.getString("human")}"
                }
                Text(
                    text = modeLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.2.sp
                )

                // Placeholder to balance layout
                Spacer(modifier = Modifier.width(48.dp))
            }

            // Current Turn Status Indicator
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                if (state.isComputerThinking) {
                    // Modern thinking animation indicator
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${loc.getString("computer")} is thinking",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        ThinkingDotAnimation()
                    }
                } else {
                    val turnText = if (state.currentTurn == CellType.X) {
                        loc.getString("turn_x")
                    } else {
                        loc.getString("turn_o")
                    }
                    Text(
                        text = turnText,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (state.currentTurn == CellType.X) Color(0xFF00D2FF) else Color(0xFFFF2E93),
                        letterSpacing = 1.sp
                    )
                }
            }

            // Tic Tac Toe 3x3 Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                // Grid backgrounds/board columns
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (row in 0..2) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            for (col in 0..2) {
                                val idx = row * 3 + col
                                val isWinIdx = state.winningLine?.contains(idx) == true
                                BoardCell(
                                    cell = state.board[idx],
                                    onClick = { viewModel.makeMove(idx, onVibrateLoss) },
                                    isWinningCell = isWinIdx,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("game_cell_$idx")
                                )
                            }
                        }
                    }
                }
            }

            // Bottom blank space during active game to keep pristine focus on the grid.
            // Match end overlays are overlayed directly when the game completes.
            Spacer(modifier = Modifier.height(48.dp))
        }

        // Match Finish Overlay (PLAY AGAIN & EXIT buttons, Confetti/Animation)
        if (state.winStatus != WinStatus.ONGOING) {
            MatchEndOverlay(
                state = state,
                viewModel = viewModel,
                loc = loc,
                onVibrateLoss = onVibrateLoss
            )
        }
    }
}

@Composable
fun ThinkingDotAnimation() {
    val transition = rememberInfiniteTransition(label = "dots")
    val dotCount = 3
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (i in 0 until dotCount) {
            val scale by transition.animateFloat(
                initialValue = 0.4f,
                targetValue = 1.2f,
                animationSpec = infiniteRepeatable(
                    animation = tween(400, delayMillis = i * 150),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "dot_$i"
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.secondary)
            )
        }
    }
}

@Composable
fun BoardCell(
    cell: CellType?,
    onClick: () -> Unit,
    isWinningCell: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .aspectRatio(1f)
            .padding(6.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isWinningCell) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
            }
        ),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(
            width = if (isWinningCell) 3.dp else 1.dp,
            color = if (isWinningCell) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)
            }
        ),
        onClick = onClick
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (cell != null) {
                AnimatedSymbol(cell = cell, isWinningCell = isWinningCell)
            }
        }
    }
}

@Composable
fun AnimatedSymbol(cell: CellType, isWinningCell: Boolean) {
    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(cell) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f)
        )
    }

    val primaryColor = Color(0xFF00D2FF)  // Neon X Blue
    val secondaryColor = Color(0xFFFF2E93) // Neon O Pink
    val highlightColor = Color(0xFFFFD700) // Winning Gold

    Canvas(modifier = Modifier.fillMaxSize(0.6f)) {
        val width = size.width
        val height = size.height
        val strokeWidthVal = 14f

        if (cell == CellType.X) {
            val color = if (isWinningCell) highlightColor else primaryColor
            // Line 1: Top-Left to Bottom-Right
            val p1 = animProgress.value.coerceAtMost(0.5f) * 2f
            drawLine(
                color = color,
                start = androidx.compose.ui.geometry.Offset(0f, 0f),
                end = androidx.compose.ui.geometry.Offset(width * p1, height * p1),
                strokeWidth = strokeWidthVal,
                cap = StrokeCap.Round
            )
            // Line 2: Top-Right to Bottom-Left
            if (animProgress.value > 0.5f) {
                val p2 = (animProgress.value - 0.5f) * 2f
                drawLine(
                    color = color,
                    start = androidx.compose.ui.geometry.Offset(width, 0f),
                    end = androidx.compose.ui.geometry.Offset(width - width * p2, height * p2),
                    strokeWidth = strokeWidthVal,
                    cap = StrokeCap.Round
                )
            }
        } else {
            val color = if (isWinningCell) highlightColor else secondaryColor
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * animProgress.value,
                useCenter = false,
                style = Stroke(
                    width = strokeWidthVal,
                    cap = StrokeCap.Round
                )
            )
        }
    }
}

// ---------------- MATCH END OVERLAY ----------------

@Composable
fun MatchEndOverlay(
    state: TicTacToeState,
    viewModel: TicTacToeViewModel,
    loc: Localization,
    onVibrateLoss: () -> Unit
) {
    val isXWinner = state.winStatus == WinStatus.X_WON
    val isOWinner = state.winStatus == WinStatus.O_WON
    val isDraw = state.winStatus == WinStatus.DRAW

    val resultText = when {
        isXWinner -> loc.getString("winner_x")
        isOWinner -> loc.getString("winner_o")
        else -> loc.getString("draw")
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        // Confetti Particle Canvas
        if (isXWinner || isOWinner) {
            ConfettiEffect()
        }

        // Overlay layout with ONLY TWO buttons: PLAY AGAIN, EXIT
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated visual game result banner
            var scaleVal by remember { mutableStateOf(0f) }
            LaunchedEffect(Unit) {
                animProgress(0f, 1f) { scaleVal = it }
            }

            Card(
                modifier = Modifier
                    .scale(scaleVal)
                    .fillMaxWidth(0.9f)
                    .padding(bottom = 40.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 16.dp),
                border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = resultText,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Button 1: PLAY AGAIN
            Button(
                onClick = { viewModel.restartMatch(onVibrateLoss) },
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(60.dp)
                    .testTag("play_again_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                shape = RoundedCornerShape(16.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
            ) {
                Text(
                    text = loc.getString("play_again"),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 1.2.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Button 2: EXIT
            Button(
                onClick = { viewModel.exitMatch() },
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(60.dp)
                    .testTag("exit_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(16.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Text(
                    text = loc.getString("exit"),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.2.sp
                )
            }
        }
    }
}

suspend inline fun animProgress(from: Float, to: Float, crossinline onUpdate: (Float) -> Unit) {
    val anim = Animatable(from)
    anim.animateTo(
        targetValue = to,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 300f)
    ) {
        onUpdate(value)
    }
}

// ---------------- CONFETTI EFFECT ----------------

data class ConfettiParticle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    val size: Float,
    var rotation: Float,
    val rotationSpeed: Float
)

@Composable
fun ConfettiEffect() {
    val particles = remember { mutableStateListOf<ConfettiParticle>() }
    val colors = listOf(
        Color(0xFF00D2FF), Color(0xFFFF2E93), Color(0xFFFFD700),
        Color(0xFF00FFCC), Color(0xFF9D4EDD), Color(0xFFFF9E00)
    )

    LaunchedEffect(Unit) {
        // Spawn 80 colorful falling particles
        repeat(80) {
            particles.add(
                ConfettiParticle(
                    x = (0..1000).random().toFloat() / 1000f,
                    y = -0.1f - (0..1000).random().toFloat() / 1000f,
                    vx = ((10..50).random().toFloat() - 30f) / 1500f,
                    vy = (15..35).random().toFloat() / 1000f,
                    color = colors.random(),
                    size = (12..28).random().toFloat(),
                    rotation = (0..360).random().toFloat(),
                    rotationSpeed = ((5..15).random().toFloat() - 10f)
                )
            )
        }

        // Smooth physics-loop at maximum frame rate
        while (true) {
            withFrameMillis {
                for (i in particles.indices) {
                    val p = particles[i]
                    p.y += p.vy
                    p.x += p.vx
                    p.vx += ((0..10).random().toFloat() - 5f) / 8000f
                    p.rotation += p.rotationSpeed
                    // Recycle particles back to the top once they exit off the bottom
                    if (p.y > 1.1f) {
                        p.y = -0.1f
                        p.x = (0..1000).random().toFloat() / 1000f
                        p.vy = (15..35).random().toFloat() / 1000f
                    }
                }
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        particles.forEach { p ->
            val px = p.x * w
            val py = p.y * h
            drawContext.canvas.save()
            drawContext.canvas.translate(px, py)
            drawContext.canvas.rotate(p.rotation)
            drawRoundRect(
                color = p.color,
                size = androidx.compose.ui.geometry.Size(p.size, p.size),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
            )
            drawContext.canvas.restore()
        }
    }
}

// ---------------- LOCALIZATION STRINGS ----------------

class Localization(private val language: AppLanguage) {
    fun getString(key: String): String {
        return when (language) {
            AppLanguage.ENGLISH -> when (key) {
                "play_with_friends" -> "PLAY WITH FRIENDS"
                "settings" -> "Settings"
                "theme" -> "Theme"
                "dark_theme" -> "Dark Mode"
                "light_theme" -> "Light Mode"
                "language" -> "Language"
                "vibration" -> "Vibration"
                "vibration_on" -> "ON"
                "vibration_off" -> "OFF"
                "select_piece" -> "CHOOSE YOUR SYMBOL"
                "play_mode" -> "PLAY MODE"
                "human" -> "HUMAN"
                "computer" -> "COMPUTER"
                "play" -> "PLAY"
                "turn_x" -> "X's Turn"
                "turn_o" -> "O's Turn"
                "winner_x" -> "X Wins! 🎉"
                "winner_o" -> "O Wins! 🎉"
                "draw" -> "It's a Draw! 🤝"
                "play_again" -> "PLAY AGAIN"
                "exit" -> "EXIT"
                else -> key
            }
            AppLanguage.SPANISH -> when (key) {
                "play_with_friends" -> "JUGAR CON AMIGOS"
                "settings" -> "Ajustes"
                "theme" -> "Tema"
                "dark_theme" -> "Modo Oscuro"
                "light_theme" -> "Modo Claro"
                "language" -> "Idioma"
                "vibration" -> "Vibración"
                "vibration_on" -> "SÍ"
                "vibration_off" -> "NO"
                "select_piece" -> "ELIGE TU SÍMBOLO"
                "play_mode" -> "MODO DE JUEGO"
                "human" -> "HUMANO"
                "computer" -> "MÁQUINA"
                "play" -> "JUGAR"
                "turn_x" -> "Turno de X"
                "turn_o" -> "Turno de O"
                "winner_x" -> "¡Gana X! 🎉"
                "winner_o" -> "¡Gana O! 🎉"
                "draw" -> "¡Empate! 🤝"
                "play_again" -> "JUGAR DE NUEVO"
                "exit" -> "SALIR"
                else -> key
            }
            AppLanguage.FRENCH -> when (key) {
                "play_with_friends" -> "JOUER AVEC AMIS"
                "settings" -> "Paramètres"
                "theme" -> "Thème"
                "dark_theme" -> "Mode Sombre"
                "light_theme" -> "Mode Clair"
                "language" -> "Langue"
                "vibration" -> "Vibration"
                "vibration_on" -> "ACTIF"
                "vibration_off" -> "INACTIF"
                "select_piece" -> "CHOISISSEZ LE SYMBOLE"
                "play_mode" -> "MODE DE JEU"
                "human" -> "HUMAIN"
                "computer" -> "ORDINATEUR"
                "play" -> "JOUER"
                "turn_x" -> "Tour de X"
                "turn_o" -> "Tour de O"
                "winner_x" -> "X a Gagné ! 🎉"
                "winner_o" -> "O a Gagné ! 🎉"
                "draw" -> "Match Nul ! 🤝"
                "play_again" -> "REJOUER"
                "exit" -> "QUITTER"
                else -> key
            }
            AppLanguage.JAPANESE -> when (key) {
                "play_with_friends" -> "友達と遊ぶ"
                "settings" -> "設定"
                "theme" -> "テーマ"
                "dark_theme" -> "ダークモード"
                "light_theme" -> "ライトモード"
                "language" -> "言語"
                "vibration" -> "バイブ"
                "vibration_on" -> "オン"
                "vibration_off" -> "オフ"
                "select_piece" -> "シンボルの選択"
                "play_mode" -> "プレイモード"
                "human" -> "対戦プレイ"
                "computer" -> "コンピューター"
                "play" -> "スタート"
                "turn_x" -> "X のターン"
                "turn_o" -> "O のターン"
                "winner_x" -> "X の勝ち！ 🎉"
                "winner_o" -> "O の勝ち！ 🎉"
                "draw" -> "引き分け！ 🤝"
                "play_again" -> "もう一度"
                "exit" -> "終了"
                else -> key
            }
        }
    }
}

// ---------------- VIBRATION UTILITY ----------------

fun triggerLossVibration(context: Context) {
    try {
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }
        }
    } catch (e: Exception) {
        // Safe catch for simulator environments or restrictive permissions
    }
}
