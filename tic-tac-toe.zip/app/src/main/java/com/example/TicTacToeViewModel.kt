package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ScreenState {
    HOME,
    SELECTION,
    GAME
}

enum class CellType {
    X, O
}

enum class PlayMode {
    HUMAN,
    COMPUTER
}

enum class WinStatus {
    ONGOING,
    X_WON,
    O_WON,
    DRAW
}

enum class AppLanguage(val displayName: String) {
    ENGLISH("English"),
    SPANISH("Español"),
    FRENCH("Français"),
    JAPANESE("日本語")
}

data class TicTacToeState(
    val screenState: ScreenState = ScreenState.HOME,
    // Preferences
    val isDarkTheme: Boolean = true,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val isVibrationEnabled: Boolean = true,
    // Selection state
    val chosenPiece: CellType = CellType.X,
    val playMode: PlayMode = PlayMode.HUMAN,
    // Game state
    val board: List<CellType?> = List(9) { null },
    val currentTurn: CellType = CellType.X,
    val winStatus: WinStatus = WinStatus.ONGOING,
    val winningLine: List<Int>? = null,
    val isComputerThinking: Boolean = false
)

class TicTacToeViewModel : ViewModel() {

    private val _state = MutableStateFlow(TicTacToeState())
    val state: StateFlow<TicTacToeState> = _state.asStateFlow()

    // Preferences Actions
    fun toggleTheme() {
        _state.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun setLanguage(lang: AppLanguage) {
        _state.update { it.copy(language = lang) }
    }

    fun toggleVibration() {
        _state.update { it.copy(isVibrationEnabled = !it.isVibrationEnabled) }
    }

    // Navigation Actions
    fun goToSelection() {
        _state.update { it.copy(screenState = ScreenState.SELECTION) }
    }

    fun goToHome() {
        _state.update { it.copy(screenState = ScreenState.HOME) }
    }

    // Selection Screen Actions
    fun selectPiece(piece: CellType) {
        _state.update { it.copy(chosenPiece = piece) }
    }

    fun selectPlayMode(mode: PlayMode) {
        _state.update { it.copy(playMode = mode) }
    }

    fun startGame(onVibrateLoss: () -> Unit) {
        val firstTurn = CellType.X // X always starts in standard Tic Tac Toe
        _state.update {
            it.copy(
                screenState = ScreenState.GAME,
                board = List(9) { null },
                currentTurn = firstTurn,
                winStatus = WinStatus.ONGOING,
                winningLine = null,
                isComputerThinking = false
            )
        }
        
        // If computer is starting and player is O, trigger computer move
        if (_state.value.playMode == PlayMode.COMPUTER && _state.value.chosenPiece == CellType.O) {
            triggerComputerMove(onVibrateLoss)
        }
    }

    // Game Actions
    fun makeMove(index: Int, onVibrateLoss: () -> Unit) {
        val currentState = _state.value
        if (currentState.screenState != ScreenState.GAME ||
            currentState.isComputerThinking ||
            currentState.board[index] != null ||
            currentState.winStatus != WinStatus.ONGOING
        ) {
            return
        }

        // Apply current move
        val nextBoard = currentState.board.toMutableList()
        nextBoard[index] = currentState.currentTurn

        // Check if game is finished after this move
        val evaluation = evaluateBoard(nextBoard)
        val nextTurn = if (currentState.currentTurn == CellType.X) CellType.O else CellType.X

        _state.update {
            it.copy(
                board = nextBoard,
                currentTurn = nextTurn,
                winStatus = evaluation.status,
                winningLine = evaluation.line
            )
        }

        // Check for vibration if match ended and vibration is enabled
        if (evaluation.status != WinStatus.ONGOING) {
            handleGameEnd(evaluation.status, onVibrateLoss)
            return
        }

        // Trigger computer turn if applicable
        if (currentState.playMode == PlayMode.COMPUTER && nextTurn != currentState.chosenPiece) {
            triggerComputerMove(onVibrateLoss)
        }
    }

    private fun triggerComputerMove(onVibrateLoss: () -> Unit) {
        _state.update { it.copy(isComputerThinking = true) }
        viewModelScope.launch {
            // Introduce a natural computer thinking delay (600ms) to feel realistic and polished
            delay(600)
            val currentState = _state.value
            if (currentState.winStatus != WinStatus.ONGOING) {
                _state.update { it.copy(isComputerThinking = false) }
                return@launch
            }

            val playerPiece = currentState.chosenPiece
            val computerPiece = if (playerPiece == CellType.X) CellType.O else CellType.X
            val compMove = getComputerMove(currentState.board, computerPiece, playerPiece)

            if (compMove != -1) {
                val nextBoard = currentState.board.toMutableList()
                nextBoard[compMove] = computerPiece

                val evaluation = evaluateBoard(nextBoard)
                val nextTurn = playerPiece

                _state.update {
                    it.copy(
                        board = nextBoard,
                        currentTurn = nextTurn,
                        winStatus = evaluation.status,
                        winningLine = evaluation.line,
                        isComputerThinking = false
                    )
                }

                if (evaluation.status != WinStatus.ONGOING) {
                    handleGameEnd(evaluation.status, onVibrateLoss)
                }
            } else {
                _state.update { it.copy(isComputerThinking = false) }
            }
        }
    }

    private fun handleGameEnd(status: WinStatus, onVibrateLoss: () -> Unit) {
        val currentState = _state.value
        val playerPiece = currentState.chosenPiece
        val isComputerOpponent = currentState.playMode == PlayMode.COMPUTER

        // Loss condition:
        // vs COMPUTER, and winner is the opponent (not playerPiece)
        val isLoss = isComputerOpponent && (
            (status == WinStatus.X_WON && playerPiece == CellType.O) ||
            (status == WinStatus.O_WON && playerPiece == CellType.X)
        )

        if (isLoss && currentState.isVibrationEnabled) {
            onVibrateLoss()
        }
    }

    // Play again
    fun restartMatch(onVibrateLoss: () -> Unit) {
        startGame(onVibrateLoss)
    }

    // Exit match
    fun exitMatch() {
        _state.update { it.copy(screenState = ScreenState.HOME) }
    }

    // Board helper algorithms
    private data class BoardEvaluation(
        val status: WinStatus,
        val line: List<Int>?
    )

    private fun evaluateBoard(board: List<CellType?>): BoardEvaluation {
        val winPatterns = listOf(
            listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8), // Rows
            listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8), // Columns
            listOf(0, 4, 8), listOf(2, 4, 6)                  // Diagonals
        )

        for (pattern in winPatterns) {
            val a = board[pattern[0]]
            val b = board[pattern[1]]
            val c = board[pattern[2]]
            if (a != null && a == b && b == c) {
                val status = if (a == CellType.X) WinStatus.X_WON else WinStatus.O_WON
                return BoardEvaluation(status, pattern)
            }
        }

        val isDraw = board.none { it == null }
        val status = if (isDraw) WinStatus.DRAW else WinStatus.ONGOING
        return BoardEvaluation(status, null)
    }

    private fun getComputerMove(board: List<CellType?>, computerPiece: CellType, playerPiece: CellType): Int {
        // 1. Can computer win in this move?
        for (i in 0..8) {
            if (board[i] == null) {
                val nextBoard = board.toMutableList()
                nextBoard[i] = computerPiece
                if (evaluateBoard(nextBoard).status != WinStatus.ONGOING) {
                    return i
                }
            }
        }

        // 2. Can player win in this move? Block them!
        for (i in 0..8) {
            if (board[i] == null) {
                val nextBoard = board.toMutableList()
                nextBoard[i] = playerPiece
                if (evaluateBoard(nextBoard).status != WinStatus.ONGOING) {
                    return i
                }
            }
        }

        // 3. Take center if available
        if (board[4] == null) return 4

        // 4. Take corners if available
        val corners = listOf(0, 2, 6, 8).filter { board[it] == null }
        if (corners.isNotEmpty()) {
            return corners.random()
        }

        // 5. Take any remaining empty cell
        val empty = (0..8).filter { board[it] == null }
        return if (empty.isNotEmpty()) empty.random() else -1
    }
}
