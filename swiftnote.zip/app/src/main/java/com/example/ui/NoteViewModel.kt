package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Note
import com.example.data.NoteRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NoteViewModel(
    private val repository: NoteRepository,
    context: Context
) : ViewModel() {

    private val sharedPrefs = context.getSharedPreferences("note_app_prefs", Context.MODE_PRIVATE)

    // Theme Mode: "system", "light", "dark"
    private val _themeMode = MutableStateFlow(sharedPrefs.getString("theme_mode", "system") ?: "system")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
        sharedPrefs.edit().putString("theme_mode", mode).apply()
    }

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // All notes from Repository
    val allNotes: StateFlow<List<Note>> = repository.allNotes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered notes based on Search Query
    val filteredNotes: StateFlow<List<Note>> = combine(allNotes, _searchQuery) { notes, query ->
        if (query.isBlank()) {
            notes
        } else {
            notes.filter { note ->
                note.title.contains(query, ignoreCase = true) ||
                        note.content.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Current note being edited
    private val _currentNoteId = MutableStateFlow<Int?>(null)
    val currentNoteId: StateFlow<Int?> = _currentNoteId.asStateFlow()

    private val _noteTitle = MutableStateFlow("")
    val noteTitle: StateFlow<String> = _noteTitle.asStateFlow()

    private val _noteContent = MutableStateFlow("")
    val noteContent: StateFlow<String> = _noteContent.asStateFlow()

    private var currentCreatedAt: Long? = null

    private val _isNotePinned = MutableStateFlow(false)
    val isNotePinned: StateFlow<Boolean> = _isNotePinned.asStateFlow()

    private val _isNoteFavorite = MutableStateFlow(false)
    val isNoteFavorite: StateFlow<Boolean> = _isNoteFavorite.asStateFlow()

    private val _noteColorHex = MutableStateFlow("default")
    val noteColorHex: StateFlow<String> = _noteColorHex.asStateFlow()

    // Save status
    private val _saveStatus = MutableStateFlow("")
    val saveStatus: StateFlow<String> = _saveStatus.asStateFlow()

    private var autoSaveJob: Job? = null

    fun updateNoteTitle(newTitle: String) {
        _noteTitle.value = newTitle
        triggerAutoSave()
    }

    fun updateNoteContent(newContent: String) {
        _noteContent.value = newContent
        triggerAutoSave()
    }

    private fun triggerAutoSave() {
        _saveStatus.value = "Saving..."
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(1000) // 1 second debounce to prevent excessive database writes while typing
            saveCurrentNote()
        }
    }

    suspend fun saveCurrentNoteSync() {
        autoSaveJob?.cancel()
        saveCurrentNote()
    }

    private suspend fun saveCurrentNote() {
        val title = _noteTitle.value
        val content = _noteContent.value

        // If it's a completely empty note and we haven't saved it yet, don't write to DB
        if (title.isBlank() && content.isBlank() && _currentNoteId.value == null) {
            _saveStatus.value = ""
            return
        }

        val currentId = _currentNoteId.value
        val now = System.currentTimeMillis()
        val noteToSave = Note(
            id = currentId ?: 0,
            title = title,
            content = content,
            createdAt = currentCreatedAt ?: now,
            updatedAt = now,
            isPinned = _isNotePinned.value,
            isFavorite = _isNoteFavorite.value,
            colorHex = _noteColorHex.value
        )

        val newId = repository.insertNote(noteToSave)
        if (currentId == null) {
            _currentNoteId.value = newId.toInt()
        }
        _saveStatus.value = "Saved"
    }

    fun prepareNewNote() {
        autoSaveJob?.cancel()
        _currentNoteId.value = null
        _noteTitle.value = ""
        _noteContent.value = ""
        currentCreatedAt = System.currentTimeMillis()
        _isNotePinned.value = false
        _isNoteFavorite.value = false
        _noteColorHex.value = "default"
        _saveStatus.value = ""
    }

    fun selectNoteForEditing(noteId: Int) {
        autoSaveJob?.cancel()
        viewModelScope.launch {
            val note = repository.getNoteById(noteId)
            if (note != null) {
                _currentNoteId.value = note.id
                _noteTitle.value = note.title
                _noteContent.value = note.content
                currentCreatedAt = note.createdAt
                _isNotePinned.value = note.isPinned
                _isNoteFavorite.value = note.isFavorite
                _noteColorHex.value = note.colorHex
                _saveStatus.value = "Saved"
            }
        }
    }

    fun togglePinOnDetail() {
        _isNotePinned.value = !_isNotePinned.value
        viewModelScope.launch {
            saveCurrentNote()
        }
    }

    fun toggleFavoriteOnDetail() {
        _isNoteFavorite.value = !_isNoteFavorite.value
        viewModelScope.launch {
            saveCurrentNote()
        }
    }

    fun updateColorOnDetail(colorId: String) {
        _noteColorHex.value = colorId
        viewModelScope.launch {
            saveCurrentNote()
        }
    }

    // Quick actions on list screen
    fun togglePin(note: Note) {
        viewModelScope.launch {
            repository.insertNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    fun toggleFavorite(note: Note) {
        viewModelScope.launch {
            repository.insertNote(note.copy(isFavorite = !note.isFavorite, updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    fun deleteCurrentNote() {
        val currentId = _currentNoteId.value
        if (currentId != null) {
            viewModelScope.launch {
                repository.deleteNoteById(currentId)
                prepareNewNote()
            }
        }
    }

    class Factory(
        private val repository: NoteRepository,
        private val context: Context
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(NoteViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return NoteViewModel(repository, context) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
