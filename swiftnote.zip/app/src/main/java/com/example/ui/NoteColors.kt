package com.example.ui

import androidx.compose.ui.graphics.Color

data class ColorThemePair(
    val id: String,
    val name: String,
    val lightBg: Color,
    val darkBg: Color,
    val lightBorder: Color,
    val darkBorder: Color
)

object NoteColors {
    val list = listOf(
        ColorThemePair(
            id = "default",
            name = "Default",
            lightBg = Color(0xFFF8FAFC),
            darkBg = Color(0xFF1E293B),
            lightBorder = Color(0xFFE2E8F0),
            darkBorder = Color(0xFF334155)
        ),
        ColorThemePair(
            id = "red",
            name = "Rose",
            lightBg = Color(0xFFFFF1F2),
            darkBg = Color(0xFF4C1D24),
            lightBorder = Color(0xFFFECDD3),
            darkBorder = Color(0xFF881337)
        ),
        ColorThemePair(
            id = "orange",
            name = "Amber",
            lightBg = Color(0xFFFFFBEB),
            darkBg = Color(0xFF451A03),
            lightBorder = Color(0xFFFDE68A),
            darkBorder = Color(0xFF78350F)
        ),
        ColorThemePair(
            id = "yellow",
            name = "Lemon",
            lightBg = Color(0xFFFEFCE8),
            darkBg = Color(0xFF3B2F0F),
            lightBorder = Color(0xFFFEF08A),
            darkBorder = Color(0xFF713F12)
        ),
        ColorThemePair(
            id = "green",
            name = "Mint",
            lightBg = Color(0xFFF0FDF4),
            darkBg = Color(0xFF14532D),
            lightBorder = Color(0xFFA7F3D0),
            darkBorder = Color(0xFF064E3B)
        ),
        ColorThemePair(
            id = "blue",
            name = "Ocean",
            lightBg = Color(0xFFF0F9FF),
            darkBg = Color(0xFF0C4A6E),
            lightBorder = Color(0xFFBAE6FD),
            darkBorder = Color(0xFF075985)
        ),
        ColorThemePair(
            id = "purple",
            name = "Lavender",
            lightBg = Color(0xFFFAF5FF),
            darkBg = Color(0xFF3B0764),
            lightBorder = Color(0xFFE9D5FF),
            darkBorder = Color(0xFF581C87)
        ),
        ColorThemePair(
            id = "pink",
            name = "Blossom",
            lightBg = Color(0xFFFDF2F8),
            darkBg = Color(0xFF4A044E),
            lightBorder = Color(0xFFFBCFE8),
            darkBorder = Color(0xFF701A75)
        )
    )

    fun get(id: String?): ColorThemePair {
        return list.firstOrNull { it.id == id } ?: list[0]
    }
}
