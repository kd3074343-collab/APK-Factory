package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.NoteDatabase
import com.example.data.NoteRepository
import com.example.ui.DetailScreen
import com.example.ui.HomeScreen
import com.example.ui.NoteViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Room persistence components
        val database = NoteDatabase.getDatabase(applicationContext)
        val repository = NoteRepository(database.noteDao())

        // Instantiate ViewModel using custom Factory
        val viewModel: NoteViewModel by viewModels {
            NoteViewModel.Factory(repository, applicationContext)
        }

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val isDark = when (themeMode) {
                "light" -> false
                "dark" -> true
                else -> systemDark
            }

            MyApplicationTheme(darkTheme = isDark, dynamicColor = false) {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = "home",
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Home Screen Route
                    composable("home") {
                        HomeScreen(
                            viewModel = viewModel,
                            isDark = isDark,
                            onNoteClick = { noteId ->
                                viewModel.selectNoteForEditing(noteId)
                                navController.navigate("detail?noteId=$noteId")
                            },
                            onAddNoteClick = {
                                navController.navigate("detail")
                            }
                        )
                    }

                    // Detail Screen Route (Optional noteId parameter)
                    composable(
                        route = "detail?noteId={noteId}",
                        arguments = listOf(
                            navArgument("noteId") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) { backStackEntry ->
                        val noteIdStr = backStackEntry.arguments?.getString("noteId")
                        
                        // If noteIdStr is provided and current viewmodel state isn't initialized yet, load it
                        LaunchedEffect(noteIdStr) {
                            if (noteIdStr != null) {
                                val id = noteIdStr.toIntOrNull()
                                if (id != null) {
                                    viewModel.selectNoteForEditing(id)
                                }
                            } else {
                                viewModel.prepareNewNote()
                            }
                        }

                        DetailScreen(
                            viewModel = viewModel,
                            isDark = isDark,
                            onBack = {
                                navController.popBackStack()
                            }
                        )
                    }
                }
            }
        }
    }
}
