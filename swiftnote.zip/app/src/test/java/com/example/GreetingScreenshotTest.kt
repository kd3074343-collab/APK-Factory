package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.Note
import com.example.ui.NoteCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    val note = Note(
        id = 1,
        title = "Ideas for Note App",
        content = "1. Clean Material 3 design\n2. Real-time debounced auto-save\n3. Responsive grid for tablet/mobile",
        createdAt = 1782658451000L,
        updatedAt = 1782658451000L,
        isPinned = true,
        isFavorite = true,
        colorHex = "green"
    )

    composeTestRule.setContent {
      MyApplicationTheme {
        NoteCard(
          note = note,
          isDark = false,
          onClick = {},
          onPinToggle = {},
          onFavoriteToggle = {},
          onDeleteClick = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
