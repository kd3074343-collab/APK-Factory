package com.example.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

object SoundManager {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var isMuted = false

    fun toggleMute() {
        isMuted = !isMuted
    }

    private var lastStretchTime = 0L
    private var lastClickTime = 0L
    private var lastExplosionTime = 0L

    private fun playSynth(
        durationMs: Int,
        frequencyStart: Float,
        frequencyEnd: Float = frequencyStart,
        waveType: String = "sine"
    ) {
        if (isMuted) return
        scope.launch {
            try {
                val sampleRate = 22050
                val numSamples = (durationMs * sampleRate) / 1000
                val buffer = ShortArray(numSamples)

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val progress = i.toDouble() / numSamples
                    val freq = frequencyStart + (frequencyEnd - frequencyStart) * progress

                    val value = when (waveType) {
                        "sine" -> sin(2.0 * Math.PI * freq * t)
                        "noise" -> Math.random() * 2.0 - 1.0
                        "explosion" -> {
                            val noise = Math.random() * 2.0 - 1.0
                            val envelope = 1.0 - progress
                            noise * envelope
                        }
                        "stretch" -> {
                            // Sub-harmonic flutter
                            val flutter = sin(2.0 * Math.PI * 15.0 * t) * 0.3
                            sin(2.0 * Math.PI * (freq + flutter * 50.0) * t)
                        }
                        else -> sin(2.0 * Math.PI * freq * t)
                    }

                    // Apply linear fade-out to prevent pops
                    val finalFade = if (progress > 0.8) (1.0 - progress) / 0.2 else 1.0
                    val sampleValue = (value * 32767.0 * 0.3 * finalFade).toInt().coerceIn(-32768, 32767)
                    buffer[i] = sampleValue.toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()
                // Auto-release after playing
                scope.launch {
                    kotlinx.coroutines.delay(durationMs + 100L)
                    try {
                        audioTrack.stop()
                        audioTrack.release()
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            } catch (e: Exception) {
                Log.e("SoundManager", "Failed to play synthesized sound", e)
            }
        }
    }

    fun playClick() {
        val now = System.currentTimeMillis()
        if (now - lastClickTime < 100L) return
        lastClickTime = now
        playSynth(durationMs = 80, frequencyStart = 523.25f) // C5 note beep
    }

    fun playStretch(dragRatio: Float) {
        val now = System.currentTimeMillis()
        if (now - lastStretchTime < 120L) return
        lastStretchTime = now
        // Frequency shifts lower to higher pitch as you stretch
        val targetFreq = 180f + dragRatio * 200f
        playSynth(durationMs = 120, frequencyStart = targetFreq, waveType = "stretch")
    }

    fun playLaunch() {
        playSynth(durationMs = 200, frequencyStart = 300f, frequencyEnd = 900f, waveType = "sine")
    }

    fun playExplosion() {
        val now = System.currentTimeMillis()
        if (now - lastExplosionTime < 150L) return
        lastExplosionTime = now
        playSynth(durationMs = 500, frequencyStart = 100f, waveType = "explosion")
    }

    fun playVictory() {
        scope.launch {
            // Arpeggio of happy major chord notes
            playSynth(150, 523.25f) // C5
            kotlinx.coroutines.delay(120)
            playSynth(150, 659.25f) // E5
            kotlinx.coroutines.delay(120)
            playSynth(150, 783.99f) // G5
            kotlinx.coroutines.delay(120)
            playSynth(350, 1046.50f) // C6
        }
    }

    fun playDefeat() {
        scope.launch {
            // Sad descending notes
            playSynth(200, 311.13f) // Eb4
            kotlinx.coroutines.delay(180)
            playSynth(200, 293.66f) // D4
            kotlinx.coroutines.delay(180)
            playSynth(450, 220.00f) // A3
        }
    }
}
