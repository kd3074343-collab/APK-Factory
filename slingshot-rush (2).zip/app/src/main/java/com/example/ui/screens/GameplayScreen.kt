package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.pow

@Composable
fun GameplayScreen(viewModel: GameViewModel) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val surfaceColor = MaterialTheme.colorScheme.surface
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface

    // High performance text Paint cached across recompositions
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        }
    }

    // Flawless VSYNC-aligned frame tick game loop
    LaunchedEffect(viewModel.currentScreen) {
        if (viewModel.currentScreen == GameScreen.GAMEPLAY) {
            var lastTime = withFrameNanos { it }
            while (true) {
                withFrameNanos { time ->
                    val dt = ((time - lastTime) / 1_000_000_000f).coerceIn(0.005f, 0.03f)
                    lastTime = time
                    viewModel.updatePhysics(dt)
                }
            }
        }
    }

    // Interactive pointer input to read dragging on slingshot
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    if (viewModel.isDarkMode) listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                    else listOf(Color(0xFFE0F2FE), Color(0xFFBAE6FD))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. GAMEPLAY HEADER BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back to Selection
                IconButton(
                    onClick = {
                        SoundManager.playClick()
                        viewModel.currentScreen = GameScreen.LEVEL_SELECTION
                    },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        .size(44.dp)
                        .testTag("game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Title Banner: Level & Round
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${viewModel.t("level")} ${viewModel.currentLevel}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = if (viewModel.isDarkMode) Color.White else Color.Black
                    )
                    Text(
                        text = "${viewModel.t("round")} ${viewModel.currentRoundIndex + 1} / ${viewModel.roundsCount}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = if (viewModel.isDarkMode) Color.LightGray else Color.DarkGray
                    )
                }

                // Balance and Score Display
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Wind indicator (only if level >= 8)
                    if (viewModel.currentLevel >= 8) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            modifier = Modifier.padding(end = 8.dp).testTag("wind_indicator")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (viewModel.windX > 0) "💨 ➡️" else "💨 ⬅️",
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${viewModel.t("wind")}: ${kotlin.math.abs(viewModel.windX).toInt()}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                    }

                    // Score Display
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.testTag("score_display")
                    ) {
                        Text(
                            text = "${viewModel.t("score")}: ${viewModel.totalLevelScore}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // 2. BOSS HEALTH GAUGE (only if boss level round)
            if (viewModel.bossActive) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 32.dp, vertical = 4.dp)
                        .testTag("boss_health_panel"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = viewModel.t("boss_hp"),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.Red
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { viewModel.bossHealth / viewModel.bossMaxHealth },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .testTag("boss_health_bar"),
                        color = Color.Red,
                        trackColor = Color.DarkGray
                    )
                }
            }

            // 3. MAIN PHYSICS SIMULATION ENGINE CANVAS
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                // Virtualize coords from actual pixel sizes
                                val virtualOffset = Offset(
                                    (offset.x / size.width) * 1000f,
                                    (offset.y / size.height) * 600f
                                )
                                // Check click within slingshot pull radius (anchor is at 150, 400)
                                val dist = sqrt(
                                    (virtualOffset.x - viewModel.slingshotAnchor.x).pow(2f) +
                                    (virtualOffset.y - viewModel.slingshotAnchor.y).pow(2f)
                                )
                                if (dist < 100f) {
                                    viewModel.onDragStart()
                                }
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val rawPos = change.position
                                val virtualOffset = Offset(
                                    (rawPos.x / size.width) * 1000f,
                                    (rawPos.y / size.height) * 600f
                                )
                                viewModel.onDrag(virtualOffset)
                            },
                            onDragEnd = {
                                viewModel.onDragRelease()
                            }
                        )
                    }
                    .testTag("physics_game_canvas")
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val scaleX = size.width / 1000f
                    val scaleY = size.height / 600f

                    // Function to map virtual units to absolute canvas pixels
                    fun toPixel(p: Offset) = Offset(p.x * scaleX, p.y * scaleY)

                    // Apply Screen Shake transform matrix on high speed impacts
                    val shake = viewModel.cameraShakeIntensity
                    val shakeOffset = if (shake > 0f) {
                        Offset(
                            (Math.random() - 0.5).toFloat() * shake * 3f * scaleX,
                            (Math.random() - 0.5).toFloat() * shake * 3f * scaleY
                        )
                    } else Offset.Zero

                    withTransform({
                        translate(shakeOffset.x, shakeOffset.y)
                    }) {
                        // A. DRAW GROUND LAYER
                        drawRect(
                            color = if (viewModel.isDarkMode) Color(0xFF1E293B) else Color(0xFF8D6E63),
                            topLeft = Offset(0f, 520f * scaleY),
                            size = Size(1000f * scaleX, 100f * scaleY)
                        )
                        // Lush green/dark moss strip on top of ground
                        drawRect(
                            color = if (viewModel.isDarkMode) Color(0xFF15803D) else Color(0xFF4CAF50),
                            topLeft = Offset(0f, 520f * scaleY),
                            size = Size(1000f * scaleX, 12f * scaleY)
                        )

                        // B. DRAW SLINGSHOT FRAMES & BANDS (Classic Wood / Gold / Cyber / Inferno)
                        val slingColor = getSlingshotColor(viewModel.selectedSlingshotSkin)
                        val bandColor = getBandColor(viewModel.selectedSlingshotSkin)

                        val leftFork = Offset(120f, 380f)
                        val rightFork = Offset(180f, 380f)
                        val basePost = Offset(150f, 520f)

                        // Draw Back rubber band
                        if (viewModel.isDragging) {
                            drawLine(
                                color = bandColor,
                                start = toPixel(leftFork),
                                end = toPixel(viewModel.dragPosition),
                                strokeWidth = 6f * scaleY
                            )
                        }

                        // Draw Main Wooden/Glass Y Fork Frame
                        val forkPath = Path().apply {
                            moveTo(leftFork.x * scaleX, leftFork.y * scaleY)
                            lineTo(150f * scaleX, 430f * scaleY)
                            lineTo(rightFork.x * scaleX, rightFork.y * scaleY)
                            moveTo(150f * scaleX, 430f * scaleY)
                            lineTo(basePost.x * scaleX, basePost.y * scaleY)
                        }
                        drawPath(
                            path = forkPath,
                            color = slingColor,
                            style = Stroke(width = 10f * scaleY, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )

                        // Draw Front rubber band
                        if (viewModel.isDragging) {
                            drawLine(
                                color = bandColor,
                                start = toPixel(rightFork),
                                end = toPixel(viewModel.dragPosition),
                                strokeWidth = 6f * scaleY
                            )
                        }

                        // C. TRAJECTORY AIM PREVIEW PATH LINE
                        if (viewModel.isDragging) {
                            val dragDistX = viewModel.slingshotAnchor.x - viewModel.dragPosition.x
                            val dragDistY = viewModel.slingshotAnchor.y - viewModel.dragPosition.y
                            val speedFactor = 12f
                            var vx = dragDistX * speedFactor
                            var vy = dragDistY * speedFactor
                            var px = viewModel.slingshotAnchor.x
                            var py = viewModel.slingshotAnchor.y
                            val g = 450f

                            val stepDt = 0.05f
                            for (i in 0..15) {
                                vy += g * stepDt
                                vx += viewModel.windX * stepDt
                                vx *= 0.995f
                                vy *= 0.995f
                                px += vx * stepDt
                                py += vy * stepDt
                                if (py >= 520f) {
                                    drawCircle(
                                        color = Color.White.copy(alpha = (1f - (i.toFloat() / 15f)).coerceIn(0.1f, 1f)),
                                        radius = 4f * scaleY,
                                        center = toPixel(Offset(px, 520f))
                                    )
                                    break
                                }
                                drawCircle(
                                    color = Color.White.copy(alpha = (1f - (i.toFloat() / 15f)).coerceIn(0.1f, 1f)),
                                    radius = 4f * scaleY,
                                    center = toPixel(Offset(px, py))
                                )
                            }
                        }

                        // D. DRAW FLYING DEBRIS / OBSTACLES & ENEMIES
                        viewModel.obstacles.forEach { obs ->
                            if (obs.health > 0f) {
                                val obstacleColor = getObstacleColor(obs.type)
                                val left = (obs.x - obs.width / 2f) * scaleX
                                val top = (obs.y - obs.height / 2f) * scaleY
                                val w = obs.width * scaleX
                                val h = obs.height * scaleY

                                if (obs.type == ObstacleType.ENEMY) {
                                    // Draw cute round green alien enemy
                                    val radius = obs.width / 2f * scaleX
                                    val center = toPixel(Offset(obs.x, obs.y))
                                    drawCircle(
                                        color = obstacleColor,
                                        radius = radius,
                                        center = center
                                    )
                                    // Eye whites
                                    drawCircle(
                                        color = Color.White,
                                        radius = radius * 0.3f,
                                        center = Offset(center.x - radius * 0.25f, center.y - radius * 0.1f)
                                    )
                                    drawCircle(
                                        color = Color.White,
                                        radius = radius * 0.3f,
                                        center = Offset(center.x + radius * 0.25f, center.y - radius * 0.1f)
                                    )
                                    // Pupils
                                    drawCircle(
                                        color = Color.Black,
                                        radius = radius * 0.12f,
                                        center = Offset(center.x - radius * 0.2f, center.y - radius * 0.1f)
                                    )
                                    drawCircle(
                                        color = Color.Black,
                                        radius = radius * 0.12f,
                                        center = Offset(center.x + radius * 0.3f, center.y - radius * 0.1f)
                                    )
                                    // Smile / Worry Mouth
                                    val isWorried = obs.health < obs.maxHealth
                                    drawLine(
                                        color = Color.Black,
                                        start = Offset(center.x - radius * 0.25f, center.y + radius * 0.3f),
                                        end = Offset(center.x + radius * 0.25f, center.y + if (isWorried) radius * 0.2f else radius * 0.35f),
                                        strokeWidth = 3f
                                    )
                                } else if (obs.type == ObstacleType.BOSS) {
                                    // DRAW LARGE INTUITIVE BOSS monster
                                    val radius = obs.width / 2f * scaleX
                                    val center = toPixel(Offset(obs.x, obs.y))

                                    // Pulse aura
                                    drawCircle(
                                        color = obstacleColor.copy(alpha = 0.2f),
                                        radius = radius * 1.2f,
                                        center = center
                                    )
                                    // Boss body
                                    drawCircle(
                                        color = obstacleColor,
                                        radius = radius,
                                        center = center
                                    )
                                    // Horns
                                    drawLine(
                                        color = Color.White,
                                        start = Offset(center.x - radius * 0.5f, center.y - radius * 0.8f),
                                        end = Offset(center.x - radius * 0.8f, center.y - radius * 1.3f),
                                        strokeWidth = 3f * scaleY
                                    )
                                    drawLine(
                                        color = Color.White,
                                        start = Offset(center.x - radius * 0.8f, center.y - radius * 1.3f),
                                        end = Offset(center.x - radius * 0.2f, center.y - radius * 0.9f),
                                        strokeWidth = 3f * scaleY
                                    )
                                    drawLine(
                                        color = Color.White,
                                        start = Offset(center.x + radius * 0.5f, center.y - radius * 0.8f),
                                        end = Offset(center.x + radius * 0.8f, center.y - radius * 1.3f),
                                        strokeWidth = 3f * scaleY
                                    )
                                    drawLine(
                                        color = Color.White,
                                        start = Offset(center.x + radius * 0.8f, center.y - radius * 1.3f),
                                        end = Offset(center.x + radius * 0.2f, center.y - radius * 0.9f),
                                        strokeWidth = 3f * scaleY
                                    )

                                    // Large Cyclops Eye
                                    drawCircle(
                                        color = Color.White,
                                        radius = radius * 0.4f,
                                        center = center
                                    )
                                    drawCircle(
                                        color = Color.Red,
                                        radius = radius * 0.2f,
                                        center = center
                                    )
                                    drawCircle(
                                        color = Color.Black,
                                        radius = radius * 0.08f,
                                        center = center
                                    )
                                    // Mean eyebrows
                                    drawLine(
                                        color = Color.Black,
                                        start = Offset(center.x - radius * 0.45f, center.y - radius * 0.45f),
                                        end = Offset(center.x + radius * 0.45f, center.y - radius * 0.45f),
                                        strokeWidth = 5f
                                    )
                                } else if (obs.type == ObstacleType.TNT) {
                                    // Draw red barrel with TNT label
                                    drawRoundRect(
                                        color = obstacleColor,
                                        topLeft = Offset(left, top),
                                        size = Size(w, h),
                                        cornerRadius = CornerRadius(8f * scaleX, 8f * scaleY)
                                    )
                                    // yellow caution bands
                                    drawRect(
                                        color = Color(0xFFFFEB3B),
                                        topLeft = Offset(left, top + h * 0.25f),
                                        size = Size(w, h * 0.15f)
                                    )
                                    drawRect(
                                        color = Color(0xFFFFEB3B),
                                        topLeft = Offset(left, top + h * 0.6f),
                                        size = Size(w, h * 0.15f)
                                    )
                                    // draw simple black caution marks
                                    drawLine(
                                        color = Color.Black,
                                        start = Offset(left + w * 0.2f, top + h * 0.45f),
                                        end = Offset(left + w * 0.8f, top + h * 0.55f),
                                        strokeWidth = 4f
                                    )
                                    drawLine(
                                        color = Color.Black,
                                        start = Offset(left + w * 0.8f, top + h * 0.45f),
                                        end = Offset(left + w * 0.2f, top + h * 0.55f),
                                        strokeWidth = 4f
                                    )
                                } else {
                                    // Standard building blocks: Wood, Glass, Stone, Metal
                                    drawRoundRect(
                                        color = obstacleColor,
                                        topLeft = Offset(left, top),
                                        size = Size(w, h),
                                        cornerRadius = CornerRadius(6f * scaleX, 6f * scaleY)
                                    )
                                    // Draw border outline
                                    drawRoundRect(
                                        color = obstacleColor.copy(alpha = 0.5f),
                                        topLeft = Offset(left, top),
                                        size = Size(w, h),
                                        cornerRadius = CornerRadius(6f * scaleX, 6f * scaleY),
                                        style = Stroke(width = 2f)
                                    )

                                    // Break cracks if damaged
                                    if (obs.health < obs.maxHealth * 0.7f) {
                                        drawLine(
                                            color = Color.Black.copy(alpha = 0.3f),
                                            start = Offset(left + w * 0.3f, top + h * 0.2f),
                                            end = Offset(left + w * 0.5f, top + h * 0.6f),
                                            strokeWidth = 2f
                                        )
                                        drawLine(
                                            color = Color.Black.copy(alpha = 0.3f),
                                            start = Offset(left + w * 0.5f, top + h * 0.6f),
                                            end = Offset(left + w * 0.2f, top + h * 0.8f),
                                            strokeWidth = 2f
                                        )
                                        drawLine(
                                            color = Color.Black.copy(alpha = 0.3f),
                                            start = Offset(left + w * 0.7f, top + h * 0.4f),
                                            end = Offset(left + w * 0.5f, top + h * 0.6f),
                                            strokeWidth = 2f
                                        )
                                    }
                                }
                            }
                        }

                        // E. DRAW ACTIVE PROJECTILE & TRAIL
                        val projColor = getProjectileColor(viewModel.selectedProjectileSkin)
                        val activeProj = viewModel.projectile

                        if (activeProj.isFlying) {
                            // Fading trailing line
                            activeProj.trail.forEachIndexed { idx, offset ->
                                val alphaRatio = (idx.toFloat() / activeProj.trail.size).coerceIn(0.1f, 1f)
                                drawCircle(
                                    color = projColor.copy(alpha = alphaRatio * 0.3f),
                                    radius = (activeProj.radius * 0.7f) * scaleY * alphaRatio,
                                    center = toPixel(offset)
                                )
                            }
                            // Main sphere projectile
                            drawCircle(
                                color = projColor,
                                radius = activeProj.radius * scaleY,
                                center = toPixel(Offset(activeProj.x, activeProj.y))
                            )
                            // Specular lighting reflection circle on top left
                            drawCircle(
                                color = Color.White.copy(alpha = 0.6f),
                                radius = activeProj.radius * 0.3f * scaleY,
                                center = toPixel(Offset(activeProj.x - activeProj.radius * 0.3f, activeProj.y - activeProj.radius * 0.3f))
                            )
                        } else if (viewModel.isDragging) {
                            // Draw projectile at dragged point
                            drawCircle(
                                color = projColor,
                                radius = activeProj.radius * scaleY,
                                center = toPixel(viewModel.dragPosition)
                            )
                            drawCircle(
                                color = Color.White.copy(alpha = 0.6f),
                                radius = activeProj.radius * 0.3f * scaleY,
                                center = toPixel(Offset(viewModel.dragPosition.x - activeProj.radius * 0.3f, viewModel.dragPosition.y - activeProj.radius * 0.3f))
                            )
                        }

                        // F. PARTICLES EXPLOSIONS DRAW
                        viewModel.particles.forEach { part ->
                            drawCircle(
                                color = part.color.copy(alpha = part.alpha),
                                radius = part.size * scaleY,
                                center = toPixel(Offset(part.x, part.y))
                            )
                        }

                        // G. FLOATING TEXTS DRAW
                        viewModel.floatingTexts.forEach { fText ->
                            paint.color = fText.color.copy(alpha = fText.alpha).toArgb()
                            paint.textSize = 14f * scaleY * 2.5f
                            drawContext.canvas.nativeCanvas.drawText(
                                fText.text,
                                fText.x * scaleX,
                                fText.y * scaleY,
                                paint
                            )
                        }
                    }
                }

                // Drag guideline instructions overlay
                if (viewModel.currentRoundIndex == 0 && !viewModel.isProjectileFlying && !viewModel.isDragging) {
                    Text(
                        text = "🎯 " + viewModel.t("drag_guide"),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (viewModel.isDarkMode) Color.LightGray else Color.DarkGray,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 60.dp)
                            .testTag("drag_instruction_tooltip")
                    )
                }
            }

            // 4. FOOTER CONTROLS (PROJECTILES REMAINING & QUICK REPLAY)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Ammo bullets remaining indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.testTag("bullets_ammo_panel")
                ) {
                    val activeProjColor = getProjectileColor(viewModel.selectedProjectileSkin)
                    for (i in 0 until viewModel.projectilesLeft) {
                        Surface(
                            shape = CircleShape,
                            color = activeProjColor,
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .size(20.dp)
                                .testTag("ammo_dot_$i")
                        ) {}
                    }
                    if (viewModel.projectilesLeft == 0 && viewModel.isProjectileFlying) {
                        Text(
                            text = "LAST SHOT!",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Red
                        )
                    }
                }

                // Quick restart button
                IconButton(
                    onClick = {
                        SoundManager.playClick()
                        viewModel.restartLevel()
                    },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        .size(44.dp)
                        .testTag("game_quick_refresh")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Restart Round",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 5. GAME OVERLAYS (VICTORY AND DEFEAT SCREENS)
        AnimatedVisibility(
            visible = (viewModel.gameplayState == GameplayState.LEVEL_WON),
            modifier = Modifier.fillMaxSize()
        ) {
            LevelWinOverlay(
                viewModel = viewModel,
                onNextLevel = {
                    SoundManager.playClick()
                    viewModel.proceedToNextLevel()
                },
                onReplay = {
                    SoundManager.playClick()
                    viewModel.restartLevel()
                },
                onMenu = {
                    SoundManager.playClick()
                    viewModel.currentScreen = GameScreen.LEVEL_SELECTION
                }
            )
        }

        AnimatedVisibility(
            visible = (viewModel.gameplayState == GameplayState.LEVEL_LOST),
            modifier = Modifier.fillMaxSize()
        ) {
            LevelLostOverlay(
                viewModel = viewModel,
                onRetry = {
                    SoundManager.playClick()
                    viewModel.restartLevel()
                },
                onMenu = {
                    SoundManager.playClick()
                    viewModel.currentScreen = GameScreen.LEVEL_SELECTION
                }
            )
        }
    }
}

// VICTORY SCREEN OVERLAY CONTAINER
@Composable
fun LevelWinOverlay(
    viewModel: GameViewModel,
    onNextLevel: () -> Unit,
    onReplay: () -> Unit,
    onMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f))
            .testTag("victory_overlay"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .width(320.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = viewModel.t("victory"),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFFFC107), // Golden
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("victory_title")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Star rating calculations
                val stars = when {
                    viewModel.projectilesLeft >= 2 -> 3
                    viewModel.projectilesLeft == 1 -> 2
                    else -> 1
                }

                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().testTag("victory_stars")
                ) {
                    for (i in 1..3) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Star $i",
                            tint = if (i <= stars) Color(0xFFFFC107) else Color.LightGray,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Coin Earnings pill
                val base = 50
                val ammoBonus = viewModel.projectilesLeft * 25
                val bossBonus = if (viewModel.currentLevel % 5 == 0) 150 else 0
                val totalEarned = base + ammoBonus + bossBonus

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🪙", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "+$totalEarned ${viewModel.t("coins")}!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "${viewModel.t("score")}: ${viewModel.totalLevelScore}",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Action buttons layout
                Button(
                    onClick = onNextLevel,
                    enabled = (viewModel.currentLevel < 20),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("next_level_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(viewModel.t("next"), fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onReplay,
                        modifier = Modifier.weight(1f).height(48.dp).testTag("replay_level_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(viewModel.t("replay"), fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onMenu,
                        modifier = Modifier.weight(1f).height(48.dp).testTag("victory_menu_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(viewModel.t("menu"), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// LOSE SCREEN OVERLAY CONTAINER
@Composable
fun LevelLostOverlay(
    viewModel: GameViewModel,
    onRetry: () -> Unit,
    onMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f))
            .testTag("defeat_overlay"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .width(300.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = viewModel.t("you_lost"),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("you_lost_title")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Out of Projectiles!",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = onRetry,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("retry_round_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(viewModel.t("retry"), fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onMenu,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("defeat_menu_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(viewModel.t("menu"), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Color getters for skins
private fun getSlingshotColor(skinId: String): Color {
    return when (skinId) {
        "classic" -> Color(0xFF8B5A2B) // Oak
        "golden" -> Color(0xFFFFD700) // Shiny gold
        "cyber" -> Color(0xFF00E5FF) // Cyan laser
        "inferno" -> Color(0xFF424242) // Dark volcanic ash charcoal
        else -> Color(0xFF8B5A2B)
    }
}

private fun getBandColor(skinId: String): Color {
    return when (skinId) {
        "classic" -> Color(0xFFD7CCC8) // Off-white rubber
        "golden" -> Color(0xFFFFEE58) // Golden glow
        "cyber" -> Color(0xFF2979FF) // Pulsing energy blue
        "inferno" -> Color(0xFFFF3D00) // Magma hot lava red
        else -> Color(0xFFD7CCC8)
    }
}

private fun getProjectileColor(skinId: String): Color {
    return when (skinId) {
        "default" -> Color(0xFFD32F2F) // Standard red cartoon ball
        "fireball" -> Color(0xFFFF9100) // Orange Meteor Ember
        "plasma" -> Color(0xFFD500F9) // High voltage violet
        "bubble" -> Color(0xFF2979FF) // Crystal sky blue water bubble
        else -> Color(0xFFD32F2F)
    }
}

private fun getObstacleColor(type: ObstacleType): Color {
    return when (type) {
        ObstacleType.WOOD -> Color(0xFF8B5A2B)
        ObstacleType.STONE -> Color(0xFF7A7A7A)
        ObstacleType.GLASS -> Color(0xFF80DEEA)
        ObstacleType.METAL -> Color(0xFFB0BEC5)
        ObstacleType.TNT -> Color(0xFFD32F2F)
        ObstacleType.ENEMY -> Color(0xFF4CAF50)
        ObstacleType.BOSS -> Color(0xFF9C27B0)
    }
}
