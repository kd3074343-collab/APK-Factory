package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.GameScreen
import com.example.ui.GameViewModel
import com.example.ui.SoundManager

@Composable
fun LevelSelectionScreen(viewModel: GameViewModel) {
    val totalLevels = 20

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // App Header Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    SoundManager.playClick()
                    viewModel.currentScreen = GameScreen.HOME
                },
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    .testTag("back_to_home_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Default.ArrowBack,
                    contentDescription = "Back to Home",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = viewModel.t("level") + "s",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground
            )

            // Coin counter
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.testTag("selection_coins_balance")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🪙",
                        fontSize = 14.sp,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text(
                        text = "${viewModel.totalCoins}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        // Horizontal line separator
        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

        // Lazy Level Selection Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .testTag("levels_grid")
        ) {
            items((1..totalLevels).toList()) { num ->
                val progress = viewModel.levelList.find { it.levelNumber == num }
                val isUnlocked = progress?.unlocked ?: (num == 1) // default lvl 1 is true, others false
                val stars = progress?.stars ?: 0
                val bestScore = progress?.bestScore ?: 0

                LevelCard(
                    levelNumber = num,
                    isUnlocked = isUnlocked,
                    starsEarned = stars,
                    bestScore = bestScore,
                    difficultyLabel = viewModel.getDifficultyLabel(num),
                    onClick = {
                        if (isUnlocked) {
                            SoundManager.playClick()
                            viewModel.selectAndLoadLevel(num)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun LevelCard(
    levelNumber: Int,
    isUnlocked: Boolean,
    starsEarned: Int,
    bestScore: Int,
    difficultyLabel: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .aspectRatio(1f)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(enabled = isUnlocked, onClick = onClick)
            .testTag("level_card_$levelNumber"),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) {
                if (starsEarned > 0) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
                else MaterialTheme.colorScheme.surfaceVariant
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isUnlocked) 4.dp else 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            if (isUnlocked) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Level Title
                    Text(
                        text = "$levelNumber",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = if (starsEarned > 0) MaterialTheme.colorScheme.onPrimaryContainer
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Difficulty Indicator Bubble
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = getDifficultyColor(difficultyLabel).copy(alpha = 0.15f),
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Text(
                            text = difficultyLabel.uppercase(),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = getDifficultyColor(difficultyLabel),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Score if played
                    if (bestScore > 0) {
                        Text(
                            text = "PTS: $bestScore",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }

                    // Star indicators
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (i in 1..3) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Star $i",
                                tint = if (i <= starsEarned) Color(0xFFFFC107) else Color.LightGray.copy(alpha = 0.4f),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            } else {
                // Locked indicator
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked Level",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "LOCKED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                }
            }
        }
    }
}

private fun getDifficultyColor(difficulty: String): Color {
    return when (difficulty.lowercase()) {
        "easy", "आसान", "সহজ" -> Color(0xFF4CAF50) // Green
        "medium", "मध्यम", "মাঝারি" -> Color(0xFFFF9800) // Orange
        "hard", "कठिन", "কঠিন" -> Color(0xFFE91E63) // Pink
        "very_hard", "बहुत कठिन", "খুব কঠিন" -> Color(0xFF9C27B0) // Purple
        else -> Color(0xFFF44336) // Red Extreme
    }
}
