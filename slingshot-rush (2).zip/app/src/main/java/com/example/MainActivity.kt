package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.GameScreen
import com.example.ui.GameViewModel
import com.example.ui.screens.GameplayScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LevelSelectionScreen
import com.example.ui.screens.SettingsPopup
import com.example.ui.screens.ShopScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val gameViewModel: GameViewModel = viewModel()
      var showSettings by remember { mutableStateOf(false) }

      MyApplicationTheme(
        darkTheme = gameViewModel.isDarkMode,
        dynamicColor = false // Force custom themed palette for games
      ) {
        Box(modifier = Modifier.fillMaxSize()) {
          // Screen state router
          when (gameViewModel.currentScreen) {
            GameScreen.HOME -> {
              HomeScreen(
                viewModel = gameViewModel,
                onOpenSettings = { showSettings = true }
              )
            }
            GameScreen.LEVEL_SELECTION -> {
              LevelSelectionScreen(viewModel = gameViewModel)
            }
            GameScreen.SHOP -> {
              ShopScreen(viewModel = gameViewModel)
            }
            GameScreen.GAMEPLAY -> {
              GameplayScreen(viewModel = gameViewModel)
            }
          }

          // Overlay Settings Popup
          if (showSettings) {
            SettingsPopup(
              viewModel = gameViewModel,
              onDismiss = { showSettings = false }
            )
          }
        }
      }
    }
  }
}

