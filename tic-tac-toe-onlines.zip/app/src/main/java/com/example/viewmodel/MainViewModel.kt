package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.example.model.GameRoom
import com.example.model.PlayerInfo
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

enum class Screen {
    LOGIN,
    HOME,
    MATCHMAKING,
    GAME_ROOM
}

class MainViewModel : ViewModel() {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()

    val currentUser = MutableStateFlow<FirebaseUser?>(auth.currentUser)

    private val _currentScreen = MutableStateFlow<Screen>(
        if (auth.currentUser != null) Screen.HOME else Screen.LOGIN
    )
    val currentScreen: StateFlow<Screen> = _currentScreen

    private val _activeRoom = MutableStateFlow<GameRoom?>(null)
    val activeRoom: StateFlow<GameRoom?> = _activeRoom

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching

    private var myQueueRef: DatabaseReference? = null
    private var activeRoomRef: DatabaseReference? = null
    private var activeRoomListener: ValueEventListener? = null
    private var myQueueListener: ValueEventListener? = null

    init {
        auth.addAuthStateListener { firebaseAuth ->
            currentUser.value = firebaseAuth.currentUser
            if (firebaseAuth.currentUser == null) {
                _currentScreen.value = Screen.LOGIN
                cleanupRoom()
                cleanupMatchmaking()
            } else if (_currentScreen.value == Screen.LOGIN) {
                _currentScreen.value = Screen.HOME
            }
        }
    }

    fun startRandomMatchmaking() {
        val user = currentUser.value ?: return
        _isSearching.value = true
        _currentScreen.value = Screen.MATCHMAKING

        val queueRef = database.reference.child("matchmaking_queue")
        val myRef = queueRef.child(user.uid)
        myQueueRef = myRef

        val myInfo = mapOf(
            "uid" to user.uid,
            "displayName" to (user.displayName ?: "Player"),
            "photoUrl" to (user.photoUrl?.toString() ?: ""),
            "matchedRoomId" to ""
        )

        myRef.setValue(myInfo).addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                _errorMessage.value = "Failed to join matchmaking queue."
                _currentScreen.value = Screen.HOME
                _isSearching.value = false
                return@addOnCompleteListener
            }

            // 1. Listen for matches found by others for us
            myQueueListener = myRef.child("matchedRoomId").addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val roomId = snapshot.getValue(String::class.java)
                    if (!roomId.isNullOrEmpty()) {
                        joinRoomAsMatch(roomId)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    _errorMessage.value = "Matchmaking error: ${error.message}"
                }
            })

            // 2. Query queue for other players to match with (FIFO order)
            queueRef.get().addOnSuccessListener { snapshot ->
                val waitingPlayers = mutableListOf<DataSnapshot>()
                for (child in snapshot.children) {
                    if (child.key != user.uid) {
                        val matchedId = child.child("matchedRoomId").getValue(String::class.java)
                        if (matchedId.isNullOrEmpty()) {
                            waitingPlayers.add(child)
                        }
                    }
                }

                if (waitingPlayers.isNotEmpty()) {
                    // Match with the first available player
                    val opponentSnap = waitingPlayers.first()
                    val opponentUid = opponentSnap.key ?: return@addOnSuccessListener
                    val opponentName = opponentSnap.child("displayName").getValue(String::class.java) ?: "Opponent"
                    val opponentPhoto = opponentSnap.child("photoUrl").getValue(String::class.java) ?: ""

                    val generatedRoomId = "match_" + UUID.randomUUID().toString().substring(0, 8)
                    val roomRef = database.reference.child("rooms").child(generatedRoomId)

                    val newRoom = GameRoom(
                        id = generatedRoomId,
                        playerX = PlayerInfo(
                            uid = opponentUid,
                            displayName = opponentName,
                            photoUrl = opponentPhoto
                        ),
                        playerO = PlayerInfo(
                            uid = user.uid,
                            displayName = user.displayName ?: "Player",
                            photoUrl = user.photoUrl?.toString() ?: ""
                        ),
                        board = List(9) { "" },
                        turn = opponentUid, // Player X goes first
                        status = "PLAYING",
                        playerXOnline = true,
                        playerOOnline = true
                    )

                    // Create the match room
                    roomRef.setValue(newRoom).addOnSuccessListener {
                        // Notify the waiting player by writing to their matchedRoomId
                        queueRef.child(opponentUid).child("matchedRoomId").setValue(generatedRoomId)
                        
                        // Remove ourselves from the queue
                        myRef.removeValue()
                        _isSearching.value = false
                        
                        // Observe this room
                        observeRoom(generatedRoomId)
                    }.addOnFailureListener { e ->
                        Log.e("MainViewModel", "Failed to write matchmaking room: ${e.message}")
                    }
                }
            }
        }
    }

    private fun joinRoomAsMatch(roomId: String) {
        cleanupMatchmaking()
        _isSearching.value = false
        observeRoom(roomId)
    }

    fun cancelMatchmaking() {
        cleanupMatchmaking()
        _currentScreen.value = Screen.HOME
    }

    fun createPrivateRoom() {
        val user = currentUser.value ?: return
        // Generate a 6-letter uppercase room code
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val generatedRoomId = (1..6).map { chars.random() }.joinToString("")

        val roomRef = database.reference.child("rooms").child(generatedRoomId)
        activeRoomRef = roomRef

        val newRoom = GameRoom(
            id = generatedRoomId,
            playerX = PlayerInfo(
                uid = user.uid,
                displayName = user.displayName ?: "Player",
                photoUrl = user.photoUrl?.toString() ?: ""
            ),
            playerO = null,
            board = List(9) { "" },
            turn = user.uid,
            status = "WAITING",
            playerXOnline = true,
            playerOOnline = false
        )

        roomRef.setValue(newRoom).addOnSuccessListener {
            observeRoom(generatedRoomId)
        }.addOnFailureListener { e ->
            _errorMessage.value = "Failed to create room: ${e.message}"
        }
    }

    fun joinPrivateRoom(roomIdInput: String, onError: (String) -> Unit) {
        val user = currentUser.value ?: return
        val roomId = roomIdInput.trim().uppercase()
        if (roomId.isEmpty()) {
            onError("Please enter a Room ID")
            return
        }

        val roomRef = database.reference.child("rooms").child(roomId)

        roomRef.get().addOnSuccessListener { snapshot ->
            val room = snapshot.getValue(GameRoom::class.java)
            if (room == null) {
                onError("Room not found")
                return@addOnSuccessListener
            }

            if (room.playerO != null && room.playerO.uid != user.uid && room.playerX?.uid != user.uid) {
                onError("Room is full")
                return@addOnSuccessListener
            }

            if (room.status == "OPPONENT_LEFT") {
                onError("Room is inactive because a player left")
                return@addOnSuccessListener
            }

            if (room.playerX?.uid == user.uid) {
                observeRoom(roomId)
                return@addOnSuccessListener
            }

            if (room.playerO?.uid == user.uid) {
                observeRoom(roomId)
                return@addOnSuccessListener
            }

            val updatedPlayerO = PlayerInfo(
                uid = user.uid,
                displayName = user.displayName ?: "Player",
                photoUrl = user.photoUrl?.toString() ?: ""
            )

            val updates = mapOf(
                "playerO" to updatedPlayerO,
                "status" to "PLAYING",
                "playerOOnline" to true
            )

            roomRef.updateChildren(updates).addOnSuccessListener {
                observeRoom(roomId)
            }.addOnFailureListener { e ->
                onError("Failed to join room: ${e.message}")
            }
        }.addOnFailureListener { e ->
            onError("Error checking room: ${e.message}")
        }
    }

    fun observeRoom(roomId: String) {
        cleanupRoom()
        val user = currentUser.value ?: return
        val roomRef = database.reference.child("rooms").child(roomId)
        activeRoomRef = roomRef

        // Register online status and onDisconnect triggers
        roomRef.get().addOnSuccessListener { snapshot ->
            val room = snapshot.getValue(GameRoom::class.java) ?: return@addOnSuccessListener
            val isPlayerX = (room.playerX?.uid == user.uid)
            val isPlayerO = (room.playerO?.uid == user.uid)

            if (isPlayerX) {
                roomRef.child("playerXOnline").setValue(true)
                roomRef.child("playerXOnline").onDisconnect().setValue(false)
                roomRef.child("status").onDisconnect().setValue("OPPONENT_LEFT")
            } else if (isPlayerO) {
                roomRef.child("playerOOnline").setValue(true)
                roomRef.child("playerOOnline").onDisconnect().setValue(false)
                roomRef.child("status").onDisconnect().setValue("OPPONENT_LEFT")
            }
        }

        activeRoomListener = roomRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val room = snapshot.getValue(GameRoom::class.java)
                if (room != null) {
                    _activeRoom.value = room
                    _currentScreen.value = Screen.GAME_ROOM

                    if (room.status != "OPPONENT_LEFT" && room.status == "PLAYING") {
                        val isPlayerX = (room.playerX?.uid == user.uid)
                        val isPlayerO = (room.playerO?.uid == user.uid)
                        if (isPlayerX && !room.playerOOnline) {
                            roomRef.child("status").setValue("OPPONENT_LEFT")
                        } else if (isPlayerO && !room.playerXOnline) {
                            roomRef.child("status").setValue("OPPONENT_LEFT")
                        }
                    }
                } else {
                    if (_currentScreen.value == Screen.GAME_ROOM) {
                        _errorMessage.value = "Room has been deleted."
                        leaveRoom()
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                _errorMessage.value = "Database error: ${error.message}"
            }
        })
    }

    fun makeMove(cellIndex: Int) {
        val user = currentUser.value ?: return
        val room = _activeRoom.value ?: return
        if (room.status != "PLAYING") return
        if (room.turn != user.uid) return
        if (cellIndex < 0 || cellIndex >= 9) return
        if (room.board[cellIndex].isNotEmpty()) return

        val isPlayerX = (room.playerX?.uid == user.uid)
        val mark = if (isPlayerX) "X" else "O"

        val newBoard = room.board.toMutableList()
        newBoard[cellIndex] = mark

        val winPatterns = listOf(
            listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
            listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
            listOf(0, 4, 8), listOf(2, 4, 6)
        )

        var winnerMark = ""
        for (pattern in winPatterns) {
            val a = newBoard[pattern[0]]
            val b = newBoard[pattern[1]]
            val c = newBoard[pattern[2]]
            if (a.isNotEmpty() && a == b && b == c) {
                winnerMark = a
                break
            }
        }

        val gameStatus: String
        val winnerUid: String
        if (winnerMark.isNotEmpty()) {
            gameStatus = "FINISHED"
            winnerUid = if (winnerMark == "X") room.playerX?.uid ?: "" else room.playerO?.uid ?: ""
        } else if (newBoard.all { it.isNotEmpty() }) {
            gameStatus = "FINISHED"
            winnerUid = "DRAW"
        } else {
            gameStatus = "PLAYING"
            winnerUid = ""
        }

        val nextTurn = if (gameStatus == "PLAYING") {
            if (isPlayerX) room.playerO?.uid ?: "" else room.playerX?.uid ?: ""
        } else {
            ""
        }

        val updates = mapOf(
            "board" to newBoard,
            "status" to gameStatus,
            "winner" to winnerUid,
            "turn" to nextTurn
        )

        activeRoomRef?.updateChildren(updates)
    }

    fun requestRematch() {
        val user = currentUser.value ?: return
        val room = _activeRoom.value ?: return
        val ref = activeRoomRef ?: return

        val isPlayerX = (room.playerX?.uid == user.uid)
        val isPlayerO = (room.playerO?.uid == user.uid)

        if (isPlayerX) {
            ref.child("rematchX").setValue(true)
        } else if (isPlayerO) {
            ref.child("rematchO").setValue(true)
        }

        val otherPlayerAgreed = if (isPlayerX) room.rematchO else room.rematchX
        if (otherPlayerAgreed) {
            // Reset room for new game. Toggle starting turn to O for balance if player X went first last time
            val nextTurn = room.playerX?.uid ?: ""
            val resetRoomUpdates = mapOf(
                "board" to List(9) { "" },
                "status" to "PLAYING",
                "winner" to "",
                "turn" to nextTurn,
                "rematchX" to false,
                "rematchO" to false
            )
            ref.updateChildren(resetRoomUpdates)
        }
    }

    fun leaveRoom() {
        val user = currentUser.value
        val roomId = _activeRoom.value?.id
        if (roomId != null && user != null) {
            val roomRef = database.reference.child("rooms").child(roomId)
            roomRef.child("status").setValue("OPPONENT_LEFT")
            roomRef.get().addOnSuccessListener { snapshot ->
                val room = snapshot.getValue(GameRoom::class.java) ?: return@addOnSuccessListener
                if (room.playerX?.uid == user.uid) {
                    roomRef.child("playerXOnline").setValue(false)
                } else if (room.playerO?.uid == user.uid) {
                    roomRef.child("playerOOnline").setValue(false)
                }
            }
        }

        cleanupRoom()
        _currentScreen.value = Screen.HOME
    }

    private fun cleanupRoom() {
        activeRoomRef?.let { ref ->
            activeRoomListener?.let { ref.removeEventListener(it) }
            ref.child("status").onDisconnect().cancel()
            ref.child("playerXOnline").onDisconnect().cancel()
            ref.child("playerOOnline").onDisconnect().cancel()
        }
        activeRoomListener = null
        activeRoomRef = null
        _activeRoom.value = null
    }

    private fun cleanupMatchmaking() {
        myQueueRef?.let { ref ->
            myQueueListener?.let { ref.removeEventListener(it) }
            ref.removeValue()
        }
        myQueueListener = null
        myQueueRef = null
        _isSearching.value = false
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun signOut() {
        auth.signOut()
    }
}
