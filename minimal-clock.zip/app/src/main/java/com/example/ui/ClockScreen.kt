package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ClockScreen(
    viewModel: ClockViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    // Map theme colors dynamically for smoothness
    val backgroundColor by animateColorAsState(
        targetValue = when (uiState.selectedTheme) {
            ClockThemeMode.LIGHT -> Color(0xFFFFFFFF)
            ClockThemeMode.DARK -> Color(0xFF121212)
            ClockThemeMode.WARM_IVORY -> Color(0xFFFDFBF7)
        },
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "backgroundColor"
    )

    val surfaceColor by animateColorAsState(
        targetValue = when (uiState.selectedTheme) {
            ClockThemeMode.LIGHT -> Color(0xFFFAFAFA)
            ClockThemeMode.DARK -> Color(0xFF1E1E1E)
            ClockThemeMode.WARM_IVORY -> Color(0xFFFAF6EE)
        },
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "surfaceColor"
    )

    val onSurfaceColor by animateColorAsState(
        targetValue = when (uiState.selectedTheme) {
            ClockThemeMode.LIGHT -> Color(0xFF000000)
            ClockThemeMode.DARK -> Color(0xFFFAFAFA)
            ClockThemeMode.WARM_IVORY -> Color(0xFF2C3E50)
        },
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "onSurfaceColor"
    )

    val borderColor by animateColorAsState(
        targetValue = when (uiState.selectedTheme) {
            ClockThemeMode.LIGHT -> Color(0xFF121212)
            ClockThemeMode.DARK -> Color(0xFFCCCCCC)
            ClockThemeMode.WARM_IVORY -> Color(0xFF2C3E50)
        },
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "borderColor"
    )

    val secondaryTextColor by animateColorAsState(
        targetValue = when (uiState.selectedTheme) {
            ClockThemeMode.LIGHT -> Color(0xFF757575)
            ClockThemeMode.DARK -> Color(0xFF9E9E9E)
            ClockThemeMode.WARM_IVORY -> Color(0xFF7F8C8D)
        },
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "secondaryTextColor"
    )

    val secondHandColor = when (uiState.selectedTheme) {
        ClockThemeMode.LIGHT -> Color(0xFFD32F2F)
        ClockThemeMode.DARK -> Color(0xFFFF5252)
        ClockThemeMode.WARM_IVORY -> Color(0xFFC0392B)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = backgroundColor
    ) { paddingValues ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentAlignment = Alignment.Center
        ) {
            val isPortrait = maxWidth < maxHeight

            if (isPortrait) {
                // Vertical layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Spacer(modifier = Modifier.height(16.dp))

                    // Clock dial section
                    Box(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        AnalogClockFrame(
                            uiState = uiState,
                            borderColor = borderColor,
                            onSurfaceColor = onSurfaceColor,
                            secondaryTextColor = secondaryTextColor,
                            secondHandColor = secondHandColor,
                            surfaceColor = surfaceColor,
                            modifier = Modifier
                                .testTag("analog_clock")
                                .aspectRatio(1f)
                                .fillMaxWidth(0.9f)
                                .widthIn(max = 380.dp)
                        )
                    }

                    // Digital and Date details
                    Column(
                        modifier = Modifier
                            .weight(0.8f)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        DigitalClockDisplay(
                            timeString = uiState.digitalTime,
                            textColor = onSurfaceColor,
                            modifier = Modifier.testTag("digital_clock")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Extra Date visual representation below Digital clock for modern clarity
                        Text(
                            text = "Today • " + uiState.dateString,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Medium,
                                fontSize = 16.sp,
                                letterSpacing = 1.5.sp,
                                color = secondaryTextColor
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Unified minimalist controls at the bottom
                        ControlsWidget(
                            uiState = uiState,
                            viewModel = viewModel,
                            onSurfaceColor = onSurfaceColor,
                            surfaceColor = surfaceColor,
                            secondaryTextColor = secondaryTextColor
                        )
                    }
                }
            } else {
                // Horizontal Landscape layout
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1.1f),
                        contentAlignment = Alignment.Center
                    ) {
                        AnalogClockFrame(
                            uiState = uiState,
                            borderColor = borderColor,
                            onSurfaceColor = onSurfaceColor,
                            secondaryTextColor = secondaryTextColor,
                            secondHandColor = secondHandColor,
                            surfaceColor = surfaceColor,
                            modifier = Modifier
                                .testTag("analog_clock")
                                .aspectRatio(1f)
                                .fillMaxHeight(0.95f)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(0.9f)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        DigitalClockDisplay(
                            timeString = uiState.digitalTime,
                            textColor = onSurfaceColor,
                            modifier = Modifier.testTag("digital_clock")
                        )

                        Text(
                            text = "Today • " + uiState.dateString,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Medium,
                                fontSize = 16.sp,
                                letterSpacing = 1.5.sp,
                                color = secondaryTextColor
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        ControlsWidget(
                            uiState = uiState,
                            viewModel = viewModel,
                            onSurfaceColor = onSurfaceColor,
                            surfaceColor = surfaceColor,
                            secondaryTextColor = secondaryTextColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnalogClockFrame(
    uiState: ClockUiState,
    borderColor: Color,
    onSurfaceColor: Color,
    secondaryTextColor: Color,
    secondHandColor: Color,
    surfaceColor: Color,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    // Smooth transition animations for angles in discrete ticking mode to prevent sudden jump flickers
    val hourAngleAnimated by animateFloatAsState(targetValue = uiState.hourHandAngle, label = "hourAngle")
    val minuteAngleAnimated by animateFloatAsState(targetValue = uiState.minuteHandAngle, label = "minuteAngle")
    val secondAngleAnimated by animateFloatAsState(targetValue = uiState.secondHandAngle, label = "secondAngle")

    Box(
        modifier = modifier
            .shadow(
                elevation = 4.dp,
                shape = CircleShape,
                ambientColor = onSurfaceColor.copy(alpha = 0.05f),
                spotColor = onSurfaceColor.copy(alpha = 0.1f)
            )
            .background(surfaceColor, shape = CircleShape)
            .border(width = 5.dp, color = borderColor, shape = CircleShape)
            .padding(12.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val centerX = width / 2f
            val centerY = height / 2f
            val radius = width / 2f

            // 1. Draw Minute Dots
            drawClockTickMarks(
                centerX = centerX,
                centerY = centerY,
                radius = radius,
                primaryColor = onSurfaceColor,
                secondaryColor = secondaryTextColor
            )

            // 2. Draw Date Text Box Inside Dial
            // Positioned at 30% from top (centered below 12 y-axis)
            val textLayoutResult = textMeasurer.measure(
                text = uiState.dateString,
                style = TextStyle(
                    fontSize = (radius * 0.12f).coerceIn(11f, 15f).sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif,
                    color = onSurfaceColor,
                    letterSpacing = 1.sp
                )
            )
            val dateWidth = textLayoutResult.size.width
            val dateHeight = textLayoutResult.size.height
            val dateYOffset = centerY - radius * 0.40f

            // Clean background aperture card for date representation
            drawRoundRect(
                color = onSurfaceColor.copy(alpha = 0.07f),
                topLeft = Offset(centerX - dateWidth / 2f - 12f, dateYOffset - dateHeight / 2f - 4f),
                size = androidx.compose.ui.geometry.Size(dateWidth + 24f, dateHeight + 8f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
            )

            drawText(
                textLayoutResult = textLayoutResult,
                topLeft = Offset(centerX - dateWidth / 2f, dateYOffset - dateHeight / 2f)
            )

            // 3. Draw Numbers 1 to 12
            drawClockNumbers(
                textMeasurer = textMeasurer,
                centerX = centerX,
                centerY = centerY,
                radius = radius,
                color = onSurfaceColor
            )

            // 4. Draw Hour Hand
            drawHand(
                centerX = centerX,
                centerY = centerY,
                length = radius * 0.52f,
                width = radius * 0.045f,
                angleDegrees = hourAngleAnimated,
                color = onSurfaceColor
            )

            // 5. Draw Minute Hand
            drawHand(
                centerX = centerX,
                centerY = centerY,
                length = radius * 0.78f,
                width = radius * 0.025f,
                angleDegrees = minuteAngleAnimated,
                color = onSurfaceColor
            )

            // 6. Draw Red Second Hand with a beautiful classic sweep style counterweight
            drawSecondHand(
                centerX = centerX,
                centerY = centerY,
                length = radius * 0.85f,
                angleDegrees = secondAngleAnimated,
                color = secondHandColor
            )

            // 7. Center Pin Cap
            drawCircle(
                color = onSurfaceColor,
                radius = radius * 0.035f,
                center = Offset(centerX, centerY)
            )
            drawCircle(
                color = secondHandColor,
                radius = radius * 0.015f,
                center = Offset(centerX, centerY)
            )
        }
    }
}

@Composable
fun DigitalClockDisplay(
    timeString: String,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Text(
        text = timeString,
        style = TextStyle(
            fontFamily = FontFamily.Monospace, // Monospaced to eliminate letter-jittering when seconds tick
            fontWeight = FontWeight.Bold,
            fontSize = 32.sp,
            letterSpacing = 0.5.sp,
            color = textColor
        ),
        textAlign = TextAlign.Center,
        modifier = modifier
    )
}

@Composable
fun ControlsWidget(
    uiState: ClockUiState,
    viewModel: ClockViewModel,
    onSurfaceColor: Color,
    surfaceColor: Color,
    secondaryTextColor: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 400.dp)
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = onSurfaceColor.copy(alpha = 0.02f),
                spotColor = onSurfaceColor.copy(alpha = 0.05f)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = surfaceColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Sweep Action Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { viewModel.toggleSweepMode() }
                    )
                    .testTag("sweep_mode_toggle_row"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Smooth Sweep Hand",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = onSurfaceColor
                        )
                    )
                    Text(
                        text = if (uiState.isSweepMode) "Continuous motion (Sweeping)" else "Tick interval (Standard)",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 12.sp,
                            color = secondaryTextColor
                        )
                    )
                }

                Switch(
                    checked = uiState.isSweepMode,
                    onCheckedChange = { viewModel.toggleSweepMode() },
                    modifier = Modifier.testTag("sweep_mode_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = onSurfaceColor,
                        uncheckedThumbColor = onSurfaceColor.copy(alpha = 0.6f),
                        uncheckedTrackColor = onSurfaceColor.copy(alpha = 0.08f)
                    )
                )
            }

            // Theme Buttons
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Aesthetic Theme Mode",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = secondaryTextColor
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ClockThemeOption(
                        label = "Light",
                        isSelected = uiState.selectedTheme == ClockThemeMode.LIGHT,
                        backgroundColor = Color.White,
                        borderColor = Color.Black,
                        textColor = Color.Black,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("theme_btn_light")
                            .clickable { viewModel.changeTheme(ClockThemeMode.LIGHT) }
                    )

                    ClockThemeOption(
                        label = "Dark",
                        isSelected = uiState.selectedTheme == ClockThemeMode.DARK,
                        backgroundColor = Color(0xFF1E1E1E),
                        borderColor = Color.White,
                        textColor = Color.White,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("theme_btn_dark")
                            .clickable { viewModel.changeTheme(ClockThemeMode.DARK) }
                    )

                    ClockThemeOption(
                        label = "Ivory",
                        isSelected = uiState.selectedTheme == ClockThemeMode.WARM_IVORY,
                        backgroundColor = Color(0xFFFAF6EE),
                        borderColor = Color(0xFF2C3E50),
                        textColor = Color(0xFF2C3E50),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("theme_btn_ivory")
                            .clickable { viewModel.changeTheme(ClockThemeMode.WARM_IVORY) }
                    )
                }
            }
        }
    }
}

@Composable
fun ClockThemeOption(
    label: String,
    isSelected: Boolean,
    backgroundColor: Color,
    borderColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val selectionWidth = if (isSelected) 2.5.dp else 1.dp
    val computedBorderColor = if (isSelected) borderColor else borderColor.copy(alpha = 0.2f)

    Box(
        modifier = modifier
            .height(40.dp)
            .background(backgroundColor, shape = RoundedCornerShape(8.dp))
            .border(width = selectionWidth, color = computedBorderColor, shape = RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 12.sp,
                color = textColor
            )
        )
    }
}

private fun DrawScope.drawClockTickMarks(
    centerX: Float,
    centerY: Float,
    radius: Float,
    primaryColor: Color,
    secondaryColor: Color
) {
    val numTicks = 60
    for (i in 0 until numTicks) {
        val angleRad = (i * 6f) * (Math.PI / 180f)
        val isMajor = i % 5 == 0

        val startRadius = if (isMajor) radius * 0.88f else radius * 0.93f
        val endRadius = radius * 0.97f
        val strokeWidth = if (isMajor) radius * 0.015f else radius * 0.007f
        val color = if (isMajor) primaryColor else secondaryColor.copy(alpha = 0.6f)

        val startX = centerX + startRadius * sin(angleRad).toFloat()
        val startY = centerY - startRadius * cos(angleRad).toFloat()
        val endX = centerX + endRadius * sin(angleRad).toFloat()
        val endY = centerY - endRadius * cos(angleRad).toFloat()

        drawLine(
            color = color,
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = strokeWidth.coerceAtLeast(1.5f),
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawClockNumbers(
    textMeasurer: androidx.compose.ui.text.TextMeasurer,
    centerX: Float,
    centerY: Float,
    radius: Float,
    color: Color
) {
    val numberRadius = radius * 0.74f

    for (h in 1..12) {
        val angleRad = (h * 30f) * (Math.PI / 180f)

        val textLayoutResult = textMeasurer.measure(
            text = "$h",
            style = TextStyle(
                fontSize = (radius * 0.14f).coerceIn(12f, 22f).sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif,
                color = color
            )
        )

        val textWidth = textLayoutResult.size.width
        val textHeight = textLayoutResult.size.height

        val numX = centerX + numberRadius * sin(angleRad).toFloat()
        val numY = centerY - numberRadius * cos(angleRad).toFloat()

        drawText(
            textLayoutResult = textLayoutResult,
            topLeft = Offset(numX - textWidth / 2f, numY - textHeight / 2f)
        )
    }
}

private fun DrawScope.drawHand(
    centerX: Float,
    centerY: Float,
    length: Float,
    width: Float,
    angleDegrees: Float,
    color: Color
) {
    val angleRad = angleDegrees * (Math.PI / 180f)

    // The hands extend slightly backward beyond the center pivot for a incredibly beautiful balanced look
    val tailLength = length * 0.12f
    val startX = centerX - tailLength * sin(angleRad).toFloat()
    val startY = centerY + tailLength * cos(angleRad).toFloat()

    val endX = centerX + length * sin(angleRad).toFloat()
    val endY = centerY - length * cos(angleRad).toFloat()

    drawLine(
        color = color,
        start = Offset(startX, startY),
        end = Offset(endX, endY),
        strokeWidth = width,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.drawSecondHand(
    centerX: Float,
    centerY: Float,
    length: Float,
    angleDegrees: Float,
    color: Color
) {
    val angleRad = angleDegrees * (Math.PI / 180f)

    // Classic aesthetic red second hand with a longer circular-tipped tail counterweight
    val tailLength = length * 0.22f
    val startX = centerX - tailLength * sin(angleRad).toFloat()
    val startY = centerY + tailLength * cos(angleRad).toFloat()

    val endX = centerX + length * sin(angleRad).toFloat()
    val endY = centerY - length * cos(angleRad).toFloat()

    // Draw main thin second hand line
    drawLine(
        color = color,
        start = Offset(startX, startY),
        end = Offset(endX, endY),
        strokeWidth = (length * 0.012f).coerceAtLeast(1.8f),
        cap = StrokeCap.Round
    )

    // Draw Swiss Railway classic tip circle dot on second hand at 80% length
    val tipDotRadius = (length * 0.05f).coerceAtLeast(3f)
    val dotCenterX = centerX + (length * 0.78f) * sin(angleRad).toFloat()
    val dotCenterY = centerY - (length * 0.78f) * cos(angleRad).toFloat()

    drawCircle(
        color = color,
        radius = tipDotRadius,
        center = Offset(dotCenterX, dotCenterY)
    )

    // Draw visual circle counterweight at tail end for stunning luxury clock look
    val tailDotRadius = (length * 0.035f).coerceAtLeast(2f)
    val tailDotCenterX = centerX - (tailLength * 0.7f) * sin(angleRad).toFloat()
    val tailDotCenterY = centerY + (tailLength * 0.7f) * cos(angleRad).toFloat()

    drawCircle(
        color = color,
        radius = tailDotRadius,
        center = Offset(tailDotCenterX, tailDotCenterY)
    )
}
