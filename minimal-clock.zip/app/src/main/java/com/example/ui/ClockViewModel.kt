package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

enum class ClockThemeMode {
    LIGHT, // White background, black border, black hands, red second hand
    DARK,  // Black background, white border, white hands, red second hand
    WARM_IVORY, // Soft warm cream color background, dark brown charcoal indicators, modern luxury feel
}

data class ClockUiState(
    val hour: Int = 12,
    val minute: Int = 0,
    val second: Int = 0,
    val millisecond: Int = 0,
    val digitalTime: String = "12:00:00 AM",
    val dateString: String = "20 Jun",
    val hourHandAngle: Float = 0f,
    val minuteHandAngle: Float = 0f,
    val secondHandAngle: Float = 0f,
    val isSweepMode: Boolean = true, // Continuous smooth sweeping
    val chimeOnHour: Boolean = false, // Sound alert helper representation
    val selectedTheme: ClockThemeMode = ClockThemeMode.LIGHT
)

class ClockViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ClockUiState())
    val uiState: StateFlow<ClockUiState> = _uiState.asStateFlow()

    private val monthNames = arrayOf(
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    )

    private val timeFormatter = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())

    init {
        startClock()
    }

    private fun startClock() {
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                updateTime()
                // Update around 60 times a second (16ms) in sweep mode for ultra-smooth movement,
                // or sleep up to 100ms when standard mode to minimize CPU resources.
                val delayTime = if (_uiState.value.isSweepMode) 16L else 100L
                delay(delayTime)
            }
        }
    }

    private fun updateTime() {
        val calendar = Calendar.getInstance()
        val now = calendar.time

        val hour24 = calendar.get(Calendar.HOUR_OF_DAY)
        val hour12 = calendar.get(Calendar.HOUR)
        val minute = calendar.get(Calendar.MINUTE)
        val second = calendar.get(Calendar.SECOND)
        val millisecond = calendar.get(Calendar.MILLISECOND)

        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val monthIdx = calendar.get(Calendar.MONTH)
        val month = if (monthIdx in monthNames.indices) monthNames[monthIdx] else ""
        val dateStr = "$day $month"

        val digitalStr = timeFormatter.format(now).uppercase()

        // Calculate hand rotations (in degrees)
        val secFraction = if (_uiState.value.isSweepMode) millisecond / 1000f else 0f
        val secAngle = (second + secFraction) * 6f // 360 / 60 = 6 deg per second

        val minFraction = (second + secFraction) / 60f
        val minAngle = (minute + minFraction) * 6f // 360 / 60 = 6 deg per minute

        val hourFraction = (minute + minFraction) / 60f
        val hourAngle = ((hour12 % 12) + hourFraction) * 30f // 360 / 12 = 30 deg per hour

        _uiState.update { currentState ->
            currentState.copy(
                hour = hour12,
                minute = minute,
                second = second,
                millisecond = millisecond,
                digitalTime = digitalStr,
                dateString = dateStr,
                hourHandAngle = hourAngle,
                minuteHandAngle = minAngle,
                secondHandAngle = secAngle
            )
        }
    }

    fun toggleSweepMode() {
        _uiState.update { it.copy(isSweepMode = !it.isSweepMode) }
    }

    fun changeTheme(theme: ClockThemeMode) {
        _uiState.update { it.copy(selectedTheme = theme) }
    }

    fun toggleChime() {
        _uiState.update { it.copy(chimeOnHour = !it.chimeOnHour) }
    }
}
